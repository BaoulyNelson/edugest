"""
workers/taches_bulletins.py
============================
Tâches Celery pour la génération de bulletins en masse.
Chaque tâche est idempotente et gère son propre contexte tenant.

RÈGLE CRITIQUE : toujours passer ecole_id explicitement.
Ne jamais utiliser obtenir_tenant_courant() dans un worker Celery.
Le thread local n'est pas propagé entre processus.
"""

import logging
from celery import shared_task
from django.utils import timezone

logger = logging.getLogger("workers.bulletins")


def _configurer_tenant(ecole_id: str):
    """Configure le tenant dans le thread local du worker Celery."""
    from apps.etablissements.models import Etablissement
    from apps.noyau.middleware import definir_tenant_courant

    ecole = Etablissement.objects.get(id=ecole_id, est_actif=True)
    definir_tenant_courant(ecole)
    return ecole


def _nettoyer_tenant():
    from apps.noyau.middleware import definir_tenant_courant
    definir_tenant_courant(None)


@shared_task(
    bind=True,
    max_retries=3,
    default_retry_delay=120,
    name="bulletins.generer_tous_periode",
    acks_late=True,  # Acquitter seulement après succès
)
def generer_bulletins_periode(
    self,
    ecole_id: str,
    periode_id: int,
    classe_id: int = None,
    genere_par_id: str = None,
) -> dict:
    """
    Génère tous les bulletins d'une période en tâche de fond.
    Supporte le filtrage par classe (génération partielle).
    Retourne un rapport complet des succès et erreurs.
    """
    debut = timezone.now()
    rapport = {
        "ecole_id": ecole_id,
        "periode_id": periode_id,
        "classe_id": classe_id,
        "generes": 0,
        "erreurs": 0,
        "details_erreurs": [],
        "duree_secondes": None,
    }

    try:
        ecole = _configurer_tenant(ecole_id)

        from apps.academique.models import PeriodeAcademique
        from apps.academique.models import Classe
        from apps.bulletins.services import ServiceGenBulletin
        from apps.comptes.models import Utilisateur

        periode = PeriodeAcademique.objects.get(id=periode_id, ecole=ecole)

        utilisateur = None
        if genere_par_id:
            utilisateur = Utilisateur.objects.filter(id=genere_par_id).first()

        classe = None
        if classe_id:
            classe = Classe.objects.get(id=classe_id, ecole=ecole)

        service = ServiceGenBulletin(utilisateur=utilisateur, ecole=ecole)
        rapport_gen = service.generer_tous(periode=periode, classe=classe)

        rapport.update(rapport_gen)
        rapport["duree_secondes"] = (timezone.now() - debut).total_seconds()

        logger.info(
            f"Génération bulletins terminée : ecole={ecole.slug} "
            f"periode={periode.libelle} | {rapport['generes']} générés, "
            f"{rapport['erreurs']} erreurs | {rapport['duree_secondes']:.1f}s"
        )

    except Exception as exc:
        logger.error(f"Erreur génération bulletins : {exc}", exc_info=True)
        raise self.retry(exc=exc)
    finally:
        _nettoyer_tenant()

    return rapport


@shared_task(
    bind=True,
    max_retries=2,
    name="bulletins.calculer_moyennes_periode",
)
def calculer_moyennes_periode(
    self,
    ecole_id: str,
    periode_id: int,
    classe_id: int = None,
) -> dict:
    """
    Calcule les moyennes de tous les élèves d'une période en masse.
    Lance également le calcul des classements après les moyennes.
    """
    try:
        ecole = _configurer_tenant(ecole_id)

        from apps.academique.models import PeriodeAcademique, Classe
        from apps.eleves.models import Inscription, StatutInscription
        from apps.notes.services import ServiceCalculMoyenne
        from decimal import Decimal

        periode = PeriodeAcademique.objects.get(id=periode_id, ecole=ecole)

        qs = Inscription.objects.filter(
            annee_scolaire=periode.annee_scolaire,
            statut=StatutInscription.VALIDEE,
        )
        if classe_id:
            qs = qs.filter(classe_id=classe_id)

        service = ServiceCalculMoyenne()
        calcules = 0
        erreurs = []

        # Déterminer la base de notation depuis le système de l'école
        from apps.parametrage.models import SystemeNotation
        systeme = SystemeNotation.objects.filter(ecole=ecole, est_courant=True).first()
        base = systeme.base_notation if systeme else Decimal("10.00")

        for inscription in qs.select_related("classe"):
            try:
                service.calculer_moyennes_periode(inscription, periode, base=base)
                calcules += 1
            except Exception as exc:
                erreurs.append({
                    "eleve": str(inscription.eleve_id),
                    "erreur": str(exc),
                })

        # Calcul des classements par classe
        classes_traitees = set()
        for inscription in qs:
            if inscription.classe_id not in classes_traitees:
                try:
                    service.calculer_classements_classe(inscription.classe, periode)
                    classes_traitees.add(inscription.classe_id)
                except Exception as exc:
                    logger.warning(f"Classement impossible classe={inscription.classe_id} : {exc}")

        return {
            "calcules": calcules,
            "erreurs": len(erreurs),
            "details_erreurs": erreurs,
        }

    except Exception as exc:
        raise self.retry(exc=exc)
    finally:
        _nettoyer_tenant()


"""
workers/taches_badges.py
=========================
Génération de badges en masse.
"""


@shared_task(
    bind=True,
    max_retries=2,
    name="badges.generer_classe",
)
def generer_badges_classe(
    self,
    ecole_id: str,
    classe_id: int,
    type_badge: str = "eleve",
) -> dict:
    """
    Génère tous les badges d'une classe en tâche de fond.
    Retourne un ZIP contenant tous les PDFs.
    """
    try:
        ecole = _configurer_tenant(ecole_id)

        from apps.academique.models import Classe
        from apps.badges.services import ServiceBadge

        classe = Classe.objects.get(id=classe_id, ecole=ecole)
        service = ServiceBadge(ecole=ecole)

        if type_badge == "eleve":
            resultat = service.generer_badges_classe(classe)
        else:
            raise ValueError(f"Type de badge inconnu : {type_badge}")

        return {
            "classe": classe.code,
            "generes": resultat["generes"],
            "fichier_zip": resultat.get("fichier_zip"),
        }

    except Exception as exc:
        raise self.retry(exc=exc)
    finally:
        _nettoyer_tenant()


"""
workers/taches_notifications.py
================================
Notifications par email aux parents.
"""


@shared_task(
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    name="notifications.bulletin_disponible",
)
def notifier_bulletin_disponible(
    self,
    ecole_id: str,
    bulletin_id: str,
) -> bool:
    """Envoie un email au parent pour signaler qu'un bulletin est disponible."""
    try:
        ecole = _configurer_tenant(ecole_id)

        from apps.bulletins.models import Bulletin
        from django.core.mail import send_mail
        from django.conf import settings

        bulletin = Bulletin.objects.get(id=bulletin_id, ecole=ecole)
        eleve = bulletin.inscription.eleve

        if not eleve.email_parent:
            return False

        url_bulletin = (
            f"https://{ecole.slug}.scolaire.ht"
            f"/bulletins/verifier/{bulletin.code_verification}/"
        )

        send_mail(
            subject=f"[{ecole.nom_affichage}] Bulletin disponible — {bulletin.periode.libelle}",
            message=(
                f"Cher(e) parent/tuteur,\n\n"
                f"Le bulletin de {eleve.nom_complet} pour "
                f"{bulletin.periode.libelle} est disponible.\n\n"
                f"Consultez-le ici : {url_bulletin}\n\n"
                f"Cordialement,\n{ecole.directeur_nom or ecole.nom}"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[eleve.email_parent],
            fail_silently=False,
        )

        logger.info(
            f"Email envoyé : eleve={eleve.matricule} "
            f"email={eleve.email_parent} bulletin={bulletin_id}"
        )
        return True

    except Exception as exc:
        raise self.retry(exc=exc)
    finally:
        _nettoyer_tenant()