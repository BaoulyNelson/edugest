"""
tests/test_notes/test_moteur.py
================================
Tests exhaustifs du moteur de calcul des moyennes.
Cas réels, cas limites, régressions documentées.
"""

import pytest
from decimal import Decimal
from apps.notes.moteur import MoteurCalculMoyenne, DonneeNote, moteur_calcul


class TestCalculDepuisTotaux:
    """Tests du calcul simplifié depuis totaux bruts."""

    def test_exemple_reel_678_sur_1200(self):
        """
        CAS DOCUMENTÉ dans le cahier des charges.
        678 points / 1200 max → 5.6500 / 10
        """
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("678"), Decimal("1200"), Decimal("10")
        )
        assert resultat == Decimal("5.6500"), (
            f"Régression : 678/1200×10 doit valoir 5.6500, obtenu {resultat}"
        )

    def test_precision_4_decimales(self):
        """La précision est toujours de 4 décimales."""
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("7"), Decimal("10"), Decimal("10")
        )
        assert resultat == Decimal("7.0000")

    def test_note_maximale(self):
        """10/10 = 10.0000."""
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("10"), Decimal("10"), Decimal("10")
        )
        assert resultat == Decimal("10.0000")

    def test_note_nulle(self):
        """0/10 = 0.0000."""
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("0"), Decimal("10"), Decimal("10")
        )
        assert resultat == Decimal("0.0000")

    def test_base_20(self):
        """Calcul sur base 20 : 15/20 × 20 = 15.0000."""
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("15"), Decimal("20"), Decimal("20")
        )
        assert resultat == Decimal("15.0000")

    def test_base_100(self):
        """Calcul sur base 100 : 75/100 × 100 = 75.0000."""
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("75"), Decimal("100"), Decimal("100")
        )
        assert resultat == Decimal("75.0000")

    def test_pas_de_float(self):
        """Vérifier qu'aucun float n'est utilisé dans les calculs."""
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("1"), Decimal("3"), Decimal("10")
        )
        assert isinstance(resultat, Decimal)
        # 1/3 × 10 = 3.3333... doit être arrondi à 3.3333
        assert resultat == Decimal("3.3333")

    def test_arrondi_half_up(self):
        """ROUND_HALF_UP : 3.33335 → 3.3334 (pas 3.3333)."""
        # 2/6 × 10 = 3.3333... → 3.3333
        resultat = moteur_calcul.calculer_depuis_totaux(
            Decimal("2"), Decimal("6"), Decimal("10")
        )
        assert resultat == Decimal("3.3333")

    def test_erreur_points_max_zero(self):
        """Lève ErreurCalcul si note_max = 0."""
        from apps.noyau.exceptions import ErreurCalcul
        with pytest.raises(ErreurCalcul, match="points_max"):
            moteur_calcul.calculer_depuis_totaux(
                Decimal("5"), Decimal("0"), Decimal("10")
            )

    def test_erreur_points_negatifs(self):
        """Lève ErreurCalcul si points_obtenus < 0."""
        from apps.noyau.exceptions import ErreurCalcul
        with pytest.raises(ErreurCalcul, match="négatif"):
            moteur_calcul.calculer_depuis_totaux(
                Decimal("-1"), Decimal("10"), Decimal("10")
            )

    def test_erreur_points_sup_max(self):
        """Lève ErreurCalcul si points_obtenus > points_max."""
        from apps.noyau.exceptions import ErreurCalcul
        with pytest.raises(ErreurCalcul):
            moteur_calcul.calculer_depuis_totaux(
                Decimal("11"), Decimal("10"), Decimal("10")
            )


class TestCalculMoyenneMatiere:
    """Tests du calcul pondéré depuis une liste de notes."""

    def _note(self, valeur, note_max="10", coeff="1", absence_nj=False) -> DonneeNote:
        return DonneeNote(
            note_id=f"n_{valeur}",
            valeur=Decimal(valeur) if valeur is not None else None,
            note_max=Decimal(note_max),
            coefficient=Decimal(coeff),
            est_absence_non_justifiee=absence_nj,
        )

    def test_une_seule_note(self):
        """1 note = sa valeur normalisée."""
        notes = [self._note("7.5")]
        res = moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("7.5000")

    def test_deux_notes_egal_coeff(self):
        """(8 + 6) / 2 = 7.0000."""
        notes = [self._note("8"), self._note("6")]
        res = moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("7.0000")

    def test_coefficients_differents(self):
        """Note composition (coeff 3) pèse plus qu'une interrogation (coeff 1)."""
        notes = [
            self._note("4", coeff="1"),   # Interro : 4/10, coeff 1
            self._note("8", coeff="3"),   # Compo  : 8/10, coeff 3
        ]
        # (4×1 + 8×3) / (1+3) = (4+24) / 4 = 7.0
        res = moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("7.0000")

    def test_absence_non_justifiee_compte_zero(self):
        """Absence non justifiée = 0 dans le calcul."""
        notes = [
            self._note("8"),
            self._note(None, absence_nj=True),  # Absent : compte 0
        ]
        # (8 + 0) / 2 = 4.0
        res = moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("4.0000")

    def test_absence_justifiee_exclue(self):
        """Absence justifiée (valeur=None) est exclue du calcul."""
        notes = [
            self._note("8"),
            self._note(None),  # Absent justifié : exclu
        ]
        # Seulement 8 compte → 8.0
        res = moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("8.0000")
        assert res.nb_notes_exclues == 1

    def test_baremes_differents_normalises(self):
        """Notes sur barèmes différents doivent être normalisées avant calcul."""
        notes = [
            self._note("8", note_max="10"),   # 8/10 = 80%
            self._note("15", note_max="20"),  # 15/20 = 75%
        ]
        # Moyenne : (80 + 75) / 2 = 77.5% → 7.7500 /10
        res = moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("7.7500")

    def test_liste_vide_erreur(self):
        """Liste vide lève ErreurCalcul."""
        from apps.noyau.exceptions import ErreurCalcul
        with pytest.raises(ErreurCalcul, match="vide"):
            moteur_calcul.calculer_moyenne_matiere([], Decimal("10"))

    def test_toutes_absences_justifiees_erreur(self):
        """Toutes les notes exclues → ErreurCalcul."""
        from apps.noyau.exceptions import ErreurCalcul
        notes = [self._note(None), self._note(None)]
        with pytest.raises(ErreurCalcul, match="exclues"):
            moteur_calcul.calculer_moyenne_matiere(notes, Decimal("10"))


class TestCalculMoyenneGenerale:
    """Tests de la moyenne générale pondérée par matière."""

    def _resultat_matiere(self, moyenne, base="10"):
        from apps.notes.moteur import ResultatMoyenneMatiere
        return ResultatMoyenneMatiere(
            points_ponderes=Decimal("100"),
            total_coefficients=Decimal("1"),
            moyenne_sur_base=Decimal(moyenne),
            base=Decimal(base),
            nb_notes=1,
            nb_notes_exclues=0,
        )

    def test_trois_matieres_egales(self):
        """(7 + 8 + 9) / 3 = 8.0000."""
        matieres = [
            (self._resultat_matiere("7"), Decimal("1")),
            (self._resultat_matiere("8"), Decimal("1")),
            (self._resultat_matiere("9"), Decimal("1")),
        ]
        res = moteur_calcul.calculer_moyenne_generale(matieres, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("8.0000")

    def test_matieres_coeff_differents(self):
        """Matière coeff 3 pèse plus que matière coeff 1."""
        matieres = [
            (self._resultat_matiere("4"), Decimal("1")),  # Matière faible, faible coeff
            (self._resultat_matiere("8"), Decimal("3")),  # Matière forte, fort coeff
        ]
        # (4×1 + 8×3) / (1+3) = 28/4 = 7.0
        res = moteur_calcul.calculer_moyenne_generale(matieres, Decimal("10"))
        assert res.moyenne_sur_base == Decimal("7.0000")

    def test_liste_vide_erreur(self):
        from apps.noyau.exceptions import ErreurCalcul
        with pytest.raises(ErreurCalcul, match="aucune matière"):
            moteur_calcul.calculer_moyenne_generale([], Decimal("10"))


"""
tests/test_noyau/test_isolation_tenant.py
==========================================
Tests d'isolation tenant — garantit qu'aucune fuite de données n'est possible.
"""


class TestIsolationTenant:
    """
    Vérifie que les données d'un tenant ne sont jamais accessibles depuis un autre.
    Ces tests sont non négociables — un échec ici est une faille de sécurité critique.
    """

    def test_eleve_ecole_a_invisible_depuis_ecole_b(self, db, ecole, ecole_b):
        """Un élève de l'école A ne doit jamais apparaître dans le contexte de l'école B."""
        from apps.noyau.middleware import definir_tenant_courant
        from apps.eleves.models import Eleve

        # Créer un élève dans l'école A
        definir_tenant_courant(ecole)
        Eleve.objects.create(
            ecole=ecole,
            matricule="EL-A-001",
            nom="DUPONT",
            prenom="Jean",
            date_naissance="2012-01-01",
            sexe="M",
        )

        # Switcher vers l'école B
        definir_tenant_courant(ecole_b)

        # L'élève de A ne doit PAS apparaître dans le contexte de B
        assert Eleve.objects.filter(nom="DUPONT").count() == 0, (
            "FUITE DE DONNÉES : un élève de l'école A est visible depuis l'école B."
        )

        definir_tenant_courant(None)

    def test_tous_objets_bypass_tenant(self, db, ecole, ecole_b):
        """tous_objets retourne les données de tous les tenants (usage admin)."""
        from apps.noyau.middleware import definir_tenant_courant
        from apps.eleves.models import Eleve

        Eleve.objects.create(
            ecole=ecole,
            matricule="EL-GLOBAL-001",
            nom="GLOBAL",
            prenom="Test",
            date_naissance="2012-01-01",
            sexe="M",
        )

        # Sans tenant actif, tous_objets voit tout
        definir_tenant_courant(None)
        assert Eleve.tous_objets.filter(nom="GLOBAL").count() == 1

    def test_manager_sans_tenant_retourne_tout(self, db, ecole, ecole_b):
        """
        Sans tenant actif (worker Celery, shell), le TenantManager
        retourne tous les objets — à charge du code appelant de filtrer.
        """
        from apps.noyau.middleware import definir_tenant_courant
        from apps.eleves.models import Eleve

        for slug_ecole, mat in [(ecole, "MAT-A"), (ecole_b, "MAT-B")]:
            Eleve.objects.create(
                ecole=slug_ecole,
                matricule=mat,
                nom="TEST",
                prenom="Multi",
                date_naissance="2012-01-01",
                sexe="M",
            )

        definir_tenant_courant(None)
        # Sans tenant : retourne les deux
        nb_total = Eleve.tous_objets.filter(nom="TEST").count()
        assert nb_total == 2

    def test_paiement_cross_tenant_impossible(self, db, ecole, ecole_b, tenant_actif):
        """Un accès direct par ID à un paiement d'une autre école doit échouer."""
        from apps.noyau.middleware import definir_tenant_courant
        # Ce test valide que le TenantManager filtre correctement
        # En pratique, la vue TenantObjectMixin lève PermissionDenied
        definir_tenant_courant(ecole_b)
        # Rien à trouver dans ecole_b pour les ressources créées dans ecole
        from apps.finances.models import Paiement
        assert Paiement.objects.count() == 0


"""
tests/test_academique/test_workflows.py
========================================
Tests des transitions d'état des années scolaires et périodes.
"""


class TestWorkflowAnneeScolaire:
    """Vérifie la machine à états de l'AnneeScolaire."""

    def test_activation_annee_brouillon(self, db, tenant_actif, annee_active, directeur):
        """Une année en brouillon peut être activée (déjà fait par la fixture)."""
        from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
        annee = annee_active["annee"]
        assert annee.statut == StatutAnneeScolaire.ACTIVE

    def test_deux_annees_actives_impossible(self, db, tenant_actif, annee_active, directeur):
        """Impossible d'activer une deuxième année si une est déjà active."""
        from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
        from apps.academique.services import ServiceAnneeScolaire
        from apps.noyau.exceptions import RegleMetierError

        annee2 = AnneeScolaire.objects.create(
            ecole=tenant_actif,
            libelle="2025-2026",
            date_debut="2025-09-01",
            date_fin="2026-06-30",
            statut=StatutAnneeScolaire.BROUILLON,
        )
        # Ajouter une classe pour passer la garde
        from apps.academique.models import Classe
        from apps.parametrage.models import Niveau
        niveau = Niveau.objects.filter(ecole=tenant_actif).first()
        if niveau:
            Classe.objects.create(
                ecole=tenant_actif,
                annee_scolaire=annee2,
                niveau=niveau,
                code="6AF-TEST",
                libelle="Test",
            )

        service = ServiceAnneeScolaire(directeur)
        with pytest.raises(RegleMetierError, match="déjà active"):
            service.activer(annee2)

    def test_transition_archivee_vers_active_impossible(self, db, tenant_actif):
        """Une année archivée ne peut plus être réactivée."""
        from apps.academique.models import AnneeScolaire, StatutAnneeScolaire

        annee = AnneeScolaire.objects.create(
            ecole=tenant_actif,
            libelle="2010-2011",
            date_debut="2010-09-01",
            date_fin="2011-06-30",
            statut=StatutAnneeScolaire.ARCHIVEE,
        )
        assert not annee.peut_transitionner_vers(StatutAnneeScolaire.ACTIVE)
        assert not annee.peut_transitionner_vers(StatutAnneeScolaire.BROUILLON)
        assert annee.peut_transitionner_vers(StatutAnneeScolaire.ARCHIVEE) is False


class TestGardesMetierNotes:
    """Vérifie que les gardes bloquent correctement la saisie hors période."""

    def test_saisie_periode_cloturee_bloquee(
        self, db, tenant_actif, annee_active, inscription_eleve,
        parametrage_complet, directeur
    ):
        """Impossible de saisir une note dans une période close."""
        from apps.notes.services import ServiceSaisieNote
        from apps.academique.models import StatutPeriode
        from apps.noyau.exceptions import RegleMetierError

        periode = annee_active["periodes"][0]
        periode.statut = StatutPeriode.CLOTUREE
        periode.save()

        service = ServiceSaisieNote(directeur)
        with pytest.raises(RegleMetierError, match="cloturee"):
            service.saisir(
                inscription=inscription_eleve["inscription"],
                matiere=parametrage_complet["matieres"]["maths"],
                periode=periode,
                type_evaluation=parametrage_complet["types_eval"]["interro"],
                valeur=Decimal("7"),
            )

    def test_saisie_note_superieure_max_bloquee(
        self, db, tenant_actif, annee_active, inscription_eleve,
        parametrage_complet, directeur
    ):
        """Une note supérieure au maximum est rejetée."""
        from apps.notes.services import ServiceSaisieNote
        from django.core.exceptions import ValidationError

        service = ServiceSaisieNote(directeur)
        with pytest.raises(ValidationError, match="maximale"):
            service.saisir(
                inscription=inscription_eleve["inscription"],
                matiere=parametrage_complet["matieres"]["maths"],
                periode=annee_active["periodes"][0],
                type_evaluation=parametrage_complet["types_eval"]["interro"],
                valeur=Decimal("15"),  # > 10 (note_max)
            )
