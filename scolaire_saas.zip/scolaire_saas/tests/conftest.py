"""
tests/conftest.py
==================
Fixtures pytest partagées pour tous les tests.
Charge les données minimales pour que le système soit fonctionnel.
"""

import pytest
from decimal import Decimal
from django.utils import timezone


# ─── Fixtures Établissement ──────────────────────────────────────────────────

@pytest.fixture
def ecole(db):
    """Établissement de test avec abonnement actif."""
    from apps.etablissements.models import Etablissement, PlanAbonnement, Abonnement

    plan = PlanAbonnement.objects.create(
        code="test_pro",
        libelle="Plan Test",
        prix_mensuel_htg=Decimal("0"),
        prix_annuel_htg=Decimal("0"),
        fonctionnalites={
            "bulletins_pdf": True,
            "badges_impression": True,
            "api_acces": True,
        },
    )
    ecole = Etablissement.objects.create(
        slug="lycee-test",
        nom="Lycée de Test",
        nom_court="LT",
        ville="Port-au-Prince",
        est_actif=True,
        couleur_principale="#1a3c6e",
    )
    Abonnement.objects.create(
        etablissement=ecole,
        plan=plan,
        date_debut=timezone.now().date(),
        est_actif=True,
        en_periode_essai=False,
    )
    return ecole


@pytest.fixture
def ecole_b(db):
    """Second établissement — pour les tests d'isolation tenant."""
    from apps.etablissements.models import Etablissement, PlanAbonnement, Abonnement

    plan = PlanAbonnement.objects.first() or PlanAbonnement.objects.create(
        code="test_b",
        libelle="Plan Test B",
        prix_mensuel_htg=Decimal("0"),
        prix_annuel_htg=Decimal("0"),
    )
    return Etablissement.objects.create(
        slug="college-test-b",
        nom="Collège de Test B",
        ville="Cap-Haïtien",
        est_actif=True,
    )


@pytest.fixture
def tenant_actif(ecole):
    """Active le tenant dans le thread local pour la durée du test."""
    from apps.noyau.middleware import definir_tenant_courant
    definir_tenant_courant(ecole)
    yield ecole
    definir_tenant_courant(None)


# ─── Fixtures Utilisateurs ───────────────────────────────────────────────────

@pytest.fixture
def directeur(db, ecole):
    """Directeur avec tous les droits sur l'école de test."""
    from apps.comptes.models import Utilisateur
    from apps.securite.models import Role, UtilisateurRole, PermissionGranulaire, PERMISSIONS_PAR_ROLE

    user = Utilisateur.objects.create_user(
        email="directeur@test.ht",
        mot_de_passe="TestPass2024!",
        nom="Directeur",
        prenom="Test",
    )

    # Créer un rôle directeur minimal
    role = Role.objects.create(
        ecole=ecole,
        code="directeur",
        libelle="Directeur",
        est_systeme=True,
    )

    # Créer et assigner les permissions
    for code_perm in PERMISSIONS_PAR_ROLE.get("directeur", []):
        parties = code_perm.split(".")
        if len(parties) == 3:
            perm, _ = PermissionGranulaire.objects.get_or_create(
                code=code_perm,
                defaults={
                    "description": code_perm,
                    "module": parties[0],
                    "action": parties[1],
                    "portee": parties[2],
                },
            )
            role.permissions.add(perm)

    UtilisateurRole.objects.create(
        ecole=ecole,
        utilisateur=user,
        role=role,
        est_actif=True,
        attribue_par=user,
    )
    return user


@pytest.fixture
def enseignant_user(db, ecole):
    """Utilisateur avec rôle enseignant."""
    from apps.comptes.models import Utilisateur
    from apps.securite.models import Role, UtilisateurRole

    user = Utilisateur.objects.create_user(
        email="enseignant@test.ht",
        mot_de_passe="TestPass2024!",
        nom="Enseignant",
        prenom="Test",
    )
    role, _ = Role.objects.get_or_create(
        ecole=ecole, code="enseignant",
        defaults={"libelle": "Enseignant", "est_systeme": True},
    )
    UtilisateurRole.objects.create(
        ecole=ecole, utilisateur=user, role=role, est_actif=True, attribue_par=user
    )
    return user


# ─── Fixtures Académiques ────────────────────────────────────────────────────

@pytest.fixture
def parametrage_complet(db, tenant_actif):
    """
    Crée un paramétrage scolaire complet : cycle, niveau, matières, coefficients.
    Inspiré du système haïtien.
    """
    from apps.parametrage.models import (
        CycleEnseignement, Niveau, Matiere, TypeEvaluation,
        CoefficientsMatiere, SystemeNotation, Mention
    )
    from apps.academique.models import AnneeScolaire

    cycle = CycleEnseignement.objects.create(
        ecole=tenant_actif,
        code="FOND",
        libelle="Fondamental",
        ordre_affichage=1,
    )
    niveau = Niveau.objects.create(
        ecole=tenant_actif,
        cycle=cycle,
        code="6AF",
        libelle="6e Année Fondamentale",
        ordre_affichage=6,
    )

    # Matières de base
    maths = Matiere.objects.create(
        ecole=tenant_actif, code="MATHS", libelle="Mathématiques", ordre_affichage=1
    )
    francais = Matiere.objects.create(
        ecole=tenant_actif, code="FR", libelle="Français", ordre_affichage=2
    )
    sciences = Matiere.objects.create(
        ecole=tenant_actif, code="SC", libelle="Sciences Naturelles", ordre_affichage=3
    )

    # Types d'évaluation
    interro = TypeEvaluation.objects.create(
        ecole=tenant_actif,
        code="INT",
        libelle="Interrogation",
        poids=Decimal("1.00"),
        note_max_defaut=Decimal("10.00"),
        ordre_affichage=1,
    )
    devoir = TypeEvaluation.objects.create(
        ecole=tenant_actif,
        code="DEV",
        libelle="Devoir",
        poids=Decimal("2.00"),
        note_max_defaut=Decimal("10.00"),
        ordre_affichage=2,
    )
    compo = TypeEvaluation.objects.create(
        ecole=tenant_actif,
        code="COMP",
        libelle="Composition",
        poids=Decimal("3.00"),
        note_max_defaut=Decimal("10.00"),
        ordre_affichage=3,
    )

    # Système de notation haïtien : sur 10, passage à 5
    systeme = SystemeNotation.objects.create(
        ecole=tenant_actif,
        libelle="Système Haïtien /10",
        base_notation=Decimal("10.00"),
        note_passage=Decimal("5.00"),
        est_courant=True,
    )

    # Mentions
    Mention.objects.bulk_create([
        Mention(ecole=tenant_actif, systeme_notation=systeme, libelle="Excellent",
                libelle_court="EXC", moyenne_min=Decimal("9.00"), moyenne_max=Decimal("10.00"),
                couleur="#22c55e", ordre_affichage=1),
        Mention(ecole=tenant_actif, systeme_notation=systeme, libelle="Très Bien",
                libelle_court="TB", moyenne_min=Decimal("8.00"), moyenne_max=Decimal("8.99"),
                couleur="#84cc16", ordre_affichage=2),
        Mention(ecole=tenant_actif, systeme_notation=systeme, libelle="Bien",
                libelle_court="B", moyenne_min=Decimal("7.00"), moyenne_max=Decimal("7.99"),
                couleur="#facc15", ordre_affichage=3),
        Mention(ecole=tenant_actif, systeme_notation=systeme, libelle="Passable",
                libelle_court="P", moyenne_min=Decimal("5.00"), moyenne_max=Decimal("6.99"),
                couleur="#f97316", ordre_affichage=4),
        Mention(ecole=tenant_actif, systeme_notation=systeme, libelle="Insuffisant",
                libelle_court="INS", moyenne_min=Decimal("0.00"), moyenne_max=Decimal("4.99"),
                couleur="#ef4444", ordre_affichage=5),
    ])

    # Année scolaire
    annee = AnneeScolaire.objects.create(
        ecole=tenant_actif,
        libelle="2024-2025",
        date_debut="2024-09-01",
        date_fin="2025-06-30",
        statut="brouillon",
    )

    # Coefficients par niveau
    for matiere, coeff in [(maths, "3.00"), (francais, "3.00"), (sciences, "2.00")]:
        CoefficientsMatiere.objects.create(
            ecole=tenant_actif,
            matiere=matiere,
            niveau=niveau,
            annee_scolaire=annee,
            coefficient=Decimal(coeff),
            note_max=Decimal("10.00"),
        )

    return {
        "cycle": cycle,
        "niveau": niveau,
        "matieres": {"maths": maths, "francais": francais, "sciences": sciences},
        "types_eval": {"interro": interro, "devoir": devoir, "compo": compo},
        "systeme": systeme,
        "annee": annee,
    }


@pytest.fixture
def annee_active(db, tenant_actif, parametrage_complet):
    """Année scolaire dans l'état ACTIVE avec une classe."""
    from apps.academique.models import AnneeScolaire, Classe, StatutAnneeScolaire
    from apps.academique.models import PeriodeAcademique, StatutPeriode

    annee = parametrage_complet["annee"]
    annee.statut = StatutAnneeScolaire.ACTIVE
    annee.est_courante = True
    annee.save()

    classe = Classe.objects.create(
        ecole=tenant_actif,
        annee_scolaire=annee,
        niveau=parametrage_complet["niveau"],
        code="6AF-A",
        libelle="6e Année Fondamentale - Section A",
        capacite_max=35,
    )

    # Ajouter les matières à la classe
    from apps.academique.models import MatiereClasse
    for matiere in parametrage_complet["matieres"].values():
        MatiereClasse.objects.create(
            ecole=tenant_actif,
            classe=classe,
            matiere=matiere,
        )

    # Créer les 3 trimestres
    periodes = []
    for i, (debut, fin, libelle) in enumerate([
        ("2024-09-01", "2024-11-30", "1er Trimestre 2024-2025"),
        ("2024-12-01", "2025-02-28", "2e Trimestre 2024-2025"),
        ("2025-03-01", "2025-06-30", "3e Trimestre 2024-2025"),
    ], start=1):
        p = PeriodeAcademique.objects.create(
            ecole=tenant_actif,
            annee_scolaire=annee,
            numero=i,
            libelle=libelle,
            libelle_court=f"T{i}",
            type_periode="trimestre",
            date_debut=debut,
            date_fin=fin,
            statut=StatutPeriode.OUVERTE,
            poids_calcul=Decimal("1.00"),
        )
        periodes.append(p)

    return {"annee": annee, "classe": classe, "periodes": periodes}


@pytest.fixture
def inscription_eleve(db, tenant_actif, annee_active, directeur):
    """Élève inscrit dans la classe de test."""
    from apps.eleves.models import Eleve, Inscription, StatutInscription

    eleve = Eleve.objects.create(
        ecole=tenant_actif,
        matricule="EL-001-2024",
        nom="JEAN",
        prenom="Pierre",
        date_naissance="2012-05-15",
        sexe="M",
        statut="actif",
    )
    inscription = Inscription.objects.create(
        ecole=tenant_actif,
        eleve=eleve,
        annee_scolaire=annee_active["annee"],
        classe=annee_active["classe"],
        type_inscription="nouveau",
        statut=StatutInscription.VALIDEE,
        date_inscription=timezone.now().date(),
        date_validation=timezone.now().date(),
        validee_par=directeur,
    )
    return {"eleve": eleve, "inscription": inscription}
