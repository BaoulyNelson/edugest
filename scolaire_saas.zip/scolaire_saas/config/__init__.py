"""Charge Celery au démarrage de Django."""
import pymysql

pymysql.install_as_MySQLdb()
# Django exige que le driver MySQL déclare au moins la version 1.4.3.
# PyMySQL fonctionne très bien mais ne déclare pas nativement une version
# assez récente pour passer cette vérification : on la force ici.
pymysql.version_info = (1, 4, 6, "final", 0)
pymysql.__version__ = "1.4.6"

from .celery import app as celery_app