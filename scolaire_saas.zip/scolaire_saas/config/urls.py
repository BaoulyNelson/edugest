"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
"""
config/urls.py
==============
La route racine "/" pointe vers les pages SaaS publiques (sans tenant).
Les routes tenant ne s'activent que depuis un sous-domaine valide.
"""

from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from django.shortcuts import redirect

handler403 = "apps.noyau.views.erreur_403"
handler404 = "apps.noyau.views.erreur_404"
handler500 = "apps.noyau.views.erreur_500"

urlpatterns = [
    # ── Route racine → page d'accueil SaaS publique (sans tenant) ────────────
    path("", lambda r: redirect("saas:accueil"), name="racine"),

    # ── Admin Django natif ─────────────────────────────────────────────────────
    path("django-admin/", admin.site.urls),

    # ── Routes SaaS publiques — PAS de tenant requis ──────────────────────────
    path("saas/", include("apps.etablissements.urls")),
    path("comptes/", include("apps.comptes.urls")),
    path("sante/", include("health_check.urls")),

    # ── Routes protégées — TenantMiddleware actif ─────────────────────────────
    path("", include("apps.noyau.urls_import")),
    path("tableau-bord/", include("apps.noyau.urls_tableau_bord")),
    path("parametrage/", include("apps.parametrage.urls")),
    path("academique/", include("apps.academique.urls")),
    path("eleves/", include("apps.eleves.urls")),
    path("enseignants/", include("apps.enseignants.urls")),
    path("classes/", include("apps.classes.urls")),
    path("notes/", include("apps.notes.urls")),
    path("bulletins/", include("apps.bulletins.urls")),
    path("finances/", include("apps.finances.urls")),
    path("badges/", include("apps.badges.urls")),
    path("securite/", include("apps.securite.urls")),
    path("rapports/", include("apps.rapports.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
