"""
config/settings/production.py
==============================
Configuration production — sécurité maximale.
Chaque paramètre sensible vient des variables d'environnement.
"""

from .base import *  # noqa: F403
from decouple import config, Csv

DEBUG = False
# NB : Csv() attend une chaîne en entrée, donc le default doit être une
# chaîne vide "" et non une liste [] (sinon Csv() plante sur les valeurs
# par défaut, puisque le cast s'applique aussi au default dans decouple).
ALLOWED_HOSTS = config("ALLOWED_HOSTS", default="", cast=Csv())

# ─── Sécurité HTTPS ──────────────────────────────────────────────────────────

SECURE_HSTS_SECONDS = 31536000            # 1 an
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_SSL_REDIRECT = True
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"

CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True
CSRF_TRUSTED_ORIGINS = config("CSRF_TRUSTED_ORIGINS", default="", cast=Csv())

SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = "DENY"
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"

# ─── Base de données production ───────────────────────────────────────────────

DATABASES["default"]["CONN_MAX_AGE"] = 60  # noqa: F405
DATABASES["default"]["OPTIONS"].update({  # noqa: F405
    "ssl": {"ssl-mode": "REQUIRED"} if config("DB_SSL", default=False, cast=bool) else {},
})

# ─── Cache Redis production ───────────────────────────────────────────────────

CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.redis.RedisCache",
        "LOCATION": config("REDIS_URL"),
        "KEY_PREFIX": "scolaire_prod",
        "TIMEOUT": 3600,
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
            "CONNECTION_POOL_KWARGS": {"max_connections": 20},
        },
    }
}

# ─── Email production (SendGrid / SMTP) ──────────────────────────────────────

EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
EMAIL_HOST = config("EMAIL_HOST")
EMAIL_PORT = config("EMAIL_PORT", default=587, cast=int)
EMAIL_HOST_USER = config("EMAIL_HOST_USER")
EMAIL_HOST_PASSWORD = config("EMAIL_HOST_PASSWORD")
EMAIL_USE_TLS = True

# ─── Sentry — monitoring des erreurs ─────────────────────────────────────────

SENTRY_DSN = config("SENTRY_DSN", default=None)
if SENTRY_DSN:
    import sentry_sdk
    from sentry_sdk.integrations.django import DjangoIntegration
    from sentry_sdk.integrations.celery import CeleryIntegration

    sentry_sdk.init(
        dsn=SENTRY_DSN,
        integrations=[DjangoIntegration(), CeleryIntegration()],
        traces_sample_rate=0.1,
        send_default_pii=False,  # RGPD : pas de données personnelles
        environment="production",
    )

# ─── Logging production ───────────────────────────────────────────────────────

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "json": {
            "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
            "format": "%(asctime)s %(levelname)s %(name)s %(message)s",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "json",
        },
        "fichier_erreurs": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": "/var/log/scolaire/erreurs.log",
            "maxBytes": 50 * 1024 * 1024,  # 50MB
            "backupCount": 10,
            "formatter": "json",
        },
        "fichier_audit": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": "/var/log/scolaire/audit.log",
            "maxBytes": 100 * 1024 * 1024,
            "backupCount": 30,
            "formatter": "json",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": "WARNING",
    },
    "loggers": {
        "django": {
            "handlers": ["fichier_erreurs"],
            "level": "ERROR",
            "propagate": False,
        },
        "audit": {
            "handlers": ["fichier_audit"],
            "level": "INFO",
            "propagate": False,
        },
    },
}