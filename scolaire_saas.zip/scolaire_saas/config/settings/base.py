"""
config/settings/base.py
=======================
Configuration Django partagée entre tous les environnements.
Les valeurs sensibles sont toujours lues depuis les variables d'environnement.
"""

from pathlib import Path

import dj_database_url
from decouple import config
from celery.schedules import crontab

# Racine du projet : remonte de config/settings/ vers scolaire_saas/
RACINE_PROJET = Path(__file__).resolve().parent.parent.parent

# NB : python-decouple cherche automatiquement un fichier .env en remontant
# depuis le répertoire courant (celui d'où `manage.py` est lancé). Comme
# manage.py est à la racine du projet, le fichier .env doit y être placé
# (RACINE_PROJET / ".env"), exactement comme avant avec environ.

# ─── Application ────────────────────────────────────────────────────────────

SECRET_KEY = config("SECRET_KEY")
DEBUG = config("DEBUG", default=False, cast=bool)

DJANGO_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.humanize",
]

APPS_TIERCES = [
    "crispy_forms",
    "crispy_bootstrap5",
    "widget_tweaks",
    "django_extensions",
    "axes",
    "django_celery_beat",
    "django_celery_results",
    "health_check",
    "health_check.db",
    "health_check.cache",
]

APPS_LOCALES = [
    "apps.noyau",
    "apps.comptes",
    "apps.etablissements",
    "apps.parametrage",
    "apps.academique",
    "apps.eleves",
    "apps.enseignants",
    "apps.classes",
    "apps.notes",
    "apps.bulletins",
    "apps.finances",
    "apps.badges",
    "apps.securite",
    "apps.rapports",
]

INSTALLED_APPS = DJANGO_APPS + APPS_TIERCES + APPS_LOCALES

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    # Middleware tenant — après auth, avant les vues
    "apps.noyau.middleware.TenantMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "axes.middleware.AxesMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"

# ─── Templates ──────────────────────────────────────────────────────────────

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [RACINE_PROJET / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "apps.noyau.context_processors.configuration_site",
                # Injecte l'établissement courant dans tous les templates
                "apps.noyau.context_processors.etablissement_courant",
            ],
            # Enregistrement explicite des tag libraries du projet.
            # Plus fiable que l'auto-découverte APP_DIRS (qui peut échouer
            # silencieusement selon l'ordre de chargement des apps ou l'OS).
            "libraries": {
                "scolaire_tags": "apps.noyau.templatetags.scolaire_tags",
            },
        },
    },
]

# ─── Base de données ─────────────────────────────────────────────────────────

# python-decouple ne sait pas parser une DATABASE_URL (contrairement à
# django-environ). On utilise donc dj-database-url pour ça :
#   pip install dj-database-url
DATABASES = {
    "default": dj_database_url.parse(config("DATABASE_URL")),
}
DATABASES["default"]["OPTIONS"] = {
    "charset": "utf8mb4",
    "init_command": "SET sql_mode='STRICT_TRANS_TABLES'",
}
# Connexions persistantes — réduit la latence en production
DATABASES["default"]["CONN_MAX_AGE"] = config("DB_CONN_MAX_AGE", default=60, cast=int)

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ─── Cache ───────────────────────────────────────────────────────────────────

CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.redis.RedisCache",
        "LOCATION": config("REDIS_URL", default="redis://127.0.0.1:6379/0"),
        "KEY_PREFIX": "scolaire",
        "TIMEOUT": 3600,
    }
}

# ─── Authentification ────────────────────────────────────────────────────────

AUTH_USER_MODEL = "comptes.Utilisateur"

AUTHENTICATION_BACKENDS = [
    "axes.backends.AxesStandaloneBackend",
    "apps.comptes.backends.BackendAuthMultitenant",
]

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LOGIN_URL = "/comptes/connexion/"
LOGIN_REDIRECT_URL = "/tableau-bord/"
LOGOUT_REDIRECT_URL = "/comptes/connexion/"

# ─── Sessions ────────────────────────────────────────────────────────────────

SESSION_ENGINE = "django.contrib.sessions.backends.db"
SESSION_CACHE_ALIAS = "default"
SESSION_COOKIE_AGE = 3600 * 8  # 8 heures
SESSION_EXPIRE_AT_BROWSER_CLOSE = False
SESSION_COOKIE_NAME = "scolaire_session"

# ─── Internationalisation ────────────────────────────────────────────────────

LANGUAGE_CODE = "fr"
TIME_ZONE = "America/Port-au-Prince"
USE_I18N = True
USE_L10N = True
USE_TZ = True

LANGUAGES = [
    ("fr", "Français"),
    ("ht", "Kreyòl Ayisyen"),
    ("en", "English"),
    ("es", "Español"),
]

LOCALE_PATHS = [RACINE_PROJET / "locale"]

# ─── Fichiers statiques & médias ─────────────────────────────────────────────

STATIC_URL = "/static/"
STATIC_ROOT = RACINE_PROJET / "staticfiles"
STATICFILES_DIRS = [RACINE_PROJET / "static"]
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

MEDIA_URL = "/media/"
# decouple n'a pas d'équivalent à env.path() : on caste nous-mêmes en Path
MEDIA_ROOT = Path(config("MEDIA_ROOT", default=str(RACINE_PROJET / "media")))

# ─── Email ───────────────────────────────────────────────────────────────────

DEFAULT_FROM_EMAIL = config("DEFAULT_FROM_EMAIL", default="noreply@scolaire.ht")
SERVER_EMAIL = DEFAULT_FROM_EMAIL
EMAIL_SUBJECT_PREFIX = "[ScolaireSaaS] "

# ─── Celery ──────────────────────────────────────────────────────────────────

CELERY_BROKER_URL = config("CELERY_BROKER_URL", default="redis://127.0.0.1:6379/1")
CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TASK_SERIALIZER = "json"
CELERY_RESULT_SERIALIZER = "json"
CELERY_TIMEZONE = TIME_ZONE
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 30 * 60  # 30 minutes max par tâche

CELERY_BEAT_SCHEDULE = {
    "expirer-essais-gratuits-quotidiennement": {
        "task": "apps.etablissements.tasks.expirer_essais_gratuits",
        "schedule": crontab(hour=0, minute=0),
    },
}

# Queues séparées par domaine métier
CELERY_TASK_ROUTES = {
    "workers.taches_bulletins.*": {"queue": "bulletins"},
    "workers.taches_badges.*": {"queue": "badges"},
    "workers.taches_rapports.*": {"queue": "rapports"},
    "workers.taches_notifications.*": {"queue": "notifications"},
}

# ─── Axes (protection brute-force) ───────────────────────────────────────────

from datetime import timedelta

AXES_FAILURE_LIMIT = 5
AXES_COOLOFF_TIME = timedelta(hours=1)
# "username" is the email field in FormulaireConnexion; nested values are combined with AND.
AXES_LOCKOUT_PARAMETERS = [["username", "ip_address"]]
AXES_LOCKOUT_CALLABLE = "apps.comptes.securite.gerer_verrouillage"
AXES_RESET_ON_SUCCESS = True
# ─── Crispy Forms ────────────────────────────────────────────────────────────

CRISPY_ALLOWED_TEMPLATE_PACKS = "bootstrap5"
CRISPY_TEMPLATE_PACK = "bootstrap5"

# ─── Paramètres métier globaux ───────────────────────────────────────────────

SCOLAIRE = {
    # Taille max d'un fichier photo (5MB)
    "MAX_TAILLE_PHOTO": 5 * 1024 * 1024,
    # Formats d'image acceptés pour les photos
    "FORMATS_PHOTO_ACCEPTES": ["image/jpeg", "image/png", "image/webp"],
    # Nombre de décimales pour les moyennes
    "PRECISION_MOYENNE": 4,
    # TTL cache des moyennes calculées (secondes)
    "TTL_CACHE_MOYENNES": 3600,
    # Taille max des badges générés
    "BADGE_LARGEUR_MM": 85,
    "BADGE_HAUTEUR_MM": 54,
}

# ===========================================================
# MESSAGES
# ===========================================================
from django.contrib.messages import constants as messages
MESSAGE_TAGS = {
    messages.DEBUG: 'debug',
    messages.INFO: 'info',
    messages.SUCCESS: 'success',
    messages.WARNING: 'warning',
    messages.ERROR: 'danger',
}