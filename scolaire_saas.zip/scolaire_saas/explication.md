# SCOLAIRE SAAS — Description complète du système de A à Z

---

## QU'EST-CE QUE C'EST ?

C'est une plateforme web SaaS (Software as a Service) multitenant de gestion d'établissements scolaires. Concrètement, un seul serveur héberge le logiciel, et des centaines d'écoles différentes l'utilisent chacune de leur côté, avec leurs propres données totalement isolées les unes des autres. C'est exactement comme Gmail : un seul système, des millions de comptes séparés.

Le système couvre tout ce qu'une école fait au quotidien : inscrire des élèves, saisir des notes, calculer des moyennes, générer des bulletins PDF, encaisser les frais scolaires, imprimer des badges, gérer les enseignants, contrôler les accès par rôle, et conserver une trace immuable de toutes les actions.

---

## PARTIE 1 — L'ÉDITEUR SAAS (vous, le propriétaire du logiciel)

Vous êtes l'entreprise qui vend l'accès au logiciel. Depuis un panneau d'administration central, vous gérez les plans d'abonnement (Starter, Essentiel, Pro, Réseau), les limites par plan (nombre d'élèves maximum, fonctionnalités activées ou non), et vous pouvez activer ou bloquer n'importe quelle école d'un seul clic. Vous voyez toutes les écoles, tous les abonnements, tous les paiements de licences. Aucune école ne peut voir ce que font les autres.

---

## PARTIE 2 — L'ÉCOLE S'INSCRIT ET CONFIGURE SON ESPACE

### Étape 1 : Inscription SaaS

Un directeur d'école visite le site public, voit les tarifs, et crée son compte. Il choisit un identifiant unique pour son école, par exemple `lycee-petion-cap`. À partir de là, son école est accessible à l'adresse `lycee-petion-cap.scolaire.ht`. Dès la création du compte, les rôles système sont générés automatiquement (Directeur, Secrétaire, Comptable, Enseignant, Surveillant, Parent).

### Étape 2 : Paramétrage de l'école

Avant toute chose, le directeur configure son école selon sa réalité pédagogique. Il n'y a rien de codé en dur : tout est configurable.

Il définit d'abord ses **cycles d'enseignement**. Par exemple pour une école haïtienne : Fondamental et Secondaire. Pour une école française : École, Collège, Lycée. Le système ne connaît aucun de ces noms à l'avance, le directeur les crée librement.

Dans chaque cycle, il crée ses **niveaux**. Pour le Fondamental haïtien : 1re AF, 2e AF, 3e AF, 4e AF, 5e AF, 6e AF. Pour le Secondaire : 7e AF, 8e AF, 9e AF, 10e AF (Seconde), 11e AF (Rhéto), 12e AF (Philo). Il peut aussi créer des sections (A, B, C) et des options pédagogiques (Sciences, Lettres, Commerce).

Il configure ensuite ses **matières** : Mathématiques, Français, Créole, Sciences Naturelles, Histoire-Géographie, Anglais, Éducation Physique, etc. Chaque matière a un code, un libellé court pour les bulletins, et un type (théorique, pratique, sport, art).

Il définit ses **types d'évaluation** : Interrogation, Devoir, Composition, Examen. Chaque type a un poids dans le calcul de la moyenne. Une composition peut peser trois fois plus qu'une interrogation.

Il configure son **système de notation** : sur 10 pour le système haïtien, sur 20 pour le système français, sur 100 si besoin. Il fixe la note de passage (5/10, 10/20...) et crée ses **mentions** avec les tranches correspondantes : Excellent entre 9 et 10, Très Bien entre 8 et 8,99, Bien entre 7 et 7,99, Passable entre 5 et 6,99, Insuffisant en dessous de 5.

Il fixe les **coefficients de chaque matière par niveau** : les Mathématiques ont un coefficient 3 en 6e AF, le Français un coefficient 3, les Sciences un coefficient 2. Ces coefficients peuvent changer d'une année à l'autre sans affecter l'historique.

Il configure ses **règles de passage** par niveau : la moyenne minimale pour être admis, les matières éliminatoires (un élève avec moins de 3/10 en Français est refusé même si sa moyenne générale est suffisante), le nombre maximum de matières insuffisantes toléré.

Il paramètre les **types de frais** : frais d'inscription (paiement unique), écolage mensuel, frais de cantine, transport, livres. Pour chaque type, il peut définir si un bulletin peut être imprimé même si ce frais n'est pas réglé, ou si la génération du bulletin doit être bloquée jusqu'au paiement.

Enfin, il personnalise l'identité visuelle de son école : logo, couleurs (utilisées dans les bulletins et les badges), devise ou slogan, nom du directeur, signature numérisée, cachet officiel, numéro d'agrément du Ministère de l'Éducation.

---

## PARTIE 3 — L'ANNÉE SCOLAIRE DÉMARRE

### Le cycle de vie d'une année scolaire

Une année scolaire passe par quatre états obligatoires et dans l'ordre : **Brouillon → Active → Clôturée → Archivée**. On ne peut jamais sauter un état, ni revenir en arrière.

En état **Brouillon**, le directeur prépare l'année. Il crée les classes (par exemple : 6e AF - Section A, 6e AF - Section B, 10e AF - Sciences), désigne les titulaires, et associe les matières à chaque classe avec leurs enseignants respectifs.

Quand tout est prêt, il **active** l'année. Le système vérifie qu'au moins une classe existe et qu'aucune autre année n'est déjà active. Une seule année peut être active à la fois. À partir de ce moment, les inscriptions sont ouvertes.

L'année **active** crée automatiquement les périodes selon le découpage choisi : trois trimestres, deux semestres, ou quatre quadrimestres. Chaque période a une date de début et de fin, et un poids dans le calcul de la moyenne annuelle.

### Les périodes académiques

Chaque période passe également par des états : **Ouverte → Clôturée → Publiée**.

Quand une période est **ouverte**, les enseignants saisissent les notes. Quand elle est **clôturée**, plus aucune note ne peut être saisie ou modifiée — toutes les notes sont verrouillées définitivement, et les calculs de moyennes peuvent commencer. Quand elle est **publiée**, les résultats sont définitifs et les bulletins peuvent être générés.

---

## PARTIE 4 — LES ÉLÈVES

### Création du dossier

La secrétaire crée la fiche d'un élève avec toutes ses informations : nom, prénom, date et lieu de naissance, sexe, nationalité, photo, adresse, informations médicales (groupe sanguin, allergies), et les informations des parents (noms du père et de la mère, téléphones, email). Le système génère automatiquement un matricule unique par école.

### Inscription

L'élève est ensuite inscrit pour l'année scolaire en cours dans une classe précise. Le système vérifie automatiquement que l'année est bien active, que le verrou administratif n'est pas activé, que l'élève n'est pas déjà inscrit cette année, et que la classe n'a pas atteint sa capacité maximale. L'inscription commence à l'état "En attente" et doit être validée par un responsable habilité.

Un nouvel élève qui arrive d'une autre école est inscrit en "Transfert entrant" avec la mention de l'école d'origine. Un élève qui redouble est inscrit en "Doublement de classe". Toutes ces distinctions sont conservées dans l'historique.

### Mouvements d'élèves

Tout au long de l'année, les mouvements d'élèves sont tracés et conservés. Un élève peut être suspendu pour motif disciplinaire (avec le motif obligatoirement consigné), transféré vers une autre classe de la même école, ou abandonner l'année. Chaque mouvement est horodaté, signé par l'agent qui l'a réalisé, et conservé pour toujours dans le dossier de l'élève. Ces données alimentent les statistiques de rétention scolaire.

---

## PARTIE 5 — LES ENSEIGNANTS

Chaque enseignant a un dossier dans le système : identité, qualifications, spécialité principale et secondaire, diplôme le plus élevé, nombre d'années d'expérience, numéro de licence du Ministère de l'Éducation, type de contrat (permanent, vacataire, contractuel), date d'embauche.

Un enseignant peut être lié à un compte utilisateur pour se connecter au système et saisir ses propres notes. Ou il peut n'avoir aucun accès et être géré uniquement par la direction.

Les enseignants sont affectés aux matières de chaque classe. L'affectation précise si l'enseignant est principal ou remplaçant, et pour quelle période de l'année. L'emploi du temps hebdomadaire peut être configuré avec les jours, heures de début et de fin, et la salle attribuée.

---

## PARTIE 6 — LES NOTES

### Saisie

L'enseignant ou la secrétaire accède à la grille de saisie en choisissant une classe, une matière et une période. La grille affiche tous les élèves inscrits dans la classe. Pour chaque élève et pour chaque type d'évaluation (Interrogation, Devoir, Composition), on saisit une note.

Le système vérifie immédiatement que la note ne dépasse pas le maximum autorisé, que la période est bien ouverte, que l'année scolaire est active, et que le verrou administratif n'est pas enclenché. Si une de ces conditions échoue, la saisie est refusée avec un message explicatif clair.

Si un élève est absent, on peut marquer l'absence. Si l'absence est justifiée, la note est exclue du calcul de la moyenne. Si elle n'est pas justifiée, elle vaut zéro.

Au moment de la saisie, le système copie et fige le coefficient de la matière dans chaque note. Ainsi, même si le directeur modifie les coefficients après coup, toutes les notes déjà saisies conservent le coefficient qui était en vigueur au moment de leur saisie. C'est une garantie d'intégrité historique absolue.

### Calcul des moyennes

Le calcul est entièrement automatique et centralisé dans un moteur de calcul unique. Ce moteur utilise uniquement des nombres décimaux de haute précision, jamais des nombres flottants, pour éviter les erreurs d'arrondi. Un élève ayant obtenu 678 points sur 1200 possibles obtient exactement 5,6500 sur 10 — pas 5,649999 ni 5,650001.

La formule normalise chaque note sur 100 avant de la pondérer, ce qui permet de mélanger des notes sur 5, sur 10, sur 20 ou sur 100 dans la même classe sans erreur. Les notes sont ensuite pondérées par le coefficient du type d'évaluation, puis par le coefficient de la matière, pour obtenir la moyenne générale.

Après le calcul des moyennes par matière, le système calcule la moyenne générale pondérée pour chaque élève. Il classe ensuite automatiquement les élèves dans leur classe par ordre décroissant de moyenne et attribue à chacun son rang. La mention (Excellent, Très Bien, Bien, Passable, Insuffisant) est attribuée selon les tranches configurées par l'école.

La décision d'admission (admis ou refusé) est évaluée automatiquement selon les règles de passage de l'école : vérification de la moyenne générale minimale, vérification des matières éliminatoires, vérification du nombre de matières insuffisantes.

---

## PARTIE 7 — LES BULLETINS

### Génération

Quand une période est clôturée et que les moyennes sont calculées, la secrétaire ou le directeur lance la génération des bulletins. Cela peut se faire un par un ou pour toute une classe d'un seul coup. La génération en masse est exécutée en tâche de fond par Celery pour ne pas bloquer l'interface, et un rapport est produit à la fin (nombre de bulletins générés, nombre d'erreurs éventuelles).

Chaque bulletin PDF contient : l'en-tête de l'école (logo, nom, devise, numéro d'agrément), les informations de l'élève (nom, classe, matricule, effectif de la classe), le tableau complet des matières avec la moyenne de chaque matière, le coefficient, le rang dans la classe et l'appréciation, le bilan général (moyenne générale, rang global, mention, décision), les observations disciplinaires si le type de discipline est configuré pour apparaître dans le bulletin, les zones de signature (directeur, parent/tuteur, cachet), et un QR code unique en pied de page.

### Workflow de validation

Un bulletin passe par quatre états : **Brouillon → Validé → Publié → Archivé**.

Un bulletin en brouillon vient d'être généré et peut être régénéré si des corrections sont nécessaires. Un bulletin validé a été vérifié et approuvé par la direction. Un bulletin publié est définitif : la moyenne associée est verrouillée, le PDF est figé, plus rien ne peut être modifié — c'est un contrat irréversible. Un bulletin archivé est conservé pour l'historique de l'école.

### Vérification d'authenticité

Chaque bulletin imprimé contient un QR code. Quand un parent ou un employeur scanne ce QR code, il accède à une page publique du site de l'école qui affiche les informations du bulletin et confirme son authenticité. Cette page est accessible sans connexion et répond à la question "ce bulletin est-il vrai ?".

---

## PARTIE 8 — LES FINANCES

### Configuration des frais

Le directeur crée les types de frais de son école : frais d'inscription, écolage mensuel (octobre, novembre, décembre...), cantine, transport. Pour chaque type, il précise la fréquence (unique, mensuel, trimestriel, annuel) et le montant par défaut.

### Assignation aux élèves

Pour chaque élève inscrit, la secrétaire ou le comptable assigne les frais dus. Le montant peut différer du montant par défaut si l'élève bénéficie d'une remise (montant fixe ou pourcentage). Le motif de la remise est obligatoirement saisi et conservé. Le système calcule automatiquement le montant net dû après remises.

### Paiements

Quand un parent vient payer, le comptable enregistre le versement : montant payé, mode de paiement (espèces, virement, Mobile Money comme MonCash ou NatCash, chèque), référence externe si besoin. Le système vérifie que le montant ne dépasse pas le solde restant, génère un numéro de reçu unique dans le format REC-2025-000142, et émet un reçu PDF immédiatement téléchargeable.

Le statut du frais se met à jour automatiquement : "Partiel" si le paiement ne couvre pas tout, "Complet" si le solde est soldé.

### Annulation de paiements

Une erreur de caisse peut arriver. Le comptable peut annuler un paiement en saisissant obligatoirement un motif. L'annulation ne supprime jamais le paiement original : elle crée une écriture de journal inverse (montant négatif) qui remet le solde à l'état précédent. La piste d'audit est complète et inaltérable.

### Journal de caisse et rapports

Le journal de caisse enregistre toutes les entrées et sorties dans l'ordre chronologique. Le rapport journalier détaille le total encaissé, le total annulé, le net en caisse, et la ventilation par mode de paiement pour chaque journée. Le tableau des soldes par classe montre en un coup d'œil quels élèves ont un solde en attente, classés du plus élevé au plus faible.

---

## PARTIE 9 — LES BADGES ET CARTES D'IDENTITÉ

Le système génère des badges au format carte d'identité standard (85mm × 54mm). Un badge élève contient la photo, le nom complet en majuscules, la classe, le matricule, l'année scolaire, le logo et les couleurs de l'école, et un QR code encodant le matricule et l'identifiant de l'école.

Les badges peuvent être générés un par un ou pour toute une classe. La génération en masse produit un fichier ZIP contenant un PDF par élève, prêt à imprimer. Des codes-barres Code128 peuvent également être ajoutés pour les écoles qui utilisent un système de contrôle d'accès ou de bibliothèque.

---

## PARTIE 10 — LA SÉCURITÉ ET LES ACCÈS

### Système de rôles

Chaque utilisateur de l'école a un ou plusieurs rôles qui définissent précisément ce qu'il peut faire. Le système utilise un contrôle d'accès basé sur les rôles (RBAC) avec des permissions très granulaires du type `notes.saisir.propres_classes` ou `bulletins.publier.toutes_classes`.

Le **Directeur** a accès à tout : activer et clôturer les années, publier les bulletins, gérer les utilisateurs, consulter les finances, modifier le paramétrage.

La **Secrétaire** peut inscrire des élèves, générer et valider des bulletins, consulter les finances et créer des badges, mais ne peut pas modifier le paramétrage ni gérer les rôles des autres utilisateurs.

Le **Comptable** encaisse les paiements, annule des paiements (avec motif), consulte les rapports financiers, mais n'a pas accès aux notes ni aux bulletins.

L'**Enseignant** saisit et valide uniquement les notes de ses propres classes — il ne peut pas toucher aux notes d'une classe qui ne lui est pas assignée. Il peut générer les bulletins de ses classes mais pas les publier.

Le **Surveillant** consulte les dossiers d'élèves et peut enregistrer des suspensions, mais n'a pas accès aux notes ni aux finances.

Le **Parent** peut uniquement consulter les bulletins et le solde financier de son propre enfant — en lecture seule, sans aucune possibilité de modification.

Les permissions sont vérifiées sur chaque page et sur chaque action. Les résultats de ces vérifications sont mis en cache pendant 5 minutes pour ne pas interroger la base de données à chaque clic.

### Isolation des données entre écoles

C'est la garantie fondamentale du système. Un utilisateur connecté à l'adresse `lycee-petion-cap.scolaire.ht` ne peut absolument pas accéder aux données de `college-notre-dame.scolaire.ht`. Le système identifie l'école depuis le sous-domaine à chaque requête, l'injecte dans un contexte sécurisé, et filtre automatiquement toutes les données en base. Il est techniquement impossible qu'un élève d'une école apparaisse dans la liste d'une autre école.

### Journal d'audit immuable

Toutes les actions significatives sont enregistrées : connexion d'un utilisateur, création d'une note, modification d'un bulletin, enregistrement d'un paiement, annulation d'un paiement, activation d'une année scolaire, publication de résultats. Chaque entrée contient l'heure exacte, l'utilisateur, l'action, l'objet concerné, l'état avant et après la modification, et l'adresse IP.

Ces entrées ne peuvent jamais être modifiées ni supprimées — même par le directeur. Si quelqu'un essaie, le système rejette la tentative. Le journal est accessible au directeur pour auditer toutes les actions réalisées dans son établissement.

---

## PARTIE 11 — LES GARDES MÉTIER (ce que le système refuse automatiquement)

Le système refuse catégoriquement certaines actions selon l'état dans lequel se trouve l'école. Ces refus sont automatiques, documentés et ne peuvent pas être contournés par une simple manipulation manuelle.

Il est **impossible** de saisir une note si la période est clôturée ou publiée. Il est **impossible** de modifier une note après que la période est clôturée. Il est **impossible** de générer un bulletin si la période n'est pas au moins clôturée. Il est **impossible** de publier un bulletin si sa moyenne générale n'a pas été calculée. Il est **impossible** de modifier une moyenne après qu'elle a été publiée. Il est **impossible** d'activer une deuxième année scolaire alors qu'une autre est déjà active. Il est **impossible** d'inscrire un élève après que le verrou administratif a été activé. Il est **impossible** de clôturer une année s'il reste des bulletins non publiés. Il est **impossible** d'inscrire un élève dans une classe pleine. Il est **impossible** d'enregistrer un paiement supérieur au solde restant dû. Il est **impossible** d'annuler un paiement déjà annulé. Il est **impossible** de modifier ou supprimer une entrée du journal d'audit.

Chaque refus produit un message clair expliquant pourquoi l'action est impossible et ce qu'il faut faire pour débloquer la situation.

---

## PARTIE 12 — LES RAPPORTS ET STATISTIQUES

Le tableau de bord principal affiche en temps réel le nombre d'élèves inscrits, le nombre de classes actives, le nombre de bulletins publiés, et l'état de l'année scolaire courante.

Le rapport académique présente le nombre d'élèves par classe, le taux d'admission par niveau (combien d'élèves admis sur combien d'inscrits), et les statistiques de moyennes par classe.

Le rapport financier présente le total des frais dus sur l'année, le total encaissé, le solde global restant, et la répartition par type de frais.

Le rapport sur les élèves montre la répartition par statut (actifs, suspendus, transférés, abandons) et les tendances de présence.

Toutes les données peuvent être exportées en CSV pour être traitées dans un tableur ou transmises au Ministère de l'Éducation.

---

## PARTIE 13 — CE QUI SE PASSE EN COULISSE (tâches automatiques)

Certaines opérations longues ne se font pas en temps réel mais en tâche de fond, pour que l'interface reste rapide et réactive.

Quand le directeur demande la génération des bulletins pour toute une classe de 40 élèves, la demande est mise en file d'attente. Un worker traite les 40 bulletins un par un, génère chaque PDF, l'enregistre, et produit un rapport final. L'utilisateur peut continuer à travailler pendant ce temps.

De même, quand les moyennes de toute une promotion de 200 élèves doivent être calculées en fin de trimestre, le calcul est distribué en tâche de fond. À la fin, les classements sont automatiquement recalculés pour toutes les classes.

Quand un bulletin est publié, un email peut être envoyé automatiquement au parent de l'élève pour l'informer que le bulletin est disponible, avec un lien direct vers la page de vérification.

---

## EN RÉSUMÉ

Le système accompagne une école depuis l'ouverture de son compte jusqu'à l'archivage de la dernière année scolaire. Il gère chaque étape : paramétrage complet selon la pédagogie locale, inscriptions des élèves, saisie des notes, calcul automatique et précis des moyennes et classements, génération de bulletins PDF prêts à imprimer, encaissement des frais et émission de reçus, impression de badges avec QR codes, contrôle des accès par rôle, et traçabilité totale de toutes les actions.

Tout est configurable par l'école elle-même. Rien n'est imposé. Le système s'adapte au système éducatif haïtien, français, canadien, ou tout autre. Et toutes ces données sont strictement isolées entre les différentes écoles abonnées.