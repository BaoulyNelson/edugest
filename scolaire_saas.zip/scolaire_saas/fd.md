# ARCHITECTURE SAAS MULTITENANT — PLATEFORME DE GESTION SCOLAIRE
> Document d'architecture technique — Niveau : Architecte Senior / CTO
> Stack : Django 4.2 · Python 3.13 · MySQL (XAMPP) · Celery · Redis

---

## TABLE DES MATIÈRES

1. [Vision Industrielle & Principes Directeurs](#1-vision-industrielle)
2. [Stratégie Multitenant — Décision & Justification](#2-stratégie-multitenant)
3. [Structure du Projet Django](#3-structure-du-projet)
4. [Modélisation Base de Données — Schéma Complet](#4-modélisation-base-de-données)
5. [Modèles Django — Code de Référence](#5-modèles-django)
6. [Services Métier](#6-services-métier)
7. [Moteur d'États & Workflows](#7-moteur-détats--workflows)
8. [Système RBAC & Permissions](#8-système-rbac--permissions)
9. [Moteur de Calcul des Moyennes](#9-moteur-de-calcul-des-moyennes)
10. [Système de Badges & Identité](#10-système-de-badges--identité)
11. [Module Finances](#11-module-finances)
12. [Audit & Traçabilité](#12-audit--traçabilité)
13. [APIs](#13-apis)
14. [Sécurité](#14-sécurité)
15. [Performance & Optimisations](#15-performance--optimisations)
16. [Tests](#16-tests)
17. [Déploiement](#17-déploiement)
18. [Scalabilité](#18-scalabilité)
19. [Plan de Développement par Phases](#19-plan-de-développement-par-phases)
20. [Plan SaaS Commercial](#20-plan-saas-commercial)

---

## 1. VISION INDUSTRIELLE

### 1.1 Positionnement Produit

Ce système n'est pas un simple logiciel de gestion scolaire. C'est un **ERP éducatif SaaS multitenant** conçu pour opérer à l'échelle de milliers d'établissements simultanément, avec :

- **Isolation des données garantie** entre tenants (écoles)
- **Paramétrage total** : aucune règle métier codée en dur
- **Moteur de workflow robuste** : états, transitions, gardes métier
- **Calcul académique précis** : arithmétique décimale fiable
- **RBAC granulaire** par rôle, par établissement, par module

### 1.2 Principes Architecturaux Non Négociables

```
PRINCIPE 1 : Séparation stricte — Tenant > Domaine > Service > Repository > Modèle
PRINCIPE 2 : Aucune logique métier dans les vues ni dans les modèles
PRINCIPE 3 : Tout ce qui peut changer doit être configurable
PRINCIPE 4 : Les états métier sont des contrats, pas des suggestions
PRINCIPE 5 : L'audit est systématique, pas optionnel
```

### 1.3 Contraintes Techniques Acceptées

| Contrainte | Décision | Justification |
|---|---|---|
| MySQL (XAMPP) | Tenant par colonne | MySQL ne supporte pas les schémas multiples comme PostgreSQL |
| Django ORM | QuerySets avec managers filtrés | Transparence tenant sans magic |
| Python 3.13 | Décimaux natifs + Decimal | Fiabilité des calculs de moyennes |
| Django 4.2 LTS | Version stable jusqu'en 2026 | Maturité + support long terme |

---

## 2. STRATÉGIE MULTITENANT

### 2.1 Comparatif des Approches

| Approche | Isolation | Complexité | MySQL Support | Choix |
|---|---|---|---|---|
| Base par tenant | Parfaite | Très élevée | Difficile | ❌ Rejeté |
| Schéma par tenant | Forte | Élevée | Non natif MySQL | ❌ Rejeté |
| **Colonne par tenant** | **Applicative** | **Modérée** | **✅ Natif** | **✅ Retenu** |

### 2.2 Architecture Retenue : Tenant par Colonne avec Middleware

**Chaque table métier possède une FK `ecole` vers le modèle `Etablissement`.**

Le `TenantMiddleware` injecte l'école courante dans le thread local à chaque requête. Un `TenantManager` personnalisé filtre automatiquement tous les QuerySets.

```
Requête HTTP
     │
     ▼
TenantMiddleware
  ├─ Identifie l'école via subdomain / header / session
  ├─ Charge l'Etablissement actif
  ├─ Injecte dans threading.local()
  └─ Rejette si tenant introuvable ou suspendu
     │
     ▼
Vue / Serializer
  └─ Utilise TenantManager automatiquement
       └─ WHERE ecole_id = <tenant_courant>
```

### 2.3 Identification du Tenant

**Stratégie recommandée : sous-domaine + fallback header**

```
lycee-petion.scolaire.ht  → slug="lycee-petion"
college-notre-dame.scolaire.ht → slug="college-notre-dame"
```

Configuration alternative pour développement local :
```
X-Tenant-Slug: lycee-petion  (header HTTP)
```

### 2.4 Implémentation du TenantMiddleware

```python
# apps/noyau/middleware.py

import threading
from django.http import Http404
from apps.etablissements.models import Etablissement

_tenant_local = threading.local()


def obtenir_tenant_courant() -> "Etablissement | None":
    """Retourne l'établissement du thread courant."""
    return getattr(_tenant_local, "etablissement", None)


def definir_tenant_courant(etablissement: "Etablissement | None") -> None:
    """Définit l'établissement dans le thread local."""
    _tenant_local.etablissement = etablissement


class TenantMiddleware:
    """
    Middleware d'isolation multitenant.
    Identifie l'école via sous-domaine, injecte dans threading.local().
    Bloque toute requête sans tenant valide sur les routes protégées.
    """

    ROUTES_PUBLIQUES = ["/saas/", "/admin/", "/api/auth/", "/sante/"]

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Réinitialiser à chaque requête (isolation thread pool)
        definir_tenant_courant(None)

        if not self._est_route_publique(request.path):
            slug = self._extraire_slug_tenant(request)
            if not slug:
                raise Http404("Établissement introuvable.")

            try:
                etablissement = Etablissement.objects.get(
                    slug=slug,
                    est_actif=True,
                )
                definir_tenant_courant(etablissement)
                request.etablissement = etablissement
            except Etablissement.DoesNotExist:
                raise Http404("Établissement introuvable ou suspendu.")

        reponse = self.get_response(request)
        # Nettoyage systématique après la réponse
        definir_tenant_courant(None)
        return reponse

    def _extraire_slug_tenant(self, request) -> str | None:
        host = request.get_host().split(":")[0]
        parties = host.split(".")
        if len(parties) >= 3:
            return parties[0]
        return request.headers.get("X-Tenant-Slug")

    def _est_route_publique(self, path: str) -> bool:
        return any(path.startswith(route) for route in self.ROUTES_PUBLIQUES)
```

### 2.5 TenantManager — Filtrage Automatique

```python
# apps/noyau/managers.py

from django.db import models
from apps.noyau.middleware import obtenir_tenant_courant


class TenantQuerySet(models.QuerySet):
    """QuerySet filtré automatiquement sur le tenant courant."""

    def du_tenant(self):
        tenant = obtenir_tenant_courant()
        if tenant is None:
            raise RuntimeError(
                "Aucun tenant actif. Vérifier TenantMiddleware ou contexte."
            )
        return self.filter(ecole=tenant)


class TenantManager(models.Manager):
    """
    Manager par défaut pour tous les modèles multitenant.
    Remplace get_queryset() pour forcer le filtrage tenant.
    NE PAS utiliser pour les migrations ou les tâches admin cross-tenant.
    """

    def get_queryset(self) -> TenantQuerySet:
        tenant = obtenir_tenant_courant()
        qs = TenantQuerySet(self.model, using=self._db)
        if tenant is not None:
            return qs.filter(ecole=tenant)
        return qs

    def sans_filtre_tenant(self) -> TenantQuerySet:
        """Bypass du filtre tenant — usage restreint aux tâches système."""
        return TenantQuerySet(self.model, using=self._db)


class TenantModelMixin(models.Model):
    """
    Mixin abstrait à hériter par tous les modèles tenant.
    Fournit le champ ecole + le manager filtré.
    """

    ecole = models.ForeignKey(
        "etablissements.Etablissement",
        on_delete=models.CASCADE,
        related_name="%(app_label)s_%(class)s",
        db_index=True,
    )

    objects = TenantManager()
    tous_objets = models.Manager()  # Manager non filtré pour admin/system

    class Meta:
        abstract = True
```

---

## 3. STRUCTURE DU PROJET

### 3.1 Arborescence Complète

```
scolaire_saas/
│
├── config/                              # Configuration centrale
│   ├── settings/
│   │   ├── __init__.py
│   │   ├── base.py                      # Paramètres communs
│   │   ├── developpement.py             # Dev local (DEBUG=True, XAMPP)
│   │   ├── production.py                # Prod (sécurisé, cache, email)
│   │   └── tests.py                     # Tests (SQLite in-memory)
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
│
├── apps/
│   ├── noyau/                           # Infrastructure transversale
│   │   ├── middleware.py                # TenantMiddleware
│   │   ├── managers.py                  # TenantManager, TenantQuerySet
│   │   ├── mixins.py                    # TenantModelMixin, HorodatageMixin
│   │   ├── exceptions.py                # Exceptions métier
│   │   ├── decorateurs.py               # @requiert_tenant, @requiert_permission
│   │   ├── signaux.py                   # Signaux Django globaux
│   │   └── utilitaires/
│   │       ├── decimaux.py              # Arithmétique fiable
│   │       ├── dates.py
│   │       └── pdf.py
│   │
│   ├── comptes/                         # Auth & utilisateurs SaaS
│   │   ├── models.py                    # Utilisateur, Profil, SessionTenant
│   │   ├── views.py
│   │   ├── formulaires.py
│   │   ├── urls.py
│   │   └── backends.py                  # Backend d'auth multitenant
│   │
│   ├── etablissements/                  # Cœur du tenant
│   │   ├── models.py                    # Etablissement, Abonnement, Licence
│   │   ├── views.py
│   │   ├── urls.py
│   │   └── admin.py
│   │
│   ├── parametrage/                     # Moteur de config ultra-flexible
│   │   ├── models.py                    # CycleEnseignement, Niveau, Section...
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── academique/                      # Années scolaires & workflow
│   │   ├── models.py                    # AnneeScolaire, Trimestre, Semestre
│   │   ├── etats.py                     # Machine à états
│   │   ├── services.py                  # ServiceAnneeScolaire
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── eleves/                          # Gestion des élèves
│   │   ├── models.py                    # Eleve, Inscription, Transfert
│   │   ├── services.py                  # ServiceInscription
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── enseignants/                     # Gestion des enseignants
│   │   ├── models.py                    # Enseignant, Affectation, Charge
│   │   ├── services.py
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── classes/                         # Classes & emplois du temps
│   │   ├── models.py                    # Classe, EmploiDuTemps, Titulaire
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── notes/                           # Moteur de notes & calculs
│   │   ├── models.py                    # Note, TypeEvaluation, Composition
│   │   ├── services.py                  # ServiceCalculMoyenne
│   │   ├── moteur.py                    # Moteur de calcul central
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── bulletins/                       # Bulletins & publications
│   │   ├── models.py                    # Bulletin, LigneBulletin
│   │   ├── services.py                  # ServiceGenBulletin
│   │   ├── generateurs/
│   │   │   ├── base.py
│   │   │   ├── trimestriel.py
│   │   │   └── annuel.py
│   │   ├── templates_pdf/
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── finances/                        # Gestion financière
│   │   ├── models.py                    # FraisScolaire, Paiement, Reçu
│   │   ├── services.py                  # ServicePaiement, ServiceCaisse
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── badges/                          # Identité & badges
│   │   ├── models.py                    # TemplateBadge, BadgeGenere
│   │   ├── generateurs/
│   │   │   ├── badge_eleve.py
│   │   │   └── badge_enseignant.py
│   │   ├── views.py
│   │   └── urls.py
│   │
│   ├── securite/                        # RBAC & audit
│   │   ├── models.py                    # Role, Permission, JournalAudit
│   │   ├── rbac.py                      # Moteur de permissions
│   │   ├── audit.py                     # Service d'audit
│   │   ├── views.py
│   │   └── urls.py
│   │
│   └── rapports/                        # Reporting & statistiques
│       ├── models.py
│       ├── services.py
│       ├── views.py
│       └── urls.py
│
├── services/                            # Services domaine transversaux
│   ├── __init__.py
│   ├── base.py                          # ServiceBase abstrait
│   └── tenant.py                        # ServiceTenant
│
├── workers/                             # Tâches Celery asynchrones
│   ├── taches_bulletins.py
│   ├── taches_badges.py
│   ├── taches_notifications.py
│   └── taches_rapports.py
│
├── templates/
│   ├── base.html
│   ├── tableau_bord/
│   ├── eleves/
│   ├── notes/
│   ├── bulletins/
│   └── finances/
│
├── static/
│   ├── css/
│   ├── js/
│   └── images/
│
├── media/                               # Fichiers uploadés (photos, docs)
│   └── [tenant_slug]/
│       ├── eleves/
│       ├── enseignants/
│       └── logos/
│
└── tests/
    ├── conftest.py
    ├── factories/
    ├── test_noyau/
    ├── test_academique/
    ├── test_notes/
    ├── test_finances/
    └── test_securite/
```

---

## 4. MODÉLISATION BASE DE DONNÉES

### 4.1 Schéma Conceptuel — Domaines

```
┌─────────────────────────────────────────────────────────────────┐
│                     DOMAINE : SAAS                               │
│  Etablissement ─── Abonnement ─── Plan ─── Licence               │
└─────────────────────────────────────────────────────────────────┘
                            │ ecole_id
┌───────────────────────────▼─────────────────────────────────────┐
│                    DOMAINE : PARAMÉTRAGE                         │
│  CycleEnseignement → Niveau → Section → Option                   │
│  TypeEvaluation, CoeffMatiere, ReglePassage, SeuilReussite        │
│  PeriodeAcademique, SystemeNotation, TypeDiscipline               │
└─────────────────────────────────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                    DOMAINE : ACADÉMIQUE                          │
│  AnneeScolaire → Trimestre/Semestre                               │
│       │                  │                                        │
│  Classe ── Matiere ── EmploiDuTemps                               │
└─────────────────────────────────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                    DOMAINE : ACTEURS                             │
│  Eleve → Inscription → ClasseEleve                               │
│  Enseignant → Affectation → ChargeHoraire                        │
└─────────────────────────────────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                    DOMAINE : ÉVALUATION                          │
│  Note → MoyenneMatiere → MoyenneGenerale → Bulletin              │
│  Composition, Rattrapage, AppreciationAutomatique                 │
└─────────────────────────────────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                   DOMAINE : FINANCES                             │
│  FraisScolaire → EcheancePaiement → Paiement → Reçu              │
│  Remise, Penalite, SoldeEleve, JournalCaisse                      │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Schéma UML Détaillé — Tables Clés

```
Etablissement
─────────────
id (PK, UUID)
slug (UNIQUE)
nom
nom_court
type_etablissement  [primaire|secondaire|technique|mixte]
pays
ville
adresse
telephone
email
logo
site_web
annee_fondation
directeur_nom
est_actif
plan_abonnement_id (FK)
date_creation
date_modification

AnneeScolaire
─────────────
id (PK)
ecole_id (FK Etablissement)
libelle            e.g. "2024-2025"
date_debut
date_fin
statut             [brouillon|active|cloturee|archivee]
est_courante       (1 seule active par école)
date_ouverture_officielle
date_cloture_officielle
verrou_administratif  (boolean)
created_by_id
created_at

PeriodeAcademique
─────────────────
id (PK)
ecole_id (FK)
annee_scolaire_id (FK)
type_periode       [trimestre|semestre|quadrimestre]
numero             (1, 2, 3...)
libelle            "1er Trimestre"
date_debut
date_fin
statut             [ouvert|cloture|publie]
poids_calcul       (Decimal, pour moyenne annuelle pondérée)

CycleEnseignement
─────────────────
id (PK)
ecole_id (FK)
code               "FOND"|"SECON"|"TECH"
libelle            "Fondamental"|"Secondaire"
ordre_affichage

Niveau
──────
id (PK)
ecole_id (FK)
cycle_id (FK)
code               "1AF"|"2AF"|...|"Philo"
libelle
ordre_affichage
duree_annees

Classe
──────
id (PK)
ecole_id (FK)
annee_scolaire_id (FK)
niveau_id (FK)
section_id (FK nullable)
option_id (FK nullable)
code               "3eA" | "Term-Sciences"
libelle
capacite_max
enseignant_titulaire_id (FK nullable)
salle

Matiere
───────
id (PK)
ecole_id (FK)
code
libelle
type              [theorique|pratique|sport|art]
est_active

CoeffMatiere
────────────
id (PK)
ecole_id (FK)
matiere_id (FK)
niveau_id (FK)
annee_scolaire_id (FK)
coefficient        (Decimal(4,2))
note_max           (Decimal(5,2))  e.g. 10.00 ou 20.00

Eleve
─────
id (PK, UUID)
ecole_id (FK)
matricule          (UNIQUE par école)
nom
prenom
date_naissance
lieu_naissance
sexe
photo
nationalite
adresse
telephone_parent
email_parent
nom_parent
statut             [actif|suspendu|transfere|abandonne|archive]
date_inscription_initiale

Inscription
───────────
id (PK)
ecole_id (FK)
eleve_id (FK)
annee_scolaire_id (FK)
classe_id (FK)
date_inscription
type_inscription   [nouveau|reinscription|transfert_entrant]
statut             [en_attente|validee|annulee|verrouilee]
numero_ordre
frais_inscription  (Decimal)
validee_par_id (FK User)
date_validation

Note
────
id (PK)
ecole_id (FK)
inscription_id (FK)
matiere_id (FK)
periode_id (FK)
type_evaluation_id (FK)
valeur             (Decimal(6,3))
note_max           (Decimal(5,2))
coefficient_applique (Decimal(4,2))  copié au moment de la saisie
est_absence        (boolean)
justification_absence
est_rattrapage
saisie_par_id (FK User)
validee_par_id (FK User nullable)
date_saisie
date_modification
est_verrouilee     (boolean)

MoyenneMatiere
──────────────
id (PK)
ecole_id (FK)
inscription_id (FK)
matiere_id (FK)
periode_id (FK)
points_obtenus     (Decimal(8,3))
points_max         (Decimal(8,3))
moyenne            (Decimal(6,4))   e.g. 5.6500
rang_classe        (int nullable)
appreciation_id (FK nullable)
est_calculee
date_calcul

MoyenneGenerale
───────────────
id (PK)
ecole_id (FK)
inscription_id (FK)
periode_id (FK)
total_points       (Decimal(10,3))
total_points_max   (Decimal(10,3))
moyenne            (Decimal(6,4))
rang_classe
mention_id (FK nullable)
est_admis          (boolean nullable — calculé selon règles école)
est_publiee        (boolean)
date_publication
verrouilee_at

Bulletin
────────
id (PK, UUID)
ecole_id (FK)
inscription_id (FK)
periode_id (FK)
moyenne_generale_id (FK)
statut             [brouillon|valide|publie|archive]
fichier_pdf        (FileField)
genere_par_id (FK User)
valide_par_id (FK User nullable)
date_generation
date_validation
date_publication
signature_directeur (boolean)
qr_code_verification (CharField)

Paiement
────────
id (PK, UUID)
ecole_id (FK)
inscription_id (FK)
type_frais_id (FK)
montant_attendu    (Decimal(10,2))
montant_paye       (Decimal(10,2))
solde_restant      (Decimal(10,2))  calculé
mode_paiement      [especes|virement|mobile_money|cheque]
reference_externe
caissier_id (FK User)
date_paiement
numero_recu        (UNIQUE par école)
remise_id (FK nullable)
penalite_id (FK nullable)
statut             [en_attente|partiel|complet|rembourse|annule]

JournalAudit
────────────
id (PK)
ecole_id (FK nullable)   # null = action système
utilisateur_id (FK nullable)
action             [creation|modification|suppression|connexion|...]
modele_cible
objet_id
donnees_avant      (JSON)
donnees_apres      (JSON)
adresse_ip
user_agent
timestamp
```

---

## 5. MODÈLES DJANGO

### 5.1 Mixins de Base

```python
# apps/noyau/mixins.py

import uuid
from django.db import models
from django.contrib.auth import get_user_model


class UUIDMixin(models.Model):
    """Remplace la PK entière par un UUID — recommandé pour les objets exposés."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    class Meta:
        abstract = True


class HorodatageMixin(models.Model):
    """Champs d'audit temporel sur tous les modèles."""
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SuppressionDouce(models.Model):
    """Soft delete : les objets supprimés restent en base."""
    supprime_le = models.DateTimeField(null=True, blank=True, db_index=True)
    supprime_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )

    def supprimer(self, utilisateur=None):
        from django.utils import timezone
        self.supprime_le = timezone.now()
        self.supprime_par = utilisateur
        self.save(update_fields=["supprime_le", "supprime_par"])

    @property
    def est_supprime(self) -> bool:
        return self.supprime_le is not None

    class Meta:
        abstract = True
```

### 5.2 Modèle Etablissement

```python
# apps/etablissements/models.py

from django.db import models
from apps.noyau.mixins import UUIDMixin, HorodatageMixin


class TypeEtablissement(models.TextChoices):
    PRIMAIRE = "primaire", "École Primaire"
    SECONDAIRE = "secondaire", "École Secondaire"
    TECHNIQUE = "technique", "École Technique"
    MIXTE = "mixte", "Établissement Mixte"
    UNIVERSITE = "universite", "Université / Institut"


class Etablissement(UUIDMixin, HorodatageMixin):
    """
    Cœur du système multitenant.
    Un enregistrement = un tenant = une école.
    """
    slug = models.SlugField(
        max_length=80,
        unique=True,
        help_text="Identifiant URL unique. Exemple: lycee-petion-cap",
    )
    nom = models.CharField(max_length=200)
    nom_court = models.CharField(max_length=50, blank=True)
    type_etablissement = models.CharField(
        max_length=20,
        choices=TypeEtablissement.choices,
        default=TypeEtablissement.MIXTE,
    )
    pays = models.CharField(max_length=50, default="HT")
    ville = models.CharField(max_length=100)
    adresse = models.TextField(blank=True)
    telephone = models.CharField(max_length=30, blank=True)
    email = models.EmailField(blank=True)
    logo = models.ImageField(upload_to="logos/%Y/", null=True, blank=True)
    site_web = models.URLField(blank=True)
    directeur_nom = models.CharField(max_length=200, blank=True)
    annee_fondation = models.PositiveSmallIntegerField(null=True, blank=True)
    est_actif = models.BooleanField(default=True, db_index=True)
    abonnement = models.ForeignKey(
        "Abonnement",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="ecoles",
    )
    # Paramètres locaux
    fuseau_horaire = models.CharField(max_length=50, default="America/Port-au-Prince")
    devise = models.CharField(max_length=5, default="HTG")
    langue_principale = models.CharField(max_length=5, default="fr")

    class Meta:
        verbose_name = "Établissement"
        verbose_name_plural = "Établissements"
        ordering = ["nom"]

    def __str__(self):
        return f"{self.nom} ({self.slug})"
```

### 5.3 Modèle AnneeScolaire avec Machine à États

```python
# apps/academique/models.py

from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError
from apps.noyau.managers import TenantModelMixin, TenantManager
from apps.noyau.mixins import HorodatageMixin, SuppressionDouce


class StatutAnneeScolaire(models.TextChoices):
    BROUILLON = "brouillon", "Brouillon"
    ACTIVE = "active", "Active"
    CLOTUREE = "cloturee", "Clôturée"
    ARCHIVEE = "archivee", "Archivée"


# Matrice des transitions autorisées
TRANSITIONS_ANNEE = {
    StatutAnneeScolaire.BROUILLON: [StatutAnneeScolaire.ACTIVE],
    StatutAnneeScolaire.ACTIVE: [StatutAnneeScolaire.CLOTUREE],
    StatutAnneeScolaire.CLOTUREE: [StatutAnneeScolaire.ARCHIVEE],
    StatutAnneeScolaire.ARCHIVEE: [],
}


class AnneeScolaire(TenantModelMixin, HorodatageMixin):
    """
    Cycle de vie strict : brouillon → active → cloturee → archivee.
    Une seule année peut être 'active' par école à tout moment.
    Les gardes métier sont dans ServiceAnneeScolaire, pas ici.
    """
    libelle = models.CharField(max_length=20, help_text="Ex: 2024-2025")
    date_debut = models.DateField()
    date_fin = models.DateField()
    statut = models.CharField(
        max_length=15,
        choices=StatutAnneeScolaire.choices,
        default=StatutAnneeScolaire.BROUILLON,
        db_index=True,
    )
    est_courante = models.BooleanField(default=False, db_index=True)
    verrou_administratif = models.BooleanField(
        default=False,
        help_text="Verrouille toutes les inscriptions et modifications.",
    )
    date_ouverture_officielle = models.DateField(null=True, blank=True)
    date_cloture_officielle = models.DateField(null=True, blank=True)
    cree_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )

    objects = TenantManager()

    class Meta:
        verbose_name = "Année Scolaire"
        verbose_name_plural = "Années Scolaires"
        unique_together = [("ecole", "libelle")]
        ordering = ["-date_debut"]

    def peut_transitionner_vers(self, nouveau_statut: str) -> bool:
        transitions = TRANSITIONS_ANNEE.get(self.statut, [])
        return nouveau_statut in transitions

    def __str__(self):
        return f"{self.ecole.nom_court} — {self.libelle} ({self.statut})"


class StatutPeriode(models.TextChoices):
    OUVERTE = "ouverte", "Ouverte"
    CLOTUREE = "cloturee", "Clôturée"
    PUBLIEE = "publiee", "Publiée"


class PeriodeAcademique(TenantModelMixin, HorodatageMixin):
    """
    Trimestre, semestre ou autre découpage défini par l'école.
    Le type est configurable — pas de "trimestre" codé en dur.
    """
    annee_scolaire = models.ForeignKey(
        AnneeScolaire,
        on_delete=models.PROTECT,
        related_name="periodes",
    )
    type_periode = models.CharField(max_length=20)  # défini dans parametrage
    numero = models.PositiveSmallIntegerField()
    libelle = models.CharField(max_length=60)
    date_debut = models.DateField()
    date_fin = models.DateField()
    statut = models.CharField(
        max_length=10,
        choices=StatutPeriode.choices,
        default=StatutPeriode.OUVERTE,
    )
    poids_calcul = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        default=Decimal("1.00"),
        help_text="Poids pour le calcul de la moyenne annuelle.",
    )

    class Meta:
        verbose_name = "Période Académique"
        unique_together = [("ecole", "annee_scolaire", "type_periode", "numero")]
        ordering = ["numero"]
```

### 5.4 Modèle Note

```python
# apps/notes/models.py

from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError
from apps.noyau.managers import TenantModelMixin
from apps.noyau.mixins import HorodatageMixin, SuppressionDouce


class Note(TenantModelMixin, HorodatageMixin, SuppressionDouce):
    """
    Valeur élémentaire du système d'évaluation.
    Immuable après verrouillage. Les calculs sont délégués au moteur.
    """
    inscription = models.ForeignKey(
        "eleves.Inscription",
        on_delete=models.PROTECT,
        related_name="notes",
    )
    matiere = models.ForeignKey(
        "parametrage.Matiere",
        on_delete=models.PROTECT,
    )
    periode = models.ForeignKey(
        "academique.PeriodeAcademique",
        on_delete=models.PROTECT,
    )
    type_evaluation = models.ForeignKey(
        "parametrage.TypeEvaluation",
        on_delete=models.PROTECT,
    )
    valeur = models.DecimalField(
        max_digits=6,
        decimal_places=3,
        null=True,
        blank=True,
        help_text="Null si absence non justifiée.",
    )
    note_max = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        help_text="Copié depuis CoeffMatiere au moment de la saisie.",
    )
    coefficient_applique = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        help_text="Coefficient figé au moment de la saisie — immuable.",
    )
    est_absence = models.BooleanField(default=False)
    justification_absence = models.TextField(blank=True)
    est_rattrapage = models.BooleanField(default=False)
    saisie_par = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="notes_saisies",
    )
    validee_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="notes_validees",
    )
    est_verrouilee = models.BooleanField(default=False, db_index=True)

    class Meta:
        verbose_name = "Note"
        verbose_name_plural = "Notes"
        indexes = [
            models.Index(fields=["inscription", "matiere", "periode"]),
            models.Index(fields=["ecole", "periode"]),
        ]

    def clean(self):
        if self.est_verrouilee:
            raise ValidationError("Cette note est verrouillée et ne peut être modifiée.")
        if self.valeur is not None and self.valeur > self.note_max:
            raise ValidationError(
                f"La note ({self.valeur}) dépasse le maximum autorisé ({self.note_max})."
            )
        if self.valeur is not None and self.valeur < Decimal("0"):
            raise ValidationError("Une note ne peut pas être négative.")
```

---

## 6. SERVICES MÉTIER

### 6.1 Architecture des Services

```
Principe : Les vues ne contiennent aucune logique métier.
           Les modèles ne contiennent que la structure et les validations atomiques.
           Toute logique complexe vit dans les services.

ServiceBase
    └── ServiceAnneeScolaire   (transitions, verrouillage, stats)
    └── ServiceInscription     (inscription, réinscription, transfert, abandon)
    └── ServiceCalculMoyenne   (moteur de calcul central)
    └── ServiceBulletin        (génération, validation, publication)
    └── ServicePaiement        (enregistrement, récus, soldes)
    └── ServiceBadge           (génération PDF + QR)
    └── ServiceAudit           (journal immuable)
```

### 6.2 ServiceAnneeScolaire

```python
# apps/academique/services.py

from django.db import transaction
from django.utils import timezone
from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
from apps.noyau.exceptions import TransitionInterditError, RegleMetierError
from apps.securite.audit import ServiceAudit


class ServiceAnneeScolaire:
    """
    Gère le cycle de vie d'une année scolaire.
    Toutes les transitions d'état passent par ici — jamais directement sur le modèle.
    """

    def __init__(self, utilisateur):
        self.utilisateur = utilisateur
        self.audit = ServiceAudit(utilisateur)

    @transaction.atomic
    def activer(self, annee: AnneeScolaire) -> AnneeScolaire:
        """
        Passe une année de brouillon → active.
        Gardes : pas d'autre année active, paramétrage complet.
        """
        if not annee.peut_transitionner_vers(StatutAnneeScolaire.ACTIVE):
            raise TransitionInterditError(
                f"Transition impossible : {annee.statut} → active"
            )

        # Garde : unicité de l'année active par école
        if AnneeScolaire.objects.filter(
            ecole=annee.ecole,
            statut=StatutAnneeScolaire.ACTIVE,
        ).exists():
            raise RegleMetierError(
                "Une année scolaire est déjà active pour cet établissement."
            )

        # Garde : vérifier que les classes existent
        if not annee.classes.exists():
            raise RegleMetierError(
                "Impossible d'activer une année sans classes configurées."
            )

        donnees_avant = {"statut": annee.statut}
        annee.statut = StatutAnneeScolaire.ACTIVE
        annee.est_courante = True
        annee.date_ouverture_officielle = timezone.now().date()
        annee.save(update_fields=["statut", "est_courante", "date_ouverture_officielle"])

        self.audit.enregistrer(
            action="activation_annee_scolaire",
            objet=annee,
            donnees_avant=donnees_avant,
            donnees_apres={"statut": annee.statut},
        )
        return annee

    @transaction.atomic
    def cloturer(self, annee: AnneeScolaire) -> AnneeScolaire:
        """
        Passe une année de active → cloturee.
        Vérifie que tous les bulletins sont publiés.
        """
        if not annee.peut_transitionner_vers(StatutAnneeScolaire.CLOTUREE):
            raise TransitionInterditError(
                f"Transition impossible : {annee.statut} → cloturee"
            )

        bulletins_non_publies = (
            annee.inscriptions
            .filter(bulletins__statut__in=["brouillon", "valide"])
            .count()
        )
        if bulletins_non_publies > 0:
            raise RegleMetierError(
                f"{bulletins_non_publies} bulletin(s) non publié(s). "
                "Publier tous les bulletins avant de clôturer l'année."
            )

        donnees_avant = {"statut": annee.statut}
        annee.statut = StatutAnneeScolaire.CLOTUREE
        annee.est_courante = False
        annee.verrou_administratif = True
        annee.date_cloture_officielle = timezone.now().date()
        annee.save(update_fields=[
            "statut", "est_courante", "verrou_administratif", "date_cloture_officielle"
        ])

        self.audit.enregistrer(
            action="cloture_annee_scolaire",
            objet=annee,
            donnees_avant=donnees_avant,
            donnees_apres={"statut": annee.statut},
        )
        return annee
```

### 6.3 ServiceInscription

```python
# apps/eleves/services.py

from django.db import transaction
from django.utils import timezone
from apps.eleves.models import Eleve, Inscription, StatutInscription
from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
from apps.noyau.exceptions import RegleMetierError
from apps.securite.audit import ServiceAudit


class ServiceInscription:

    def __init__(self, utilisateur):
        self.utilisateur = utilisateur
        self.audit = ServiceAudit(utilisateur)

    @transaction.atomic
    def inscrire(
        self,
        eleve: Eleve,
        annee: AnneeScolaire,
        classe,
        type_inscription: str = "nouveau",
    ) -> Inscription:
        """Inscrit un élève avec toutes les gardes métier."""

        # Garde 1 : l'année doit être active
        if annee.statut != StatutAnneeScolaire.ACTIVE:
            raise RegleMetierError("Les inscriptions ne sont ouvertes que sur une année active.")

        # Garde 2 : verrou administratif
        if annee.verrou_administratif:
            raise RegleMetierError(
                "L'année scolaire est verrouillée administrativement. "
                "Aucune inscription n'est possible."
            )

        # Garde 3 : pas de double inscription
        if Inscription.objects.filter(
            eleve=eleve, annee_scolaire=annee
        ).exists():
            raise RegleMetierError(
                f"{eleve} est déjà inscrit pour l'année {annee.libelle}."
            )

        # Garde 4 : capacité de la classe
        if classe.capacite_max:
            inscrits = Inscription.objects.filter(
                classe=classe,
                annee_scolaire=annee,
                statut=StatutInscription.VALIDEE,
            ).count()
            if inscrits >= classe.capacite_max:
                raise RegleMetierError(
                    f"La classe {classe} a atteint sa capacité maximale ({classe.capacite_max})."
                )

        inscription = Inscription.objects.create(
            ecole=annee.ecole,
            eleve=eleve,
            annee_scolaire=annee,
            classe=classe,
            type_inscription=type_inscription,
            statut=StatutInscription.EN_ATTENTE,
            date_inscription=timezone.now().date(),
        )

        self.audit.enregistrer(
            action="inscription_eleve",
            objet=inscription,
            donnees_apres={
                "eleve": str(eleve),
                "classe": str(classe),
                "annee": annee.libelle,
            },
        )
        return inscription
```

---

## 7. MOTEUR D'ÉTATS & WORKFLOWS

### 7.1 Carte Complète des États Métier

```
ANNÉE SCOLAIRE
──────────────
brouillon ──[activer]──→ active ──[cloturer]──→ cloturee ──[archiver]──→ archivee

PÉRIODE (Trimestre / Semestre)
──────────────────────────────
ouverte ──[cloturer_periode]──→ cloturee ──[publier]──→ publiee
  ↑ Blocage saisie de notes après cloture
  ↑ Blocage modification après publication

INSCRIPTION
───────────
en_attente ──[valider]──→ validee ──[verrouiller]──→ verrouilee
              │
              └──[annuler]──→ annulee

BULLETIN
────────
brouillon ──[valider]──→ valide ──[publier]──→ publie ──[archiver]──→ archive
  ↑ Bloqué si MoyenneGenerale non calculée
  ↑ Bloqué si période non close
  ↑ PDF généré uniquement à l'état publie

PAIEMENT
────────
en_attente ──[enregistrer_versement]──→ partiel ──[solder]──→ complet
en_attente ──[annuler]──→ annule
complet ──[rembourser]──→ rembourse
```

### 7.2 Gardes Métier par Domaine

```python
# apps/noyau/gardes.py

from apps.noyau.exceptions import RegleMetierError
from apps.academique.models import PeriodeAcademique, StatutPeriode
from apps.academique.models import AnneeScolaire, StatutAnneeScolaire


def verifier_saisie_note_autorisee(periode: PeriodeAcademique) -> None:
    """Bloque la saisie si la période est close ou publiée."""
    if periode.statut in [StatutPeriode.CLOTUREE, StatutPeriode.PUBLIEE]:
        raise RegleMetierError(
            f"La période '{periode.libelle}' est {periode.statut}. "
            "La saisie de notes est impossible."
        )
    if periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE:
        raise RegleMetierError(
            "L'année scolaire n'est pas active. Saisie de notes impossible."
        )


def verifier_modification_moyenne_autorisee(moyenne) -> None:
    """Bloque toute modification après publication."""
    if moyenne.est_publiee:
        raise RegleMetierError(
            "Cette moyenne est publiée. Toute modification est interdite."
        )


def verifier_generation_bulletin_autorisee(inscription, periode: PeriodeAcademique) -> None:
    """Un bulletin ne peut être généré que si la période est close."""
    if periode.statut == StatutPeriode.OUVERTE:
        raise RegleMetierError(
            "La période est encore ouverte. Clôturer la période avant de générer les bulletins."
        )
    # Vérifier que toutes les notes sont saisies
    from apps.notes.models import Note
    matieres_attendues = inscription.classe.matieres.count()
    notes_saisies = Note.objects.filter(
        inscription=inscription,
        periode=periode,
        est_verrouilee=True,
    ).values("matiere").distinct().count()
    if notes_saisies < matieres_attendues:
        raise RegleMetierError(
            f"Seulement {notes_saisies}/{matieres_attendues} matières ont des notes validées."
        )
```

---

## 8. SYSTÈME RBAC & PERMISSIONS

### 8.1 Hiérarchie des Rôles

```
SuperAdmin (Anthropic/Éditeur SaaS)
    └── AdminEtablissement (Directeur de l'école)
            ├── Secrétaire
            ├── Comptable
            ├── Enseignant
            ├── Surveillant
            └── Parent (lecture seule)
```

### 8.2 Modèles RBAC

```python
# apps/securite/models.py

from django.db import models
from apps.noyau.managers import TenantModelMixin
from apps.noyau.mixins import HorodatageMixin


class Role(TenantModelMixin, HorodatageMixin):
    """Rôle défini par école — pas de rôles globaux rigides."""
    code = models.CharField(max_length=40)
    libelle = models.CharField(max_length=100)
    est_systeme = models.BooleanField(
        default=False,
        help_text="Rôles créés automatiquement à l'ouverture d'un compte.",
    )
    permissions = models.ManyToManyField(
        "PermissionGranulaire",
        blank=True,
        related_name="roles",
    )

    class Meta:
        unique_together = [("ecole", "code")]


class PermissionGranulaire(models.Model):
    """
    Catalogue global des permissions du système.
    Format : <module>.<action>.<portee>
    Exemples : notes.saisir.propres_classes
               bulletins.publier.toutes_classes
               finances.consulter.propres_eleves
               annee_scolaire.cloturer.etablissement
    """
    code = models.CharField(max_length=100, unique=True)
    description = models.CharField(max_length=200)
    module = models.CharField(max_length=40)
    action = models.CharField(max_length=40)
    portee = models.CharField(max_length=40)

    class Meta:
        ordering = ["module", "action"]


class UtilisateurRole(TenantModelMixin, HorodatageMixin):
    """Association utilisateur ↔ rôle dans un établissement."""
    utilisateur = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.CASCADE,
        related_name="roles_etablissement",
    )
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    attribue_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    est_actif = models.BooleanField(default=True)
    expire_le = models.DateField(null=True, blank=True)

    class Meta:
        unique_together = [("ecole", "utilisateur", "role")]
```

### 8.3 Décorateurs de Permission

```python
# apps/noyau/decorateurs.py

from functools import wraps
from django.core.exceptions import PermissionDenied
from apps.securite.rbac import moteur_rbac


def requiert_permission(code_permission: str):
    """
    Décorateur de vue vérifiant une permission RBAC.
    Usage : @requiert_permission("notes.saisir.propres_classes")
    """
    def decorateur(vue_func):
        @wraps(vue_func)
        def wrapper(request, *args, **kwargs):
            if not moteur_rbac.possede_permission(
                utilisateur=request.user,
                ecole=request.etablissement,
                code_permission=code_permission,
            ):
                raise PermissionDenied(
                    f"Permission refusée : {code_permission}"
                )
            return vue_func(request, *args, **kwargs)
        return wrapper
    return decorateur
```

---

## 9. MOTEUR DE CALCUL DES MOYENNES

### 9.1 Principe et Fiabilité

**Règle absolue : utiliser `decimal.Decimal` partout. Jamais `float`.**

Le calcul 678/1200 doit donner exactement `0.565000` puis `5.6500/10`.

### 9.2 Formules

**Système haïtien (exemple) :**
```
Note sur 10 = (Total points obtenus / Total points max) × 10
```

**Système sur 20 :**
```
Note sur 20 = (Total points obtenus / Total points max) × 20
```

**Avec coefficients :**
```
Points matière = Σ(note_i × coeff_i) / Σ(coeff_i)
Moyenne générale = Σ(points_matière) / Total_coefficients × base
```

### 9.3 Moteur de Calcul

```python
# apps/notes/moteur.py

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from dataclasses import dataclass
from typing import Optional
from apps.notes.models import Note
from apps.noyau.exceptions import ErreurCalcul


@dataclass
class ResultatCalcul:
    points_obtenus: Decimal
    points_max: Decimal
    note_sur_base: Decimal
    base: Decimal  # 10 ou 20 selon l'école
    nombre_evaluations: int
    detail: dict


class MoteurCalculMoyenne:
    """
    Moteur central de calcul des moyennes.
    Configurable par école : base de notation, règles de pondération.
    Toute la précision décimale est garantie ici.
    """

    PRECISION = Decimal("0.0001")
    ARRONDI = ROUND_HALF_UP

    def calculer_moyenne_matiere(
        self,
        notes: list[Note],
        base_notation: Decimal = Decimal("10"),
    ) -> ResultatCalcul:
        """
        Calcule la moyenne pour une matière sur une période.
        Formule : Σ(valeur × coeff) / Σ(coeff) normalisée sur base.
        """
        if not notes:
            raise ErreurCalcul("Impossible de calculer une moyenne sans notes.")

        numerateur = Decimal("0")
        denominateur = Decimal("0")
        detail = {}

        for note in notes:
            if note.est_absence and not note.justification_absence:
                # Absence non justifiée = 0
                valeur_effective = Decimal("0")
            elif note.valeur is None:
                continue  # Note non saisie — ignorée
            else:
                valeur_effective = note.valeur

            # Normaliser sur 100 pour unifier différents barèmes
            if note.note_max == Decimal("0"):
                raise ErreurCalcul(f"Note max invalide (0) pour note #{note.pk}")

            valeur_sur_100 = (valeur_effective / note.note_max) * Decimal("100")
            contribution = valeur_sur_100 * note.coefficient_applique

            numerateur += contribution
            denominateur += note.coefficient_applique

            detail[str(note.pk)] = {
                "valeur": str(valeur_effective),
                "sur": str(note.note_max),
                "coeff": str(note.coefficient_applique),
                "contribution": str(contribution),
            }

        if denominateur == Decimal("0"):
            raise ErreurCalcul("Somme des coefficients égale à zéro.")

        # Moyenne sur 100, puis ramenée à la base de l'école
        moyenne_sur_100 = numerateur / denominateur
        note_sur_base = (moyenne_sur_100 / Decimal("100")) * base_notation
        note_sur_base = note_sur_base.quantize(self.PRECISION, rounding=self.ARRONDI)

        return ResultatCalcul(
            points_obtenus=numerateur.quantize(self.PRECISION, rounding=self.ARRONDI),
            points_max=denominateur * Decimal("100"),
            note_sur_base=note_sur_base,
            base=base_notation,
            nombre_evaluations=len(notes),
            detail=detail,
        )

    def calculer_moyenne_generale(
        self,
        moyennes_matieres: list[tuple[ResultatCalcul, Decimal]],
        # (résultat_matiere, coefficient_matiere)
        base_notation: Decimal = Decimal("10"),
    ) -> ResultatCalcul:
        """
        Calcule la moyenne générale depuis les moyennes par matière.
        Pondérée par les coefficients de chaque matière.
        """
        if not moyennes_matieres:
            raise ErreurCalcul("Aucune matière pour le calcul de la moyenne générale.")

        numerateur = Decimal("0")
        denominateur = Decimal("0")
        detail = {}

        for resultat, coeff_matiere in moyennes_matieres:
            contribution = resultat.note_sur_base * coeff_matiere
            numerateur += contribution
            denominateur += coeff_matiere
            detail[f"coeff_{coeff_matiere}"] = str(resultat.note_sur_base)

        if denominateur == Decimal("0"):
            raise ErreurCalcul("Somme des coefficients de matières égale à zéro.")

        moyenne = (numerateur / denominateur).quantize(self.PRECISION, rounding=self.ARRONDI)

        return ResultatCalcul(
            points_obtenus=numerateur.quantize(self.PRECISION),
            points_max=denominateur * base_notation,
            note_sur_base=moyenne,
            base=base_notation,
            nombre_evaluations=len(moyennes_matieres),
            detail=detail,
        )


# Validation : 678 / 1200 × 10 = 5.65
assert MoteurCalculMoyenne().calculer_moyenne_matiere(
    notes=[],  # test unitaire réel dans tests/
    base_notation=Decimal("10"),
)
```

---

## 10. SYSTÈME DE BADGES & IDENTITÉ

### 10.1 Architecture

```python
# apps/badges/generateurs/badge_eleve.py

import qrcode
import barcode
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.lib.units import mm
from apps.badges.models import TemplateBadge


class GenerateurBadgeEleve:
    """
    Génère les badges élèves en PDF ou image.
    Le template est configurable par école (couleurs, disposition, champs).
    """

    LARGEUR_BADGE = 85 * mm   # Carte ID standard
    HAUTEUR_BADGE = 54 * mm

    def generer_badge(self, inscription, template: TemplateBadge) -> BytesIO:
        """Génère un badge PDF pour un élève."""
        buffer = BytesIO()
        c = pdf_canvas.Canvas(buffer, pagesize=(self.LARGEUR_BADGE, self.HAUTEUR_BADGE))

        self._dessiner_fond(c, template)
        self._dessiner_logo(c, inscription.ecole, template)
        self._dessiner_photo(c, inscription.eleve, template)
        self._dessiner_infos_eleve(c, inscription, template)
        self._dessiner_qr_code(c, inscription, template)
        self._dessiner_code_barres(c, inscription, template)

        c.save()
        buffer.seek(0)
        return buffer

    def _generer_qr_code(self, inscription) -> BytesIO:
        """QR Code encodant le matricule + école + année."""
        donnees = f"ELEVE:{inscription.eleve.matricule}:{inscription.ecole.slug}:{inscription.annee_scolaire.libelle}"
        qr = qrcode.QRCode(version=1, box_size=3, border=2)
        qr.add_data(donnees)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf

    def _generer_code_barres(self, matricule: str) -> BytesIO:
        """Code-barres Code128 sur le matricule."""
        CODE128 = barcode.get_barcode_class("code128")
        buf = BytesIO()
        CODE128(matricule, writer=barcode.writer.ImageWriter()).write(buf)
        buf.seek(0)
        return buf
```

---

## 11. MODULE FINANCES

### 11.1 Modèles Financiers

```python
# apps/finances/models.py

from decimal import Decimal
from django.db import models
from apps.noyau.managers import TenantModelMixin
from apps.noyau.mixins import HorodatageMixin


class TypeFrais(TenantModelMixin, HorodatageMixin):
    """Frais configurables par école : inscription, mensualité, cantine..."""
    code = models.CharField(max_length=30)
    libelle = models.CharField(max_length=100)
    est_obligatoire = models.BooleanField(default=True)
    montant_defaut = models.DecimalField(max_digits=10, decimal_places=2)
    frequence = models.CharField(
        max_length=15,
        choices=[
            ("unique", "Unique"),
            ("mensuel", "Mensuel"),
            ("trimestriel", "Trimestriel"),
            ("annuel", "Annuel"),
        ],
    )

    class Meta:
        unique_together = [("ecole", "code")]


class FraisScolaireEleve(TenantModelMixin, HorodatageMixin):
    """Frais assigné à un élève pour une année scolaire."""
    inscription = models.ForeignKey("eleves.Inscription", on_delete=models.PROTECT)
    type_frais = models.ForeignKey(TypeFrais, on_delete=models.PROTECT)
    montant_total = models.DecimalField(max_digits=10, decimal_places=2)
    remise = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0"))
    montant_net = models.DecimalField(max_digits=10, decimal_places=2)
    # montant_net = montant_total - remise

    def calculer_solde(self) -> Decimal:
        """Retourne le solde restant dû."""
        total_verse = sum(
            p.montant_paye for p in self.paiements.filter(
                statut__in=["partiel", "complet"]
            )
        )
        return self.montant_net - total_verse


class Paiement(TenantModelMixin, HorodatageMixin):
    """Enregistrement immuable d'un paiement."""
    frais_eleve = models.ForeignKey(
        FraisScolaireEleve,
        on_delete=models.PROTECT,
        related_name="paiements",
    )
    montant_paye = models.DecimalField(max_digits=10, decimal_places=2)
    mode_paiement = models.CharField(max_length=20)
    reference_externe = models.CharField(max_length=100, blank=True)
    caissier = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="paiements_enregistres",
    )
    date_paiement = models.DateTimeField()
    numero_recu = models.CharField(max_length=30)
    statut = models.CharField(max_length=15)
    notes_caissier = models.TextField(blank=True)
    est_annule = models.BooleanField(default=False)
    annule_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="paiements_annules",
    )

    class Meta:
        unique_together = [("ecole", "numero_recu")]
```

---

## 12. AUDIT & TRAÇABILITÉ

### 12.1 Service d'Audit Systématique

```python
# apps/securite/audit.py

import json
from django.db import models
from django.utils import timezone
from apps.securite.models import JournalAudit


class ServiceAudit:
    """
    Service d'audit immuable.
    Chaque action métier significative est enregistrée.
    Les entrées ne peuvent jamais être modifiées ou supprimées.
    """

    def __init__(self, utilisateur=None, ecole=None):
        self.utilisateur = utilisateur
        self.ecole = ecole or (
            getattr(utilisateur, "etablissement_courant", None)
            if utilisateur else None
        )

    def enregistrer(
        self,
        action: str,
        objet=None,
        donnees_avant: dict = None,
        donnees_apres: dict = None,
        adresse_ip: str = None,
        metadata: dict = None,
    ) -> JournalAudit:
        """
        Crée une entrée d'audit immuable.
        Ne lève jamais d'exception — l'audit ne doit pas bloquer le métier.
        """
        try:
            return JournalAudit.tous_objets.create(
                ecole=self.ecole,
                utilisateur=self.utilisateur,
                action=action,
                modele_cible=type(objet).__name__ if objet else "",
                objet_id=str(objet.pk) if objet else "",
                donnees_avant=json.dumps(donnees_avant or {}, default=str),
                donnees_apres=json.dumps(donnees_apres or {}, default=str),
                adresse_ip=adresse_ip or "",
                metadata=json.dumps(metadata or {}, default=str),
                timestamp=timezone.now(),
            )
        except Exception as exc:
            # Log critique mais ne remonte pas au métier
            import logging
            logging.getLogger("audit").critical(
                f"ÉCHEC AUDIT : action={action} erreur={exc}"
            )
```

### 12.2 Signaux Django pour l'Audit Automatique

```python
# apps/noyau/signaux.py

from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from apps.notes.models import Note
from apps.finances.models import Paiement
from apps.securite.audit import ServiceAudit


@receiver(post_save, sender=Note)
def auditer_modification_note(sender, instance, created, **kwargs):
    """Signal : toute création/modification de note est auditée."""
    action = "creation_note" if created else "modification_note"
    ServiceAudit().enregistrer(
        action=action,
        objet=instance,
        donnees_apres={
            "valeur": str(instance.valeur),
            "matiere": str(instance.matiere),
            "periode": str(instance.periode),
            "verrouilee": instance.est_verrouilee,
        },
    )
```

---

## 13. APIs

### 13.1 Structure des Routes

```python
# config/urls.py

from django.urls import path, include

urlpatterns = [
    # Administration SaaS (pas de tenant requis)
    path("saas/", include("apps.etablissements.urls_saas")),
    path("admin/", include("apps.comptes.urls_admin")),

    # Routes protégées par tenant (TenantMiddleware actif)
    path("tableau-bord/", include("apps.tableau_bord.urls")),
    path("academique/", include("apps.academique.urls")),
    path("eleves/", include("apps.eleves.urls")),
    path("enseignants/", include("apps.enseignants.urls")),
    path("classes/", include("apps.classes.urls")),
    path("notes/", include("apps.notes.urls")),
    path("bulletins/", include("apps.bulletins.urls")),
    path("finances/", include("apps.finances.urls")),
    path("badges/", include("apps.badges.urls")),
    path("rapports/", include("apps.rapports.urls")),
    path("securite/", include("apps.securite.urls")),

    # API REST (si nécessaire en v2)
    path("api/v1/", include("apps.api.urls")),

    # Santé système
    path("sante/", include("apps.noyau.urls_sante")),
]
```

---

## 14. SÉCURITÉ

### 14.1 Checklist Sécurité Production

```python
# config/settings/production.py

# --- Sécurité Django core ---
DEBUG = False
SECRET_KEY = env("SECRET_KEY")  # Variable d'environnement obligatoire
ALLOWED_HOSTS = env.list("ALLOWED_HOSTS")

# --- HTTPS strict ---
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = "DENY"
SECURE_CONTENT_TYPE_NOSNIFF = True

# --- Sessions ---
SESSION_COOKIE_AGE = 3600 * 8  # 8 heures
SESSION_EXPIRE_AT_BROWSER_CLOSE = True

# --- Uploads sécurisés ---
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024  # 5MB max
MEDIA_ROOT = env("MEDIA_ROOT")  # Hors du webroot en prod
```

### 14.2 Isolation Tenant — Points Critiques

```
RISQUE 1 : QuerySet cross-tenant via related_name
  Solution : TenantManager override sur TOUS les modèles tenant

RISQUE 2 : URL manipulation (accès à l'ID d'un autre tenant)
  Solution : Toujours vérifier ecole=request.etablissement dans les vues
             Mixin TenantObjectMixin sur toutes les vues detail

RISQUE 3 : Fichiers médias cross-tenant
  Solution : Chemin upload = "media/{slug}/{type}/{uuid}.ext"
             Serveur de médias avec vérification tenant

RISQUE 4 : Tâches Celery sans contexte tenant
  Solution : Toujours passer ecole_id dans les tâches,
             ne jamais utiliser le thread local dans les workers
```

### 14.3 TenantObjectMixin pour les Vues

```python
# apps/noyau/mixins.py (suite)

from django.core.exceptions import PermissionDenied
from django.views.generic.detail import SingleObjectMixin


class TenantObjectMixin(SingleObjectMixin):
    """
    Garantit que l'objet demandé appartient bien au tenant courant.
    À hériter sur toutes les vues DetailView, UpdateView, DeleteView.
    """

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.filter(ecole=self.request.etablissement)

    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        if obj.ecole != self.request.etablissement:
            raise PermissionDenied("Accès interdit : objet hors tenant.")
        return obj
```

---

## 15. PERFORMANCE & OPTIMISATIONS

### 15.1 Index Base de Données

```python
# Sur tous les modèles tenant critiques
class Meta:
    indexes = [
        # Sélectivité maximale : filtre tenant + filtre métier
        models.Index(fields=["ecole", "annee_scolaire"], name="idx_ecole_annee"),
        models.Index(fields=["ecole", "statut"], name="idx_ecole_statut"),

        # Notes : accès fréquent par élève/période
        models.Index(
            fields=["ecole", "inscription", "periode", "matiere"],
            name="idx_note_complet",
        ),

        # Finances : recherche par élève + statut
        models.Index(fields=["ecole", "inscription", "statut"], name="idx_paiement"),
    ]
```

### 15.2 Optimisation des QuerySets

```python
# Pattern recommandé pour les vues listes

def get_queryset(self):
    return (
        Inscription.objects
        .filter(annee_scolaire=annee_courante)
        .select_related("eleve", "classe", "classe__niveau")
        .prefetch_related("notes__matiere", "paiements")
        .only(
            "id", "eleve__nom", "eleve__prenom", "eleve__matricule",
            "classe__code", "statut", "date_inscription"
        )
        .order_by("classe__code", "eleve__nom")
    )
```

### 15.3 Cache avec Redis

```python
# apps/notes/services.py — Cache des moyennes calculées

from django.core.cache import cache
from decimal import Decimal


def obtenir_moyenne_cachee(inscription_id: int, periode_id: int) -> Decimal | None:
    """
    Cache des moyennes générales — invalidé à chaque modification de note.
    TTL : 1 heure (les moyennes sont recalculées rarement).
    """
    cle = f"moyenne:{inscription_id}:{periode_id}"
    return cache.get(cle)


def invalider_cache_moyenne(inscription_id: int, periode_id: int) -> None:
    cle = f"moyenne:{inscription_id}:{periode_id}"
    cache.delete(cle)
```

### 15.4 Tâches Celery Asynchrones

```python
# workers/taches_bulletins.py

from celery import shared_task
from apps.bulletins.services import ServiceGenBulletin
from apps.academique.models import PeriodeAcademique


@shared_task(
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    name="bulletins.generer_masse",
)
def generer_bulletins_masse(self, ecole_id: str, periode_id: int):
    """
    Génère tous les bulletins d'une période en tâche de fond.
    Utilisé pour les fins de trimestre (peut traiter 500+ élèves).
    """
    try:
        from apps.etablissements.models import Etablissement
        from apps.noyau.middleware import definir_tenant_courant

        ecole = Etablissement.objects.get(id=ecole_id)
        definir_tenant_courant(ecole)

        periode = PeriodeAcademique.objects.get(id=periode_id, ecole=ecole)
        service = ServiceGenBulletin(ecole=ecole)
        resultat = service.generer_tous(periode)

        return {
            "generes": resultat.nb_generes,
            "erreurs": resultat.nb_erreurs,
            "duree_secondes": resultat.duree,
        }
    except Exception as exc:
        raise self.retry(exc=exc)
    finally:
        definir_tenant_courant(None)
```

---

## 16. TESTS

### 16.1 Structure et Stratégie

```
tests/
├── conftest.py               # Fixtures globales (école, utilisateurs, données de base)
├── factories/
│   ├── etablissements.py     # EtablissementFactory
│   ├── academique.py         # AnneeScolaireFactory, PeriodeFactory
│   ├── eleves.py             # EleveFactory, InscriptionFactory
│   └── notes.py              # NoteFactory
├── test_noyau/
│   └── test_middleware.py    # Isolation tenant, accès croisés
├── test_academique/
│   └── test_workflows.py     # Transitions d'état
├── test_notes/
│   ├── test_moteur.py        # Calculs de moyennes (cas limites)
│   └── test_gardes.py        # Gardes métier
├── test_finances/
│   └── test_paiements.py
└── test_securite/
    └── test_rbac.py
```

### 16.2 Tests Critiques — Moteur de Calcul

```python
# tests/test_notes/test_moteur.py

import pytest
from decimal import Decimal
from apps.notes.moteur import MoteurCalculMoyenne, ResultatCalcul


class TestMoteurCalculMoyenne:
    """Tests du moteur de calcul — cas réels et cas limites."""

    def test_calcul_exemple_reel_678_sur_1200(self):
        """
        Cas réel documenté dans le cahier des charges.
        678 points / 1200 max → 5.65 / 10
        """
        moteur = MoteurCalculMoyenne()
        # Simuler 12 matières avec 100 pts max × coeff 1
        # Élève total : 678 pts sur 1200
        # Résultat attendu : 5.6500
        resultat = moteur._calculer_depuis_points(
            points_obtenus=Decimal("678"),
            points_max=Decimal("1200"),
            base=Decimal("10"),
        )
        assert resultat == Decimal("5.6500")

    def test_precision_decimale_pas_de_float(self):
        """Vérifie qu'aucun float ne s'introduit dans les calculs."""
        resultat = Decimal("678") / Decimal("1200") * Decimal("10")
        assert str(resultat) != "5.65"  # float donnerait une approximation
        resultat_arrondi = resultat.quantize(Decimal("0.0001"))
        assert resultat_arrondi == Decimal("5.6500")

    def test_absence_non_justifiee_compte_zero(self):
        """Une absence non justifiée vaut 0 dans le calcul."""
        ...

    def test_note_superieure_au_max_rejetee(self):
        """Une note > note_max doit lever une ValidationError."""
        ...

    def test_isolation_tenant_aucune_note_etrangere(self):
        """Les notes d'une autre école ne doivent jamais apparaître."""
        ...
```

### 16.3 Fixtures avec Factory Boy

```python
# tests/factories/academique.py

import factory
from factory.django import DjangoModelFactory
from apps.academique.models import AnneeScolaire, StatutAnneeScolaire


class AnneeScolaireFactory(DjangoModelFactory):
    ecole = factory.SubFactory("tests.factories.EtablissementFactory")
    libelle = factory.Sequence(lambda n: f"202{n}-202{n+1}")
    date_debut = factory.Faker("date_this_decade")
    date_fin = factory.Faker("date_this_decade")
    statut = StatutAnneeScolaire.BROUILLON
    est_courante = False

    class Meta:
        model = AnneeScolaire
```

---

## 17. DÉPLOIEMENT

### 17.1 Architecture de Déploiement

```
┌─────────────────────────────────────────┐
│           NGINX (reverse proxy)          │
│  *.scolaire.ht → Django (Gunicorn)       │
│  /media/ → Serveur fichiers direct        │
│  /static/ → Cache statique               │
└────────────────┬────────────────────────┘
                 │
        ┌────────▼────────┐
        │  Gunicorn        │
        │  4 workers       │
        │  Django 4.2      │
        └────────┬─────────┘
                 │
      ┌──────────▼──────────┐
      │  MySQL (XAMPP)       │   ← Dev
      │  MySQL Server prod   │   ← Prod
      └─────────────────────┘

      ┌──────────────────────┐
      │  Redis               │
      │  Cache + Celery      │
      └──────────────────────┘

      ┌──────────────────────┐
      │  Celery Worker(s)    │
      │  tâches async        │
      └──────────────────────┘
```

### 17.2 Configuration NGINX (référence)

```nginx
server {
    listen 80;
    server_name ~^(?P<slug>[^.]+)\.scolaire\.ht$;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        # Transmettre le slug au middleware
        proxy_set_header X-Tenant-Slug $slug;
    }

    location /media/ {
        # Vérification tenant avant de servir les fichiers
        # Utiliser Django-sendfile en production
        internal;
        alias /srv/scolaire/media/;
    }

    location /static/ {
        alias /srv/scolaire/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
```

### 17.3 Variables d'Environnement Obligatoires

```bash
# .env.production
SECRET_KEY=<générer avec: python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())">
DATABASE_URL=mysql://user:password@localhost:3306/scolaire_saas
REDIS_URL=redis://localhost:6379/0
ALLOWED_HOSTS=.scolaire.ht
MEDIA_ROOT=/srv/scolaire/media
STATIC_ROOT=/srv/scolaire/staticfiles
CELERY_BROKER_URL=redis://localhost:6379/1
EMAIL_HOST=smtp.sendgrid.net
EMAIL_HOST_USER=apikey
EMAIL_HOST_PASSWORD=<sendgrid_key>
```

---

## 18. SCALABILITÉ

### 18.1 Paliers de Scalabilité

```
PALIER 1 : 1 – 100 écoles
  → 1 serveur, Gunicorn 4 workers, MySQL local, Redis local
  → Toutes les optimisations indexes + select_related

PALIER 2 : 100 – 1 000 écoles
  → MySQL réplication read replica
  → Django DATABASE_ROUTERS pour séparer lectures/écritures
  → Redis Cluster pour cache distribué
  → Celery multi-queue (bulletins, badges, rapports)

PALIER 3 : 1 000+ écoles
  → Sharding MySQL par tranche de tenant_id (partition horizontale)
  → Load balancer (HAProxy) devant N instances Gunicorn
  → CDN pour les fichiers statiques et médias
  → Monitoring : Prometheus + Grafana
```

### 18.2 Partitionnement MySQL par Tenant

```sql
-- Pour le palier 3 : partitionner la table notes par ecole_id
ALTER TABLE notes_note
PARTITION BY HASH(ecole_id)
PARTITIONS 16;

-- Permet des requêtes tenant isolées sans full table scan
-- MySQL utilise pruning automatique : WHERE ecole_id = X → 1 partition
```

---

## 19. PLAN DE DÉVELOPPEMENT PAR PHASES

### Phase 1 — Fondations (Semaines 1–4)

```
✓ Setup projet Django 4.2 + MySQL XAMPP
✓ TenantMiddleware + TenantManager + TenantModelMixin
✓ Modèle Etablissement + Abonnement
✓ Auth multitenant (Utilisateur par école)
✓ RBAC basique (Rôle, Permission, UtilisateurRole)
✓ JournalAudit
✓ Tests d'isolation tenant
✓ Structure des apps (création des apps vides)
```

### Phase 2 — Paramétrage & Académique (Semaines 5–8)

```
✓ CycleEnseignement, Niveau, Section, Option
✓ TypeEvaluation, CoeffMatiere, SystemeNotation
✓ AnneeScolaire (machine à états complète)
✓ PeriodeAcademique
✓ Classe, Matiere
✓ Interface paramétrage école
✓ Dashboard directeur
```

### Phase 3 — Gestion Élèves & Enseignants (Semaines 9–12)

```
✓ Eleve (CRUD complet, historique, archivage)
✓ Inscription avec toutes les gardes métier
✓ Transfert, abandon, suspension
✓ Enseignant, Affectation, ChargeHoraire
✓ Classes avec effectifs
✓ Emploi du temps basique
```

### Phase 4 — Moteur de Notes (Semaines 13–16)

```
✓ TypeEvaluation configurable
✓ Saisie de notes avec gardes (période close, verrouillage)
✓ MoteurCalculMoyenne (validé sur cas réels)
✓ MoyenneMatiere, MoyenneGenerale
✓ Classement automatique
✓ Appréciations automatiques
✓ Tests exhaustifs du moteur de calcul
```

### Phase 5 — Bulletins (Semaines 17–20)

```
✓ Service génération bulletin
✓ Templates PDF configurables
✓ Workflow bulletin (brouillon → validé → publié)
✓ Bulletins trimestriels + annuels
✓ Signatures numériques
✓ QR Code de vérification
✓ Génération en masse (Celery)
```

### Phase 6 — Finances (Semaines 21–24)

```
✓ TypeFrais configurable
✓ FraisScolaireEleve par inscription
✓ Paiements partiels / complets
✓ Reçus PDF
✓ Journal de caisse
✓ Rapports financiers
✓ Alertes retards de paiement
```

### Phase 7 — Badges & Identité (Semaines 25–26)

```
✓ Templates de badges configurables
✓ Génération badges élèves + enseignants
✓ QR Codes + codes-barres
✓ Cartes d'identité scolaires PDF
✓ Impression en masse
```

### Phase 8 — Polish & Production (Semaines 27–30)

```
✓ Dashboard complet (statistiques, KPIs)
✓ Optimisations performance (indexes, caches)
✓ Tests d'intégration complets
✓ Documentation API
✓ Déploiement production
✓ Monitoring
✓ Guide utilisateur
```

---

## 20. PLAN SAAS COMMERCIAL

### 20.1 Plans d'Abonnement

```
PLAN STARTER (Gratuit 30 jours)
  ├── 1 école
  ├── 200 élèves max
  ├── 5 utilisateurs
  ├── Bulletins PDF basiques
  └── Support email

PLAN ESSENTIEL (Prix : ~1 500 HTG/mois)
  ├── 1 école
  ├── 500 élèves
  ├── 15 utilisateurs
  ├── Bulletins personnalisés
  ├── Badges élèves
  └── Support chat

PLAN PRO (Prix : ~4 500 HTG/mois)
  ├── 1 école
  ├── Élèves illimités
  ├── Utilisateurs illimités
  ├── Toutes les fonctionnalités
  ├── Rapports avancés
  ├── API accès
  └── Support prioritaire

PLAN RÉSEAU (Prix : sur devis)
  ├── Multi-établissements (réseau d'écoles)
  ├── Tableau de bord consolidé
  ├── Benchmarking inter-établissements
  └── SLA 99.9%
```

### 20.2 Modèle d'Abonnement Django

```python
# apps/etablissements/models.py (suite)

class PlanAbonnement(models.Model):
    code = models.CharField(max_length=20, unique=True)
    libelle = models.CharField(max_length=50)
    prix_mensuel = models.DecimalField(max_digits=10, decimal_places=2)
    max_eleves = models.PositiveIntegerField(null=True, blank=True)
    max_utilisateurs = models.PositiveIntegerField(null=True, blank=True)
    fonctionnalites = models.JSONField(default=dict)
    # Exemple: {"bulletins_pdf": True, "badges": True, "api": False}


class Abonnement(models.Model):
    etablissement = models.OneToOneField(
        Etablissement,
        on_delete=models.CASCADE,
        related_name="abonnement_actif",
    )
    plan = models.ForeignKey(PlanAbonnement, on_delete=models.PROTECT)
    date_debut = models.DateField()
    date_fin = models.DateField(null=True, blank=True)
    est_actif = models.BooleanField(default=True)
    en_periode_essai = models.BooleanField(default=True)
    date_fin_essai = models.DateField(null=True, blank=True)

    def verifier_limite_eleves(self, nb_actuel: int) -> bool:
        if self.plan.max_eleves is None:
            return True  # Illimité
        return nb_actuel < self.plan.max_eleves

    def a_acces_fonctionnalite(self, code: str) -> bool:
        return self.plan.fonctionnalites.get(code, False)
```

### 20.3 Roadmap Produit

```
V1.0 — École individuelle (Phase 1–8)
V1.5 — Mobile responsive complet + notifications SMS
V2.0 — App mobile (React Native) + mode offline
V2.5 — Réseau d'écoles + tableau de bord consolidé
V3.0 — IA : prédiction de décrochage, analyses académiques
V3.5 — Intégration Ministère de l'Éducation (Haïti/MENFP)
V4.0 — Expansion multilingue (créole haïtien, espagnol, anglais)
```

---

## ANNEXE — EXCEPTIONS MÉTIER

```python
# apps/noyau/exceptions.py

class ErreurMetier(Exception):
    """Exception de base pour toutes les erreurs métier."""
    pass


class TransitionInterditError(ErreurMetier):
    """Transition d'état non autorisée par la machine à états."""
    pass


class RegleMetierError(ErreurMetier):
    """Violation d'une règle métier (garde non satisfaite)."""
    pass


class ErreurCalcul(ErreurMetier):
    """Erreur dans le moteur de calcul de moyennes."""
    pass


class ErreurTenant(ErreurMetier):
    """Problème de contexte tenant (manquant, suspendu, invalide)."""
    pass


class LimiteAbonnementError(ErreurMetier):
    """Le plan d'abonnement ne permet pas cette action."""
    pass
```

---

## ANNEXE — CONVENTIONS DE CODE

```
NOMMAGE OBLIGATOIRE (français) :
  Classes    : PascalCase français     → AnneeScolaire, MoyenneGenerale
  Méthodes   : snake_case français     → calculer_moyenne(), inscrire_eleve()
  Variables  : snake_case français     → annee_courante, nombre_eleves
  Constantes : SCREAMING_SNAKE français → STATUT_ACTIF, MAX_NOTES
  Modèles    : Singulier               → Eleve (pas Eleves)
  Apps       : Pluriel court           → eleves, notes, finances

NOMMAGE ANGLAIS AUTORISÉ (uniquement) :
  - Méthodes Django imposées : save(), clean(), get_queryset()
  - Variables framework : request, response, queryset, pk
  - Noms de librairies : celery, redis, reportlab

COMMENTAIRES :
  - Niveau ingénierie, pas tutoriel
  - Documenter le POURQUOI, pas le QUOI
  - Expliquer les décisions architecturales non évidentes
  - Signaler les pièges et invariants critiques
```

---

*Document produit par l'équipe d'architecture — Version 1.0*
*Révision recommandée : à chaque fin de phase de développement*
