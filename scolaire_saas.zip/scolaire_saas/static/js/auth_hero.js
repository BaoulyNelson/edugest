/* auth_hero.js — image aléatoire pour la colonne gauche (connexion + inscription)
   Pour ajouter une photo : copiez l'URL « images.unsplash.com/photo-… » (sans paramètres)
   et ajoutez une ligne dans PHOTOS. */
(function () {
  var PHOTOS = [
    { id: 'photo-1693638994385-42b1b2c817b4', by: 'Patrik Bloudek', url: 'https://unsplash.com/fr/@bloudekp' },
    { id: 'photo-1603979649806-5299879db16b', by: 'Ansgar Scheffold' },
    { id: 'photo-1681167779860-ceb10418d405', by: 'Alex Moliski' },
    { id: 'photo-1688383213635-9bc2fc25103d', by: 'Tobias Reich' },
    { id: 'photo-1596550782892-01e5f0229ce7', by: 'Explore with Joshua' },
    { id: 'photo-1689628918978-6fd2ea8d81c1', by: 'Adam Davis' },
    { id: 'photo-1600672196900-c98c011a0977', by: 'Chris Stenger' }
  ];
  var UTM = '?utm_source=scolaire_saas&utm_medium=referral';
  var hero = document.querySelector('.nova-hero');
  if (!hero || !PHOTOS.length) return;

  // Évite de tomber deux fois de suite sur la même image
  var last = -1;
  try { last = parseInt(localStorage.getItem('nova_hero_last'), 10); } catch (e) {}
  var i;
  do { i = Math.floor(Math.random() * PHOTOS.length); } while (PHOTOS.length > 1 && i === last);
  try { localStorage.setItem('nova_hero_last', i); } catch (e) {}

  var p = PHOTOS[i];
  var w = Math.min(2000, Math.round((window.innerWidth / 2) * (window.devicePixelRatio || 1)) + 200);
  var src = 'https://images.unsplash.com/' + p.id + '?auto=format&fit=crop&q=75&w=' + w;

  var img = new Image();
  img.onload = function () {
    hero.style.setProperty('--hero-img', 'url("' + src + '")');
    var c = document.getElementById('nova-credit');
    if (c) {
      var by = p.url ? '<a href="' + p.url + UTM + '" target="_blank" rel="noopener">' + p.by + '</a>' : p.by;
      c.innerHTML = 'Photo : ' + by + ' · <a href="https://unsplash.com/' + UTM + '" target="_blank" rel="noopener">Unsplash</a>';
      c.classList.add('show');
    }
  };
  // En cas d'échec (hors ligne, URL invalide) : on garde le dégradé + montagnes par défaut
  img.src = src;
})();