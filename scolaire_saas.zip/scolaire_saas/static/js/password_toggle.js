(function () {
  var eyeIcon = '<svg class="password-toggle-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
  var eyeSlashIcon = '<svg class="password-toggle-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7c2.1 0 4 .7 5.7 1.7M22 12s-3.6 7-10 7c-2.1 0-4-.7-5.7-1.7"></path><path d="M3 3l18 18"></path><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"></path></svg>';

  function initializePasswordToggles() {
    document.querySelectorAll('input[type="password"]').forEach(function (input) {
      if (input.dataset.passwordToggleInitialized === "true") return;

      input.dataset.passwordToggleInitialized = "true";
      input.dataset.passwordToggle = "true";

      var wrapper = input.closest(".pw-input-wrap, .password-toggle");
      if (!wrapper) {
        wrapper = document.createElement("div");
        wrapper.className = "password-toggle";
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);
      }

      var button = wrapper.querySelector(".pw-eye-btn, .password-toggle-button");
      if (!button) {
        button = document.createElement("button");
        button.type = "button";
        button.className = "password-toggle-button";
        button.innerHTML = eyeIcon;
        wrapper.appendChild(button);
      }

      button.setAttribute("aria-controls", input.id);
      button.setAttribute("aria-pressed", "false");
      button.setAttribute("aria-label", "Afficher le mot de passe");

      button.addEventListener("click", function () {
        var isVisible = input.type === "password";
        input.type = isVisible ? "text" : "password";
        button.setAttribute("aria-pressed", String(isVisible));
        button.setAttribute(
          "aria-label",
          isVisible ? "Masquer le mot de passe" : "Afficher le mot de passe"
        );

        var icon = button.querySelector("i");
        if (icon) {
          icon.className = isVisible ? "bi bi-eye-slash" : "bi bi-eye";
        } else {
          button.innerHTML = isVisible ? eyeSlashIcon : eyeIcon;
        }
      });
    });
  }

  initializePasswordToggles();
})();
