"""
apps/bulletins/generateurs/trimestriel.py
==========================================
Génère le PDF d'un bulletin trimestriel via ReportLab.
Le design est paramétré par l'école (couleurs, logo, titre).
"""

from io import BytesIO
from decimal import Decimal
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph,
    Spacer, HRFlowable, Image
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT


class GenerateurBulletinTrimestriel:
    """
    Génère un bulletin PDF A4 avec :
    - En-tête : logo, nom école, titre de la période
    - Informations élève : nom, classe, année, matricule
    - Tableau des matières : matière | note | coeff | moyenne | rang
    - Bilan : moyenne générale, rang, mention, décision
    - Pied de page : signatures, QR code, code de vérification
    """

    def __init__(self, ecole):
        self.ecole = ecole
        self.couleur_principale = colors.HexColor(
            ecole.couleur_principale or "#1a3c6e"
        )
        self.couleur_secondaire = colors.HexColor(
            ecole.couleur_secondaire or "#ffffff"
        )

    def generer(self, inscription, periode, moyenne_gen) -> BytesIO:
        """Génère et retourne le PDF sous forme de BytesIO."""
        buffer = BytesIO()

        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=15 * mm,
            leftMargin=15 * mm,
            topMargin=15 * mm,
            bottomMargin=15 * mm,
        )

        elements = []
        styles = self._construire_styles()

        # ── En-tête ────────────────────────────────────────────────────────────
        elements += self._construire_entete(styles, periode)
        elements.append(Spacer(1, 5 * mm))

        # ── Informations élève ─────────────────────────────────────────────────
        elements += self._construire_bloc_eleve(styles, inscription, periode)
        elements.append(Spacer(1, 5 * mm))

        # ── Tableau des notes ──────────────────────────────────────────────────
        elements.append(Paragraph("Résultats par matière", styles["sous_titre"]))
        elements.append(Spacer(1, 3 * mm))
        elements += self._construire_tableau_notes(styles, inscription, periode, moyenne_gen)
        elements.append(Spacer(1, 5 * mm))

        # ── Bilan ──────────────────────────────────────────────────────────────
        elements += self._construire_bilan(styles, moyenne_gen)
        elements.append(Spacer(1, 8 * mm))

        # ── Discipline ────────────────────────────────────────────────────────
        elements += self._construire_discipline(styles, inscription, periode)
        elements.append(Spacer(1, 8 * mm))

        # ── Signatures ────────────────────────────────────────────────────────
        elements += self._construire_signatures(styles)

        # ── QR Code & vérification ────────────────────────────────────────────
        elements += self._construire_pied_page(styles, inscription, periode)

        doc.build(elements)
        buffer.seek(0)
        return buffer

    def _construire_styles(self) -> dict:
        base = getSampleStyleSheet()
        return {
            "titre_ecole": ParagraphStyle(
                "titre_ecole",
                parent=base["Heading1"],
                fontSize=14,
                textColor=self.couleur_principale,
                alignment=TA_CENTER,
                spaceAfter=2,
            ),
            "sous_titre": ParagraphStyle(
                "sous_titre",
                parent=base["Heading2"],
                fontSize=11,
                textColor=self.couleur_principale,
                spaceAfter=3,
            ),
            "normal": ParagraphStyle(
                "normal",
                parent=base["Normal"],
                fontSize=9,
            ),
            "centré": ParagraphStyle(
                "centré",
                parent=base["Normal"],
                fontSize=9,
                alignment=TA_CENTER,
            ),
            "gras": ParagraphStyle(
                "gras",
                parent=base["Normal"],
                fontSize=9,
                fontName="Helvetica-Bold",
            ),
        }

    def _construire_entete(self, styles, periode) -> list:
        elements = []

        # Nom de l'école (centré, grande taille)
        elements.append(
            Paragraph(self.ecole.nom.upper(), styles["titre_ecole"])
        )
        if self.ecole.devise_etablissement:
            elements.append(
                Paragraph(
                    f'<i>"{self.ecole.devise_etablissement}"</i>',
                    styles["centré"],
                )
            )
        if self.ecole.numero_agrement:
            elements.append(
                Paragraph(
                    f"Agrément MENFP N° {self.ecole.numero_agrement}",
                    styles["centré"],
                )
            )

        elements.append(HRFlowable(width="100%", thickness=2, color=self.couleur_principale))
        elements.append(Spacer(1, 3 * mm))

        # Titre du bulletin
        elements.append(
            Paragraph(
                f"BULLETIN SCOLAIRE — {periode.libelle.upper()}",
                styles["sous_titre"],
            )
        )
        elements.append(
            Paragraph(
                f"Année scolaire : {periode.annee_scolaire.libelle}",
                styles["centré"],
            )
        )
        return elements

    def _construire_bloc_eleve(self, styles, inscription, periode) -> list:
        eleve = inscription.eleve
        data = [
            [
                Paragraph("<b>Nom :</b>", styles["normal"]),
                Paragraph(eleve.nom.upper(), styles["gras"]),
                Paragraph("<b>Prénom :</b>", styles["normal"]),
                Paragraph(eleve.prenom, styles["normal"]),
            ],
            [
                Paragraph("<b>Matricule :</b>", styles["normal"]),
                Paragraph(eleve.matricule, styles["normal"]),
                Paragraph("<b>Date de naissance :</b>", styles["normal"]),
                Paragraph(
                    eleve.date_naissance.strftime("%d/%m/%Y") if eleve.date_naissance else "—",
                    styles["normal"],
                ),
            ],
            [
                Paragraph("<b>Classe :</b>", styles["normal"]),
                Paragraph(inscription.classe.libelle, styles["gras"]),
                Paragraph("<b>Effectif :</b>", styles["normal"]),
                Paragraph(
                    str(inscription.classe.nb_inscrits()),
                    styles["normal"],
                ),
            ],
        ]

        tableau = Table(data, colWidths=[35 * mm, 55 * mm, 40 * mm, 50 * mm])
        tableau.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e2e8f0")),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ]))
        return [tableau]

    def _construire_tableau_notes(self, styles, inscription, periode, moyenne_gen) -> list:
        from apps.notes.models import MoyenneMatiere

        moyennes = (
            MoyenneMatiere.objects.filter(
                inscription=inscription,
                periode=periode,
            )
            .select_related("matiere", "mention")
            .order_by("matiere__ordre_affichage")
        )

        # En-tête du tableau
        entetes = [
            Paragraph("<b>Matière</b>", styles["gras"]),
            Paragraph("<b>Coefficient</b>", styles["centré"]),
            Paragraph("<b>Moyenne</b>", styles["centré"]),
            Paragraph("<b>/ Base</b>", styles["centré"]),
            Paragraph("<b>Rang</b>", styles["centré"]),
            Paragraph("<b>Appréciation</b>", styles["centré"]),
        ]

        data = [entetes]

        for moy in moyennes:
            mention_txt = moy.mention.libelle_court if moy.mention else ""
            from apps.parametrage.models import CoefficientsMatiere
            coeff = CoefficientsMatiere.objects.filter(
                matiere=moy.matiere,
                niveau=inscription.classe.niveau,
                annee_scolaire=periode.annee_scolaire,
            ).first()
            coeff_val = coeff.coefficient if coeff else "—"

            data.append([
                Paragraph(moy.matiere.libelle, styles["normal"]),
                Paragraph(str(coeff_val), styles["centré"]),
                Paragraph(str(moy.moyenne), styles["centré"]),
                Paragraph(str(moy.base_calcul), styles["centré"]),
                Paragraph(str(moy.rang_classe or "—"), styles["centré"]),
                Paragraph(mention_txt, styles["centré"]),
            ])

        # Ligne moyenne générale
        data.append([
            Paragraph("<b>MOYENNE GÉNÉRALE</b>", styles["gras"]),
            Paragraph("", styles["centré"]),
            Paragraph(f"<b>{moyenne_gen.moyenne}</b>", styles["centré"]),
            Paragraph(str(moyenne_gen.base_calcul), styles["centré"]),
            Paragraph(
                f"<b>{moyenne_gen.rang_classe or '—'}/{moyenne_gen.nb_eleves_classe or '—'}</b>",
                styles["centré"],
            ),
            Paragraph(
                moyenne_gen.mention.libelle if moyenne_gen.mention else "—",
                styles["centré"],
            ),
        ])

        tableau = Table(
            data,
            colWidths=[60 * mm, 25 * mm, 25 * mm, 20 * mm, 20 * mm, 30 * mm],
        )
        tableau.setStyle(TableStyle([
            # En-tête
            ("BACKGROUND", (0, 0), (-1, 0), self.couleur_principale),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            # Lignes alternées
            ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#f1f5f9")]),
            # Ligne moyenne générale
            ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#dbeafe")),
            # Bordures
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#94a3b8")),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e2e8f0")),
            ("ALIGN", (1, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LEFTPADDING", (0, 0), (0, -1), 5),
        ]))
        return [tableau]

    def _construire_bilan(self, styles, moyenne_gen) -> list:
        elements = []
        elements.append(HRFlowable(width="100%", thickness=1, color=self.couleur_principale))
        elements.append(Spacer(1, 2 * mm))

        decision = {
            "admis": "✓ ADMIS(E)",
            "admis_conseil": "✓ ADMIS(E) PAR DÉCISION DU CONSEIL",
            "redoublant": "✗ REDOUBLANT(E)",
            "oriente": "→ ORIENTÉ(E)",
            "exclu": "✗ EXCLU(E)",
        }.get(moyenne_gen.decision_conseil, "En attente de décision")

        data = [
            [
                Paragraph("<b>Décision :</b>", styles["gras"]),
                Paragraph(f"<b>{decision}</b>", styles["gras"]),
                Paragraph("<b>Mention :</b>", styles["gras"]),
                Paragraph(
                    moyenne_gen.mention.libelle if moyenne_gen.mention else "—",
                    styles["normal"],
                ),
            ],
        ]
        tableau = Table(data, colWidths=[30 * mm, 75 * mm, 30 * mm, 45 * mm])
        tableau.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.5, self.couleur_principale),
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eff6ff")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        elements.append(tableau)
        return elements

    def _construire_discipline(self, styles, inscription, periode) -> list:
        from apps.eleves.models import DossierDisciplinaire
        dossiers = DossierDisciplinaire.objects.filter(
            inscription=inscription,
            type_discipline__apparait_bulletin=True,
        ).select_related("type_discipline")

        if not dossiers.exists():
            return []

        elements = [Paragraph("Observations disciplinaires", styles["sous_titre"])]
        for d in dossiers:
            elements.append(
                Paragraph(
                    f"• {d.type_discipline.libelle} ({d.date_incident.strftime('%d/%m/%Y')}) : {d.description}",
                    styles["normal"],
                )
            )
        return elements

    def _construire_signatures(self, styles) -> list:
        data = [
            [
                Paragraph("Signature du Directeur", styles["centré"]),
                Paragraph("Signature du Parent/Tuteur", styles["centré"]),
                Paragraph("Cachet de l'École", styles["centré"]),
            ],
            [
                Spacer(1, 20 * mm),
                Spacer(1, 20 * mm),
                Spacer(1, 20 * mm),
            ],
            [
                Paragraph(f"<b>{self.ecole.directeur_nom}</b>", styles["centré"]),
                Paragraph("________________________", styles["centré"]),
                Paragraph("", styles["centré"]),
            ],
        ]
        tableau = Table(data, colWidths=[60 * mm, 60 * mm, 60 * mm])
        tableau.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("LINEAFTER", (0, 0), (1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        return [tableau]

    def _construire_pied_page(self, styles, inscription, periode) -> list:
        import qrcode
        from io import BytesIO
        from reportlab.platypus import Image as RLImage

        # Générer le QR code pointant vers la page de vérification
        url_verification = (
            f"https://{self.ecole.slug}.scolaire.ht/bulletins/verifier/"
            f"{inscription.bulletins.filter(periode=periode).first().code_verification}/"
        )

        qr = qrcode.QRCode(version=1, box_size=3, border=2)
        qr.add_data(url_verification)
        qr.make(fit=True)
        img_qr = qr.make_image(fill_color="black", back_color="white")
        buf_qr = BytesIO()
        img_qr.save(buf_qr, format="PNG")
        buf_qr.seek(0)

        elements = [
            HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#94a3b8")),
            Spacer(1, 2 * mm),
        ]

        data = [
            [
                RLImage(buf_qr, width=20 * mm, height=20 * mm),
                Paragraph(
                    f"<font size='7'>Ce bulletin peut être vérifié sur "
                    f"{self.ecole.slug}.scolaire.ht<br/>"
                    f"Code : {inscription.bulletins.filter(periode=periode).first().code_verification[:16]}...</font>",
                    styles["normal"],
                ),
            ]
        ]
        tableau = Table(data, colWidths=[25 * mm, 155 * mm])
        tableau.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ]))
        elements.append(tableau)
        return elements