from django.shortcuts import render

# Create your views here.
"""Vues de gestion des bulletins."""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from django.http import FileResponse
from django.db.models import Q
from apps.noyau.decorateurs import requiert_tenant, requiert_permission, gerer_erreur_metier
from apps.bulletins.models import Bulletin
from apps.bulletins.models import StatutBulletin
from apps.bulletins.services import ServiceGenBulletin
from apps.academique.models import PeriodeAcademique
from apps.eleves.models import Inscription, StatutInscription
from apps.notes.models import MoyenneGenerale


@login_required
@requiert_tenant
def liste_bulletins(request):
    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    periode_id = request.GET.get("periode", "")
    statut = request.GET.get("statut", "")
    periodes = annee.periodes.all() if annee else PeriodeAcademique.objects.none()
    bulletins = Bulletin.objects.filter(
        ecole=request.etablissement,
        inscription__annee_scolaire=annee,
    ).select_related(
        "inscription__eleve", "periode", "moyenne_generale"
    ) if annee else Bulletin.objects.none()
    if q:
        bulletins = bulletins.filter(
            Q(inscription__eleve__nom__icontains=q)
            | Q(inscription__eleve__prenom__icontains=q)
            | Q(inscription__eleve__matricule__icontains=q)
        )
    if periode_id:
        try:
            periode_pk = PeriodeAcademique._meta.pk.to_python(periode_id)
        except (TypeError, ValueError):
            periode_pk = None
        if periode_pk is not None and periodes.filter(pk=periode_pk).exists():
            bulletins = bulletins.filter(periode_id=periode_pk)
        else:
            periode_id = ""
    if statut in dict(StatutBulletin.choices):
        bulletins = bulletins.filter(statut=statut)
    else:
        statut = ""
    return render(request, "bulletins/liste.html", {
        "bulletins": bulletins.order_by("inscription__eleve__nom", "inscription__eleve__prenom"),
        "annee": annee,
        "periodes": periodes,
        "q": q,
        "filtre_periode": periode_id,
        "filtre_statut": statut,
        "statut_choices": StatutBulletin.choices,
    })


@login_required
@requiert_tenant
@requiert_permission("bulletins.generer.toutes_classes")
@gerer_erreur_metier
def generer_bulletins(request, periode_id):
    periode = get_object_or_404(PeriodeAcademique, pk=periode_id, ecole=request.etablissement)
    if request.method == "POST":
        inscriptions = Inscription.objects.filter(
            annee_scolaire=periode.annee_scolaire,
            statut=StatutInscription.VALIDEE,
        )
        if inscriptions.exists() and not MoyenneGenerale.objects.filter(
            periode=periode,
            inscription__in=inscriptions,
        ).exists():
            messages.error(
                request,
                f"Aucune moyenne n’a été calculée pour {periode.libelle}. "
                "Calculez d’abord les moyennes depuis la page Moyennes.",
            )
            return redirect("bulletins:liste")

        from workers.taches_bulletins import generer_bulletins_periode
        resultat = generer_bulletins_periode.delay(
            ecole_id=str(request.etablissement.pk),
            periode_id=periode_id,
            genere_par_id=str(request.user.pk),
        )
        if settings.CELERY_TASK_ALWAYS_EAGER:
            rapport = resultat.get()
            generes = rapport.get("generes", 0)
            erreurs = rapport.get("erreurs", 0)
            if erreurs:
                details = rapport.get("details_erreurs", [])
                premiere_erreur = details[0].get("erreur", "") if details else ""
                message = (
                    f"{generes} bulletin(s) généré(s), {erreurs} erreur(s) "
                    f"pour {periode.libelle}."
                )
                if premiere_erreur:
                    message += f" Première erreur : {premiere_erreur}"
                messages.warning(request, message)
            elif generes:
                messages.success(
                    request,
                    f"{generes} bulletin(s) généré(s) pour {periode.libelle}.",
                )
            else:
                messages.warning(
                    request,
                    f"Aucun bulletin généré pour {periode.libelle} : "
                    "aucune inscription validée à traiter.",
                )
        else:
            messages.success(
                request,
                f"Génération des bulletins lancée pour {periode.libelle}.",
            )
    return redirect("bulletins:liste")


@login_required
@requiert_tenant
@requiert_permission("bulletins.generer.toutes_classes")
@gerer_erreur_metier
def generer_bulletins_classe(request, periode_id, classe_id):
    periode = get_object_or_404(PeriodeAcademique, pk=periode_id, ecole=request.etablissement)
    from apps.academique.models import Classe
    classe = get_object_or_404(Classe, pk=classe_id, ecole=request.etablissement)
    if request.method == "POST":
        service = ServiceGenBulletin(utilisateur=request.user, ecole=request.etablissement)
        rapport = service.generer_tous(periode=periode, classe=classe)
        messages.success(request, f"{rapport['generes']} bulletins générés, {rapport['erreurs']} erreurs.")
    return redirect("bulletins:liste")


@login_required
@requiert_tenant
def detail_bulletin(request, pk):
    bulletin = get_object_or_404(Bulletin, pk=pk, ecole=request.etablissement)
    return render(request, "bulletins/detail.html", {"bulletin": bulletin})


@login_required
@requiert_tenant
@requiert_permission("bulletins.valider.toutes_classes")
@gerer_erreur_metier
def valider_bulletin(request, pk):
    bulletin = get_object_or_404(Bulletin, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        service = ServiceGenBulletin(utilisateur=request.user, ecole=request.etablissement)
        service.valider(bulletin)
        messages.success(request, "Bulletin validé.")
    return redirect("bulletins:detail", pk=pk)


@login_required
@requiert_tenant
@requiert_permission("bulletins.publier.toutes_classes")
@gerer_erreur_metier
def publier_bulletin(request, pk):
    bulletin = get_object_or_404(Bulletin, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        service = ServiceGenBulletin(utilisateur=request.user, ecole=request.etablissement)
        service.publier(bulletin)
        messages.success(request, "Bulletin publié. Les résultats sont définitifs.")
    return redirect("bulletins:detail", pk=pk)


@login_required
@requiert_tenant
def telecharger_pdf(request, pk):
    bulletin = get_object_or_404(Bulletin, pk=pk, ecole=request.etablissement)
    if not bulletin.fichier_pdf:
        messages.error(request, "Le PDF n'est pas encore généré.")
        return redirect("bulletins:detail", pk=pk)
    return FileResponse(bulletin.fichier_pdf.open(), content_type="application/pdf",
                        as_attachment=False, filename=f"bulletin_{bulletin.inscription.eleve.matricule}.pdf")


def verifier_bulletin(request, code):
    """Page publique de vérification d'authenticité (sans tenant requis)."""
    try:
        bulletin = Bulletin.tous_objets.get(code_verification=code)
        return render(request, "bulletins/verifier.html", {"bulletin": bulletin, "valide": True})
    except Bulletin.DoesNotExist:
        return render(request, "bulletins/verifier.html", {"valide": False})


@login_required
@requiert_tenant
@requiert_permission("bulletins.publier.toutes_classes")
@gerer_erreur_metier
def publier_tous(request, periode_id):
    periode = get_object_or_404(PeriodeAcademique, pk=periode_id, ecole=request.etablissement)
    if request.method == "POST":
        service = ServiceGenBulletin(utilisateur=request.user, ecole=request.etablissement)
        bulletins = Bulletin.objects.filter(periode=periode, statut="valide")
        nb = 0
        for b in bulletins:
            try:
                service.publier(b)
                nb += 1
            except Exception:
                pass
        messages.success(request, f"{nb} bulletins publiés.")
    return redirect("bulletins:liste")
