"""
apps/bulletins/services.py
===========================
ServiceGenBulletin : génère les bulletins PDF et gère leur cycle de vie.
"""

import secrets
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from apps.bulletins.models import Bulletin, StatutBulletin, TRANSITIONS_BULLETIN
from apps.noyau.exceptions import (
    RegleMetierError, TransitionInterditError, OperationImpossibleError
)
from apps.securite.rbac import ServiceAudit


class ServiceGenBulletin:
    """
    Gère la génération, validation et publication des bulletins.
    Un bulletin = un PDF signé représentant les résultats d'un élève pour une période.
    """

    def __init__(self, utilisateur=None, ecole=None):
        self.utilisateur = utilisateur
        self.ecole = ecole
        self.audit = ServiceAudit(utilisateur)

    @transaction.atomic
    def generer(self, inscription, periode) -> Bulletin:
        """
        Génère ou régénère le bulletin d'un élève pour une période.

        Gardes :
        - La période doit être au moins CLOTUREE
        - La MoyenneGenerale doit exister
        - Le bulletin ne doit pas être PUBLIE (sauf admin)
        """
        from apps.academique.models import StatutAnneeScolaire, StatutPeriode
        from apps.notes.models import MoyenneGenerale

        if (
            inscription.annee_scolaire_id != periode.annee_scolaire_id
            or periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE
        ):
            raise RegleMetierError(
                "Les bulletins ne peuvent être générés que pour une inscription "
                "de l’année scolaire active correspondante."
            )

        # Garde 1 : période close
        if periode.statut == "ouverte":
            raise RegleMetierError(
                f"La période '{periode.libelle}' est encore ouverte. "
                "Clôturer la période avant de générer les bulletins."
            )

        # Garde 2 : moyenne générale existe
        try:
            moyenne_gen = MoyenneGenerale.objects.get(
                inscription=inscription,
                periode=periode,
            )
        except MoyenneGenerale.DoesNotExist:
            raise OperationImpossibleError(
                f"La moyenne générale de {inscription.eleve.nom_complet} "
                f"n'a pas encore été calculée pour {periode.libelle}."
            )

        # Vérifier bulletin existant
        bulletin = Bulletin.objects.filter(
            inscription=inscription,
            periode=periode,
        ).first()

        if bulletin and bulletin.statut == StatutBulletin.PUBLIE:
            raise RegleMetierError(
                "Ce bulletin est déjà publié. "
                "Il ne peut pas être régénéré sans intervention administrative."
            )

        from django.core.files.base import ContentFile
        nom_fichier = (
            f"bulletin_{inscription.eleve.matricule}_"
            f"{periode.annee_scolaire.libelle.replace('-', '_')}_"
            f"P{periode.numero}.pdf"
        )

        if bulletin:
            # Le générateur PDF lit le code de vérification du bulletin en base.
            pdf_buffer = self._generer_pdf(inscription, periode, moyenne_gen)
            # Régénérer : supprimer l'ancien PDF
            if bulletin.fichier_pdf:
                bulletin.fichier_pdf.delete(save=False)
            bulletin.statut = StatutBulletin.BROUILLON
            bulletin.moyenne_generale = moyenne_gen
            bulletin.genere_par = self.utilisateur
            bulletin.date_generation = timezone.now()
            bulletin.valide_par = None
            bulletin.date_validation = None
            bulletin.fichier_pdf.save(nom_fichier, ContentFile(pdf_buffer.read()))
            bulletin.save()
        else:
            bulletin = Bulletin(
                ecole=inscription.ecole,
                inscription=inscription,
                periode=periode,
                moyenne_generale=moyenne_gen,
                statut=StatutBulletin.BROUILLON,
                genere_par=self.utilisateur,
                date_generation=timezone.now(),
            )
            bulletin.save()
            pdf_buffer = self._generer_pdf(inscription, periode, moyenne_gen)
            bulletin.fichier_pdf.save(nom_fichier, ContentFile(pdf_buffer.read()))

        self.audit.enregistrer(
            action="generation_bulletin",
            objet=bulletin,
            donnees_apres={
                "eleve": inscription.eleve.nom_complet,
                "periode": periode.libelle,
                "moyenne": str(moyenne_gen.moyenne),
            },
        )
        return bulletin

    @transaction.atomic
    def valider(self, bulletin: Bulletin) -> Bulletin:
        """Passe un bulletin de BROUILLON → VALIDE."""
        from apps.academique.models import StatutAnneeScolaire

        if bulletin.periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE:
            raise RegleMetierError(
                "Impossible de modifier un bulletin d'une année scolaire inactive."
            )
        if not bulletin.peut_transitionner_vers(StatutBulletin.VALIDE):
            raise TransitionInterditError(
                f"Impossible de valider un bulletin en statut '{bulletin.statut}'."
            )
        bulletin.statut = StatutBulletin.VALIDE
        bulletin.valide_par = self.utilisateur
        bulletin.date_validation = timezone.now()
        bulletin.save(update_fields=["statut", "valide_par", "date_validation"])

        self.audit.enregistrer("validation_bulletin", bulletin)
        return bulletin

    @transaction.atomic
    def publier(self, bulletin: Bulletin) -> Bulletin:
        """
        Passe un bulletin de VALIDE → PUBLIE.
        IRRÉVERSIBLE : une fois publié, le bulletin ne peut plus être modifié.
        """
        from apps.academique.models import StatutAnneeScolaire

        if bulletin.periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE:
            raise RegleMetierError(
                "Impossible de modifier un bulletin d'une année scolaire inactive."
            )
        if not bulletin.peut_transitionner_vers(StatutBulletin.PUBLIE):
            raise TransitionInterditError(
                f"Impossible de publier un bulletin en statut '{bulletin.statut}'."
            )

        # Publier aussi la moyenne générale
        moy_gen = bulletin.moyenne_generale
        if not moy_gen.est_publiee:
            moy_gen.est_publiee = True
            moy_gen.publiee_le = timezone.now()
            moy_gen.publiee_par = self.utilisateur
            moy_gen.save(update_fields=["est_publiee", "publiee_le", "publiee_par"])

        bulletin.statut = StatutBulletin.PUBLIE
        bulletin.publie_par = self.utilisateur
        bulletin.date_publication = timezone.now()
        bulletin.save(update_fields=["statut", "publie_par", "date_publication"])

        self.audit.enregistrer("publication_bulletin", bulletin)
        return bulletin

    @transaction.atomic
    def generer_tous(self, periode, classe=None) -> dict:
        """
        Génère les bulletins en masse pour une période.
        Optionnel : filtré par classe.
        Retourne un rapport : {generes, erreurs, details_erreurs}.
        """
        from apps.eleves.models import Inscription, StatutInscription

        qs = Inscription.objects.filter(
            annee_scolaire=periode.annee_scolaire,
            statut=StatutInscription.VALIDEE,
        ).select_related("eleve", "classe")

        if classe:
            qs = qs.filter(classe=classe)

        rapport = {"generes": 0, "erreurs": 0, "details_erreurs": []}

        for inscription in qs:
            try:
                self.generer(inscription, periode)
                rapport["generes"] += 1
            except Exception as exc:
                rapport["erreurs"] += 1
                rapport["details_erreurs"].append({
                    "eleve": inscription.eleve.nom_complet,
                    "erreur": str(exc),
                })

        return rapport

    def _generer_pdf(self, inscription, periode, moyenne_gen) -> object:
        """
        Génère le PDF du bulletin via ReportLab.
        Délégué au générateur configuré par l'école.
        """
        from apps.bulletins.generateurs.trimestriel import GenerateurBulletinTrimestriel

        generateur = GenerateurBulletinTrimestriel(
            ecole=inscription.ecole,
        )
        return generateur.generer(
            inscription=inscription,
            periode=periode,
            moyenne_gen=moyenne_gen,
        )