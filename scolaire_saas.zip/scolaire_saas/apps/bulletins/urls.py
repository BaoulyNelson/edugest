from django.urls import path
from apps.bulletins import views

app_name = "bulletins"
urlpatterns = [
    path("", views.liste_bulletins, name="liste"),
    path("generer/<int:periode_id>/", views.generer_bulletins, name="generer"),
    path(
        "generer/<int:periode_id>/classe/<int:classe_id>/",
        views.generer_bulletins_classe,
        name="generer_classe",
    ),
    path("<uuid:pk>/", views.detail_bulletin, name="detail"),
    path("<uuid:pk>/valider/", views.valider_bulletin, name="valider"),
    path("<uuid:pk>/publier/", views.publier_bulletin, name="publier"),
    path("<uuid:pk>/pdf/", views.telecharger_pdf, name="pdf"),
    path("verifier/<str:code>/", views.verifier_bulletin, name="verifier"),
    path("publier-tout/<int:periode_id>/", views.publier_tous, name="publier_tous"),
]
