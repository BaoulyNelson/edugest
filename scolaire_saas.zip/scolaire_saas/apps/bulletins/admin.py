from django.contrib import admin
from apps.bulletins.models import Bulletin
from apps.noyau.admin import AdminTenant

admin.site.register(Bulletin, AdminTenant)
