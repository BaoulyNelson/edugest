from datetime import date
from decimal import Decimal
from tempfile import TemporaryDirectory

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.academique.models import (
    AnneeScolaire,
    Classe,
    PeriodeAcademique,
    StatutAnneeScolaire,
    StatutPeriode,
)
from apps.bulletins.models import Bulletin
from apps.eleves.models import Eleve, Inscription, StatutInscription
from apps.etablissements.models import Etablissement
from apps.noyau.exceptions import RegleMetierError
from apps.notes.models import MoyenneGenerale, MoyenneMatiere, Note
from apps.notes.services import ServiceCalculMoyenne
from apps.notes.services import ServiceSaisieNote
from apps.parametrage.models import (
    CoefficientsMatiere,
    CycleEnseignement,
    BaremeMatierePeriode,
    Matiere,
    Niveau,
    SystemeNotation,
    TypeEvaluation,
)
from apps.parametrage.forms import FormulaireBaremeMatiere
from apps.bulletins.services import ServiceGenBulletin


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ParcoursBulletinTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="parcours-bulletin@example.com",
            password="test-password",
            nom="Test",
            prenom="Parcours",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-parcours-bulletin",
            nom="École parcours bulletin",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        self.periode = PeriodeAcademique.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            numero=1,
            libelle="Semestre 1 2026-2027",
            libelle_court="S1",
            type_periode="semestre",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 1, 31),
            statut=StatutPeriode.CLOTUREE,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="TEST",
            libelle="Cycle de test",
        )
        self.niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="N1",
            libelle="Niveau 1",
        )
        self.classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            niveau=self.niveau,
            code="N1-A",
            libelle="Niveau 1 A",
        )
        self.matiere = Matiere.objects.create(
            ecole=self.ecole,
            code="MATH",
            libelle="Mathématiques",
        )
        CoefficientsMatiere.objects.create(
            ecole=self.ecole,
            matiere=self.matiere,
            niveau=self.niveau,
            annee_scolaire=self.annee,
            coefficient=Decimal("2.00"),
        )
        type_evaluation = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="EXAM",
            libelle="Examen",
            note_max_defaut=Decimal("20.00"),
        )
        eleve = Eleve.objects.create(
            ecole=self.ecole,
            matricule="PARCOURS-001",
            nom="Élève",
            prenom="Test",
            date_naissance=date(2012, 5, 3),
            sexe="F",
        )
        self.inscription = Inscription.objects.create(
            ecole=self.ecole,
            eleve=eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            statut=StatutInscription.VALIDEE,
            date_inscription=date(2026, 9, 1),
        )
        Note.objects.create(
            ecole=self.ecole,
            inscription=self.inscription,
            matiere=self.matiere,
            periode=self.periode,
            type_evaluation=type_evaluation,
            valeur=Decimal("16.00"),
            note_max=Decimal("20.00"),
            coefficient_applique=Decimal("1.00"),
            saisie_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

    @override_settings(CELERY_TASK_ALWAYS_EAGER=True)
    def test_parcours_calcul_moyennes_generation_pdf_et_affichage(self):
        with TemporaryDirectory() as media_dir, override_settings(MEDIA_ROOT=media_dir):
            ServiceCalculMoyenne(self.utilisateur).calculer_moyennes_periode(
                self.inscription,
                self.periode,
            )

            moyenne = MoyenneGenerale.objects.get(
                inscription=self.inscription,
                periode=self.periode,
            )
            moyenne_matiere = MoyenneMatiere.objects.get(
                inscription=self.inscription,
                matiere=self.matiere,
                periode=self.periode,
            )
            self.assertEqual(moyenne.moyenne, Decimal("8.0000"))
            self.assertEqual(moyenne_matiere.points_obtenus, Decimal("80.0000"))
            self.assertEqual(moyenne_matiere.points_max, Decimal("100.0000"))

            bulletin = ServiceGenBulletin(
                utilisateur=self.utilisateur,
                ecole=self.ecole,
            ).generer(self.inscription, self.periode)

            self.assertTrue(bulletin.fichier_pdf)
            with bulletin.fichier_pdf.open("rb") as fichier_pdf:
                self.assertTrue(fichier_pdf.read().startswith(b"%PDF"))
            self.assertEqual(Bulletin.objects.filter(periode=self.periode).count(), 1)

            response = self.client.get(
                reverse("bulletins:liste"),
                HTTP_X_TENANT_SLUG=self.ecole.slug,
            )
            self.assertEqual(response.status_code, 200)
            self.assertContains(response, "Test Élève")
            self.assertContains(response, "Brouillon")

            bulletin.fichier_pdf.delete(save=False)

    def test_page_moyennes_affiche_le_detail_par_eleve_et_matiere(self):
        ServiceCalculMoyenne(self.utilisateur).calculer_moyennes_periode(
            self.inscription,
            self.periode,
        )

        response = self.client.get(
            reverse("notes:moyennes"),
            {"periode": str(self.periode.pk)},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Résultats détaillés")
        self.assertContains(response, "Test Élève")
        self.assertContains(response, "Mathématiques")
        self.assertContains(response, "8.00")
        self.assertContains(response, "Détail par matière")

    def test_repartition_des_composantes_est_saisie_et_ramenee_sur_base(self):
        examen = TypeEvaluation.objects.get(ecole=self.ecole, code="EXAM")
        devoir = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="DEV",
            libelle="Devoir",
        )
        travaux_pratiques = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="TP",
            libelle="Travaux pratiques",
        )
        participation = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="PART",
            libelle="Participation informative",
            compte_dans_moyenne=False,
        )
        coefficient = CoefficientsMatiere.objects.get(
            ecole=self.ecole,
            matiere=self.matiere,
            niveau=self.niveau,
            annee_scolaire=self.annee,
        )
        types = [devoir, travaux_pratiques, examen, participation]
        donnees = {
            "mode_calcul": "points",
            "bareme_total": "100",
            f"maximum_{devoir.pk}": "20",
            f"maximum_{travaux_pratiques.pk}": "20",
            f"maximum_{examen.pk}": "60",
        }
        form = FormulaireBaremeMatiere(
            donnees,
            coefficient_matiere=coefficient,
            types_evaluation=types,
        )
        self.assertTrue(form.is_valid(), form.errors)
        form.save()
        response = self.client.get(
            reverse(
                "parametrage:configurer_bareme_coefficient",
                kwargs={"pk": coefficient.pk},
            ),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(response.status_code, 200)

        donnees["bareme_total"] = "99"
        form_invalide = FormulaireBaremeMatiere(
            donnees,
            coefficient_matiere=coefficient,
            types_evaluation=types,
        )
        self.assertFalse(form_invalide.is_valid())

        Note.objects.filter(
            inscription=self.inscription,
            matiere=self.matiere,
            periode=self.periode,
        ).delete()
        self.periode.statut = StatutPeriode.OUVERTE
        self.periode.save()
        service_saisie = ServiceSaisieNote(self.utilisateur)
        composante_non_configuree = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="ORAL",
            libelle="Oral sans points attribués",
        )
        with self.assertRaises(RegleMetierError):
            service_saisie.saisir(
                inscription=self.inscription,
                matiere=self.matiere,
                periode=self.periode,
                type_evaluation=composante_non_configuree,
                valeur=Decimal("10"),
            )

        for type_evaluation, valeur in (
            (devoir, Decimal("20")),
            (travaux_pratiques, Decimal("10")),
            (examen, Decimal("30")),
            (participation, Decimal("10")),
        ):
            note = service_saisie.saisir(
                inscription=self.inscription,
                matiere=self.matiere,
                periode=self.periode,
                type_evaluation=type_evaluation,
                valeur=valeur,
            )
            if type_evaluation == participation:
                self.assertEqual(note.note_max, participation.note_max_defaut)
                continue
            points = {
                devoir.pk: Decimal("20"),
                travaux_pratiques.pk: Decimal("20"),
                examen.pk: Decimal("60"),
            }[type_evaluation.pk]
            self.assertEqual(note.note_max, points)
            self.assertEqual(note.coefficient_applique, points)
            self.assertEqual(note.mode_calcul_applique, "points")
            self.assertEqual(note.bareme_matiere_applique, Decimal("100"))
            self.assertEqual(note.coefficient_matiere_applique, Decimal("2"))

        francais = Matiere.objects.create(
            ecole=self.ecole,
            code="FR",
            libelle="Français",
        )
        CoefficientsMatiere.objects.create(
            ecole=self.ecole,
            matiere=francais,
            niveau=self.niveau,
            annee_scolaire=self.annee,
            coefficient=Decimal("1"),
            bareme_total=Decimal("20"),
        )
        Note.objects.create(
            ecole=self.ecole,
            inscription=self.inscription,
            matiere=francais,
            periode=self.periode,
            type_evaluation=examen,
            valeur=Decimal("15"),
            note_max=Decimal("20"),
            coefficient_applique=Decimal("1"),
            coefficient_matiere_applique=Decimal("1"),
            saisie_par=self.utilisateur,
        )

        self.periode.statut = StatutPeriode.CLOTUREE
        self.periode.save()
        systeme_notation = SystemeNotation.objects.create(
            ecole=self.ecole,
            libelle="Moyenne sur 10",
            base_notation=Decimal("10"),
            note_passage=Decimal("5"),
        )
        moyenne = ServiceCalculMoyenne(self.utilisateur).calculer_moyennes_periode(
            self.inscription,
            self.periode,
        )

        self.assertEqual(moyenne.moyenne, Decimal("6.5000"))
        self.assertTrue(moyenne.est_admis)
        moyenne_matiere = MoyenneMatiere.objects.get(
            inscription=self.inscription,
            matiere=self.matiere,
            periode=self.periode,
        )
        self.assertEqual(moyenne_matiere.points_obtenus, Decimal("60.0000"))
        self.assertEqual(moyenne_matiere.points_max, Decimal("100.0000"))
        self.assertEqual(moyenne_matiere.nb_notes_prises_en_compte, 3)

        coefficient.bareme_total = Decimal("20")
        coefficient.coefficient = Decimal("9")
        coefficient.save()
        systeme_notation.base_notation = Decimal("100")
        systeme_notation.note_passage = Decimal("50")
        systeme_notation.save()
        moyenne = ServiceCalculMoyenne(self.utilisateur).calculer_moyennes_periode(
            self.inscription,
            self.periode,
        )
        self.assertEqual(moyenne.moyenne, Decimal("65.0000"))
        self.assertEqual(moyenne.base_calcul, Decimal("100.00"))

    def test_ponderation_separe_le_maximum_de_saisie_du_poids(self):
        examen = TypeEvaluation.objects.get(ecole=self.ecole, code="EXAM")
        devoir = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="DEV-POND",
            libelle="Devoir",
        )
        travaux_pratiques = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="TP-POND",
            libelle="Travaux pratiques",
        )
        coefficient = CoefficientsMatiere.objects.get(
            ecole=self.ecole,
            matiere=self.matiere,
            niveau=self.niveau,
            annee_scolaire=self.annee,
        )
        types = [devoir, travaux_pratiques, examen]
        donnees = {
            "mode_calcul": "ponderation",
            "bareme_total": "100",
            f"maximum_{devoir.pk}": "20",
            f"maximum_{travaux_pratiques.pk}": "40",
            f"maximum_{examen.pk}": "100",
            f"poids_{devoir.pk}": "20",
            f"poids_{travaux_pratiques.pk}": "30",
            f"poids_{examen.pk}": "50",
        }
        form = FormulaireBaremeMatiere(
            donnees,
            coefficient_matiere=coefficient,
            types_evaluation=types,
        )
        self.assertTrue(form.is_valid(), form.errors)
        form.save()

        Note.objects.filter(
            inscription=self.inscription,
            matiere=self.matiere,
            periode=self.periode,
        ).delete()
        self.periode.statut = StatutPeriode.OUVERTE
        self.periode.save()
        service_saisie = ServiceSaisieNote(self.utilisateur)
        for type_evaluation, valeur, maximum, poids in (
            (devoir, Decimal("16"), Decimal("20"), Decimal("20")),
            (travaux_pratiques, Decimal("24"), Decimal("40"), Decimal("30")),
            (examen, Decimal("70"), Decimal("100"), Decimal("50")),
        ):
            note = service_saisie.saisir(
                inscription=self.inscription,
                matiere=self.matiere,
                periode=self.periode,
                type_evaluation=type_evaluation,
                valeur=valeur,
            )
            self.assertEqual(note.note_max, maximum)
            self.assertEqual(note.coefficient_applique, poids)
            self.assertEqual(note.mode_calcul_applique, "ponderation")
            self.assertEqual(note.bareme_matiere_applique, Decimal("100"))

        self.periode.statut = StatutPeriode.CLOTUREE
        self.periode.save()
        SystemeNotation.objects.create(
            ecole=self.ecole,
            libelle="Moyenne sur 10",
            base_notation=Decimal("10"),
            note_passage=Decimal("5"),
        )
        moyenne = ServiceCalculMoyenne(self.utilisateur).calculer_moyennes_periode(
            self.inscription,
            self.periode,
        )
        self.assertEqual(moyenne.moyenne, Decimal("6.9000"))

    def test_baremes_par_semestre_s_additionnent_sur_le_bareme_annuel(self):
        examen = TypeEvaluation.objects.get(ecole=self.ecole, code="EXAM")
        types = [
            TypeEvaluation.objects.create(
                ecole=self.ecole,
                code=f"SEM-{index}",
                libelle=f"Composante {index}",
            )
            for index in range(1, 5)
        ]
        types.insert(0, examen)
        coefficient = CoefficientsMatiere.objects.get(
            ecole=self.ecole,
            matiere=self.matiere,
            niveau=self.niveau,
            annee_scolaire=self.annee,
        )
        BaremeMatierePeriode.objects.create(
            ecole=self.ecole,
            coefficient_matiere=coefficient,
            periode=self.periode,
            bareme_total=Decimal("50"),
            mode_calcul="points",
        )
        sem2 = PeriodeAcademique.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            numero=2,
            libelle="Semestre 2 2026-2027",
            libelle_court="S2",
            type_periode="semestre",
            date_debut=date(2027, 2, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutPeriode.OUVERTE,
        )

        configuration_semestre_1 = {
            "mode_calcul": "points",
            "bareme_total": "40",
            **dict(
                zip(
                    (
                        f"maximum_{type_evaluation.pk}"
                        for type_evaluation in types
                    ),
                    ("5", "10", "5", "15", "5"),
                )
            ),
        }
        formulaire_semestre_1 = FormulaireBaremeMatiere(
            configuration_semestre_1,
            coefficient_matiere=coefficient,
            periode=self.periode,
            types_evaluation=types,
        )
        self.assertTrue(formulaire_semestre_1.is_valid(), formulaire_semestre_1.errors)
        formulaire_semestre_1.save()

        self.periode.statut = StatutPeriode.OUVERTE
        self.periode.save()
        with self.assertRaises(RegleMetierError):
            ServiceSaisieNote(self.utilisateur).saisir(
                inscription=self.inscription,
                matiere=self.matiere,
                periode=self.periode,
                type_evaluation=types[1],
                valeur=Decimal("5"),
            )
        self.periode.statut = StatutPeriode.CLOTUREE
        self.periode.save()

        configuration_semestre_2_invalide = {
            "mode_calcul": "points",
            "bareme_total": "61",
            **{
                f"maximum_{type_evaluation.pk}": str(maximum)
                for type_evaluation, maximum in zip(types, (21, 15, 5, 10, 10))
            },
        }
        formulaire_semestre_2_invalide = FormulaireBaremeMatiere(
            configuration_semestre_2_invalide,
            coefficient_matiere=coefficient,
            periode=sem2,
            types_evaluation=types,
        )
        self.assertFalse(formulaire_semestre_2_invalide.is_valid())

        configuration_semestre_2 = {
            "mode_calcul": "points",
            "bareme_total": "60",
            **{
                f"maximum_{type_evaluation.pk}": str(maximum)
                for type_evaluation, maximum in zip(types, (10, 15, 5, 20, 10))
            },
        }
        formulaire_semestre_2 = FormulaireBaremeMatiere(
            configuration_semestre_2,
            coefficient_matiere=coefficient,
            periode=sem2,
            types_evaluation=types,
        )
        self.assertTrue(formulaire_semestre_2.is_valid(), formulaire_semestre_2.errors)
        formulaire_semestre_2.save()

        Note.objects.filter(
            inscription=self.inscription,
            matiere=self.matiere,
        ).delete()
        service_saisie = ServiceSaisieNote(self.utilisateur)
        for periode, notes_obtenues in (
            (self.periode, (4, 8, 4, 12, 4)),
            (sem2, (8, 12, 4, 16, 8)),
        ):
            periode.statut = StatutPeriode.OUVERTE
            periode.save()
            for type_evaluation, valeur in zip(types, notes_obtenues):
                note = service_saisie.saisir(
                    inscription=self.inscription,
                    matiere=self.matiere,
                    periode=periode,
                    type_evaluation=type_evaluation,
                    valeur=Decimal(valeur),
                )
                self.assertEqual(
                    note.bareme_matiere_applique,
                    Decimal("40") if periode == self.periode else Decimal("60"),
                )
            periode.statut = StatutPeriode.CLOTUREE
            periode.save()
            ServiceCalculMoyenne(self.utilisateur).calculer_moyennes_periode(
                self.inscription,
                periode,
            )

        moyennes = MoyenneMatiere.objects.filter(
            inscription=self.inscription,
            matiere=self.matiere,
            periode__in=(self.periode, sem2),
        ).order_by("periode__numero")
        self.assertEqual(
            list(moyennes.values_list("points_obtenus", flat=True)),
            [Decimal("32.0000"), Decimal("48.0000")],
        )
        self.assertEqual(
            sum(moyennes.values_list("points_obtenus", flat=True)),
            Decimal("80.0000"),
        )
        self.assertEqual(
            sum(moyennes.values_list("points_max", flat=True)),
            Decimal("100.0000"),
        )
        resultat_annuel = ServiceCalculMoyenne(
            self.utilisateur
        ).calculer_resultat_annuel(self.inscription)
        self.assertEqual(
            resultat_annuel["matieres"][0]["points_obtenus"],
            Decimal("80.0000"),
        )
        self.assertEqual(
            resultat_annuel["matieres"][0]["points_max"],
            Decimal("100"),
        )
        self.assertEqual(resultat_annuel["moyenne_generale"], Decimal("8.0000"))

        response = self.client.get(
            reverse("notes:moyennes_annuelles"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "80.00 / 100.00")

        coefficient.bareme_total = Decimal("200")
        coefficient.save()
        for periode, bareme_total, maxima in (
            (self.periode, "80", ("10", "20", "10", "30", "10")),
            (sem2, "120", ("20", "30", "10", "40", "20")),
        ):
            configuration = {
                "mode_calcul": "points",
                "bareme_total": bareme_total,
                **{
                    f"maximum_{type_evaluation.pk}": maximum
                    for type_evaluation, maximum in zip(types, maxima)
                },
            }
            formulaire = FormulaireBaremeMatiere(
                configuration,
                coefficient_matiere=coefficient,
                periode=periode,
                types_evaluation=types,
            )
            self.assertTrue(formulaire.is_valid(), formulaire.errors)
            formulaire.save()

        self.assertEqual(
            sum(
                BaremeMatierePeriode.objects.filter(
                    coefficient_matiere=coefficient
                ).values_list("bareme_total", flat=True),
                Decimal("0"),
            ),
            Decimal("200"),
        )

    def test_historique_affiche_un_seul_groupe_par_eleve(self):
        autre_type = TypeEvaluation.objects.create(
            ecole=self.ecole,
            code="DEVOIR",
            libelle="Devoir",
            note_max_defaut=Decimal("20.00"),
        )
        Note.objects.create(
            ecole=self.ecole,
            inscription=self.inscription,
            matiere=self.matiere,
            periode=self.periode,
            type_evaluation=autre_type,
            valeur=Decimal("14.00"),
            note_max=Decimal("20.00"),
            coefficient_applique=Decimal("1.00"),
            saisie_par=self.utilisateur,
        )

        response = self.client.get(
            reverse("notes:historique"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Élève", count=1)
        self.assertContains(response, "2 notes")
        self.assertContains(response, "Examen")
        self.assertContains(response, "Devoir")
