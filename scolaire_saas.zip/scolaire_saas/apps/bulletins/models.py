"""
apps/bulletins/models.py
=========================
Bulletins scolaires avec machine à états stricte.
brouillon → valide → publie → archive
"""

import uuid
from django.db import models
from apps.noyau.mixins import UUIDPrimaryKeyMixin, TenantModelMixin, HorodatageMixin


class StatutBulletin(models.TextChoices):
    BROUILLON = "brouillon", "Brouillon"
    VALIDE = "valide", "Validé"
    PUBLIE = "publie", "Publié"
    ARCHIVE = "archive", "Archivé"


TRANSITIONS_BULLETIN = {
    StatutBulletin.BROUILLON: [StatutBulletin.VALIDE],
    StatutBulletin.VALIDE:    [StatutBulletin.PUBLIE, StatutBulletin.BROUILLON],
    StatutBulletin.PUBLIE:    [StatutBulletin.ARCHIVE],
    StatutBulletin.ARCHIVE:   [],
}


class Bulletin(UUIDPrimaryKeyMixin, TenantModelMixin, HorodatageMixin):
    """
    Bulletin scolaire d'un élève pour une période.
    INVARIANT : statut=PUBLIE → le PDF est final et ne peut plus être régénéré
                sauf intervention administrateur.
    INVARIANT : Peut uniquement être généré si periode.statut ∈ [CLOTUREE, PUBLIEE].
    """
    inscription = models.ForeignKey(
        "eleves.Inscription",
        on_delete=models.PROTECT,
        related_name="bulletins",
    )
    periode = models.ForeignKey(
        "academique.PeriodeAcademique",
        on_delete=models.PROTECT,
        related_name="bulletins",
    )
    moyenne_generale = models.ForeignKey(
        "notes.MoyenneGenerale",
        on_delete=models.PROTECT,
        related_name="bulletins",
    )
    statut = models.CharField(
        max_length=10,
        choices=StatutBulletin.choices,
        default=StatutBulletin.BROUILLON,
        db_index=True,
    )
    # PDF généré
    fichier_pdf = models.FileField(
        upload_to="bulletins/%Y/%m/",
        null=True,
        blank=True,
        verbose_name="Fichier PDF",
    )
    # QR code pour vérification d'authenticité
    code_verification = models.CharField(
        max_length=64,
        unique=True,
        verbose_name="Code de vérification",
        help_text="Code unique encodé dans le QR code du bulletin.",
    )
    # Signatures
    signature_directeur = models.BooleanField(default=False)
    tampon_ecole = models.BooleanField(default=False)
    # Traçabilité
    genere_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="bulletins_generes",
    )
    valide_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="bulletins_valides",
    )
    publie_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="bulletins_publies",
    )
    date_generation = models.DateTimeField(null=True, blank=True)
    date_validation = models.DateTimeField(null=True, blank=True)
    date_publication = models.DateTimeField(null=True, blank=True)
    # Appréciation du directeur
    appreciation_directeur = models.TextField(blank=True)

    class Meta:
        verbose_name = "Bulletin"
        verbose_name_plural = "Bulletins"
        unique_together = [("ecole", "inscription", "periode")]
        indexes = [
            models.Index(fields=["ecole", "periode", "statut"], name="idx_bulletin_periode"),
        ]

    def __str__(self):
        return (
            f"Bulletin {self.inscription.eleve.nom_complet} — "
            f"{self.periode.libelle} ({self.statut})"
        )

    def peut_transitionner_vers(self, nouveau_statut: str) -> bool:
        return nouveau_statut in TRANSITIONS_BULLETIN.get(self.statut, [])

    def save(self, *args, **kwargs):
        if not self.code_verification:
            import secrets
            self.code_verification = secrets.token_urlsafe(32)
        super().save(*args, **kwargs)