"""
apps/securite/rbac.py
======================
Moteur de vérification des permissions RBAC.
Cache Redis intégré pour les performances (évite N requêtes par page).
"""

import logging
from django.core.cache import cache
from apps.securite.models import UtilisateurRole

logger = logging.getLogger("apps.securite")


class MoteurRBAC:
    """
    Vérifie les permissions d'un utilisateur dans un établissement.

    Stratégie de cache :
    - Les permissions d'un utilisateur sont cachées 5 minutes par défaut
    - Invalider le cache à chaque modification de rôle (signal post_save)
    - Clé : rbac:{ecole_id}:{user_id}
    """

    TTL_CACHE = 300  # 5 minutes

    def possede_permission(
        self,
        utilisateur,
        ecole,
        code_permission: str,
    ) -> bool:
        """
        Vérifie si un utilisateur possède une permission dans un établissement.
        Les superusers Django ont accès à tout — pas de vérification RBAC.
        """
        if utilisateur is None or not utilisateur.is_authenticated:
            return False

        # Superuser Django : accès total (admin SaaS éditeur)
        if utilisateur.is_superuser:
            return True

        permissions = self._obtenir_permissions_cachees(utilisateur, ecole)
        return code_permission in permissions

    def obtenir_toutes_permissions(self, utilisateur, ecole) -> set[str]:
        """Retourne l'ensemble des permissions d'un utilisateur dans une école."""
        if utilisateur.is_superuser:
            from apps.securite.models import PermissionGranulaire
            return set(PermissionGranulaire.objects.values_list("code", flat=True))
        return self._obtenir_permissions_cachees(utilisateur, ecole)

    def invalider_cache(self, utilisateur, ecole) -> None:
        """Invalide le cache des permissions — appeler après toute modification de rôle."""
        cle = self._cle_cache(utilisateur, ecole)
        cache.delete(cle)
        logger.debug(f"Cache RBAC invalidé : {cle}")

    def _obtenir_permissions_cachees(self, utilisateur, ecole) -> set[str]:
        """Charge les permissions depuis le cache ou la DB."""
        cle = self._cle_cache(utilisateur, ecole)
        permissions = cache.get(cle)

        if permissions is None:
            permissions = self._charger_permissions_db(utilisateur, ecole)
            cache.set(cle, permissions, timeout=self.TTL_CACHE)

        return permissions

    def _charger_permissions_db(self, utilisateur, ecole) -> set[str]:
        """Charge les permissions depuis la DB en une seule requête."""
        attributions = (
            UtilisateurRole.tous_objets
            .filter(
                utilisateur=utilisateur,
                ecole=ecole,
                est_actif=True,
                role__est_actif=True,
            )
            .select_related("role")
            .prefetch_related("role__permissions")
        )

        permissions: set[str] = set()
        from django.utils import timezone

        for attribution in attributions:
            if not attribution.est_valide:
                continue
            for perm in attribution.role.permissions.all():
                permissions.add(perm.code)

        logger.debug(
            f"RBAC chargé depuis DB : user={utilisateur.pk} "
            f"ecole={ecole.slug} → {len(permissions)} permissions"
        )
        return permissions

    def _cle_cache(self, utilisateur, ecole) -> str:
        return f"rbac:{ecole.pk}:{utilisateur.pk}"


# Instance singleton
moteur_rbac = MoteurRBAC()


"""
apps/securite/audit.py
=======================
Service d'audit — écrit dans JournalAudit de façon sûre (ne remonte jamais).
"""

import json
import logging
from django.utils import timezone
from apps.securite.models import JournalAudit
from apps.noyau.middleware import obtenir_tenant_courant

logger_audit = logging.getLogger("audit")


class ServiceAudit:
    """
    Service d'audit immuable.
    Toutes les actions métier significatives passent par ici.
    En cas d'erreur d'écriture, on log en fichier mais on ne bloque PAS le métier.
    """

    def __init__(self, utilisateur=None, ecole=None, adresse_ip: str = None):
        self.utilisateur = utilisateur
        self.ecole = ecole or obtenir_tenant_courant()
        self.adresse_ip = adresse_ip

    def enregistrer(
        self,
        action: str,
        objet=None,
        donnees_avant: dict = None,
        donnees_apres: dict = None,
        metadata: dict = None,
    ) -> JournalAudit | None:
        """
        Crée une entrée d'audit immuable.
        Silencieux en cas d'erreur — l'audit ne doit jamais bloquer le métier.
        """
        try:
            return JournalAudit.objects.create(
                ecole=self.ecole,
                utilisateur=self.utilisateur,
                action=action,
                modele_cible=type(objet).__name__ if objet else "",
                objet_id=str(objet.pk) if objet else "",
                donnees_avant=json.dumps(donnees_avant or {}, default=str, ensure_ascii=False),
                donnees_apres=json.dumps(donnees_apres or {}, default=str, ensure_ascii=False),
                metadata=json.dumps(metadata or {}, default=str, ensure_ascii=False),
                adresse_ip=self.adresse_ip,
                timestamp=timezone.now(),
            )
        except Exception as exc:
            # Critique : log dans le fichier d'audit mais ne remonte pas
            logger_audit.critical(
                f"ÉCHEC AUDIT | action={action!r} | ecole={getattr(self.ecole, 'slug', '?')} | "
                f"user={getattr(self.utilisateur, 'email', '?')} | erreur={exc}",
                exc_info=True,
            )
            return None

    @classmethod
    def depuis_request(cls, request, action: str, objet=None, **kwargs) -> "ServiceAudit":
        """Constructeur pratique depuis une requête HTTP Django."""
        ip = request.META.get("HTTP_X_FORWARDED_FOR", request.META.get("REMOTE_ADDR", ""))
        if "," in ip:
            ip = ip.split(",")[0].strip()
        instance = cls(
            utilisateur=request.user if request.user.is_authenticated else None,
            ecole=getattr(request, "etablissement", None),
            adresse_ip=ip,
        )
        instance.enregistrer(action=action, objet=objet, **kwargs)
        return instance