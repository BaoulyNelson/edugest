from django.contrib import admin
from apps.securite.models import Role, PermissionGranulaire, UtilisateurRole, JournalAudit
from apps.noyau.admin import AdminTenant

@admin.register(PermissionGranulaire)
class PermissionAdmin(admin.ModelAdmin):
    list_display = ["code", "module", "action", "portee", "est_dangereuse"]
    list_filter = ["module", "portee", "est_dangereuse"]
    search_fields = ["code", "description"]

@admin.register(Role)
class RoleAdmin(AdminTenant):
    list_display = ["libelle", "code", "ecole", "est_systeme", "est_actif"]
    list_filter = ["ecole", "est_systeme", "est_actif"]
    filter_horizontal = ["permissions"]

@admin.register(UtilisateurRole)
class UtilisateurRoleAdmin(AdminTenant):
    list_display = ["utilisateur", "role", "ecole", "est_actif", "expire_le"]
    list_filter = ["ecole", "est_actif"]
    search_fields = ["ecole__nom", "ecole__slug", "utilisateur__email", "role__code"]

@admin.register(JournalAudit)
class JournalAuditAdmin(AdminTenant):
    list_display = ["timestamp", "action", "utilisateur", "ecole", "modele_cible", "objet_id"]
    list_filter = ["ecole", "action", "modele_cible"]
    search_fields = ["ecole__nom", "ecole__slug", "action", "utilisateur__email"]
    readonly_fields = [f.name for f in JournalAudit._meta.fields]

    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False
    def has_delete_permission(self, request, obj=None): return False
