"""Vues de gestion des rôles, utilisateurs et audit."""
import hashlib
import logging
import secrets
from datetime import timedelta
from smtplib import SMTPException

from django.conf import settings
from django.contrib.auth import login
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.contrib import messages
from django.core.mail import send_mail
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Q
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST
from apps.noyau.decorateurs import requiert_tenant, requiert_permission
from apps.securite.models import (
    InvitationEcole,
    Role,
    UtilisateurRole,
    JournalAudit,
)
from apps.securite.rbac import ServiceAudit

logger = logging.getLogger(__name__)

SESSION_SIMULATION_ADMIN_ID = "simulation_superuser_id"
SESSION_SIMULATION_BACKEND = "simulation_superuser_backend"


@login_required
@requiert_tenant
def simuler_compte(request):
    """Permet à un superuser de tester les permissions d'un compte de l'école."""
    if not request.user.is_superuser:
        raise PermissionDenied("La simulation de compte est réservée aux superutilisateurs.")
    if request.session.get(SESSION_SIMULATION_ADMIN_ID):
        raise PermissionDenied("Une simulation de compte est déjà en cours.")

    from apps.comptes.models import Utilisateur

    aujourd_hui = timezone.localdate()
    attributions = (
        UtilisateurRole.tous_objets.filter(
            ecole=request.etablissement,
            est_actif=True,
            role__est_actif=True,
            utilisateur__est_actif=True,
            utilisateur__is_superuser=False,
        )
        .filter(Q(expire_le__isnull=True) | Q(expire_le__gte=aujourd_hui))
        .select_related("utilisateur", "role")
        .order_by("utilisateur__nom", "utilisateur__prenom", "role__libelle")
    )
    comptes = {}
    for attribution in attributions:
        compte = comptes.setdefault(
            str(attribution.utilisateur_id),
            {"utilisateur": attribution.utilisateur, "roles": []},
        )
        compte["roles"].append(attribution.role.libelle)

    if request.method == "POST":
        compte_id = request.POST.get("utilisateur_id", "")
        compte = comptes.get(compte_id)
        if compte is None:
            messages.error(
                request,
                "Choisissez un compte actif associé à cet établissement.",
            )
        else:
            backend = "apps.comptes.backends.BackendAuthMultitenant"
            admin_id = str(request.user.pk)
            admin_backend = request.session.get(
                "_auth_user_backend", backend
            )
            preserved_session = {
                key: request.session.get(key)
                for key in ("tenant_slug", "annee_scolaire_selectionnee")
            }
            ServiceAudit(
                utilisateur=request.user,
                ecole=request.etablissement,
            ).enregistrer(
                action="simulation_compte_demarrer",
                donnees_apres={
                    "utilisateur_simule_id": str(compte["utilisateur"].pk),
                    "etablissement_id": str(request.etablissement.pk),
                },
            )
            login(request, compte["utilisateur"], backend=backend)
            request.session[SESSION_SIMULATION_ADMIN_ID] = admin_id
            request.session[SESSION_SIMULATION_BACKEND] = admin_backend
            for key, value in preserved_session.items():
                if value is not None:
                    request.session[key] = value
            messages.warning(
                request,
                "Mode simulation : vous agissez maintenant comme "
                f"{compte['utilisateur'].nom_complet}.",
            )
            return redirect("tableau_bord:index")

    return render(
        request,
        "securite/simuler_compte.html",
        {"comptes": comptes.values()},
    )


@login_required
@requiert_tenant
@require_POST
def arreter_simulation_compte(request):
    """Restaure la session superuser qui a démarré la simulation."""
    admin_id = request.session.get(SESSION_SIMULATION_ADMIN_ID)
    backend = request.session.get(SESSION_SIMULATION_BACKEND)
    if not admin_id or not backend:
        raise PermissionDenied("Aucune simulation de compte n'est en cours.")

    from django.contrib.auth import logout
    from apps.comptes.models import Utilisateur

    admin = Utilisateur.objects.filter(
        pk=admin_id,
        is_superuser=True,
        est_actif=True,
    ).first()
    if admin is None or backend not in settings.AUTHENTICATION_BACKENDS:
        logout(request)
        messages.error(
            request,
            "La session administrateur d'origine n'est plus disponible. "
            "Veuillez vous reconnecter.",
        )
        return redirect("comptes:connexion")

    ServiceAudit(
        utilisateur=admin,
        ecole=request.etablissement,
    ).enregistrer(
        action="simulation_compte_arreter",
        donnees_avant={
            "utilisateur_simule_id": str(request.user.pk),
            "etablissement_id": str(request.etablissement.pk),
        },
    )
    preserved_session = {
        key: request.session.get(key)
        for key in ("tenant_slug", "annee_scolaire_selectionnee")
    }
    login(request, admin, backend=backend)
    request.session.pop(SESSION_SIMULATION_ADMIN_ID, None)
    request.session.pop(SESSION_SIMULATION_BACKEND, None)
    for key, value in preserved_session.items():
        if value is not None:
            request.session[key] = value
    messages.success(request, "Vous êtes de retour sur votre compte superuser.")
    return redirect("tableau_bord:index")


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def liste_roles(request):
    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    roles = Role.objects.filter(
        ecole=request.etablissement
    ).prefetch_related("permissions")
    if q:
        roles = roles.filter(Q(code__icontains=q) | Q(libelle__icontains=q))
    if statut in {"actif", "inactif"}:
        roles = roles.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    return render(request, "securite/roles.html", {
        "roles": roles,
        "q": q,
        "filtre_statut": statut,
    })


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def creer_role(request):
    from apps.securite.models import PermissionGranulaire
    if request.method == "POST":
        code = request.POST.get("code", "").strip()
        libelle = request.POST.get("libelle", "").strip()
        perms_ids = request.POST.getlist("permissions")
        if code and libelle:
            role = Role.objects.create(ecole=request.etablissement, code=code, libelle=libelle)
            role.permissions.set(PermissionGranulaire.objects.filter(pk__in=perms_ids))
            messages.success(request, f"Rôle {libelle} créé.")
            return redirect("securite:roles")
    permissions = PermissionGranulaire.objects.all().order_by("module", "action")
    return render(request, "securite/form_role.html", {"permissions": permissions})


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def modifier_role(request, pk):
    role = get_object_or_404(Role, pk=pk, ecole=request.etablissement)
    from apps.securite.models import PermissionGranulaire
    if request.method == "POST":
        perms_ids = request.POST.getlist("permissions")
        role.libelle = request.POST.get("libelle", role.libelle)
        role.save()
        role.permissions.set(PermissionGranulaire.objects.filter(pk__in=perms_ids))
        messages.success(request, "Rôle mis à jour.")
        return redirect("securite:roles")
    permissions = PermissionGranulaire.objects.all().order_by("module", "action")
    return render(request, "securite/form_role.html", {"role": role, "permissions": permissions})


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def liste_utilisateurs(request):
    q = request.GET.get("q", "").strip()
    filtre_role = request.GET.get("role", "")
    filtre_statut = request.GET.get("statut", "")

    roles = Role.objects.filter(ecole=request.etablissement).order_by("libelle")
    attributions = UtilisateurRole.tous_objets.filter(
        ecole=request.etablissement,
    ).select_related("utilisateur", "role")

    if q:
        attributions = attributions.filter(
            Q(utilisateur__nom__icontains=q)
            | Q(utilisateur__prenom__icontains=q)
            | Q(utilisateur__email__icontains=q)
        )

    if filtre_role.isdigit() and roles.filter(pk=filtre_role).exists():
        attributions = attributions.filter(role_id=filtre_role)
    else:
        filtre_role = ""

    aujourd_hui = timezone.localdate()
    if filtre_statut == "actif":
        attributions = attributions.filter(est_actif=True).filter(
            Q(expire_le__isnull=True) | Q(expire_le__gte=aujourd_hui)
        )
    elif filtre_statut == "expire":
        attributions = attributions.filter(
            est_actif=True,
            expire_le__lt=aujourd_hui,
        )
    elif filtre_statut == "inactif":
        attributions = attributions.filter(est_actif=False)
    else:
        filtre_statut = ""

    attributions = attributions.order_by(
        "utilisateur__nom",
        "utilisateur__prenom",
        "role__libelle",
    )
    return render(
        request,
        "securite/utilisateurs.html",
        {
            "attributions": attributions,
            "roles": roles,
            "q": q,
            "filtre_role": filtre_role,
            "filtre_statut": filtre_statut,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def inviter_utilisateur(request):
    roles = Role.objects.filter(est_actif=True)
    if request.method == "POST":
        email = request.POST.get("email", "").strip()
        role_id = request.POST.get("role_id")
        role = get_object_or_404(
            roles,
            pk=role_id,
        )
        from django.core.validators import validate_email
        from django.core.exceptions import ValidationError

        try:
            validate_email(email)
        except ValidationError:
            messages.error(request, "Saisissez une adresse e-mail valide.")
            return render(request, "securite/inviter.html", {"roles": roles})

        email = email.lower()
        token = secrets.token_urlsafe(32)
        invitation_url = request.build_absolute_uri(
            reverse("securite:accepter_invitation", kwargs={"token": token})
        )
        invitation = InvitationEcole(
            ecole=request.etablissement,
            email=email,
            token_hash=hashlib.sha256(token.encode("utf-8")).hexdigest(),
            role=role,
            invite_par=request.user,
            expire_le=timezone.now() + timedelta(days=7),
        )
        nom_inviteur = request.user.nom_complet or request.user.email
        from apps.etablissements.models import ConfigurationSite

        configuration_site = ConfigurationSite.objects.filter(pk=1).first()
        nom_site = (
            configuration_site.nom_site
            if configuration_site
            else "Scolaire SaaS"
        )
        corps = (
            f"Bonjour,\n\n"
            f"{nom_inviteur} vous invite à rejoindre "
            f"{request.etablissement.nom} avec le rôle « {role.libelle} ».\n\n"
            f"Si vous avez déjà un compte {nom_site}, connectez-vous avec "
            "l'adresse destinataire de cette invitation. Sinon, créez votre "
            "compte depuis le lien ci-dessous. Vous rejoindrez cette école "
            "sans en créer une autre.\n\n"
            f"Accepter l'invitation : {invitation_url}\n\n"
            "Ce lien expire dans 7 jours. Si vous n'attendiez pas cette "
            "invitation, vous pouvez ignorer ce message."
        )
        try:
            with transaction.atomic():
                invitation.save()
                messages_envoyes = send_mail(
                    subject=(
                        f"Invitation à rejoindre {request.etablissement.nom} "
                        f"— {nom_site}"
                    ),
                    message=corps,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[email],
                    fail_silently=False,
                )
                if messages_envoyes != 1:
                    invitation.delete()
                    messages.error(
                        request,
                        "L’invitation n’a pas pu être envoyée. Vérifiez la "
                        "configuration de la messagerie et réessayez.",
                    )
                    return render(
                        request, "securite/inviter.html", {"roles": roles}
                    )
        except (SMTPException, OSError):
            logger.exception("Échec d'envoi d'une invitation d'établissement")
            messages.error(
                request,
                "L’e-mail d’invitation n’a pas pu être envoyé. "
                "Aucune invitation n’a été conservée.",
            )
            return render(request, "securite/inviter.html", {"roles": roles})

        messages.success(
            request,
            f"Invitation envoyée à {email}. Le lien permet de créer un compte "
            "ou de se connecter, puis de rejoindre votre école.",
        )
        return redirect("securite:utilisateurs")
    return render(request, "securite/inviter.html", {"roles": roles})


def _hash_token_invitation(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _accepter_invitation(invitation, utilisateur):
    invitation = InvitationEcole.tous_objets.select_for_update().get(pk=invitation.pk)
    if not invitation.est_valide:
        return False
    if utilisateur.email.casefold() != invitation.email.casefold():
        return False
    if invitation.role.ecole_id != invitation.ecole_id:
        return False

    attribution, creee = UtilisateurRole.tous_objets.get_or_create(
        ecole=invitation.ecole,
        utilisateur=utilisateur,
        role=invitation.role,
        defaults={
            "est_actif": True,
            "attribue_par": invitation.invite_par,
        },
    )
    if not creee:
        attribution.est_actif = True
        attribution.attribue_par = invitation.invite_par
        attribution.save(update_fields=["est_actif", "attribue_par", "modifie_le"])
    invitation.acceptee_le = timezone.now()
    invitation.save(update_fields=["acceptee_le", "modifie_le"])
    return True


def accepter_invitation(request, token):
    invitation = get_object_or_404(
        InvitationEcole.tous_objets.select_related(
            "ecole", "role", "invite_par"
        ),
        token_hash=_hash_token_invitation(token),
    )
    form = None
    compte_existant = None
    invitation_valide = invitation.est_valide
    if invitation_valide and not request.user.is_authenticated:
        from apps.comptes.models import Utilisateur

        compte_existant = Utilisateur.objects.filter(
            email__iexact=invitation.email
        ).first()
        if not compte_existant:
            from apps.comptes.forms import FormulaireCreationCompte

            if request.method == "POST":
                form = FormulaireCreationCompte(request.POST)
                form.fields["email"].initial = invitation.email
                form.fields["email"].disabled = True
                if form.is_valid():
                    with transaction.atomic():
                        invitation_actuelle = InvitationEcole.tous_objets.select_for_update().get(
                            pk=invitation.pk
                        )
                        utilisateur = form.save(commit=False)
                        utilisateur.save()
                        if not _accepter_invitation(
                            invitation_actuelle, utilisateur
                        ):
                            utilisateur.delete()
                            messages.error(
                                request,
                                "Cette invitation a expiré ou ne peut plus être "
                                "acceptée. Demandez un nouveau lien au directeur.",
                            )
                            return redirect("saas:accueil")
                    login(
                        request,
                        utilisateur,
                        backend="django.contrib.auth.backends.ModelBackend",
                    )
                    request.session["tenant_slug"] = invitation.ecole.slug
                    messages.success(
                        request,
                        f"Bienvenue dans {invitation.ecole.nom}. Votre compte "
                        f"est associé au rôle « {invitation.role.libelle} ».",
                    )
                    return redirect("tableau_bord:index")
            else:
                form = FormulaireCreationCompte(initial={"email": invitation.email})
                form.fields["email"].disabled = True

    if request.method == "POST" and invitation_valide and request.user.is_authenticated:
        if request.user.email.casefold() != invitation.email.casefold():
            messages.error(
                request,
                f"Cette invitation est destinée à {invitation.email}. "
                "Connectez-vous avec cette adresse.",
            )
        else:
            with transaction.atomic():
                invitation_actuelle = InvitationEcole.tous_objets.select_for_update().get(
                    pk=invitation.pk
                )
                if _accepter_invitation(invitation_actuelle, request.user):
                    request.session["tenant_slug"] = invitation.ecole.slug
                    messages.success(
                        request,
                        f"Vous avez rejoint {invitation.ecole.nom} comme "
                        f"{invitation.role.libelle}.",
                    )
                    return redirect("tableau_bord:index")
            invitation_valide = False

    return render(
        request,
        "securite/accepter_invitation.html",
        {
            "invitation": invitation,
            "invitation_valide": invitation_valide,
            "compte_existant": compte_existant,
            "form": form,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def gerer_roles_utilisateur(request, pk):
    from apps.comptes.models import Utilisateur
    user = get_object_or_404(Utilisateur, pk=pk)
    attributions = UtilisateurRole.tous_objets.filter(ecole=request.etablissement, utilisateur=user)
    roles = Role.objects.filter(est_actif=True)
    return render(request, "securite/gerer_roles.html", {"profil": user, "attributions": attributions, "roles": roles})


@login_required
@requiert_tenant
@requiert_permission("utilisateurs.gerer.etablissement")
def journal_audit(request):
    q = request.GET.get("q", "").strip()
    action = request.GET.get("action", "").strip()
    entries = JournalAudit.objects.filter(ecole=request.etablissement)
    actions = list(
        entries.order_by().values_list("action", flat=True).distinct().order_by("action")
    )
    if q:
        entries = entries.filter(
            Q(action__icontains=q)
            | Q(utilisateur__nom__icontains=q)
            | Q(utilisateur__prenom__icontains=q)
            | Q(utilisateur__email__icontains=q)
            | Q(modele_cible__icontains=q)
            | Q(objet_id__icontains=q)
            | Q(adresse_ip__icontains=q)
        )
    if action and action in actions:
        entries = entries.filter(action=action)
    else:
        action = ""
    paginator = Paginator(entries.order_by("-timestamp"), 50)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "securite/journal_audit.html",
        {
            "entries": page_obj.object_list,
            "page_obj": page_obj,
            "q": q,
            "actions": actions,
            "filtre_action": action,
        },
    )
