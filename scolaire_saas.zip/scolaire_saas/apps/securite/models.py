"""
apps/securite/models.py
========================
RBAC granulaire : Rôle, PermissionGranulaire, UtilisateurRole.
JournalAudit : enregistrement immuable de toutes les actions métier.

Architecture RBAC :
  Utilisateur → UtilisateurRole → Role → PermissionGranulaire
  Un utilisateur peut avoir plusieurs rôles dans un même établissement.
  Les permissions sont vérifiées en union (si un rôle l'autorise, c'est OK).
"""

from django.db import models
from django.conf import settings
from django.utils import timezone
from apps.noyau.mixins import TenantModelMixin, HorodatageMixin


# ─── Catalogue des permissions ───────────────────────────────────────────────

class PermissionGranulaire(models.Model):
    """
    Catalogue global des permissions du système.
    Format : <module>.<action>.<portee>

    Exemples :
        notes.saisir.propres_classes
        notes.valider.toutes_classes
        bulletins.publier.toutes_classes
        finances.consulter.toutes_classes
        finances.encaisser.toutes_classes
        annee_scolaire.activer.etablissement
        eleves.inscrire.toutes_classes
        rapports.exporter.etablissement
        parametrage.modifier.etablissement
        utilisateurs.gerer.etablissement

    Scope (portee) :
        propres_classes  → seulement les classes où l'utilisateur est affecté
        toutes_classes   → toutes les classes de l'école
        etablissement    → action globale sur l'établissement
    """
    code = models.CharField(
        max_length=100,
        unique=True,
        verbose_name="Code de permission",
    )
    description = models.CharField(max_length=250)
    module = models.CharField(max_length=40, db_index=True)
    action = models.CharField(max_length=40)
    portee = models.CharField(
        max_length=30,
        choices=[
            ("propres_classes", "Propres classes"),
            ("toutes_classes", "Toutes les classes"),
            ("etablissement", "Établissement entier"),
        ],
    )
    est_dangereuse = models.BooleanField(
        default=False,
        help_text="Permissions à fort impact — ne jamais attribuer sans validation.",
    )

    class Meta:
        verbose_name = "Permission"
        verbose_name_plural = "Permissions"
        ordering = ["module", "action"]

    def __str__(self):
        return self.code


# ─── Rôles ───────────────────────────────────────────────────────────────────

ROLES_SYSTEME = {
    "directeur": "Directeur / Administrateur",
    "secretaire": "Secrétaire",
    "comptable": "Comptable",
    "enseignant": "Enseignant",
    "surveillant": "Surveillant / Censeur",
    "parent": "Parent (lecture seule)",
}

PERMISSIONS_PAR_ROLE = {
    "directeur": [
        "notes.saisir.toutes_classes",
        "notes.valider.toutes_classes",
        "bulletins.generer.toutes_classes",
        "bulletins.valider.toutes_classes",
        "bulletins.publier.toutes_classes",
        "finances.consulter.toutes_classes",
        "finances.encaisser.toutes_classes",
        "finances.annuler.toutes_classes",
        "annee_scolaire.activer.etablissement",
        "annee_scolaire.cloturer.etablissement",
        "eleves.inscrire.toutes_classes",
        "eleves.transferer.toutes_classes",
        "eleves.suspendre.toutes_classes",
        "parametrage.modifier.etablissement",
        "utilisateurs.gerer.etablissement",
        "rapports.exporter.etablissement",
        "badges.generer.toutes_classes",
    ],
    "secretaire": [
        "eleves.inscrire.toutes_classes",
        "eleves.transferer.toutes_classes",
        "bulletins.generer.toutes_classes",
        "bulletins.valider.toutes_classes",
        "finances.consulter.toutes_classes",
        "badges.generer.toutes_classes",
        "rapports.exporter.etablissement",
    ],
    "comptable": [
        "finances.consulter.toutes_classes",
        "finances.encaisser.toutes_classes",
        "finances.annuler.toutes_classes",
        "rapports.exporter.etablissement",
    ],
    "enseignant": [
        "notes.saisir.propres_classes",
        "notes.valider.propres_classes",
        "bulletins.generer.propres_classes",
        "eleves.consulter.propres_classes",
    ],
    "surveillant": [
        "eleves.consulter.toutes_classes",
        "eleves.suspendre.toutes_classes",
        "rapports.exporter.etablissement",
    ],
    "parent": [
        "bulletins.consulter.propres_enfants",
        "finances.consulter.propres_enfants",
    ],
}


class Role(TenantModelMixin, HorodatageMixin):
    """
    Rôle défini dans un établissement.
    Les rôles système sont créés automatiquement à l'ouverture du compte.
    Les écoles peuvent créer des rôles personnalisés.
    """
    code = models.CharField(max_length=40)
    libelle = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    est_systeme = models.BooleanField(
        default=False,
        help_text="True = créé automatiquement. Ne pas supprimer.",
    )
    est_actif = models.BooleanField(default=True)
    permissions = models.ManyToManyField(
        PermissionGranulaire,
        blank=True,
        related_name="roles",
        verbose_name="Permissions accordées",
    )

    class Meta:
        verbose_name = "Rôle"
        verbose_name_plural = "Rôles"
        unique_together = [("ecole", "code")]
        ordering = ["libelle"]

    def __str__(self):
        return f"{self.libelle} ({self.ecole.nom_court or self.ecole.slug})"

    def lister_permissions(self) -> list[str]:
        """Retourne la liste des codes de permission de ce rôle."""
        return list(self.permissions.values_list("code", flat=True))


class UtilisateurRole(TenantModelMixin, HorodatageMixin):
    """
    Association entre un utilisateur et un rôle dans un établissement.
    Un utilisateur peut avoir plusieurs rôles dans la même école.
    Exemple : Directeur + Enseignant (enseigne lui-même).
    """
    utilisateur = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.CASCADE,
        related_name="roles_etablissement",
    )
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name="attributions",
    )
    est_actif = models.BooleanField(default=True, db_index=True)
    expire_le = models.DateField(
        null=True,
        blank=True,
        verbose_name="Expiration",
        help_text="Null = pas d'expiration.",
    )
    attribue_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="roles_attribues",
    )
    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "Attribution de rôle"
        verbose_name_plural = "Attributions de rôles"
        unique_together = [("ecole", "utilisateur", "role")]

    def __str__(self):
        return f"{self.utilisateur.nom_complet} → {self.role.libelle}"

    @property
    def est_valide(self) -> bool:
        """Un rôle est valide s'il est actif et non expiré."""
        from django.utils import timezone
        if not self.est_actif:
            return False
        if self.expire_le and self.expire_le < timezone.now().date():
            return False
        return True


class InvitationEcole(TenantModelMixin, HorodatageMixin):
    email = models.EmailField()
    token_hash = models.CharField(max_length=64, unique=True)
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name="invitations",
    )
    invite_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="invitations_ecole_envoyees",
    )
    expire_le = models.DateTimeField(db_index=True)
    acceptee_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Invitation à rejoindre une école"
        verbose_name_plural = "Invitations à rejoindre une école"
        ordering = ["-cree_le"]
        indexes = [
            models.Index(fields=["ecole", "email", "expire_le"]),
        ]

    @property
    def est_valide(self):
        return self.acceptee_le is None and self.expire_le > timezone.now()


# ─── Journal d'audit immuable ────────────────────────────────────────────────

class JournalAudit(models.Model):
    """
    Journal immuable de toutes les actions métier.

    RÈGLES D'IMMUABILITÉ :
    - Aucune méthode save() ne doit être appelée après la création
    - Pas de mise à jour autorisée (pas de update_or_create)
    - Pas de suppression (pas de delete())
    - Accessible uniquement en lecture depuis l'interface

    Le manager `tous_objets` est utilisé car ce modèle n'est pas tenant-filtré
    (l'audit doit fonctionner même hors contexte tenant — tâches Celery, signaux).
    """
    # Contexte
    ecole = models.ForeignKey(
        "etablissements.Etablissement",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="journal_audit",
        db_index=True,
    )
    utilisateur = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="journal_audit",
    )
    # Action
    action = models.CharField(
        max_length=80,
        db_index=True,
        verbose_name="Action",
        help_text="Ex: creation_note, publication_bulletin, connexion_utilisateur",
    )
    modele_cible = models.CharField(
        max_length=60,
        blank=True,
        verbose_name="Modèle concerné",
    )
    objet_id = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="ID de l'objet",
    )
    # Données (JSON sérialisé)
    donnees_avant = models.TextField(
        blank=True,
        verbose_name="État avant",
    )
    donnees_apres = models.TextField(
        blank=True,
        verbose_name="État après",
    )
    metadata = models.TextField(
        blank=True,
        verbose_name="Métadonnées supplémentaires",
    )
    # Contexte réseau
    adresse_ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.CharField(max_length=300, blank=True)
    # Timestamp immuable
    timestamp = models.DateTimeField(
        db_index=True,
        verbose_name="Horodatage",
    )

    # Pas de TenantManager — accès cross-tenant pour les superadmins
    objects = models.Manager()

    class Meta:
        verbose_name = "Journal d'audit"
        verbose_name_plural = "Journal d'audit"
        ordering = ["-timestamp"]
        indexes = [
            models.Index(fields=["ecole", "action", "timestamp"], name="idx_audit_ecole_action"),
            models.Index(fields=["utilisateur", "timestamp"], name="idx_audit_user"),
            models.Index(fields=["modele_cible", "objet_id"], name="idx_audit_objet"),
        ]

    def __str__(self):
        user = self.utilisateur.nom_complet if self.utilisateur else "Système"
        return f"[{self.timestamp:%d/%m/%Y %H:%M}] {user} — {self.action}"

    def save(self, *args, **kwargs):
        """Interdit la modification après création."""
        if self.pk:
            raise RuntimeError(
                "JournalAudit est immuable. "
                "Aucune modification n'est autorisée après création."
            )
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        """Suppression interdite."""
        raise RuntimeError(
            "JournalAudit est immuable. La suppression est interdite."
        )