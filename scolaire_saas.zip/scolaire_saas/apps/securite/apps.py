from django.apps import AppConfig

class SecuriteConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.securite"
    verbose_name = "RBAC, permissions et journal audit"
