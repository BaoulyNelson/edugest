"""Tests du parcours d'invitation à rejoindre un établissement."""

import hashlib
import re
from datetime import timedelta
from urllib.parse import urlsplit

from django.core import mail
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from apps.comptes.models import Utilisateur
from apps.etablissements.models import Etablissement
from apps.securite.models import (
    InvitationEcole,
    PermissionGranulaire,
    Role,
    UtilisateurRole,
)


@override_settings(
    EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class InvitationEcoleTests(TestCase):
    def setUp(self):
        self.directeur = Utilisateur.objects.create_superuser(
            email="directeur@example.com",
            password="DirecteurSolide!2468",
            nom="Directeur",
            prenom="Test",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-invitations",
            nom="École des invitations",
            nom_court="EDI",
            ville="Port-au-Prince",
            departement="Ouest",
            adresse="10, rue de la Paix",
            telephone="+509 0000 0000",
            email="contact@ecole.example",
            site_web="https://ecole.example",
            devise_etablissement="Apprendre pour réussir",
            annee_fondation=2001,
            numero_agrement="AG-123",
            cree_par=self.directeur,
        )
        self.role = Role.objects.create(
            ecole=self.ecole,
            code="enseignant-test",
            libelle="Enseignant",
        )
        self.client.force_login(self.directeur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

    def _envoyer_invitation(self, email="nouveau@example.com"):
        response = self.client.post(
            reverse("securite:inviter"),
            {"email": email, "role_id": self.role.pk},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(len(mail.outbox), 1)
        match = re.search(r"https?://\S+", mail.outbox[0].body)
        self.assertIsNotNone(match)
        return urlsplit(match.group()).path

    def test_invitation_est_envoyee_et_compte_nouveau_rejoint_sans_creer_ecole(self):
        chemin = self._envoyer_invitation()
        invitation = InvitationEcole.tous_objets.get(email="nouveau@example.com")
        self.client.logout()

        self.assertIn("expire dans 7 jours", mail.outbox[0].body)
        self.assertEqual(invitation.ecole, self.ecole)
        self.assertEqual(invitation.role, self.role)

        response = self.client.get(chemin)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "nouvelle école")
        self.assertContains(response, 'src="/static/images/logo.png"')
        self.assertContains(response, "École des invitations")
        self.assertContains(response, "Apprendre pour réussir")
        self.assertContains(response, "10, rue de la Paix")
        self.assertContains(response, "contact@ecole.example")
        self.assertContains(response, "https://ecole.example")
        self.assertContains(response, "AG-123")

        response = self.client.post(
            chemin,
            {
                "email": "une-autre-adresse@example.com",
                "nom": "Nouvel",
                "prenom": "Enseignant",
                "telephone": "",
                "mot_de_passe": "MotDePasseTresSolide!2468",
                "confirmer_mot_de_passe": "MotDePasseTresSolide!2468",
            },
        )

        self.assertEqual(response.status_code, 302)
        utilisateur = Utilisateur.objects.get(email="nouveau@example.com")
        self.assertTrue(UtilisateurRole.tous_objets.filter(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=self.role,
            est_actif=True,
        ).exists())
        self.assertContains(
            self.client.get(chemin),
            "déjà été utilisée",
        )
        self.assertEqual(Etablissement.objects.count(), 1)
        self.assertEqual(self.client.session["tenant_slug"], self.ecole.slug)
        invitation.refresh_from_db()
        self.assertIsNotNone(invitation.acceptee_le)

    def test_compte_existant_peut_accepter_invitation(self):
        chemin = self._envoyer_invitation("existant@example.com")
        self.client.logout()
        utilisateur = Utilisateur.objects.create_user(
            email="existant@example.com",
            password="MotDePasseSolide!2468",
            nom="Compte",
            prenom="Existant",
        )

        response = self.client.get(chemin)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context["compte_existant"])
        self.assertContains(response, reverse("comptes:connexion"))

        self.client.force_login(utilisateur)
        response = self.client.post(chemin)

        self.assertEqual(response.status_code, 302)
        self.assertTrue(UtilisateurRole.tous_objets.filter(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=self.role,
            est_actif=True,
        ).exists())

    def test_invitation_refuse_une_autre_adresse_et_expire(self):
        chemin = self._envoyer_invitation()
        invitation = InvitationEcole.tous_objets.get(email="nouveau@example.com")
        autre_utilisateur = Utilisateur.objects.create_user(
            email="autre@example.com",
            password="MotDePasseSolide!2468",
            nom="Autre",
            prenom="Compte",
        )
        self.client.force_login(autre_utilisateur)

        response = self.client.post(chemin)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(UtilisateurRole.tous_objets.filter(
            ecole=self.ecole,
            utilisateur=autre_utilisateur,
            role=self.role,
        ).exists())

        invitation.expire_le = timezone.now()
        invitation.save(update_fields=["expire_le", "modifie_le"])
        self.client.logout()
        response = self.client.get(chemin)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Cette invitation a expiré")

    def test_jeton_stocke_uniquement_sous_forme_de_hash(self):
        chemin = self._envoyer_invitation()
        token = chemin.rstrip("/").rsplit("/", 1)[-1]
        invitation = InvitationEcole.tous_objets.get(email="nouveau@example.com")

        self.assertEqual(
            invitation.token_hash,
            hashlib.sha256(token.encode("utf-8")).hexdigest(),
        )
        self.assertNotEqual(invitation.token_hash, token)

    def test_liste_utilisateurs_peut_filtrer_recherche_role_et_statut(self):
        role_comptable = Role.objects.create(
            ecole=self.ecole,
            code="comptable-test",
            libelle="Comptable",
        )
        utilisateurs = [
            Utilisateur.objects.create_user(
                email=email,
                password="MotDePasseSolide!2468",
                nom=nom,
                prenom="Membre",
            )
            for email, nom in (
                ("actif@example.com", "Actif"),
                ("expire@example.com", "Expire"),
                ("desactive@example.com", "Désactivé"),
                ("comptable@example.com", "Comptable"),
            )
        ]
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=utilisateurs[0],
            role=self.role,
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=utilisateurs[1],
            role=self.role,
            expire_le=timezone.localdate() - timedelta(days=1),
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=utilisateurs[2],
            role=self.role,
            est_actif=False,
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=utilisateurs[3],
            role=role_comptable,
        )
        url = reverse("securite:utilisateurs")

        response = self.client.get(url, {"q": "actif"})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'onchange="this.form.requestSubmit()"', count=2)
        self.assertNotContains(response, ">Filtrer</button>", html=False)
        self.assertEqual(
            list(response.context["attributions"].values_list(
                "utilisateur__email", flat=True
            )),
            ["actif@example.com"],
        )

        response = self.client.get(url, {"role": role_comptable.pk})
        self.assertEqual(
            list(response.context["attributions"].values_list(
                "utilisateur__email", flat=True
            )),
            ["comptable@example.com"],
        )

        response = self.client.get(url, {"role": "invalide"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["filtre_role"], "")

        response = self.client.get(url, {"statut": "expire"})
        self.assertEqual(
            list(response.context["attributions"].values_list(
                "utilisateur__email", flat=True
            )),
            ["expire@example.com"],
        )

        response = self.client.get(url, {"statut": "inactif"})
        self.assertEqual(
            list(response.context["attributions"].values_list(
                "utilisateur__email", flat=True
            )),
            ["desactive@example.com"],
        )

    def test_menu_lateral_affiche_uniquement_les_roles_actifs_de_lecole_courante(self):
        role_secondaire = Role.objects.create(
            ecole=self.ecole,
            code="assistant-test",
            libelle="Assistant de direction",
        )
        autre_ecole = Etablissement.objects.create(
            slug="autre-ecole-menu-role",
            nom="Autre école",
            ville="Cap-Haïtien",
            cree_par=self.directeur,
        )
        role_autre_ecole = Role.objects.create(
            ecole=autre_ecole,
            code="directeur-autre-ecole",
            libelle="Directeur autre école",
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=self.directeur,
            role=self.role,
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=self.directeur,
            role=role_secondaire,
        )
        UtilisateurRole.tous_objets.create(
            ecole=autre_ecole,
            utilisateur=self.directeur,
            role=role_autre_ecole,
        )

        response = self.client.get(reverse("securite:utilisateurs"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'aria-label="Votre rôle dans cet établissement"')
        self.assertContains(response, "Enseignant")
        self.assertContains(response, "Assistant de direction")
        self.assertNotContains(response, "Directeur autre école")

    def test_menu_et_tableau_de_bord_masquent_les_fonctionnalites_sans_permission(self):
        utilisateur = Utilisateur.objects.create_user(
            email="comptable-sans-pouvoirs@test.ht",
            password="MotDePasseSolide!2468",
            nom="Comptable",
            prenom="Lecture",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="comptable-lecture",
            libelle="Comptable en lecture",
        )
        permission_finances = PermissionGranulaire.objects.create(
            code="finances.consulter.toutes_classes",
            description="Consulter les finances de l’établissement",
            module="finances",
            action="consulter",
            portee="toutes_classes",
        )
        role.permissions.add(permission_finances)
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=role,
        )
        self.client.force_login(utilisateur)

        response = self.client.get(
            reverse("tableau_bord:index"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        permissions = response.context["permissions_utilisateur_courant"]
        self.assertEqual(permissions, {"finances.consulter.toutes_classes"})
        self.assertContains(response, reverse("finances:tableau_bord"))
        self.assertContains(response, "Montant encaissé")
        self.assertNotContains(response, reverse("rapports:index"))
        self.assertNotContains(response, reverse("securite:utilisateurs"))
        self.assertNotContains(response, reverse("parametrage:index"))
        self.assertNotContains(response, reverse("notes:saisie"))
        self.assertNotContains(response, reverse("finances:enregistrer"))
        self.assertNotContains(response, "Inscrire un élève")
        self.assertNotContains(response, "Actions rapides")

    def test_un_utilisateur_sans_permission_ne_voit_pas_les_statistiques_financieres(self):
        utilisateur = Utilisateur.objects.create_user(
            email="membre-sans-permission@test.ht",
            password="MotDePasseSolide!2468",
            nom="Membre",
            prenom="Sans rôle",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="lecture-generale",
            libelle="Lecture générale",
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=role,
        )
        self.client.force_login(utilisateur)

        response = self.client.get(
            reverse("tableau_bord:index"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, reverse("finances:tableau_bord"))
        self.assertNotContains(response, "Montant encaissé")
        self.assertNotContains(response, "Encaissements au fil des mois")


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class SimulationCompteSuperuserTests(TestCase):
    def setUp(self):
        self.admin = Utilisateur.objects.create_superuser(
            email="admin-simulation@example.com",
            password="AdminSimulation!2468",
            nom="Admin",
            prenom="Test",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-simulation",
            nom="École de simulation",
            nom_court="EDS",
            ville="Port-au-Prince",
            departement="Ouest",
            adresse="10, rue de test",
            telephone="+509 0000 0000",
            email="contact@simulation.example",
            site_web="https://simulation.example",
            devise_etablissement="Apprendre",
            annee_fondation=2001,
            numero_agrement="SIM-123",
            cree_par=self.admin,
        )
        self.role = Role.objects.create(
            ecole=self.ecole,
            code="enseignant-simulation",
            libelle="Enseignant",
        )
        self.prof = Utilisateur.objects.create_user(
            email="prof-simulation@example.com",
            password="ProfSimulation!2468",
            nom="Professeur",
            prenom="Test",
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=self.prof,
            role=self.role,
        )
        self.client.force_login(self.admin)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

    def test_superuser_simule_un_compte_et_revient_sans_deconnexion(self):
        response = self.client.get(reverse("securite:simuler_compte"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "prof-simulation@example.com")

        response = self.client.post(
            reverse("securite:simuler_compte"),
            {"utilisateur_id": str(self.prof.pk)},
        )
        self.assertRedirects(response, reverse("tableau_bord:index"))
        self.assertEqual(str(self.client.session["_auth_user_id"]), str(self.prof.pk))
        self.assertEqual(
            self.client.session["simulation_superuser_id"],
            str(self.admin.pk),
        )

        response = self.client.get(reverse("tableau_bord:index"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Mode simulation")

        response = self.client.post(reverse("securite:arreter_simulation_compte"))
        self.assertRedirects(response, reverse("tableau_bord:index"))
        self.assertEqual(str(self.client.session["_auth_user_id"]), str(self.admin.pk))
        self.assertNotIn("simulation_superuser_id", self.client.session)

    def test_superuser_ne_peut_pas_simuler_un_compte_sans_role_actif(self):
        autre_compte = Utilisateur.objects.create_user(
            email="sans-role@example.com",
            password="SansRole!2468",
            nom="Sans rôle",
            prenom="Test",
        )
        response = self.client.post(
            reverse("securite:simuler_compte"),
            {"utilisateur_id": str(autre_compte.pk)},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(str(self.client.session["_auth_user_id"]), str(self.admin.pk))
        self.assertNotIn("simulation_superuser_id", self.client.session)

    def test_compte_non_superuser_ne_peut_pas_demarrer_une_simulation(self):
        self.client.force_login(self.prof)
        self.client.raise_request_exception = False

        response = self.client.get(reverse("securite:simuler_compte"))

        self.assertEqual(response.status_code, 403)
