from django.urls import path
from apps.securite import views

app_name = "securite"
urlpatterns = [
    path(
        "simuler-compte/",
        views.simuler_compte,
        name="simuler_compte",
    ),
    path(
        "arreter-simulation/",
        views.arreter_simulation_compte,
        name="arreter_simulation_compte",
    ),
    path("roles/", views.liste_roles, name="roles"),
    path("roles/creer/", views.creer_role, name="creer_role"),
    path("roles/<int:pk>/modifier/", views.modifier_role, name="modifier_role"),
    path("utilisateurs/", views.liste_utilisateurs, name="utilisateurs"),
    path("utilisateurs/inviter/", views.inviter_utilisateur, name="inviter"),
    path(
        "invitations/<str:token>/",
        views.accepter_invitation,
        name="accepter_invitation",
    ),
    path(
        "utilisateurs/<uuid:pk>/roles/",
        views.gerer_roles_utilisateur,
        name="gerer_roles",
    ),
    path("journal-audit/", views.journal_audit, name="journal_audit"),
]
