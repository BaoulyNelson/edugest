"""
apps/securite/management/commands/initialiser_roles.py
========================================================
Commande Django : crée les rôles système et leurs permissions pour un établissement.
À exécuter après la création d'un nouvel établissement.

Usage :
    python manage.py initialiser_roles --ecole lycee-petion-cap
    python manage.py initialiser_roles --tous
"""

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction


class Command(BaseCommand):
    help = "Initialise les rôles système et les permissions pour un ou tous les établissements."

    def add_arguments(self, parser):
        parser.add_argument(
            "--ecole",
            type=str,
            help="Slug de l'établissement à initialiser.",
        )
        parser.add_argument(
            "--tous",
            action="store_true",
            help="Initialise tous les établissements actifs.",
        )
        parser.add_argument(
            "--reinitialiser",
            action="store_true",
            help="Réinitialise les permissions des rôles existants.",
        )

    def handle(self, *args, **options):
        from apps.etablissements.models import Etablissement

        if options["tous"]:
            ecoles = Etablissement.objects.filter(est_actif=True)
        elif options["ecole"]:
            try:
                ecoles = [Etablissement.objects.get(slug=options["ecole"])]
            except Etablissement.DoesNotExist:
                raise CommandError(f"Établissement '{options['ecole']}' introuvable.")
        else:
            raise CommandError("Préciser --ecole <slug> ou --tous.")

        self._creer_permissions_catalogue()

        for ecole in ecoles:
            self._initialiser_ecole(ecole, options["reinitialiser"])

    def _creer_permissions_catalogue(self):
        """Crée ou met à jour le catalogue global des permissions."""
        from apps.securite.models import PermissionGranulaire
        from apps.securite.models import PERMISSIONS_PAR_ROLE

        toutes_permissions = set()
        for perms in PERMISSIONS_PAR_ROLE.values():
            toutes_permissions.update(perms)

        crees = 0
        for code in toutes_permissions:
            parties = code.split(".")
            if len(parties) != 3:
                continue
            module, action, portee = parties
            _, created = PermissionGranulaire.objects.get_or_create(
                code=code,
                defaults={
                    "description": f"{action.title()} — {module.title()} ({portee})",
                    "module": module,
                    "action": action,
                    "portee": portee,
                    "est_dangereuse": action in ["cloturer", "archiver", "supprimer", "annuler"],
                },
            )
            if created:
                crees += 1

        self.stdout.write(
            self.style.SUCCESS(f"  Catalogue : {crees} nouvelles permissions créées.")
        )

    @transaction.atomic
    def _initialiser_ecole(self, ecole, reinitialiser: bool):
        """Crée les rôles système pour un établissement."""
        from apps.securite.models import Role, PermissionGranulaire, ROLES_SYSTEME, PERMISSIONS_PAR_ROLE
        from apps.noyau.middleware import definir_tenant_courant

        definir_tenant_courant(ecole)
        self.stdout.write(f"\nÉtablissement : {ecole.nom} ({ecole.slug})")

        for code_role, libelle_role in ROLES_SYSTEME.items():
            role, cree = Role.objects.get_or_create(
                ecole=ecole,
                code=code_role,
                defaults={
                    "libelle": libelle_role,
                    "est_systeme": True,
                    "est_actif": True,
                },
            )

            if cree or reinitialiser:
                # Affecter les permissions correspondantes
                codes_perms = PERMISSIONS_PAR_ROLE.get(code_role, [])
                perms = PermissionGranulaire.objects.filter(code__in=codes_perms)
                role.permissions.set(perms)
                statut = "✓ créé" if cree else "↺ réinitialisé"
                self.stdout.write(
                    f"  Rôle {libelle_role!r} {statut} "
                    f"({perms.count()} permissions)"
                )
            else:
                self.stdout.write(f"  Rôle {libelle_role!r} — déjà existant (skip)")

        definir_tenant_courant(None)
        self.stdout.write(self.style.SUCCESS(f"  ✓ {ecole.slug} initialisé avec succès."))