"""
apps/notes/models.py
=====================
Modèles du système d'évaluation.
Note → MoyenneMatiere → MoyenneGenerale → décision de passage.

INVARIANTS CRITIQUES :
- Note.coefficient_applique est figé au moment de la saisie (immuable après coup)
- Note.est_verrouilee=True → aucune modification possible, quelle que soit la source
- MoyenneGenerale.est_publiee=True → données définitives, bulletin peut être généré
- Le calcul des moyennes est toujours délégué au moteur (jamais dans les modèles)
"""

from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from apps.noyau.mixins import TenantModelMixin, HorodatageMixin, SuppressionDouce


class Note(TenantModelMixin, HorodatageMixin, SuppressionDouce):
    """
    Valeur élémentaire d'évaluation.
    Immuable après verrouillage. Jamais modifiée après publication de la période.

    ATTENTION : note_max et coefficient_applique sont des COPIES au moment de la saisie.
    Si l'école change ses coefficients après coup, les notes existantes ne sont pas affectées.
    C'est intentionnel et garantit l'intégrité de l'historique.
    """
    inscription = models.ForeignKey(
        "eleves.Inscription",
        on_delete=models.PROTECT,
        related_name="notes",
        verbose_name="Inscription",
    )
    matiere = models.ForeignKey(
        "parametrage.Matiere",
        on_delete=models.PROTECT,
        verbose_name="Matière",
    )
    periode = models.ForeignKey(
        "academique.PeriodeAcademique",
        on_delete=models.PROTECT,
        verbose_name="Période",
        db_index=True,
    )
    type_evaluation = models.ForeignKey(
        "parametrage.TypeEvaluation",
        on_delete=models.PROTECT,
        verbose_name="Type d'évaluation",
    )

    # ── Valeur ────────────────────────────────────────────────────────────────
    valeur = models.DecimalField(
        max_digits=8,
        decimal_places=3,
        null=True,
        blank=True,
        verbose_name="Note obtenue",
        help_text="Null uniquement si absent. Zéro si devoir non rendu.",
    )
    note_max = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        verbose_name="Note maximale (figée)",
        help_text="Maximum de la composante, figé au moment de la saisie.",
    )
    # Coefficient figé pour préserver l'historique
    coefficient_applique = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        verbose_name="Coefficient (figé)",
        help_text=(
            "Poids de la composante figé à la saisie; les anciennes notes "
            "conservent leur ancienne valeur."
        ),
    )
    mode_calcul_applique = models.CharField(
        max_length=15,
        choices=[
            ("legacy", "Configuration historique"),
            ("points", "Addition des points"),
            ("ponderation", "Pondération en pourcentage"),
        ],
        default="legacy",
        verbose_name="Méthode de calcul figée",
    )
    bareme_matiere_applique = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name="Barème de matière appliqué",
    )
    coefficient_matiere_applique = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name="Coefficient de matière appliqué",
    )

    # ── Absence ───────────────────────────────────────────────────────────────
    est_absence = models.BooleanField(
        default=False,
        verbose_name="Absence",
    )
    absence_justifiee = models.BooleanField(
        default=False,
        verbose_name="Absence justifiée",
    )
    motif_absence = models.CharField(max_length=200, blank=True)

    # ── Rattrapage ────────────────────────────────────────────────────────────
    est_rattrapage = models.BooleanField(default=False)
    note_initiale = models.DecimalField(
        max_digits=6,
        decimal_places=3,
        null=True,
        blank=True,
        help_text="Note avant rattrapage — conservée pour historique.",
    )

    # ── Traçabilité ───────────────────────────────────────────────────────────
    saisie_par = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="notes_saisies",
        verbose_name="Saisie par",
    )
    validee_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="notes_validees",
        verbose_name="Validée par",
    )
    date_validation = models.DateTimeField(null=True, blank=True)

    # ── Verrouillage ──────────────────────────────────────────────────────────
    est_verrouilee = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name="Verrouillée",
        help_text="True = immuable. Défini automatiquement à la clôture de période.",
    )
    date_verrouillage = models.DateTimeField(null=True, blank=True)

    observations = models.CharField(max_length=255, blank=True)

    class Meta:
        verbose_name = "Note"
        verbose_name_plural = "Notes"
        indexes = [
            models.Index(
                fields=["ecole", "inscription", "periode", "matiere"],
                name="idx_note_eleve_periode_matiere",
            ),
            models.Index(fields=["ecole", "periode", "matiere"], name="idx_note_periode"),
            models.Index(fields=["ecole", "saisie_par"], name="idx_note_enseignant"),
        ]

    def __str__(self):
        return (
            f"{self.inscription.eleve.nom_complet} — "
            f"{self.matiere.code} — {self.periode.libelle_court or self.periode.libelle} : "
            f"{self.valeur or 'ABS'}/{self.note_max}"
        )

    def clean(self):
        """Validations atomiques au niveau du modèle."""
        if self.est_verrouilee:
            raise ValidationError(
                "Cette note est verrouillée. Toute modification est interdite."
            )
        if self.valeur is not None:
            if self.valeur < Decimal("0"):
                raise ValidationError("Une note ne peut pas être négative.")
            if self.note_max and self.valeur > self.note_max:
                raise ValidationError(
                    f"La note ({self.valeur}) dépasse la note maximale ({self.note_max})."
                )
        if self.est_absence and self.valeur is not None:
            raise ValidationError("Un élève absent ne peut pas avoir une note.")

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    @property
    def valeur_effective(self) -> Decimal:
        """
        Retourne la valeur prise en compte dans les calculs.
        Absence non justifiée → 0.
        Absence justifiée → None (exclue du calcul).
        """
        if self.est_absence:
            if self.absence_justifiee:
                return None  # Exclue
            return Decimal("0")  # Comptée comme zéro
        return self.valeur or Decimal("0")


# ─── Moyennes ────────────────────────────────────────────────────────────────

class MoyenneMatiere(TenantModelMixin, HorodatageMixin):
    """
    Moyenne d'un élève pour une matière sur une période.
    Calculée par MoteurCalculMoyenne — jamais manuellement.
    Recalculée à chaque modification de note dans la période.
    """
    inscription = models.ForeignKey(
        "eleves.Inscription",
        on_delete=models.PROTECT,
        related_name="moyennes_matieres",
    )
    matiere = models.ForeignKey(
        "parametrage.Matiere",
        on_delete=models.PROTECT,
    )
    periode = models.ForeignKey(
        "academique.PeriodeAcademique",
        on_delete=models.PROTECT,
        related_name="moyennes_matieres",
    )
    # Résultat du calcul
    points_obtenus = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        verbose_name="Points obtenus sur le barème de la matière",
    )
    points_max = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        verbose_name="Barème total de la matière",
    )
    moyenne = models.DecimalField(
        max_digits=7,
        decimal_places=4,
        verbose_name="Moyenne sur la base de l'école",
    )
    base_calcul = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("10.00"),
        verbose_name="Base utilisée pour le calcul",
    )
    # Classement dans la classe pour cette matière/période
    rang_classe = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        verbose_name="Rang dans la classe",
    )
    # Appréciation textuelle
    mention = models.ForeignKey(
        "parametrage.Mention",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    appreciation_libre = models.CharField(max_length=150, blank=True)
    # Métadonnées de calcul
    nb_notes_prises_en_compte = models.PositiveSmallIntegerField(default=0)
    date_calcul = models.DateTimeField(auto_now=True)
    detail_calcul = models.JSONField(
        default=dict,
        verbose_name="Détail du calcul (pour audit)",
    )

    class Meta:
        verbose_name = "Moyenne de matière"
        verbose_name_plural = "Moyennes de matières"
        unique_together = [("ecole", "inscription", "matiere", "periode")]
        indexes = [
            models.Index(
                fields=["ecole", "inscription", "periode"],
                name="idx_moy_matiere_inscription",
            ),
        ]

    def __str__(self):
        return (
            f"{self.inscription.eleve.nom_complet} — "
            f"{self.matiere.code} {self.periode.libelle_court or ''}: {self.moyenne}"
        )


class MoyenneGenerale(TenantModelMixin, HorodatageMixin):
    """
    Moyenne générale d'un élève pour une période.
    Calculée depuis les MoyenneMatiere pondérées par les coefficients.
    INVARIANT : est_publiee=True → données définitives, ne peut plus être recalculée.
    """
    inscription = models.ForeignKey(
        "eleves.Inscription",
        on_delete=models.PROTECT,
        related_name="moyennes_generales",
    )
    periode = models.ForeignKey(
        "academique.PeriodeAcademique",
        on_delete=models.PROTECT,
        related_name="moyennes_generales",
    )
    # Résultat
    total_points_ponderes = models.DecimalField(
        max_digits=12,
        decimal_places=4,
        verbose_name="Total points pondérés",
    )
    total_coefficients = models.DecimalField(
        max_digits=8,
        decimal_places=4,
        verbose_name="Somme des coefficients",
    )
    moyenne = models.DecimalField(
        max_digits=7,
        decimal_places=4,
        verbose_name="Moyenne générale",
    )
    base_calcul = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("10.00"),
    )
    # Classement
    rang_classe = models.PositiveSmallIntegerField(null=True, blank=True)
    rang_niveau = models.PositiveSmallIntegerField(null=True, blank=True)
    nb_eleves_classe = models.PositiveSmallIntegerField(null=True, blank=True)
    # Décision pédagogique
    mention = models.ForeignKey(
        "parametrage.Mention",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    est_admis = models.BooleanField(
        null=True,
        verbose_name="Admis",
        help_text="Null = non encore évalué. Calculé selon ReglePassage.",
    )
    decision_conseil = models.CharField(
        max_length=20,
        choices=[
            ("admis", "Admis"),
            ("admis_conseil", "Admis par décision du conseil"),
            ("redoublant", "Redoublant"),
            ("oriente", "Orienté"),
            ("exclu", "Exclu"),
        ],
        blank=True,
    )
    # Publication
    est_publiee = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name="Publiée",
    )
    publiee_le = models.DateTimeField(null=True, blank=True)
    publiee_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="moyennes_publiees",
    )
    date_calcul = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Moyenne générale"
        verbose_name_plural = "Moyennes générales"
        unique_together = [("ecole", "inscription", "periode")]
        indexes = [
            models.Index(
                fields=["ecole", "periode", "rang_classe"],
                name="idx_moy_gen_classement",
            ),
        ]

    def __str__(self):
        return (
            f"{self.inscription.eleve.nom_complet} — "
            f"{self.periode.libelle_court or self.periode.libelle}: {self.moyenne}"
        )

    def clean(self):
        if self.est_publiee:
            raise ValidationError(
                "Cette moyenne est publiée. Elle ne peut plus être modifiée."
            )