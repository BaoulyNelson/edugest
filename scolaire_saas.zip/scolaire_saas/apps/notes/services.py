"""
apps/notes/services.py
=======================
ServiceCalculMoyenne : orchestre le calcul des moyennes depuis la DB vers les modèles.
Fait le pont entre les modèles Django et le moteur de calcul pur.

ServiceSaisieNote : gère la saisie avec toutes les gardes métier.
"""

from decimal import (
    Decimal,
    ROUND_CEILING,
    ROUND_DOWN,
    ROUND_HALF_EVEN,
    ROUND_HALF_UP,
)
from typing import TYPE_CHECKING
from django.db import transaction
from django.utils import timezone
from apps.notes.moteur import MoteurCalculMoyenne, DonneeNote, moteur_calcul
from apps.notes.models import Note, MoyenneMatiere, MoyenneGenerale
from apps.academique.models import (
    PeriodeAcademique,
    StatutAnneeScolaire,
    StatutPeriode,
)
from apps.noyau.exceptions import (
    RegleMetierError, ErreurCalcul, OperationImpossibleError
)
from apps.securite.rbac import ServiceAudit

if TYPE_CHECKING:
    from apps.parametrage.models import CoefficientsMatiere


class ServiceSaisieNote:
    """
    Gère la saisie et modification des notes avec toutes les gardes métier.
    Point d'entrée unique pour toute création/modification de note.
    """

    def __init__(self, utilisateur):
        self.utilisateur = utilisateur
        self.audit = ServiceAudit(utilisateur)

    @transaction.atomic
    def saisir(
        self,
        inscription,
        matiere,
        periode: PeriodeAcademique,
        type_evaluation,
        valeur: Decimal | None,
        est_absence: bool = False,
        absence_justifiee: bool = False,
        motif_absence: str = "",
        observations: str = "",
    ) -> Note:
        """
        Crée ou met à jour une note avec toutes les gardes métier.

        Gardes :
        - Période doit être ouverte
        - Année scolaire doit être active
        - Pas de note si verrouillage administratif
        - Coefficient récupéré depuis la configuration matière/niveau/année
        - Barème et points attribués récupérés depuis la configuration matière
        """
        self._verifier_saisie_autorisee(periode)

        note_existante = Note.objects.filter(
            inscription=inscription,
            matiere=matiere,
            periode=periode,
            type_evaluation=type_evaluation,
        ).first()
        if note_existante:
            return self._modifier(
                note=note_existante,
                valeur=valeur,
                est_absence=est_absence,
                absence_justifiee=absence_justifiee,
                motif_absence=motif_absence,
                observations=observations,
            )

        # Récupérer le coefficient de référence depuis la config de l'école
        coeff_config = self._obtenir_coefficient(
            matiere=matiere,
            niveau=inscription.classe.niveau,
            annee_scolaire=periode.annee_scolaire,
        )

        bareme_periode = None
        if type_evaluation.compte_dans_moyenne:
            from apps.parametrage.models import BaremeMatierePeriode

            baremes_periodes = list(
                BaremeMatierePeriode.objects.filter(
                    ecole=inscription.ecole,
                    coefficient_matiere=coeff_config,
                ).prefetch_related("composantes__type_evaluation")
            )
            utilise_baremes_par_periode = bool(baremes_periodes)
            bareme_periode = next(
                (
                    bareme
                    for bareme in baremes_periodes
                    if bareme.periode_id == periode.pk
                ),
                None,
            )
            periodes_annee_ids = (
                set(periode.annee_scolaire.periodes.values_list("pk", flat=True))
                if utilise_baremes_par_periode
                else set()
            )
            if utilise_baremes_par_periode and (
                bareme_periode is None
                or {bareme.periode_id for bareme in baremes_periodes}
                != periodes_annee_ids
                or sum(
                    (bareme.bareme_total for bareme in baremes_periodes),
                    Decimal("0"),
                )
                != coeff_config.bareme_total
            ):
                raise RegleMetierError(
                    f"Configurez les barèmes de toutes les périodes pour "
                    f"{matiere.libelle} et vérifiez que leur somme égale le "
                    f"barème annuel de {coeff_config.bareme_total} points."
                )
            if bareme_periode:
                mode_calcul = bareme_periode.mode_calcul
                bareme_total = bareme_periode.bareme_total
                baremes = list(bareme_periode.composantes.all())
            else:
                mode_calcul = coeff_config.mode_calcul
                bareme_total = coeff_config.bareme_total
                baremes = list(
                    coeff_config.baremes_evaluations.select_related(
                        "type_evaluation"
                    )
                )
            composantes = [
                bareme
                for bareme in baremes
                if bareme.type_evaluation.compte_dans_moyenne
            ]
            if mode_calcul == "points":
                total_configure = sum(
                    (bareme.points_max for bareme in composantes),
                    Decimal("0"),
                )
                total_attendu = bareme_total
            elif mode_calcul == "ponderation":
                total_configure = sum(
                    (
                        bareme.poids_pourcentage or Decimal("0")
                        for bareme in composantes
                    ),
                    Decimal("0"),
                )
                total_attendu = Decimal("100.00")
            else:
                raise RegleMetierError(
                    f"La méthode de calcul de {matiere.libelle} est invalide."
                )

            if total_configure != total_attendu:
                raise RegleMetierError(
                    f"Le barème de {matiere.libelle} n'est pas configuré "
                    "correctement. Vérifiez le total des points ou des "
                    "pondérations avant de saisir des notes."
                )

            bareme_eval = next(
                (
                    bareme
                    for bareme in baremes
                    if bareme.type_evaluation_id == type_evaluation.pk
                ),
                None,
            )
            if bareme_eval is None:
                poids_applique = Decimal("0")
            elif mode_calcul == "points":
                poids_applique = bareme_eval.points_max
            else:
                poids_applique = bareme_eval.poids_pourcentage
            if (
                bareme_eval is None
                or bareme_eval.points_max <= 0
                or poids_applique is None
                or poids_applique <= 0
            ):
                raise RegleMetierError(
                    f"Aucun maximum et poids positif ne sont configurés pour "
                    f"« {type_evaluation.libelle} » en {matiere.libelle}."
                )
            note_max = bareme_eval.points_max
            coefficient_applique = poids_applique
        else:
            note_max = type_evaluation.note_max_defaut
            coefficient_applique = coeff_config.coefficient
            mode_calcul = coeff_config.mode_calcul
            bareme_total = coeff_config.bareme_total

        note = Note(
            ecole=inscription.ecole,
            inscription=inscription,
            matiere=matiere,
            periode=periode,
            type_evaluation=type_evaluation,
            valeur=valeur,
            note_max=note_max,
            coefficient_applique=coefficient_applique,
            mode_calcul_applique=(
                mode_calcul
                if type_evaluation.compte_dans_moyenne
                else "legacy"
            ),
            bareme_matiere_applique=(
                bareme_total
                if type_evaluation.compte_dans_moyenne
                else None
            ),
            coefficient_matiere_applique=coeff_config.coefficient,
            est_absence=est_absence,
            absence_justifiee=absence_justifiee,
            motif_absence=motif_absence,
            saisie_par=self.utilisateur,
            observations=observations,
        )
        note.full_clean()
        note.save()

        # Invalider le cache des moyennes pour recalcul
        self._invalider_cache_moyennes(inscription, periode)

        self.audit.enregistrer(
            action="creation_note",
            objet=note,
            donnees_apres={
                "valeur": str(valeur),
                "matiere": matiere.code,
                "periode": periode.libelle,
                "type_eval": type_evaluation.code,
            },
        )
        return note

    def _modifier(self, note: Note, **champs) -> Note:
        """Modifie une note existante non verrouillée."""
        if note.est_verrouilee:
            raise RegleMetierError(
                f"La note de {note.inscription.eleve.nom_complet} "
                f"en {note.matiere.code} est verrouillée."
            )
        donnees_avant = {"valeur": str(note.valeur)}

        for champ, valeur in champs.items():
            setattr(note, champ, valeur)
        note.modifie_le = timezone.now()
        note.full_clean()
        note.save()

        self._invalider_cache_moyennes(note.inscription, note.periode)
        self.audit.enregistrer(
            action="modification_note",
            objet=note,
            donnees_avant=donnees_avant,
            donnees_apres={"valeur": str(note.valeur)},
        )
        return note

    def _verifier_saisie_autorisee(self, periode: PeriodeAcademique) -> None:
        """Lève RegleMetierError si la saisie est interdite."""
        if not periode.accepte_saisie_notes:
            raise RegleMetierError(
                f"La période '{periode.libelle}' est {periode.statut}. "
                "La saisie de notes est impossible."
            )
        if periode.annee_scolaire.verrou_administratif:
            raise RegleMetierError(
                "L'année scolaire est verrouillée administrativement. "
                "Aucune saisie n'est possible."
            )
        if periode.annee_scolaire.statut != "active":
            raise RegleMetierError(
                "L'année scolaire n'est pas active. "
                "Impossible de saisir des notes."
            )

    def _obtenir_coefficient(
        self, matiere, niveau, annee_scolaire
    ) -> "CoefficientsMatiere":
        """Récupère la configuration de matière pour ce niveau et cette année."""
        from apps.parametrage.models import CoefficientsMatiere

        config = CoefficientsMatiere.objects.filter(
            ecole=matiere.ecole,
            matiere=matiere,
            niveau=niveau,
            annee_scolaire=annee_scolaire,
        ).first()

        if config is None:
            raise RegleMetierError(
                f"Aucun coefficient configuré pour {matiere.code} "
                f"au niveau {niveau.code} pour cette année scolaire. "
                "Configurer les coefficients avant de saisir des notes."
            )
        return config

    def _invalider_cache_moyennes(self, inscription, periode) -> None:
        """Invalide le cache Redis des moyennes après modification de note."""
        from django.core.cache import cache
        cle = f"moy_gen:{inscription.pk}:{periode.pk}"
        cache.delete(cle)


class ServiceCalculMoyenne:
    """
    Orchestre le calcul des moyennes depuis la DB.
    Utilise le moteur pur (moteur_calcul) pour les calculs.
    Persiste les résultats dans MoyenneMatiere et MoyenneGenerale.
    """

    def __init__(self, utilisateur=None):
        self.utilisateur = utilisateur
        self.moteur = moteur_calcul
        self._annual_context_cache = {}
        self._annual_system_cache = {}

    @transaction.atomic
    def calculer_moyennes_periode(
        self,
        inscription,
        periode: PeriodeAcademique,
        base: Decimal | None = None,
        forcer: bool = False,
    ) -> MoyenneGenerale:
        """
        Calcule toutes les moyennes (par matière + générale) pour une inscription/période.

        Le résultat est persisté en base et retourné.
        Si une moyenne générale publiée existe déjà et forcer=False → erreur.
        """
        if (
            inscription.annee_scolaire_id != periode.annee_scolaire_id
            or periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE
        ):
            raise RegleMetierError(
                "Les moyennes ne peuvent être calculées que pour une inscription "
                "de l’année scolaire active correspondante."
            )

        from apps.parametrage.models import SystemeNotation

        systeme = SystemeNotation.objects.filter(
            ecole=inscription.ecole,
            est_courant=True,
        ).first()
        if base is None:
            base = systeme.base_notation if systeme else Decimal("10.00")
        modes_arrondi = {
            "half_up": ROUND_HALF_UP,
            "half_even": ROUND_HALF_EVEN,
            "down": ROUND_DOWN,
            "ceiling": ROUND_CEILING,
        }
        try:
            arrondi = (
                modes_arrondi[systeme.methode_arrondi]
                if systeme
                else ROUND_HALF_UP
            )
        except KeyError as exc:
            raise RegleMetierError(
                "La règle d’arrondi du système de notation est invalide."
            ) from exc

        # Vérifier qu'on ne recalcule pas une moyenne publiée
        moy_existante = MoyenneGenerale.objects.filter(
            inscription=inscription,
            periode=periode,
        ).first()

        if moy_existante and moy_existante.est_publiee and not forcer:
            raise RegleMetierError(
                "La moyenne générale est publiée et ne peut plus être recalculée. "
                "Utiliser forcer=True pour les corrections exceptionnelles (admin uniquement)."
            )

        # Récupérer toutes les notes de la période pour cet élève
        notes_qs = (
            Note.objects
            .filter(inscription=inscription, periode=periode)
            .select_related("matiere", "type_evaluation")
            .filter(type_evaluation__compte_dans_moyenne=True)
            .filter(supprime_le__isnull=True)
            .order_by("cree_le", "pk")
        )

        if not notes_qs.exists():
            raise OperationImpossibleError(
                f"Aucune note trouvée pour {inscription.eleve.nom_complet} "
                f"sur la période {periode.libelle}."
            )

        # Regrouper les notes par matière
        notes_par_matiere: dict = {}
        for note in notes_qs:
            cle = note.matiere_id
            if cle not in notes_par_matiere:
                notes_par_matiere[cle] = {"matiere": note.matiere, "notes": []}
            notes_par_matiere[cle]["notes"].append(note)

        # Calculer la moyenne par matière
        resultats_matieres = []
        from apps.parametrage.models import (
            BaremeMatierePeriode,
            CoefficientsMatiere,
        )

        for matiere_id, donnees in notes_par_matiere.items():
            matiere = donnees["matiere"]
            donnees_notes = [
                DonneeNote(
                    note_id=str(n.pk),
                    valeur=n.valeur_effective,
                    note_max=n.note_max,
                    coefficient=n.coefficient_applique,
                    est_absence_non_justifiee=(n.est_absence and not n.absence_justifiee),
                )
                for n in donnees["notes"]
            ]

            try:
                resultat = self.moteur.calculer_moyenne_matiere(
                    donnees_notes,
                    base,
                    arrondi=arrondi,
                )
            except ErreurCalcul as exc:
                # Matière avec données insuffisantes → skip avec log
                import logging
                logging.getLogger("apps.notes").warning(
                    f"Calcul impossible pour {matiere.code} : {exc}"
                )
                continue

            # Persister la moyenne de matière
            coeff_config = CoefficientsMatiere.objects.filter(
                ecole=inscription.ecole,
                matiere=matiere,
                niveau=inscription.classe.niveau,
                annee_scolaire=periode.annee_scolaire,
            ).first()
            bareme_periode = BaremeMatierePeriode.objects.filter(
                ecole=inscription.ecole,
                coefficient_matiere=coeff_config,
                periode=periode,
            ).first() if coeff_config else None

            coeff_matiere = next(
                (
                    note.coefficient_matiere_applique
                    for note in donnees["notes"]
                    if note.coefficient_matiere_applique is not None
                ),
                coeff_config.coefficient if coeff_config else Decimal("1.00"),
            )
            bareme_matiere = next(
                (
                    note.bareme_matiere_applique
                    for note in donnees["notes"]
                    if note.bareme_matiere_applique is not None
                ),
                (
                    bareme_periode.bareme_total
                    if bareme_periode
                    else coeff_config.bareme_total if coeff_config else None
                ),
            )
            points_max = (
                bareme_matiere
                if bareme_matiere is not None
                else resultat.total_coefficients * Decimal("100")
            )
            points_obtenus = (
                (resultat.moyenne_sur_base / base) * points_max
                if bareme_matiere is not None
                else resultat.points_ponderes
            )

            moy_matiere, _ = MoyenneMatiere.objects.update_or_create(
                ecole=inscription.ecole,
                inscription=inscription,
                matiere=matiere,
                periode=periode,
                defaults={
                    "points_obtenus": points_obtenus,
                    "points_max": points_max,
                    "moyenne": resultat.moyenne_sur_base,
                    "base_calcul": base,
                    "nb_notes_prises_en_compte": resultat.nb_notes,
                    "detail_calcul": resultat.detail,
                },
            )

            resultats_matieres.append((resultat, coeff_matiere))

        if not resultats_matieres:
            raise OperationImpossibleError(
                "Aucune matière n'a pu être calculée. "
                "Vérifier que les notes et les coefficients sont configurés."
            )

        # Calculer la moyenne générale
        resultat_general = self.moteur.calculer_moyenne_generale(
            resultats_matieres,
            base,
            arrondi=arrondi,
        )

        # Déterminer la mention
        mention = self._obtenir_mention(resultat_general.moyenne_sur_base, inscription.ecole)

        # Déterminer si admis selon les règles de l'école
        est_admis = self._evaluer_admission(
            inscription=inscription,
            moyenne_generale=resultat_general.moyenne_sur_base,
            moyennes_matieres=MoyenneMatiere.objects.filter(
                inscription=inscription, periode=periode
            ),
        )

        # Persister la moyenne générale
        moy_gen, _ = MoyenneGenerale.objects.update_or_create(
            ecole=inscription.ecole,
            inscription=inscription,
            periode=periode,
            defaults={
                "total_points_ponderes": resultat_general.total_points_ponderes,
                "total_coefficients": resultat_general.total_coefficients,
                "moyenne": resultat_general.moyenne_sur_base,
                "base_calcul": base,
                "mention": mention,
                "est_admis": est_admis,
                "est_publiee": False,  # Jamais publié automatiquement
            },
        )

        return moy_gen

    def calculer_resultat_annuel(self, inscription) -> dict:
        """Calcule à la volée les points annuels depuis les moyennes de période."""
        from apps.academique.models import PeriodeAcademique
        from apps.parametrage.models import (
            CoefficientsMatiere,
            SystemeNotation,
        )

        context_key = (
            inscription.ecole_id,
            inscription.annee_scolaire_id,
            inscription.classe.niveau_id,
        )
        if context_key not in self._annual_context_cache:
            periodes = list(
                PeriodeAcademique.objects.filter(
                    ecole=inscription.ecole,
                    annee_scolaire=inscription.annee_scolaire,
                ).order_by("numero")
            )
            coefficients = list(
                CoefficientsMatiere.objects.filter(
                    ecole=inscription.ecole,
                    niveau=inscription.classe.niveau,
                    annee_scolaire=inscription.annee_scolaire,
                )
                .select_related("matiere")
                .prefetch_related("baremes_periodes")
            )
            self._annual_context_cache[context_key] = (periodes, coefficients)
        periodes, coefficients = self._annual_context_cache[context_key]
        if inscription.ecole_id not in self._annual_system_cache:
            self._annual_system_cache[inscription.ecole_id] = (
                SystemeNotation.objects.filter(
                    ecole=inscription.ecole,
                    est_courant=True,
                ).first()
            )
        systeme = self._annual_system_cache[inscription.ecole_id]
        base = systeme.base_notation if systeme else Decimal("10.00")
        modes_arrondi = {
            "half_up": ROUND_HALF_UP,
            "half_even": ROUND_HALF_EVEN,
            "down": ROUND_DOWN,
            "ceiling": ROUND_CEILING,
        }
        try:
            arrondi = (
                modes_arrondi[systeme.methode_arrondi]
                if systeme
                else ROUND_HALF_UP
            )
        except KeyError as exc:
            raise RegleMetierError(
                "La règle d’arrondi du système de notation est invalide."
            ) from exc
        resultats_matieres = []
        raisons_incompletes = []
        coefficient_general_manquant = False
        moyennes_par_matiere_et_periode = {
            (moyenne.matiere_id, moyenne.periode_id): moyenne
            for moyenne in MoyenneMatiere.objects.filter(
                ecole=inscription.ecole,
                inscription=inscription,
                periode__in=periodes,
            )
        }
        notes_coefficients_par_matiere = {}
        notes_coefficients = Note.objects.filter(
            ecole=inscription.ecole,
            inscription=inscription,
            periode__in=periodes,
            type_evaluation__compte_dans_moyenne=True,
            supprime_le__isnull=True,
            coefficient_matiere_applique__isnull=False,
        ).values_list("matiere_id", "coefficient_matiere_applique")
        for matiere_id, coefficient_applique in notes_coefficients:
            notes_coefficients_par_matiere.setdefault(matiere_id, set()).add(
                coefficient_applique
            )

        for coefficient in coefficients:
            baremes_periodes = list(coefficient.baremes_periodes.all())
            par_periode = {bareme.periode_id: bareme for bareme in baremes_periodes}
            total_annuel_configure = sum(
                (bareme.bareme_total for bareme in baremes_periodes),
                Decimal("0"),
            )
            if (
                set(par_periode) != {periode.pk for periode in periodes}
                or total_annuel_configure != coefficient.bareme_total
            ):
                raisons_incompletes.append(
                    f"{coefficient.matiere.libelle} : barèmes des périodes "
                    "incomplets ou non égaux au barème annuel."
                )
                if coefficient.est_obligatoire:
                    coefficient_general_manquant = True
                continue

            moyennes_periodes = {
                periode_id: moyenne
                for (matiere_id, periode_id), moyenne
                in moyennes_par_matiere_et_periode.items()
                if matiere_id == coefficient.matiere_id
                and periode_id in par_periode
            }
            if any(pk not in moyennes_periodes for pk in par_periode):
                raisons_incompletes.append(
                    f"{coefficient.matiere.libelle} : moyenne manquante pour "
                    "au moins une période."
                )
                if coefficient.est_obligatoire:
                    coefficient_general_manquant = True
                continue

            points_obtenus = sum(
                (
                    moyennes_periodes[periode.pk].points_obtenus
                    for periode in periodes
                ),
                Decimal("0"),
            )
            points_max = sum(
                (
                    moyennes_periodes[periode.pk].points_max
                    for periode in periodes
                ),
                Decimal("0"),
            )
            if points_max != coefficient.bareme_total:
                raisons_incompletes.append(
                    f"{coefficient.matiere.libelle} : les moyennes calculées "
                    "ne correspondent pas au barème annuel configuré."
                )
                if coefficient.est_obligatoire:
                    coefficient_general_manquant = True
                continue

            notes_coefficients = notes_coefficients_par_matiere.get(
                coefficient.matiere_id,
                set(),
            )
            if len(notes_coefficients) > 1:
                raisons_incompletes.append(
                    f"{coefficient.matiere.libelle} : le coefficient de matière "
                    "figé diffère entre les périodes."
                )
                if coefficient.est_obligatoire:
                    coefficient_general_manquant = True
                continue

            coefficient_matiere = (
                next(iter(notes_coefficients))
                if notes_coefficients
                else coefficient.coefficient
            )
            moyenne_sur_base = (
                points_obtenus / coefficient.bareme_total * base
            ).quantize(Decimal("0.0001"), rounding=arrondi)
            resultats_matieres.append(
                {
                    "matiere": coefficient.matiere,
                    "points_obtenus": points_obtenus,
                    "points_max": coefficient.bareme_total,
                    "moyenne": moyenne_sur_base,
                    "coefficient": coefficient_matiere,
                }
            )

        total_coefficients = sum(
            (resultat["coefficient"] for resultat in resultats_matieres),
            Decimal("0"),
        )
        moyenne_generale = None
        if resultats_matieres and not coefficient_general_manquant:
            moyenne_generale = (
                sum(
                    (
                        resultat["moyenne"] * resultat["coefficient"]
                        for resultat in resultats_matieres
                    ),
                    Decimal("0"),
                )
                / total_coefficients
            ).quantize(Decimal("0.0001"), rounding=arrondi)

        return {
            "matieres": resultats_matieres,
            "moyenne_generale": moyenne_generale,
            "base": base,
            "complet": moyenne_generale is not None,
            "raisons_incompletes": raisons_incompletes,
        }

    @transaction.atomic
    def calculer_classements_classe(
        self,
        classe,
        periode: PeriodeAcademique,
    ) -> int:
        """
        Calcule et persiste le rang de chaque élève dans la classe.
        Retourne le nombre d'élèves classés.
        """
        if (
            classe.annee_scolaire_id != periode.annee_scolaire_id
            or periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE
        ):
            raise RegleMetierError(
                "Les classements ne peuvent être calculés que pour une classe "
                "de l’année scolaire active correspondante."
            )

        moyennes = list(
            MoyenneGenerale.objects.filter(
                inscription__classe=classe,
                periode=periode,
                est_publiee=False,
            ).select_related("inscription__eleve")
            .order_by("-moyenne")
        )

        nb_total = len(moyennes)
        for rang, moy in enumerate(moyennes, start=1):
            MoyenneGenerale.objects.filter(pk=moy.pk).update(
                rang_classe=rang,
                nb_eleves_classe=nb_total,
            )

        return nb_total

    def _obtenir_mention(self, moyenne: Decimal, ecole) -> object | None:
        """Retourne la mention correspondant à la moyenne."""
        from apps.parametrage.models import Mention, SystemeNotation

        systeme = SystemeNotation.objects.filter(ecole=ecole, est_courant=True).first()
        if not systeme:
            return None

        return (
            Mention.objects.filter(
                ecole=ecole,
                systeme_notation=systeme,
                moyenne_min__lte=moyenne,
                moyenne_max__gte=moyenne,
            ).first()
        )

    def _evaluer_admission(self, inscription, moyenne_generale: Decimal, moyennes_matieres) -> bool | None:
        """
        Évalue l'admission selon les règles de passage de l'école.
        Le seuil du système de notation s'applique par défaut; une règle de niveau
        peut le remplacer et ajouter des conditions supplémentaires.
        Retourne None si aucun système de notation n'est configuré.
        """
        from apps.parametrage.models import ReglePassage, SystemeNotation

        systeme = SystemeNotation.objects.filter(
            ecole=inscription.ecole,
            est_courant=True,
        ).first()
        if not systeme:
            return None

        regle = ReglePassage.objects.filter(
            ecole=inscription.ecole,
            niveau=inscription.classe.niveau,
            est_active=True,
        ).first()

        seuil_passage = (
            regle.moyenne_passage
            if regle and regle.moyenne_passage is not None
            else systeme.note_passage
        )
        if moyenne_generale < seuil_passage:
            return False

        if not regle:
            return True

        # Vérification des matières éliminatoires
        if regle.matieres_eliminatoires.exists() and regle.seuil_eliminatoire:
            for moy in moyennes_matieres:
                if moy.matiere in regle.matieres_eliminatoires.all():
                    if moy.moyenne < regle.seuil_eliminatoire:
                        return False

        # Vérification du nombre de matières insuffisantes
        if regle.nb_matieres_insuffisantes_max is not None:
            nb_insuffisant = sum(
                1 for m in moyennes_matieres
                if m.moyenne < seuil_passage
            )
            if nb_insuffisant > regle.nb_matieres_insuffisantes_max:
                return False

        return True