from django.urls import path
from apps.notes import views

app_name = "notes"
urlpatterns = [
    path("saisie/", views.saisie_notes, name="saisie"),
    path(
        "saisie/<int:classe_id>/<int:matiere_id>/<int:periode_id>/",
        views.saisie_notes_detail,
        name="saisie_detail",
    ),
    path(
        "importer/<int:classe_id>/<int:matiere_id>/<int:periode_id>/",
        views.importer_notes,
        name="importer",
    ),
    path("api/enregistrer/", views.api_enregistrer_note, name="api_enregistrer"),
    path("moyennes/", views.liste_moyennes, name="moyennes"),
    path(
        "moyennes/annuelles/",
        views.liste_moyennes_annuelles,
        name="moyennes_annuelles",
    ),
    path("historique/", views.historique_notes, name="historique"),
    path(
        "moyennes/<int:periode_id>/calculer/",
        views.calculer_moyennes,
        name="calculer_moyennes",
    ),
    path(
        "moyennes/<int:periode_id>/classements/",
        views.calculer_classements,
        name="calculer_classements",
    ),
    path("releve/<uuid:inscription_id>/", views.releve_notes, name="releve"),
]
