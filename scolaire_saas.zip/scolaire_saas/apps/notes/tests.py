from decimal import Decimal
from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP
from types import SimpleNamespace
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.etablissements.models import Etablissement
from apps.notes.moteur import DonneeNote, MoteurCalculMoyenne
from apps.notes.models import Note
from apps.notes.services import ServiceCalculMoyenne, ServiceSaisieNote
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AccesSaisieNotesTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="notes-sans-permission@example.com",
            nom="Notes",
            prenom="Test",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-acces-notes",
            nom="École accès notes",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug
        self.url = reverse("notes:saisie")

    def test_saisie_est_refusee_sans_permission(self):
        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 403)

    def test_permission_toutes_classes_donne_acces_a_la_saisie(self):
        permission = PermissionGranulaire.objects.create(
            code="notes.saisir.toutes_classes",
            description="Saisir les notes de toutes les classes.",
            module="notes",
            action="saisir",
            portee="toutes_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="directeur-test",
            libelle="Directeur",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.utilisateur,
            role=role,
        )

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 200)

    def test_saisie_propres_classes_ne_peut_pas_lancer_le_calcul_global(self):
        permission = PermissionGranulaire.objects.create(
            code="notes.saisir.propres_classes",
            description="Saisir les notes de ses propres classes.",
            module="notes",
            action="saisir",
            portee="propres_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="enseignant-test",
            libelle="Enseignant",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.utilisateur,
            role=role,
        )

        response = self.client.get(reverse("notes:moyennes"))

        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context["peut_calculer_moyennes"])


class BaremesNotesTests(TestCase):
    def test_valeur_effective_respecte_le_statut_des_absences(self):
        absence_non_justifiee = Note(
            valeur=None,
            est_absence=True,
            absence_justifiee=False,
        )
        absence_justifiee = Note(
            valeur=None,
            est_absence=True,
            absence_justifiee=True,
        )

        self.assertEqual(absence_non_justifiee.valeur_effective, Decimal("0"))
        self.assertIsNone(absence_justifiee.valeur_effective)

    def test_saisie_fige_le_bareme_attribue_a_la_composante(self):
        utilisateur = SimpleNamespace(pk=1)
        inscription = SimpleNamespace(
            pk=1,
            ecole=SimpleNamespace(pk=1),
            classe=SimpleNamespace(niveau=SimpleNamespace(pk=1)),
        )
        periode = SimpleNamespace(
            pk=1,
            libelle="Session 1",
            annee_scolaire=SimpleNamespace(pk=1),
        )
        type_evaluation = SimpleNamespace(
            pk=7,
            code="EXAM",
            libelle="Examen",
            compte_dans_moyenne=True,
        )
        bareme = SimpleNamespace(
            type_evaluation=type_evaluation,
            type_evaluation_id=type_evaluation.pk,
            points_max=Decimal("20.00"),
        )
        coefficient = SimpleNamespace(
            mode_calcul="points",
            bareme_total=Decimal("20.00"),
            coefficient=Decimal("2.00"),
            baremes_evaluations=SimpleNamespace(
                select_related=lambda *args: [bareme]
            ),
        )

        with (
            patch("apps.notes.services.Note") as note_model,
            patch("apps.notes.services.ServiceAudit"),
            patch("apps.parametrage.models.BaremeMatierePeriode") as period_model,
            patch.object(ServiceSaisieNote, "_verifier_saisie_autorisee"),
            patch.object(
                ServiceSaisieNote,
                "_obtenir_coefficient",
                return_value=coefficient,
            ),
            patch.object(ServiceSaisieNote, "_invalider_cache_moyennes"),
        ):
            note_model.objects.filter.return_value.first.return_value = None
            period_model.objects.filter.return_value.first.return_value = None
            (
                period_model.objects.filter.return_value
                .prefetch_related.return_value.first.return_value
            ) = None
            period_model.objects.filter.return_value.exists.return_value = False

            ServiceSaisieNote(utilisateur).saisir(
                inscription=inscription,
                matiere=SimpleNamespace(code="MATH"),
                periode=periode,
                type_evaluation=type_evaluation,
                valeur=Decimal("16.00"),
            )

        self.assertEqual(
            note_model.call_args.kwargs["note_max"],
            Decimal("20.00"),
        )
        self.assertEqual(
            note_model.call_args.kwargs["coefficient_applique"],
            Decimal("20.00"),
        )
        self.assertEqual(
            note_model.call_args.kwargs["mode_calcul_applique"],
            "points",
        )
        self.assertEqual(
            note_model.call_args.kwargs["bareme_matiere_applique"],
            Decimal("20.00"),
        )
        self.assertEqual(
            note_model.call_args.kwargs["coefficient_matiere_applique"],
            Decimal("2.00"),
        )

    def test_moyenne_est_convertie_sur_la_base_du_systeme(self):
        resultat = MoteurCalculMoyenne().calculer_moyenne_matiere(
            [
                DonneeNote(
                    note_id="1",
                    valeur=Decimal("78.4"),
                    note_max=Decimal("100"),
                    coefficient=Decimal("1"),
                )
            ],
            base=Decimal("10"),
        )

        self.assertEqual(resultat.moyenne_sur_base, Decimal("7.8400"))

    def test_moteur_applique_la_regle_d_arrondi_configuree(self):
        note = DonneeNote(
            note_id="arrondi",
            valeur=Decimal("2.4689"),
            note_max=Decimal("20"),
            coefficient=Decimal("1"),
        )
        moteur = MoteurCalculMoyenne()

        resultat_demi_superieur = moteur.calculer_moyenne_matiere(
            [note],
            base=Decimal("10"),
            arrondi=ROUND_HALF_UP,
        )
        resultat_demi_pair = moteur.calculer_moyenne_matiere(
            [note],
            base=Decimal("10"),
            arrondi=ROUND_HALF_EVEN,
        )

        self.assertEqual(
            resultat_demi_superieur.moyenne_sur_base,
            Decimal("1.2345"),
        )
        self.assertEqual(
            resultat_demi_pair.moyenne_sur_base,
            Decimal("1.2344"),
        )


class EvaluationAdmissionTests(TestCase):
    def setUp(self):
        self.inscription = SimpleNamespace(
            ecole=SimpleNamespace(pk=1),
            classe=SimpleNamespace(niveau=SimpleNamespace(pk=2)),
        )
        self.service = ServiceCalculMoyenne()

    def test_seuil_du_systeme_sapplique_sans_regle_de_niveau(self):
        with (
            patch(
                "apps.parametrage.models.SystemeNotation.objects.filter"
            ) as systemes,
            patch(
                "apps.parametrage.models.ReglePassage.objects.filter"
            ) as regles,
        ):
            systemes.return_value.first.return_value = SimpleNamespace(
                note_passage=Decimal("5.00")
            )
            regles.return_value.first.return_value = None

            admis = self.service._evaluer_admission(
                self.inscription,
                Decimal("5.00"),
                [],
            )
            refuse = self.service._evaluer_admission(
                self.inscription,
                Decimal("4.99"),
                [],
            )

        self.assertTrue(admis)
        self.assertFalse(refuse)

    def test_seuil_de_niveau_remplace_le_seuil_global_sil_est_defini(self):
        with (
            patch(
                "apps.parametrage.models.SystemeNotation.objects.filter"
            ) as systemes,
            patch(
                "apps.parametrage.models.ReglePassage.objects.filter"
            ) as regles,
        ):
            systemes.return_value.first.return_value = SimpleNamespace(
                note_passage=Decimal("5.00")
            )
            regles.return_value.first.return_value = SimpleNamespace(
                moyenne_passage=Decimal("7.00"),
                matieres_eliminatoires=SimpleNamespace(exists=lambda: False),
                seuil_eliminatoire=None,
                nb_matieres_insuffisantes_max=None,
            )

            admis = self.service._evaluer_admission(
                self.inscription,
                Decimal("6.99"),
                [],
            )

        self.assertFalse(admis)

    def test_tolerance_compte_les_matieres_sous_le_seuil_effectif(self):
        regle = SimpleNamespace(
            moyenne_passage=Decimal("7.00"),
            matieres_eliminatoires=SimpleNamespace(exists=lambda: False),
            seuil_eliminatoire=None,
            nb_matieres_insuffisantes_max=0,
        )
        with (
            patch(
                "apps.parametrage.models.SystemeNotation.objects.filter"
            ) as systemes,
            patch(
                "apps.parametrage.models.ReglePassage.objects.filter"
            ) as regles,
        ):
            systemes.return_value.first.return_value = SimpleNamespace(
                note_passage=Decimal("5.00")
            )
            regles.return_value.first.return_value = regle

            admis = self.service._evaluer_admission(
                self.inscription,
                Decimal("8.00"),
                [SimpleNamespace(moyenne=Decimal("6.00"))],
            )

        self.assertFalse(admis)
