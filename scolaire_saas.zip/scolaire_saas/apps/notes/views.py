"""Vues de saisie et consultation des notes."""
import csv
import io
from decimal import Decimal, InvalidOperation

from django.core.exceptions import ValidationError
from django.conf import settings
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from apps.noyau.decorateurs import (
    requiert_tenant,
    requiert_permission,
    requiert_une_permission,
    gerer_erreur_metier,
)
from apps.notes.models import Note, MoyenneGenerale
from apps.notes.services import ServiceSaisieNote, ServiceCalculMoyenne
from apps.academique.models import Classe, PeriodeAcademique, AnneeScolaire, StatutAnneeScolaire
from apps.noyau.exceptions import ErreurMetierBase


@login_required
@requiert_tenant
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
)
def saisie_notes(request):
    from apps.parametrage.models import Niveau

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    classes = Classe.objects.filter(
        ecole=request.etablissement, annee_scolaire=annee
    ).select_related("niveau") if annee else Classe.objects.none()
    periodes = PeriodeAcademique.objects.filter(annee_scolaire=annee) if annee else []
    niveaux = Niveau.objects.filter(
        ecole=request.etablissement, classes__annee_scolaire=annee
    ).distinct().order_by("cycle__ordre_affichage", "ordre_affichage") if annee else Niveau.objects.none()
    if q:
        classes = classes.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(niveau__libelle__icontains=q)
        )
    if niveau_id:
        try:
            niveau_pk = Niveau._meta.pk.to_python(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            classes = classes.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""
    return render(request, "notes/saisie.html", {
        "classes": classes,
        "periodes": periodes,
        "annee": annee,
        "niveaux": niveaux,
        "q": q,
        "filtre_niveau": niveau_id,
    })


@login_required
@requiert_tenant
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
    "notes.valider.propres_classes",
    "notes.valider.toutes_classes",
)
def historique_notes(request):
    """Affiche les notes déjà saisies pour l'année de travail sélectionnée."""
    from apps.securite.rbac import moteur_rbac
    from apps.eleves.models import Inscription
    from django.db.models import Prefetch

    annee = request.annee_scolaire_courante
    permissions = moteur_rbac.obtenir_toutes_permissions(
        request.user,
        request.etablissement,
    )
    notes = Note.objects.none()
    periodes = annee.periodes.all() if annee else PeriodeAcademique.objects.none()
    classes = Classe.objects.filter(
        ecole=request.etablissement,
        annee_scolaire=annee,
    ).order_by("code") if annee else Classe.objects.none()

    acces_toutes_classes = request.user.is_superuser or any(
        code in permissions
        for code in (
            "notes.saisir.toutes_classes",
            "notes.valider.toutes_classes",
        )
    )

    if annee:
        notes = Note.objects.filter(
            ecole=request.etablissement,
            inscription__annee_scolaire=annee,
            supprime_le__isnull=True,
        ).select_related(
            "inscription__eleve",
            "inscription__classe",
            "matiere",
            "periode",
            "type_evaluation",
        )
        if not acces_toutes_classes:
            from apps.academique.models import MatiereClasse

            classes_matiere = MatiereClasse.objects.filter(
                ecole=request.etablissement,
            ).filter(
                Q(enseignant__utilisateur=request.user)
                | Q(affectations_enseignants__enseignant__utilisateur=request.user)
            ).values("classe_id")
            notes = notes.filter(
                Q(inscription__classe__enseignant_titulaire__utilisateur=request.user)
                | Q(inscription__classe_id__in=classes_matiere)
            ).distinct()
            classes = classes.filter(
                Q(enseignant_titulaire__utilisateur=request.user)
                | Q(pk__in=classes_matiere)
            ).distinct()

    q = request.GET.get("q", "").strip()
    classe_id = request.GET.get("classe", "")
    periode_id = request.GET.get("periode", "")
    if q:
        notes = notes.filter(
            Q(inscription__eleve__nom__icontains=q)
            | Q(inscription__eleve__prenom__icontains=q)
            | Q(inscription__eleve__matricule__icontains=q)
            | Q(matiere__libelle__icontains=q)
            | Q(matiere__code__icontains=q)
        )
    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError, ValidationError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            notes = notes.filter(inscription__classe_id=classe_pk)
        else:
            classe_id = ""
    if periode_id:
        try:
            periode_pk = PeriodeAcademique._meta.pk.to_python(periode_id)
        except (TypeError, ValueError, ValidationError):
            periode_pk = None
        if periode_pk is not None and periodes.filter(pk=periode_pk).exists():
            notes = notes.filter(periode_id=periode_pk)
        else:
            periode_id = ""

    inscriptions = Inscription.objects.filter(
        ecole=request.etablissement,
        annee_scolaire=annee,
        notes__in=notes,
    )
    if q:
        inscriptions = inscriptions.filter(
            Q(eleve__nom__icontains=q)
            | Q(eleve__prenom__icontains=q)
            | Q(eleve__matricule__icontains=q)
            | Q(
                notes__in=notes.filter(
                    Q(matiere__libelle__icontains=q)
                    | Q(matiere__code__icontains=q)
                )
            )
        )
    inscriptions = inscriptions.distinct().select_related(
        "eleve",
        "classe",
    ).prefetch_related(
        Prefetch(
            "notes",
            queryset=notes.order_by(
                "-cree_le",
                "periode__numero",
                "matiere__libelle",
                "type_evaluation__libelle",
            ),
            to_attr="notes_historique",
        )
    ).order_by("classe__code", "eleve__nom", "eleve__prenom")
    paginator = Paginator(inscriptions, 25)
    page_obj = paginator.get_page(request.GET.get("page"))

    return render(request, "notes/historique.html", {
        "annee": annee,
        "classes": classes,
        "periodes": periodes,
        "page_obj": page_obj,
        "total_eleves": paginator.count,
        "q": q,
        "filtre_classe": classe_id,
        "filtre_periode": periode_id,
    })


@login_required
@requiert_tenant
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
)
def saisie_notes_detail(request, classe_id, matiere_id, periode_id):
    """Grille de saisie pour une classe/matière/période."""
    classe = get_object_or_404(Classe, pk=classe_id, ecole=request.etablissement)
    from apps.parametrage.models import Matiere
    matiere = get_object_or_404(Matiere, pk=matiere_id, ecole=request.etablissement)
    periode = get_object_or_404(PeriodeAcademique, pk=periode_id, ecole=request.etablissement)
    from apps.eleves.models import Inscription, StatutInscription
    from apps.parametrage.models import (
        BaremeMatierePeriode,
        CoefficientsMatiere,
        TypeEvaluation,
    )
    from apps.securite.rbac import moteur_rbac
    q = request.GET.get("q", "").strip()
    inscriptions = Inscription.objects.filter(
        ecole=request.etablissement,
        classe=classe, statut=StatutInscription.VALIDEE
    ).select_related("eleve").order_by("eleve__nom")
    types_eval = list(TypeEvaluation.objects.filter(
        ecole=request.etablissement, est_actif=True
    ).order_by("ordre_affichage"))
    notes_existantes = {
        (n.inscription_id, n.type_evaluation_id): n
        for n in Note.objects.filter(inscription__classe=classe, matiere=matiere, periode=periode)
    }
    coefficient = CoefficientsMatiere.objects.filter(
        ecole=request.etablissement,
        matiere=matiere,
        niveau=classe.niveau,
        annee_scolaire=periode.annee_scolaire,
    ).prefetch_related("baremes_evaluations").first()
    baremes_periodes = (
        list(
            BaremeMatierePeriode.objects.filter(
                ecole=request.etablissement,
                coefficient_matiere=coefficient,
            ).prefetch_related("composantes__type_evaluation")
        )
        if coefficient
        else []
    )
    bareme_periode = next(
        (
            bareme
            for bareme in baremes_periodes
            if bareme.periode_id == periode.pk
        ),
        None,
    )
    a_baremes_par_periode = bool(
        baremes_periodes
    )
    baremes_periodes_complets = bool(
        coefficient
        and {bareme.periode_id for bareme in baremes_periodes}
        == set(
            periode.annee_scolaire.periodes.values_list("pk", flat=True)
        )
        and sum(
            (bareme.bareme_total for bareme in baremes_periodes),
            Decimal("0"),
        )
        == coefficient.bareme_total
    )
    mode_calcul = (
        bareme_periode.mode_calcul
        if bareme_periode
        else coefficient.mode_calcul if coefficient else None
    )
    bareme_total = (
        bareme_periode.bareme_total
        if bareme_periode
        else coefficient.bareme_total if coefficient else None
    )
    configurations = (
        bareme_periode.composantes.all()
        if bareme_periode
        else coefficient.baremes_evaluations.all() if coefficient else []
    )
    baremes = {
        bareme.type_evaluation_id: bareme
        for bareme in configurations
    }
    composantes_configurees = [
        bareme
        for bareme in baremes.values()
        if bareme.type_evaluation.compte_dans_moyenne
    ]
    if coefficient and mode_calcul == "points":
        total_configure = sum(
            (bareme.points_max for bareme in composantes_configurees),
            Decimal("0"),
        )
        total_attendu = bareme_total
    elif coefficient and mode_calcul == "ponderation":
        total_configure = sum(
            (
                bareme.poids_pourcentage or Decimal("0")
                for bareme in composantes_configurees
            ),
            Decimal("0"),
        )
        total_attendu = Decimal("100.00")
    elif coefficient:
        total_configure = Decimal("0")
        total_attendu = Decimal("1")
    else:
        total_configure = Decimal("0")
        total_attendu = Decimal("1")
    bareme_configure = bool(
        coefficient
        and total_configure == total_attendu
        and (
            not a_baremes_par_periode
            or (
                baremes_periodes_complets
                and bareme_periode is not None
            )
        )
    )
    lignes_grille = []
    for inscription in inscriptions:
        cellules = []
        for type_evaluation in types_eval:
            note = notes_existantes.get((inscription.pk, type_evaluation.pk))
            bareme_eval = baremes.get(type_evaluation.pk)
            cellules.append({
                "type_evaluation": type_evaluation,
                "note": note,
                "note_max": (
                    note.note_max
                    if note
                    else (
                        bareme_eval.points_max
                        if type_evaluation.compte_dans_moyenne and bareme_eval
                        else type_evaluation.note_max_defaut
                    )
                ),
                "saisie_autorisee": (
                    note is not None
                    or not type_evaluation.compte_dans_moyenne
                    or (
                        bareme_eval is not None
                        and bareme_eval.points_max > 0
                        and (
                            coefficient.mode_calcul == "points"
                            or (
                                bareme_eval.poids_pourcentage is not None
                                and bareme_eval.poids_pourcentage > 0
                            )
                        )
                        and bareme_configure
                    )
                ),
            })
        lignes_grille.append({"inscription": inscription, "cellules": cellules})
    peut_gerer_coefficients = any(
        moteur_rbac.possede_permission(
            request.user,
            request.etablissement,
            permission,
        )
        for permission in (
            "parametrage.modifier.etablissement",
            "notes.saisir.toutes_classes",
        )
    )
    a_acces_a_ses_classes = moteur_rbac.possede_permission(
        request.user,
        request.etablissement,
        "notes.saisir.propres_classes",
    )
    if not peut_gerer_coefficients and a_acces_a_ses_classes:
        from apps.academique.models import MatiereClasse

        affectation_matiere = MatiereClasse.objects.filter(
            ecole=request.etablissement,
            classe=classe,
            matiere=matiere,
        ).filter(
            Q(enseignant__utilisateur=request.user)
            | Q(
                affectations_enseignants__enseignant__utilisateur=request.user,
                affectations_enseignants__est_active=True,
            )
        ).exists()
        peut_gerer_coefficients = (
            classe.enseignant_titulaire_id == getattr(
                getattr(request.user, "profil_enseignant", None),
                "pk",
                None,
            )
            or affectation_matiere
        )
    return render(request, "notes/grille_saisie.html", {
        "classe": classe, "matiere": matiere, "periode": periode,
        "inscriptions": inscriptions, "lignes_grille": lignes_grille,
        "types_eval": types_eval,
        "notes_existantes": notes_existantes,
        "q": q,
        "peut_gerer_coefficients": peut_gerer_coefficients,
        "coefficient_configure": coefficient is not None,
        "mode_calcul": mode_calcul,
        "bareme_total": bareme_total,
        "bareme_periode_required": (
            a_baremes_par_periode
            and (not baremes_periodes_complets or bareme_periode is None)
        ),
        "bareme_configure": bareme_configure,
        "coefficient_matiere": coefficient,
    })


@login_required
@requiert_tenant
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
)
def importer_notes(request, classe_id, matiere_id, periode_id):
    """Importe les notes via le même service métier que la grille de saisie."""
    from apps.eleves.models import Inscription, StatutInscription
    from apps.parametrage.models import Matiere, TypeEvaluation

    classe = get_object_or_404(Classe, pk=classe_id, ecole=request.etablissement)
    matiere = get_object_or_404(Matiere, pk=matiere_id, ecole=request.etablissement)
    periode = get_object_or_404(
        PeriodeAcademique, pk=periode_id, ecole=request.etablissement
    )
    if classe.annee_scolaire_id != periode.annee_scolaire_id:
        raise ValidationError("La période ne correspond pas à l'année de la classe.")

    resultat = None
    if request.method == "POST":
        fichier = request.FILES.get("fichier_csv")
        if not fichier:
            messages.error(request, "Sélectionnez un fichier CSV.")
        else:
            try:
                contenu = fichier.read().decode("utf-8-sig")
                try:
                    dialecte = csv.Sniffer().sniff(contenu[:2048], delimiters=",;\t")
                except csv.Error:
                    dialecte = csv.excel
                lecteur = csv.DictReader(io.StringIO(contenu), dialect=dialecte)
                champs_requis = {"matricule", "type_evaluation_code", "valeur"}
                manquants = champs_requis - set(lecteur.fieldnames or [])
                if manquants:
                    raise ValueError(
                        "Colonnes manquantes : " + ", ".join(sorted(manquants))
                    )

                nb_importees, erreurs = 0, []
                for numero, ligne in enumerate(lecteur, start=2):
                    try:
                        with transaction.atomic():
                            inscription = Inscription.objects.get(
                                ecole=request.etablissement,
                                classe=classe,
                                statut=StatutInscription.VALIDEE,
                                eleve__matricule=(ligne.get("matricule") or "").strip(),
                            )
                            type_eval = TypeEvaluation.objects.get(
                                ecole=request.etablissement,
                                code=(ligne.get("type_evaluation_code") or "").strip(),
                            )
                            absence = _lire_booleen_csv(
                                ligne.get("est_absence", ""), "est_absence"
                            )
                            absence_justifiee = _lire_booleen_csv(
                                ligne.get("absence_justifiee", ""),
                                "absence_justifiee",
                            )
                            valeur_brute = (ligne.get("valeur") or "").strip()
                            valeur = (
                                Decimal(valeur_brute.replace(",", "."))
                                if valeur_brute
                                else None
                            )
                            ServiceSaisieNote(request.user).saisir(
                                inscription=inscription,
                                matiere=matiere,
                                periode=periode,
                                type_evaluation=type_eval,
                                valeur=valeur,
                                est_absence=absence,
                                absence_justifiee=absence_justifiee,
                                motif_absence=(ligne.get("motif_absence") or "").strip(),
                                observations=(ligne.get("observations") or "").strip(),
                            )
                        nb_importees += 1
                    except (
                        Inscription.DoesNotExist,
                        Inscription.MultipleObjectsReturned,
                        TypeEvaluation.DoesNotExist,
                        TypeEvaluation.MultipleObjectsReturned,
                        ErreurMetierBase,
                        ValidationError,
                        InvalidOperation,
                        ValueError,
                        IntegrityError,
                    ) as erreur:
                        erreurs.append(f"Ligne {numero} : {erreur}")
                resultat = {"importees": nb_importees, "erreurs": erreurs}
            except (UnicodeDecodeError, csv.Error, ValueError) as erreur:
                messages.error(request, f"Import impossible : {erreur}")

    return render(
        request,
        "notes/importer.html",
        {
            "classe": classe,
            "matiere": matiere,
            "periode": periode,
            "resultat": resultat,
        },
    )


def _lire_booleen_csv(valeur, champ):
    valeur = (valeur or "").strip().lower()
    if not valeur:
        return False
    if valeur in {"true", "1", "oui", "yes"}:
        return True
    if valeur in {"false", "0", "non", "no"}:
        return False
    raise ValueError(f"« {champ} » doit être vrai/faux (oui/non, 1/0).")


@login_required
@requiert_tenant
@require_POST
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
)
def api_enregistrer_note(request):
    """API JSON pour la saisie de notes (appel AJAX depuis la grille)."""
    import json
    from decimal import Decimal
    try:
        data = json.loads(request.body)
        from apps.eleves.models import Inscription
        from apps.parametrage.models import Matiere, TypeEvaluation
        inscription = get_object_or_404(Inscription, pk=data["inscription_id"], ecole=request.etablissement)
        matiere = get_object_or_404(Matiere, pk=data["matiere_id"], ecole=request.etablissement)
        periode = get_object_or_404(PeriodeAcademique, pk=data["periode_id"], ecole=request.etablissement)
        type_eval = get_object_or_404(TypeEvaluation, pk=data["type_eval_id"], ecole=request.etablissement)
        valeur = Decimal(str(data["valeur"])) if data.get("valeur") is not None else None
        service = ServiceSaisieNote(request.user)
        note = service.saisir(
            inscription=inscription, matiere=matiere, periode=periode,
            type_evaluation=type_eval, valeur=valeur,
            est_absence=data.get("est_absence", False),
            absence_justifiee=data.get("absence_justifiee", False),
        )
        return JsonResponse({"succes": True, "note_id": str(note.pk), "valeur": str(note.valeur)})
    except ValidationError as exc:
        return JsonResponse(
            {"succes": False, "erreur": " ".join(exc.messages)},
            status=400,
        )
    except Exception as exc:
        return JsonResponse({"succes": False, "erreur": str(exc)}, status=400)


@login_required
@requiert_tenant
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
    "notes.valider.propres_classes",
    "notes.valider.toutes_classes",
)
def liste_moyennes(request):
    from django.db.models import Avg, Count, Min, Prefetch, Q
    from apps.parametrage.models import Niveau
    from apps.securite.rbac import moteur_rbac
    from apps.eleves.models import Inscription, StatutInscription
    from apps.notes.models import MoyenneGenerale, MoyenneMatiere

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    classe_id = request.GET.get("classe", "")
    classes = Classe.objects.filter(
        ecole=request.etablissement, annee_scolaire=annee
    ).select_related("niveau", "annee_scolaire") if annee else Classe.objects.none()
    permissions = moteur_rbac.obtenir_toutes_permissions(
        request.user,
        request.etablissement,
    )
    acces_toutes_classes = request.user.is_superuser or any(
        code in permissions
        for code in (
            "notes.saisir.toutes_classes",
            "notes.valider.toutes_classes",
        )
    )
    if annee and not acces_toutes_classes:
        from apps.academique.models import MatiereClasse

        classes_matiere = MatiereClasse.objects.filter(
            ecole=request.etablissement,
        ).filter(
            Q(enseignant__utilisateur=request.user)
            | Q(affectations_enseignants__enseignant__utilisateur=request.user)
        ).values("classe_id")
        classes = classes.filter(
            Q(enseignant_titulaire__utilisateur=request.user)
            | Q(pk__in=classes_matiere)
        ).distinct()
    niveaux = Niveau.objects.filter(
        ecole=request.etablissement,
        classes__annee_scolaire=annee,
    ).distinct().order_by("cycle__ordre_affichage", "ordre_affichage") if annee else Niveau.objects.none()
    periodes = annee.periodes.annotate(
        nb_moyennes_generales=Count("moyennes_generales", distinct=True),
    ).order_by("numero") if annee else []
    for periode in periodes:
        periode.peut_calculer_moyennes = (
            periode.statut == "cloturee"
            or (
                periode.statut == "publiee"
                and periode.nb_moyennes_generales == 0
            )
        )
    selected_periode = None
    if periodes:
        periode_id = request.GET.get("periode", "")
        try:
            periode_pk = PeriodeAcademique._meta.pk.to_python(periode_id)
        except (TypeError, ValueError, ValidationError):
            periode_pk = None
        selected_periode = next(
            (periode for periode in periodes if periode.pk == periode_pk),
            None,
        )
        if selected_periode is None:
            selected_periode = next(
                (periode for periode in periodes if periode.nb_moyennes_generales),
                periodes[0],
            )
    if q:
        classes = classes.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(niveau__libelle__icontains=q)
            | Q(niveau__code__icontains=q)
        )
    if niveau_id:
        try:
            niveau_pk = Niveau._meta.pk.to_python(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            classes = classes.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""

    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError, ValidationError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            classes = classes.filter(pk=classe_pk)
        else:
            classe_id = ""

    inscriptions = Inscription.objects.none()
    page_obj = Paginator(inscriptions, 25).get_page(1)
    total_inscrits = moyennes_calculees = 0
    moyenne_classe = None
    base_calcul = None
    nb_admis = 0
    if annee and selected_periode:
        inscriptions = Inscription.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=annee,
            classe__in=classes,
            statut=StatutInscription.VALIDEE,
        )
        if q:
            inscriptions = inscriptions.filter(
                Q(eleve__nom__icontains=q)
                | Q(eleve__prenom__icontains=q)
                | Q(eleve__matricule__icontains=q)
                | Q(classe__code__icontains=q)
                | Q(classe__libelle__icontains=q)
            )
        inscriptions = inscriptions.select_related(
            "eleve",
            "classe",
            "classe__niveau",
        ).prefetch_related(
            Prefetch(
                "moyennes_generales",
                queryset=MoyenneGenerale.objects.filter(
                    ecole=request.etablissement,
                    periode=selected_periode,
                ).select_related("mention"),
                to_attr="moyenne_generale_periode",
            ),
            Prefetch(
                "moyennes_matieres",
                queryset=MoyenneMatiere.objects.filter(
                    ecole=request.etablissement,
                    periode=selected_periode,
                ).select_related("matiere", "mention").order_by("matiere__libelle"),
                to_attr="moyennes_matieres_periode",
            ),
        ).order_by("classe__code", "eleve__nom", "eleve__prenom")

        total_inscrits = inscriptions.count()
        moyennes_periode = MoyenneGenerale.objects.filter(
            ecole=request.etablissement,
            periode=selected_periode,
            inscription__in=inscriptions,
        )
        moyennes_calculees = moyennes_periode.count()
        statistiques = moyennes_periode.aggregate(
            moyenne=Avg("moyenne"),
            base=Min("base_calcul"),
        )
        moyenne_classe = statistiques["moyenne"]
        base_calcul = statistiques["base"]
        nb_admis = moyennes_periode.filter(est_admis=True).count()

        page_obj = Paginator(inscriptions, 25).get_page(request.GET.get("page"))
        for inscription in page_obj:
            inscription.moyenne_generale_periode = (
                inscription.moyenne_generale_periode[0]
                if inscription.moyenne_generale_periode
                else None
            )

    return render(request, "notes/moyennes.html", {
        "classes": classes,
        "annee": annee,
        "periodes": periodes,
        "niveaux": niveaux,
        "selected_periode": selected_periode,
        "selected_classe": classe_id,
        "q": q,
        "filtre_niveau": niveau_id,
        "page_obj": page_obj,
        "total_inscrits": total_inscrits,
        "moyennes_calculees": moyennes_calculees,
        "moyenne_classe": moyenne_classe,
        "base_calcul": base_calcul,
        "nb_admis": nb_admis,
        "peut_calculer_moyennes": (
            request.user.is_superuser
            or "notes.valider.toutes_classes" in permissions
        ),
    })


@login_required
@requiert_tenant
@requiert_une_permission(
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
    "notes.valider.propres_classes",
    "notes.valider.toutes_classes",
)
def liste_moyennes_annuelles(request):
    from django.db.models import Q
    from apps.eleves.models import Inscription, StatutInscription
    from apps.securite.rbac import moteur_rbac

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    classe_id = request.GET.get("classe", "")
    classes = (
        Classe.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=annee,
        ).select_related("niveau")
        if annee
        else Classe.objects.none()
    )
    permissions = moteur_rbac.obtenir_toutes_permissions(
        request.user,
        request.etablissement,
    )
    acces_toutes_classes = request.user.is_superuser or any(
        code in permissions
        for code in (
            "notes.saisir.toutes_classes",
            "notes.valider.toutes_classes",
        )
    )
    if annee and not acces_toutes_classes:
        from apps.academique.models import MatiereClasse

        classes_matiere = MatiereClasse.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=annee,
            enseignant__utilisateur=request.user,
        ).values("classe_id")
        classes = classes.filter(
            Q(enseignant_titulaire__utilisateur=request.user)
            | Q(pk__in=classes_matiere)
        ).distinct()

    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError, ValidationError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            classes = classes.filter(pk=classe_pk)
        else:
            classe_id = ""
    if q:
        classes = classes.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(niveau__libelle__icontains=q)
        )

    inscriptions = (
        Inscription.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=annee,
            classe__in=classes,
            statut=StatutInscription.VALIDEE,
        )
        .select_related("eleve", "classe")
        .order_by("classe__code", "eleve__nom", "eleve__prenom")
        if annee
        else Inscription.objects.none()
    )
    if q:
        inscriptions = inscriptions.filter(
            Q(eleve__nom__icontains=q)
            | Q(eleve__prenom__icontains=q)
            | Q(eleve__matricule__icontains=q)
        )
    page_obj = Paginator(inscriptions, 25).get_page(request.GET.get("page"))
    service = ServiceCalculMoyenne(request.user)
    for inscription in page_obj:
        inscription.resultat_annuel = service.calculer_resultat_annuel(inscription)

    return render(
        request,
        "notes/moyennes_annuelles.html",
        {
            "annee": annee,
            "classes": classes,
            "selected_classe": classe_id,
            "q": q,
            "page_obj": page_obj,
            "total_inscrits": inscriptions.count(),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("notes.valider.toutes_classes")
@gerer_erreur_metier
def calculer_moyennes(request, periode_id):
    periode = get_object_or_404(PeriodeAcademique, pk=periode_id, ecole=request.etablissement)
    if request.method == "POST":
        from workers.taches_bulletins import calculer_moyennes_periode
        resultat = calculer_moyennes_periode.delay(
            ecole_id=str(request.etablissement.pk),
            periode_id=periode_id,
        )
        if settings.CELERY_TASK_ALWAYS_EAGER:
            rapport = resultat.get()
            calcules = rapport.get("calcules", 0)
            erreurs = rapport.get("erreurs", 0)
            if erreurs:
                details = rapport.get("details_erreurs", [])
                premiere_erreur = details[0].get("erreur", "") if details else ""
                message = (
                    f"{calcules} moyenne(s) calculée(s), {erreurs} erreur(s) "
                    f"pour {periode.libelle}."
                )
                if premiere_erreur:
                    message += f" Première erreur : {premiere_erreur}"
                messages.warning(request, message)
            elif calcules:
                messages.success(
                    request,
                    f"Moyennes calculées pour {calcules} élève(s) "
                    f"sur {periode.libelle}.",
                )
            else:
                messages.warning(
                    request,
                    f"Aucune moyenne calculée pour {periode.libelle} : "
                    "aucune inscription validée à traiter.",
                )
        else:
            messages.success(request, f"Calcul des moyennes lancé pour {periode.libelle}.")
    return redirect("notes:moyennes")


@login_required
@requiert_tenant
@requiert_permission("notes.valider.toutes_classes")
@gerer_erreur_metier
def calculer_classements(request, periode_id):
    periode = get_object_or_404(PeriodeAcademique, pk=periode_id, ecole=request.etablissement)
    if request.method == "POST":
        service = ServiceCalculMoyenne(request.user)
        classes = Classe.objects.filter(annee_scolaire=periode.annee_scolaire)
        nb_total = 0
        for classe in classes:
            nb_total += service.calculer_classements_classe(classe, periode)
        messages.success(request, f"Classements calculés pour {nb_total} élèves.")
    return redirect("notes:moyennes")


@login_required
@requiert_tenant
def releve_notes(request, inscription_id):
    inscription = get_object_or_404(__import__("apps.eleves.models", fromlist=["Inscription"]).Inscription, pk=inscription_id, ecole=request.etablissement)
    periodes = PeriodeAcademique.objects.filter(annee_scolaire=inscription.annee_scolaire)
    from apps.notes.models import MoyenneMatiere
    q = request.GET.get("q", "").strip()
    moyennes = MoyenneMatiere.objects.filter(inscription=inscription).select_related("matiere", "periode", "mention")
    if q:
        moyennes = moyennes.filter(
            Q(matiere__libelle__icontains=q) | Q(matiere__code__icontains=q)
        )
    return render(request, "notes/releve.html", {
        "inscription": inscription,
        "periodes": periodes,
        "moyennes": moyennes,
        "q": q,
    })
