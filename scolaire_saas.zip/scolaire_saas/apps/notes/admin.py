from django.contrib import admin
from apps.notes.models import MoyenneGenerale, MoyenneMatiere, Note
from apps.noyau.admin import AdminTenant

admin.site.register((Note, MoyenneMatiere, MoyenneGenerale), AdminTenant)
