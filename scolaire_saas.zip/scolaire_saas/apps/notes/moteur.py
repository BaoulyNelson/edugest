"""
apps/notes/moteur.py
=====================
Moteur central de calcul des moyennes.
Point névralgique du système : toute la logique arithmétique est ici.

GARANTIES :
- Arithmétique Decimal exclusivement (jamais float)
- 4 décimales de précision (ROUND_HALF_UP)
- Coefficients figés depuis la note (jamais recalculés depuis la config)
- Résultats reproductibles et auditables (detail_calcul JSON)
- Aucune dépendance aux modèles Django (testable en isolation complète)
"""

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Optional
from apps.noyau.exceptions import ErreurCalcul
from apps.noyau.utilitaires.decimaux import (
    arrondir_moyenne,
    arrondir_affichage,
    normaliser_sur_base,
    vers_decimal,
)


@dataclass
class DonneeNote:
    """
    Représentation pure d'une note pour le moteur de calcul.
    Indépendante de Django ORM — permet les tests unitaires sans DB.
    """
    note_id: str
    valeur: Optional[Decimal]          # None si absence justifiée (exclue)
    note_max: Decimal
    coefficient: Decimal
    type_evaluation_code: str = ""
    est_absence_non_justifiee: bool = False  # Comptée comme 0


@dataclass
class ResultatMoyenneMatiere:
    """Résultat du calcul de moyenne pour une matière sur une période."""
    points_ponderes: Decimal
    total_coefficients: Decimal
    moyenne_sur_base: Decimal
    base: Decimal
    nb_notes: int
    nb_notes_exclues: int           # Absences justifiées
    detail: dict = field(default_factory=dict)

    @property
    def pourcentage(self) -> Decimal:
        """Pourcentage d'obtention (0–100)."""
        if self.base == Decimal("0"):
            return Decimal("0")
        return arrondir_affichage(
            (self.moyenne_sur_base / self.base) * Decimal("100")
        )


@dataclass
class ResultatMoyenneGenerale:
    """Résultat du calcul de moyenne générale pour une période."""
    total_points_ponderes: Decimal
    total_coefficients: Decimal
    moyenne_sur_base: Decimal
    base: Decimal
    nb_matieres: int
    detail: dict = field(default_factory=dict)

    @property
    def pourcentage(self) -> Decimal:
        if self.base == Decimal("0"):
            return Decimal("0")
        return arrondir_affichage(
            (self.moyenne_sur_base / self.base) * Decimal("100")
        )


class MoteurCalculMoyenne:
    """
    Moteur de calcul des moyennes — stateless, thread-safe, testable.

    Formule de base (matière) :
        note_sur_base = (Σ(valeur_normalisée × coeff_eval) / Σ(coeff_eval)) × base

    Formule générale :
        moy_gen = (Σ(note_sur_base_matière × coeff_matière) / Σ(coeff_matière))

    Exemple validé (cahier des charges) :
        678 points / 1200 max × 10 = 5.6500 ✓
    """

    PRECISION = Decimal("0.0001")
    ARRONDI = ROUND_HALF_UP

    def calculer_moyenne_matiere(
        self,
        notes: list[DonneeNote],
        base: Decimal = Decimal("10.00"),
        arrondi: str = ROUND_HALF_UP,
    ) -> ResultatMoyenneMatiere:
        """
        Calcule la moyenne d'une matière pour un ensemble de notes.

        Algorithme :
        1. Filtrer les notes exclues (absences justifiées : valeur=None)
        2. Normaliser chaque note sur 100
        3. Pondérer par le coefficient de l'évaluation
        4. Ramener le résultat sur la base de l'école

        Raises:
            ErreurCalcul: si les données sont insuffisantes ou incohérentes
        """
        if not notes:
            raise ErreurCalcul(
                "Impossible de calculer une moyenne : liste de notes vide."
            )

        if base <= Decimal("0"):
            raise ErreurCalcul(f"Base de notation invalide : {base}")

        notes_incluses = []
        notes_exclues = []
        detail = {}

        for note in notes:
            # Validation des données d'entrée
            if note.note_max <= Decimal("0"):
                raise ErreurCalcul(
                    f"Note max invalide ({note.note_max}) pour note#{note.note_id}"
                )
            if note.coefficient <= Decimal("0"):
                raise ErreurCalcul(
                    f"Coefficient invalide ({note.coefficient}) pour note#{note.note_id}"
                )

            # Absence justifiée → exclue du calcul
            if note.valeur is None and not note.est_absence_non_justifiee:
                notes_exclues.append(note)
                detail[note.note_id] = {"statut": "exclu_absence_justifiee"}
                continue

            # Valeur effective : absence non justifiée = 0
            valeur_effective = (
                Decimal("0")
                if note.est_absence_non_justifiee
                else (note.valeur or Decimal("0"))
            )

            notes_incluses.append((note, valeur_effective))

        if not notes_incluses:
            raise ErreurCalcul(
                "Toutes les notes sont exclues (absences justifiées). "
                "Impossible de calculer une moyenne."
            )

        # Calcul pondéré
        somme_numerateur = Decimal("0")
        somme_denominateur = Decimal("0")

        for note, valeur_effective in notes_incluses:
            # Normalisation sur 100 pour unifier les barèmes (sur 5, 10, 20, 100...)
            valeur_sur_100 = (valeur_effective / note.note_max) * Decimal("100")
            contribution = valeur_sur_100 * note.coefficient

            somme_numerateur += contribution
            somme_denominateur += note.coefficient

            detail[note.note_id] = {
                "valeur": str(valeur_effective),
                "sur": str(note.note_max),
                "coeff": str(note.coefficient),
                "valeur_sur_100": str(arrondir_affichage(valeur_sur_100)),
                "contribution": str(arrondir_affichage(contribution)),
            }

        if somme_denominateur == Decimal("0"):
            raise ErreurCalcul("Somme des coefficients = 0. Vérifier la configuration.")

        # Moyenne sur 100, ramenée sur la base de l'école
        moyenne_sur_100 = somme_numerateur / somme_denominateur
        moyenne_sur_base = (moyenne_sur_100 / Decimal("100")) * base
        moyenne_arrondie = moyenne_sur_base.quantize(
            self.PRECISION,
            rounding=arrondi,
        )

        return ResultatMoyenneMatiere(
            points_ponderes=somme_numerateur.quantize(
                self.PRECISION,
                rounding=arrondi,
            ),
            total_coefficients=somme_denominateur,
            moyenne_sur_base=moyenne_arrondie,
            base=base,
            nb_notes=len(notes_incluses),
            nb_notes_exclues=len(notes_exclues),
            detail=detail,
        )

    def calculer_moyenne_generale(
        self,
        matieres: list[tuple[ResultatMoyenneMatiere, Decimal]],
        # Chaque tuple : (résultat_matière, coefficient_matière)
        base: Decimal = Decimal("10.00"),
        arrondi: str = ROUND_HALF_UP,
    ) -> ResultatMoyenneGenerale:
        """
        Calcule la moyenne générale depuis les moyennes de matières.

        Raises:
            ErreurCalcul: si aucune matière ou coefficients à zéro
        """
        if not matieres:
            raise ErreurCalcul(
                "Impossible de calculer la moyenne générale : aucune matière."
            )

        somme_numerateur = Decimal("0")
        somme_denominateur = Decimal("0")
        detail = {}

        for i, (resultat_matiere, coeff_matiere) in enumerate(matieres):
            if coeff_matiere <= Decimal("0"):
                raise ErreurCalcul(
                    f"Coefficient de matière invalide ({coeff_matiere}) "
                    f"pour la matière #{i}"
                )

            contribution = resultat_matiere.moyenne_sur_base * coeff_matiere
            somme_numerateur += contribution
            somme_denominateur += coeff_matiere

            detail[f"matiere_{i}"] = {
                "moyenne": str(resultat_matiere.moyenne_sur_base),
                "coeff": str(coeff_matiere),
                "contribution": str(arrondir_affichage(contribution)),
            }

        if somme_denominateur == Decimal("0"):
            raise ErreurCalcul("Somme des coefficients de matières = 0.")

        moyenne = (somme_numerateur / somme_denominateur).quantize(
            self.PRECISION, rounding=arrondi
        )

        return ResultatMoyenneGenerale(
            total_points_ponderes=somme_numerateur.quantize(
                self.PRECISION,
                rounding=arrondi,
            ),
            total_coefficients=somme_denominateur,
            moyenne_sur_base=moyenne,
            base=base,
            nb_matieres=len(matieres),
            detail=detail,
        )

    def calculer_depuis_totaux(
        self,
        points_obtenus: Decimal,
        points_max: Decimal,
        base: Decimal = Decimal("10.00"),
    ) -> Decimal:
        """
        Calcul direct depuis des totaux bruts.
        Cas d'usage : calcul simplifié 678/1200 × 10 = 5.6500.

        >>> moteur.calculer_depuis_totaux(Decimal("678"), Decimal("1200"), Decimal("10"))
        Decimal('5.6500')
        """
        if points_max <= Decimal("0"):
            raise ErreurCalcul(f"points_max invalide : {points_max}")
        if points_obtenus < Decimal("0"):
            raise ErreurCalcul(f"points_obtenus négatif : {points_obtenus}")
        if points_obtenus > points_max:
            raise ErreurCalcul(
                f"points_obtenus ({points_obtenus}) > points_max ({points_max})"
            )

        return normaliser_sur_base(points_obtenus, points_max, base)


# ─── Instance singleton partageable ─────────────────────────────────────────
moteur_calcul = MoteurCalculMoyenne()


# ─── Validation de régression à l'import ─────────────────────────────────────
_test_result = moteur_calcul.calculer_depuis_totaux(
    Decimal("678"), Decimal("1200"), Decimal("10")
)
assert _test_result == Decimal("5.6500"), (
    f"RÉGRESSION CRITIQUE : 678/1200×10 devrait valoir 5.6500, "
    f"obtenu : {_test_result}"
)