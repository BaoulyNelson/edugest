from django.contrib import admin
import csv
import io
from decimal import InvalidOperation
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.http import HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import path, reverse
from django.contrib import messages
from django.utils import timezone
from apps.etablissements.forms import FormulaireAbonnement
from apps.etablissements.models import (
    Abonnement,
    ConfigurationSite,
    DemandeChangementForfait,
    Etablissement,
    PlanAbonnement,
    date_fin_periode_abonnement,
)


@admin.register(ConfigurationSite)
class ConfigurationSiteAdmin(admin.ModelAdmin):
    list_display = ["nom_site", "email_contact", "telephone_contact"]
    fields = [
        "nom_site",
        "slogan",
        "logo",
        "email_contact",
        "telephone_contact",
        "adresse",
        "site_web",
    ]

    def has_module_permission(self, request):
        return request.user.is_superuser

    def has_view_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_change_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_add_permission(self, request):
        return request.user.is_superuser and not ConfigurationSite.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Etablissement)
class EtablissementAdmin(admin.ModelAdmin):
    list_display = ["slug", "nom", "type_etablissement", "ville", "est_actif", "cree_le"]
    list_filter = ["type_etablissement", "est_actif", "pays"]
    search_fields = ["slug", "nom", "ville"]
    readonly_fields = ["cree_le", "modifie_le"]

@admin.register(PlanAbonnement)
class PlanAbonnementAdmin(admin.ModelAdmin):
    change_list_template = "admin/etablissements/planabonnement/change_list.html"
    list_display = [
        "code",
        "libelle",
        "prix_mensuel_htg",
        "prix_annuel_htg",
        "max_eleves",
        "est_actif",
        "est_visible_public",
        "ordre_affichage",
    ]
    list_filter = ["est_actif", "est_visible_public"]
    search_fields = ["code", "libelle"]

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path(
                "importer-csv/",
                self.admin_site.admin_view(self.importer_csv),
                name="etablissements_planabonnement_import",
            )
        ]
        return custom_urls + urls

    def importer_csv(self, request):
        if not request.user.is_superuser:
            raise PermissionDenied

        if request.method == "POST":
            fichier = request.FILES.get("fichier_csv")
            if not fichier:
                messages.error(request, "Sélectionnez un fichier CSV.")
                return HttpResponseRedirect(request.path)
            try:
                contenu = fichier.read().decode("utf-8-sig")
                try:
                    dialecte = csv.Sniffer().sniff(contenu[:2048], delimiters=",;\t")
                except csv.Error:
                    dialecte = csv.excel
                lecteur = csv.DictReader(io.StringIO(contenu), dialect=dialecte)
                if not lecteur.fieldnames:
                    raise ValueError("Le fichier CSV est vide ou sans en-tête.")

                from apps.etablissements.management.commands.importer_plans_abonnement import (
                    CHAMPS_REQUIS,
                    Command,
                )

                manquants = CHAMPS_REQUIS - set(lecteur.fieldnames)
                if manquants:
                    raise ValueError(
                        "Colonnes manquantes : " + ", ".join(sorted(manquants))
                    )

                crees, mis_a_jour, erreurs = 0, 0, []
                for numero, ligne in enumerate(lecteur, start=2):
                    try:
                        with transaction.atomic():
                            cree = Command._enregistrer_plan(ligne)
                        if cree:
                            crees += 1
                        else:
                            mis_a_jour += 1
                    except (ValueError, InvalidOperation, csv.Error) as erreur:
                        erreurs.append(f"Ligne {numero} : {erreur}")
                messages.success(
                    request,
                    f"Import terminé : {crees} plan(s) créé(s), "
                    f"{mis_a_jour} mis à jour.",
                )
                if erreurs:
                    messages.warning(
                        request,
                        "Erreurs : " + " ; ".join(erreurs[:10]),
                    )
                return HttpResponseRedirect(
                    reverse("admin:etablissements_planabonnement_changelist")
                )
            except (UnicodeDecodeError, csv.Error, ValueError) as erreur:
                messages.error(request, f"Import impossible : {erreur}")

        contexte = {
            **self.admin_site.each_context(request),
            "title": "Importer les plans d'abonnement",
            "opts": self.model._meta,
        }
        return TemplateResponse(
            request,
            "admin/etablissements/planabonnement/importer.html",
            contexte,
        )
class AbonnementActifFilter(admin.SimpleListFilter):
    title = "Abonnement actif"
    parameter_name = "est_actif"

    def lookups(self, request, model_admin):
        return (("oui", "Oui"), ("non", "Non"))

    def queryset(self, request, queryset):
        if self.value() == "oui":
            return queryset.filter(est_actif=True)
        if self.value() == "non":
            return queryset.filter(est_actif=False)
        return queryset


@admin.register(Abonnement)
class AbonnementAdmin(admin.ModelAdmin):
    list_display = [
        "etablissement", "plan", "abonnement_actif", "etat_abonnement",
        "date_debut", "date_echeance",
    ]
    list_filter = [
        "etablissement", "plan", "periodicite", AbonnementActifFilter,
        "en_periode_essai",
    ]
    search_fields = [
        "etablissement__nom",
        "etablissement__slug",
        "plan__code",
        "plan__libelle",
    ]
    list_select_related = ("etablissement", "plan")
    form = FormulaireAbonnement

    @admin.display(description="Type d'abonnement")
    def etat_abonnement(self, obj):
        return "Essai gratuit" if obj.en_periode_essai else obj.get_periodicite_display()

    @admin.display(description="Abonnement actif", boolean=True, ordering="est_actif")
    def abonnement_actif(self, obj):
        return obj.est_actif

    @admin.display(description="Échéance")
    def date_echeance(self, obj):
        return obj.date_fin_essai if obj.en_periode_essai else obj.date_fin

    def get_fieldsets(self, request, obj=None):
        en_essai = obj.en_periode_essai if obj else True
        champs = ["etablissement", "plan", "date_debut"]
        if en_essai:
            champs.extend(["en_periode_essai", "date_fin_essai"])
        else:
            champs.extend(["periodicite", "date_fin", "renouvellement_auto"])
            champs.append("en_periode_essai")
        champs.extend(["est_actif", "souscrit_par", "notes_internes"])
        return ((None, {"fields": tuple(champs)}),)

@admin.register(DemandeChangementForfait)
class DemandeChangementForfaitAdmin(admin.ModelAdmin):
    list_display = ["abonnement", "plan", "periodicite", "statut", "cree_le", "traitee_par"]
    list_filter = ["abonnement__etablissement", "statut", "cree_le"]
    search_fields = ["abonnement__etablissement__nom", "abonnement__etablissement__slug"]
    list_select_related = ("abonnement__etablissement", "plan", "demandeur", "traitee_par")
    readonly_fields = [
        "abonnement", "plan", "periodicite", "demandeur", "statut", "traitee_le",
        "traitee_par", "commentaire_admin", "cree_le", "modifie_le",
    ]
    actions = ["approuver_apres_verification", "refuser_demande"]

    @admin.action(description="Approuver après vérification du paiement")
    def approuver_apres_verification(self, request, queryset):
        approuvees = 0
        ignorees = 0
        for item in queryset:
            with transaction.atomic():
                demande = (
                    DemandeChangementForfait.objects.select_for_update()
                    .select_related("plan")
                    .get(pk=item.pk)
                )
                if (
                    demande.statut != DemandeChangementForfait.Statut.EN_ATTENTE
                    or not demande.plan.est_actif
                ):
                    ignorees += 1
                    continue
                abonnement = Abonnement.objects.select_for_update().get(
                    pk=demande.abonnement_id
                )
                if abonnement.demande_forfait_en_attente_id != demande.pk:
                    ignorees += 1
                    continue
                abonnement.plan = demande.plan
                abonnement.periodicite = demande.periodicite
                abonnement.date_debut = timezone.localdate()
                abonnement.date_fin = date_fin_periode_abonnement(
                    abonnement.date_debut,
                    demande.periodicite,
                )
                abonnement.renouvellement_auto = False
                abonnement.est_actif = True
                abonnement.en_periode_essai = False
                abonnement.date_fin_essai = None
                abonnement.demande_forfait_en_attente = None
                abonnement.save(update_fields=[
                    "plan", "periodicite", "date_debut", "date_fin",
                    "renouvellement_auto", "est_actif", "en_periode_essai",
                    "date_fin_essai", "demande_forfait_en_attente", "modifie_le",
                ])
                demande.statut = DemandeChangementForfait.Statut.APPROUVEE
                demande.traitee_le = timezone.now()
                demande.traitee_par = request.user
                demande.save(update_fields=[
                    "statut", "traitee_le", "traitee_par", "modifie_le",
                ])
                approuvees += 1
        self.message_user(
            request,
            f"{approuvees} demande(s) approuvée(s) ; {ignorees} ignorée(s) "
            "(déjà traitée(s) ou forfait désactivé).",
        )

    @admin.action(description="Refuser la demande")
    def refuser_demande(self, request, queryset):
        count = 0
        for item in queryset:
            with transaction.atomic():
                demande = DemandeChangementForfait.objects.select_for_update().get(
                    pk=item.pk
                )
                if demande.statut != DemandeChangementForfait.Statut.EN_ATTENTE:
                    continue
                abonnement = Abonnement.objects.select_for_update().get(
                    pk=demande.abonnement_id
                )
                if abonnement.demande_forfait_en_attente_id == demande.pk:
                    abonnement.demande_forfait_en_attente = None
                    abonnement.save(update_fields=[
                        "demande_forfait_en_attente", "modifie_le",
                    ])
                demande.statut = DemandeChangementForfait.Statut.REFUSEE
                demande.traitee_le = timezone.now()
                demande.traitee_par = request.user
                demande.save(update_fields=[
                    "statut", "traitee_le", "traitee_par", "modifie_le",
                ])
                count += 1
        self.message_user(request, f"{count} demande(s) refusée(s).")

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
