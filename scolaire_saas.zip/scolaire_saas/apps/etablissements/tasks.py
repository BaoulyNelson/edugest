"""Tâches planifiées de gestion des abonnements."""

from celery import shared_task
from django.db import transaction
from django.utils import timezone

from apps.etablissements.models import Abonnement


@shared_task
def expirer_essais_gratuits() -> int:
    """Désactive les essais échus et les établissements qui leur sont liés."""
    aujourd_hui = timezone.localdate()
    essais_expires = Abonnement.objects.filter(
        est_actif=True,
        en_periode_essai=True,
        date_fin_essai__isnull=False,
        date_fin_essai__lte=aujourd_hui,
    )
    with transaction.atomic():
        etablissements_ids = list(
            essais_expires.values_list("etablissement_id", flat=True)
        )
        if not etablissements_ids:
            return 0
        essais_expires.update(est_actif=False, modifie_le=timezone.now())
        from apps.etablissements.models import Etablissement

        Etablissement.objects.filter(
            pk__in=etablissements_ids,
            est_actif=True,
        ).update(est_actif=False, modifie_le=timezone.now())
    return len(etablissements_ids)
