"""
apps/etablissements/vues_saas.py
=================================
Vues SaaS publiques — pas de tenant requis.
Gère l'inscription, la création d'école, et le tableau de bord propriétaire.
"""

import logging
import re
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from django.http import JsonResponse

logger = logging.getLogger("apps.etablissements")


@login_required
def configurer_site(request):
    """Permet uniquement au superuser de configurer l'identité globale du site."""
    from apps.etablissements.forms import FormulaireConfigurationSite
    from apps.etablissements.models import ConfigurationSite

    if not request.user.is_superuser:
        raise PermissionDenied

    configuration, _ = ConfigurationSite.objects.get_or_create(pk=1)
    if request.method == "POST":
        form = FormulaireConfigurationSite(
            request.POST,
            request.FILES,
            instance=configuration,
        )
        if form.is_valid():
            form.save()
            messages.success(request, "La configuration du site a été enregistrée.")
            return redirect("saas:configuration")
    else:
        form = FormulaireConfigurationSite(instance=configuration)

    return render(
        request,
        "saas/configuration.html",
        {"form": form, "configuration": configuration},
    )


def accueil_saas(request):
    """Page d'accueil publique avec les plans."""
    from django.db.models import Q
    from django.utils import timezone
    from apps.etablissements.models import (
        PlanAbonnement,
        PeriodiciteFacturation,
        TypeEtablissement,
    )

    url_creation_espace = reverse("saas:inscription")
    if request.user.is_authenticated:
        from apps.etablissements.models import Etablissement
        from apps.securite.models import UtilisateurRole

        ecoles_accessibles = (
            UtilisateurRole.tous_objets.filter(
                utilisateur=request.user,
                est_actif=True,
                role__est_actif=True,
            )
            .filter(
                Q(expire_le__isnull=True)
                | Q(expire_le__gte=timezone.localdate())
            )
            .values_list("ecole_id", flat=True)
        )
        possede_ou_rejoint_ecole = Etablissement.objects.filter(
            Q(cree_par=request.user) | Q(pk__in=ecoles_accessibles)
        ).exists()
        url_creation_espace = reverse(
            "saas:tableau_bord" if possede_ou_rejoint_ecole else "saas:creer_ecole"
        )

    periodicite = request.GET.get(
        "periodicite",
        PeriodiciteFacturation.MENSUELLE,
    )
    if periodicite not in PeriodiciteFacturation.values:
        periodicite = PeriodiciteFacturation.MENSUELLE
    plans = PlanAbonnement.objects.filter(est_actif=True, est_visible_public=True)
    return render(
        request,
        "saas/accueil.html",
        {
            "plans": plans,
            "periodicite": periodicite,
            "url_creation_espace": url_creation_espace,
        },
    )


@login_required
def slug_ecole_disponible(request):
    from apps.etablissements.models import Etablissement

    slug = request.GET.get("slug", "").strip().lower()
    slug = re.sub(r"[^a-z0-9-]+", "-", slug)
    slug = re.sub(r"-+", "-", slug).strip("-")[:80].rstrip("-")
    if not slug:
        return JsonResponse({"slug": "", "disponible": False})

    slug_disponible = slug
    suffixe = 2
    while Etablissement.objects.filter(slug=slug_disponible).exists():
        suffix = f"-{suffixe}"
        slug_disponible = f"{slug[:80 - len(suffix)].rstrip('-')}{suffix}"
        suffixe += 1

    return JsonResponse({
        "slug": slug_disponible,
        "disponible": slug_disponible == slug,
    })


def inscription_saas(request):
    """Création d'un compte propriétaire d'école."""
    from apps.comptes.forms import FormulaireCreationCompte
    from apps.etablissements.models import PlanAbonnement, PeriodiciteFacturation

    if request.method == "GET" and "periodicite" in request.GET:
        periodicite = request.GET["periodicite"]
        if periodicite in PeriodiciteFacturation.values:
            request.session["saas_periodicite_selectionnee"] = periodicite
        else:
            request.session.pop("saas_periodicite_selectionnee", None)

    if request.method == "GET" and "plan" in request.GET:
        plan = PlanAbonnement.objects.filter(
            code=request.GET["plan"],
            est_actif=True,
            est_visible_public=True,
        ).first()
        if plan:
            request.session["saas_plan_selectionne"] = plan.code
        else:
            request.session.pop("saas_plan_selectionne", None)
            messages.error(request, "Cette formule n'est plus disponible.")

    if request.method == "POST":
        form = FormulaireCreationCompte(request.POST)
        if form.is_valid():
            try:
                utilisateur = form.save()
                from django.contrib.auth import login
                login(
                    request,
                    utilisateur,
                    backend="django.contrib.auth.backends.ModelBackend",
                )
                messages.success(
                    request,
                    f"Bienvenue {utilisateur.prenom} ! "
                    "Créez maintenant votre établissement."
                )
                return redirect("saas:creer_ecole")
            except Exception as exc:
                logger.error(f"Erreur création compte : {exc}", exc_info=True)
                messages.error(request, f"Erreur lors de la création du compte : {exc}")
        # Si form invalide, on retombe sur le render avec les erreurs
    else:
        form = FormulaireCreationCompte()
    plan_selectionne = PlanAbonnement.objects.filter(
        code=request.session.get("saas_plan_selectionne"),
        est_actif=True,
        est_visible_public=True,
    ).first()
    periodicite_selectionnee = request.session.get(
        "saas_periodicite_selectionnee",
        PeriodiciteFacturation.MENSUELLE,
    )
    return render(request, "saas/inscription.html", {
        "form": form,
        "plan_selectionne": plan_selectionne,
        "periodicite_selectionnee": periodicite_selectionnee,
    })


@login_required
def creer_ecole(request):
    """
    Création d'un établissement par un propriétaire SaaS.
    Après création : redirige vers le tableau de bord SaaS (fonctionne en local).
    En production : redirige vers le sous-domaine de l'école.
    """
    from apps.etablissements.forms import FormulaireEtablissement
    from apps.etablissements.models import (
        PlanAbonnement,
        PeriodiciteFacturation,
        TypeEtablissement,
    )

    if "periodicite" in request.GET:
        periodicite = request.GET["periodicite"]
        if periodicite in PeriodiciteFacturation.values:
            request.session["saas_periodicite_selectionnee"] = periodicite
        else:
            request.session.pop("saas_periodicite_selectionnee", None)

    plan_code = request.GET.get("plan")
    if plan_code:
        plan = PlanAbonnement.objects.filter(
            code=plan_code,
            est_actif=True,
            est_visible_public=True,
        ).first()
        if plan:
            request.session["saas_plan_selectionne"] = plan.code
        else:
            request.session.pop("saas_plan_selectionne", None)
            messages.error(request, "Cette formule n'est plus disponible.")

    plan_selectionne = PlanAbonnement.objects.filter(
        code=request.session.get("saas_plan_selectionne"),
        est_actif=True,
        est_visible_public=True,
    ).first()

    if request.method == "POST":
        form = FormulaireEtablissement(request.POST, request.FILES)

        if form.is_valid():
            try:
                with transaction.atomic():
                    ecole = form.save(commit=False)
                    ecole.cree_par = request.user
                    ecole.save()

                    if plan_selectionne:
                        _creer_abonnement_en_attente(
                            ecole,
                            request.user,
                            plan_selectionne,
                            request.session.get(
                                "saas_periodicite_selectionnee",
                                PeriodiciteFacturation.MENSUELLE,
                            ),
                        )
                    else:
                        _creer_abonnement_essai(ecole)

                    from apps.etablissements.preconfiguration import preconfigurer_ecole
                    preconfigurer_ecole(ecole)

                    # Initialiser les rôles système et nommer directeur
                    _initialiser_ecole(ecole, request.user)

                detail_configuration = (
                    "Votre établissement démarre sans structure scolaire prédéfinie."
                    if ecole.type_etablissement == TypeEtablissement.INCOMPLET
                    else (
                        "Son profil a été préconfiguré et l’année scolaire proposée "
                        "reste en brouillon. Configurez les classes dans le "
                        "paramétrage avant d’activer l’année."
                    )
                )
                messages.success(
                    request,
                    f"✅ École « {ecole.nom} » créée avec succès ! "
                    f"Slug : {ecole.slug} — "
                    f"{detail_configuration}"
                )
                request.session.pop("saas_plan_selectionne", None)
                request.session.pop("saas_periodicite_selectionnee", None)
                # Redirection vers tableau de bord SaaS (fonctionne partout)
                query = f"?ecole_creee=1"
                if plan_selectionne:
                    query += f"&activation_requise={ecole.slug}"
                return redirect(f"{reverse('saas:tableau_bord')}{query}")

            except Exception as exc:
                logger.error(f"Erreur création école : {exc}", exc_info=True)
                messages.error(
                    request,
                    f"Erreur lors de la création de l'école : {exc}"
                )
        else:
            # Afficher un résumé des erreurs en haut du formulaire
            nb_erreurs = sum(len(v) for v in form.errors.values())
            messages.error(
                request,
                f"Le formulaire contient {nb_erreurs} erreur(s). "
                "Vérifiez les champs en rouge ci-dessous."
            )
    else:
        form = FormulaireEtablissement()

    return render(request, "saas/creer_ecole.html", {
        "form": form,
        "plan_selectionne": plan_selectionne,
        "periodicite_selectionnee": request.session.get(
            "saas_periodicite_selectionnee",
            PeriodiciteFacturation.MENSUELLE,
        ),
    })


@login_required
def tableau_bord_saas(request):
    """Liste les écoles possédées ou accessibles à l'utilisateur."""
    from django.db.models import Count, Q
    from django.utils import timezone
    from apps.academique.models import StatutAnneeScolaire
    from apps.eleves.models import StatutEleve
    from apps.enseignants.models import StatutEnseignant
    from apps.etablissements.models import Abonnement, Etablissement, TypeEtablissement
    from apps.securite.models import UtilisateurRole

    essais_expires = Abonnement.objects.filter(
        etablissement__cree_par=request.user,
        est_actif=True,
        en_periode_essai=True,
        date_fin_essai__isnull=False,
        date_fin_essai__lte=timezone.localdate(),
    ).select_related("etablissement")
    for abonnement in essais_expires:
        abonnement.expirer_essai_si_necessaire()

    roles_utilisateur = (
        UtilisateurRole.tous_objets.filter(
            utilisateur=request.user,
            est_actif=True,
            role__est_actif=True,
        )
        .filter(
            Q(expire_le__isnull=True)
            | Q(expire_le__gte=timezone.localdate())
        )
        .select_related("role")
    )
    ecoles_accessibles = roles_utilisateur.values_list("ecole_id", flat=True)
    base_ecoles = Etablissement.objects.filter(
        Q(cree_par=request.user) | Q(pk__in=ecoles_accessibles)
    ).distinct()
    terme = request.GET.get("recherche", "").strip()
    type_selectionne = request.GET.get("type", "").strip()
    ecoles = base_ecoles
    if terme:
        ecoles = ecoles.filter(
            Q(nom__icontains=terme)
            | Q(nom_court__icontains=terme)
            | Q(slug__icontains=terme)
            | Q(ville__icontains=terme)
        )
    types_valides = {valeur for valeur, _ in TypeEtablissement.choices}
    if type_selectionne in types_valides:
        ecoles = ecoles.filter(type_etablissement=type_selectionne)
    else:
        type_selectionne = ""

    ecoles = list(
        ecoles.annotate(
            nombre_eleves=Count(
                "eleves_eleve_set",
                filter=Q(
                    eleves_eleve_set__statut=StatutEleve.ACTIF,
                    eleves_eleve_set__supprime_le__isnull=True,
                ),
                distinct=True,
            ),
            nombre_enseignants=Count(
                "enseignants_enseignant_set",
                filter=Q(
                    enseignants_enseignant_set__statut=StatutEnseignant.ACTIF,
                    enseignants_enseignant_set__supprime_le__isnull=True,
                ),
                distinct=True,
            ),
            nombre_classes=Count(
                "academique_classe_set",
                filter=Q(
                    academique_classe_set__annee_scolaire__statut=StatutAnneeScolaire.ACTIVE,
                    academique_classe_set__est_actif=True,
                ),
                distinct=True,
            ),
        )
        .select_related("abonnement_actif__plan")
        .prefetch_related("abonnement_actif__demandes_forfait")
        .order_by("-cree_le")
    )
    role_par_ecole = {}
    for attribution in roles_utilisateur.filter(ecole_id__in=[ecole.pk for ecole in ecoles]):
        role_par_ecole.setdefault(attribution.ecole_id, []).append(attribution.role.libelle)
    for ecole in ecoles:
        ecole.est_proprietaire = ecole.cree_par_id == request.user.pk
        ecole.roles_utilisateur_courant = role_par_ecole.get(ecole.pk, [])

    return render(
        request,
        "saas/tableau_bord.html",
        {
            "ecoles": ecoles,
            "nombre_ecoles_total": base_ecoles.count(),
            "nombre_ecoles_resultat": len(ecoles),
            "recherche": terme,
            "type_selectionne": type_selectionne,
            "types_etablissements": TypeEtablissement.choices,
        },
    )




# ── À ajouter dans vues_saas.py ──────────────────────────────────────────────

@login_required
def modifier_ecole(request, slug):
    """Modifier les informations d'un établissement dont on est propriétaire."""
    from apps.etablissements.models import Etablissement
    from apps.etablissements.forms import FormulaireEtablissement

    ecole = get_object_or_404(Etablissement, slug=slug, cree_par=request.user)

    if request.method == "POST":
        form = FormulaireEtablissement(request.POST, request.FILES, instance=ecole)
        if form.is_valid():
            form.save()
            messages.success(request, f"École « {ecole.nom} » mise à jour.")
            return redirect("saas:tableau_bord")
        nb_erreurs = sum(len(v) for v in form.errors.values())
        messages.error(request, f"{nb_erreurs} erreur(s) dans le formulaire.")
    else:
        form = FormulaireEtablissement(instance=ecole)

    return render(request, "saas/modifier_ecole.html", {"form": form, "ecole": ecole})


@login_required
def gerer_abonnement(request, slug):
    """Soumettre une demande de changement de forfait."""
    from apps.etablissements.models import (
        Abonnement,
        DemandeChangementForfait,
        Etablissement,
    )
    from apps.etablissements.forms import FormulaireDemandeForfait

    ecole = get_object_or_404(Etablissement, slug=slug, cree_par=request.user)
    abonnement = get_object_or_404(
        Abonnement.objects.select_related(
            "plan",
            "demande_forfait_en_attente__plan",
        ),
        etablissement=ecole,
    )
    demande_en_attente = abonnement.demande_forfait_en_attente

    if request.method == "POST":
        if demande_en_attente:
            messages.info(
                request,
                "Une demande de changement de forfait est déjà en attente de validation.",
            )
            return redirect("saas:gerer_abonnement", slug=ecole.slug)
        form = FormulaireDemandeForfait(request.POST, abonnement=abonnement)
        if form.is_valid():
            demande = form.save(commit=False)
            demande.abonnement = abonnement
            demande.demandeur = request.user
            with transaction.atomic():
                abonnement_verrouille = (
                    Abonnement.objects.select_for_update()
                    .get(pk=abonnement.pk)
                )
                if abonnement_verrouille.demande_forfait_en_attente_id:
                    messages.info(
                        request,
                        "Une demande de changement de forfait est déjà en attente de validation.",
                    )
                    return redirect("saas:gerer_abonnement", slug=ecole.slug)
                if demande.plan_id == abonnement_verrouille.plan_id:
                    messages.info(
                        request,
                        "Ce forfait est déjà celui de votre établissement.",
                    )
                    return redirect("saas:gerer_abonnement", slug=ecole.slug)
                demande.save()
                abonnement_verrouille.demande_forfait_en_attente = demande
                abonnement_verrouille.save(update_fields=[
                    "demande_forfait_en_attente", "modifie_le",
                ])
            messages.success(
                request,
                "Votre demande est enregistrée. Le forfait actuel reste actif "
                "jusqu'à la vérification du paiement et à l'approbation.",
            )
            return redirect("saas:gerer_abonnement", slug=ecole.slug)
    else:
        form = FormulaireDemandeForfait(abonnement=abonnement)

    return render(request, "saas/abonnement.html", {
        "form": form,
        "ecole": ecole,
        "abonnement": abonnement,
        "demande_en_attente": demande_en_attente,
        "demandes_precedentes": abonnement.demandes_forfait.exclude(
            statut=DemandeChangementForfait.Statut.EN_ATTENTE
        ).select_related("plan", "traitee_par")[:5],
        "plans_disponibles": form.fields["plan"].queryset,
    })
    
# ─── Fonctions internes ───────────────────────────────────────────────────────

def _creer_abonnement_essai(ecole) -> None:
    """
    Crée automatiquement un abonnement d'essai gratuit pour la nouvelle école.
    Utilise le premier plan actif trouvé, ou crée un plan d'essai si aucun n'existe.
    """
    from apps.etablissements.models import PlanAbonnement, Abonnement
    from django.utils import timezone
    import datetime

    # Chercher ou créer un plan d'essai
    plan = PlanAbonnement.objects.filter(
        est_actif=True,
        prix_mensuel_htg=0,
        prix_annuel_htg=0,
    ).order_by("ordre_affichage").first()
    if not plan:
        plan = PlanAbonnement.objects.create(
            code="essai_gratuit",
            libelle="Essai Gratuit",
            prix_mensuel_htg=0,
            prix_annuel_htg=0,
            max_eleves=200,
            max_utilisateurs=10,
            fonctionnalites={
                "bulletins_pdf": True,
                "badges_impression": True,
                "api_acces": False,
                "rapports_avances": False,
                "export_excel": True,
                "sms_notifications": False,
            },
            est_actif=True,
            est_visible_public=True,
            ordre_affichage=0,
        )

    date_fin_essai = timezone.now().date() + datetime.timedelta(days=30)

    Abonnement.objects.create(
        etablissement=ecole,
        plan=plan,
        date_debut=timezone.now().date(),
        est_actif=True,
        en_periode_essai=True,
        date_fin_essai=date_fin_essai,
        renouvellement_auto=False,
    )


def _creer_abonnement_en_attente(
    ecole,
    utilisateur,
    plan,
    periodicite="mensuelle",
) -> None:
    from apps.etablissements.models import (
        Abonnement,
        DemandeChangementForfait,
        PeriodiciteFacturation,
    )
    from django.utils import timezone

    abonnement = Abonnement.objects.create(
        etablissement=ecole,
        plan=plan,
        date_debut=timezone.localdate(),
        periodicite=periodicite,
        est_actif=False,
        en_periode_essai=False,
        renouvellement_auto=False,
    )
    demande = DemandeChangementForfait.objects.create(
        abonnement=abonnement,
        plan=plan,
        periodicite=periodicite,
        demandeur=utilisateur,
    )
    abonnement.demande_forfait_en_attente = demande
    abonnement.save(update_fields=["demande_forfait_en_attente", "modifie_le"])


def _initialiser_ecole(ecole, utilisateur) -> None:
    """
    Crée les rôles système et attribue le rôle Directeur au créateur.
    S'exécute dans le contexte tenant de l'école.
    """
    from apps.noyau.middleware import definir_tenant_courant
    from apps.securite.models import (
        Role, PermissionGranulaire, UtilisateurRole,
        ROLES_SYSTEME, PERMISSIONS_PAR_ROLE
    )

    definir_tenant_courant(ecole)
    try:
        # 1. Créer les permissions dans le catalogue global
        _assurer_permissions_catalogue()

        # 2. Créer les rôles système pour cette école
        for code_role, libelle_role in ROLES_SYSTEME.items():
            role, _ = Role.objects.get_or_create(
                ecole=ecole,
                code=code_role,
                defaults={
                    "libelle": libelle_role,
                    "est_systeme": True,
                    "est_actif": True,
                },
            )
            # Affecter les permissions au rôle
            codes_perms = PERMISSIONS_PAR_ROLE.get(code_role, [])
            perms = PermissionGranulaire.objects.filter(code__in=codes_perms)
            role.permissions.set(perms)

        # 3. Attribuer le rôle Directeur au créateur
        role_directeur = Role.objects.get(ecole=ecole, code="directeur")
        UtilisateurRole.objects.get_or_create(
            ecole=ecole,
            utilisateur=utilisateur,
            role=role_directeur,
            defaults={
                "est_actif": True,
                "attribue_par": utilisateur,
            },
        )

        # 4. Stocker le slug dans la session pour que le tenant soit actif
        #    quand l'utilisateur navigue vers les pages de l'école
        logger.info(
            f"École {ecole.slug} initialisée : "
            f"{len(ROLES_SYSTEME)} rôles système créés."
        )

    finally:
        definir_tenant_courant(None)


def _assurer_permissions_catalogue() -> None:
    """Crée les permissions manquantes dans le catalogue global."""
    from apps.securite.models import PermissionGranulaire, PERMISSIONS_PAR_ROLE

    toutes = set()
    for perms in PERMISSIONS_PAR_ROLE.values():
        toutes.update(perms)

    for code in toutes:
        parties = code.split(".")
        if len(parties) != 3:
            continue
        module, action, portee = parties
        PermissionGranulaire.objects.get_or_create(
            code=code,
            defaults={
                "description": f"{action.title()} — {module.title()} ({portee})",
                "module": module,
                "action": action,
                "portee": portee,
                "est_dangereuse": action in ["cloturer", "archiver", "annuler", "supprimer"],
            },
        )


@login_required
def acceder_ecole(request, slug):
    """
    Vue de switch tenant — fonctionne en local ET en production.
    Stocke le slug dans la session → le middleware le lit automatiquement.
    Redirige ensuite vers le tableau de bord de l'école.
    """
    from django.db.models import Q
    from django.utils import timezone
    from apps.etablissements.models import Abonnement, Etablissement
    from apps.securite.models import UtilisateurRole

    try:
        ecole = Etablissement.objects.get(slug=slug)
    except Etablissement.DoesNotExist:
        messages.error(request, f"L'établissement '{slug}' est introuvable.")
        return redirect("saas:tableau_bord")

    abonnement = Abonnement.objects.filter(etablissement=ecole).first()
    if abonnement:
        abonnement.expirer_essai_si_necessaire()
        ecole.refresh_from_db(fields=["est_actif"])

    if not ecole.est_actif:
        messages.error(
            request,
            f"L'établissement « {ecole.nom} » est désactivé. "
            "Gérez son forfait ou contactez l’administrateur.",
        )
        return redirect("saas:tableau_bord")

    if abonnement and not abonnement.est_actif:
        messages.info(
            request,
            "L'accès à cet établissement sera disponible après la validation de son forfait.",
        )
        return redirect("saas:tableau_bord")

    # Vérifier que l'utilisateur a bien un rôle dans cette école
    a_acces = (
        request.user.is_superuser
        or UtilisateurRole.tous_objets.filter(
            utilisateur=request.user,
            ecole=ecole,
            est_actif=True,
            role__est_actif=True,
        )
        .filter(
            Q(expire_le__isnull=True)
            | Q(expire_le__gte=timezone.localdate())
        )
        .exists()
    )

    if not a_acces:
        messages.error(request, f"Vous n'avez pas accès à l'établissement '{ecole.nom}'.")
        return redirect("saas:tableau_bord")

    # Stocker le slug dans la session → middleware le lira à chaque requête
    request.session["tenant_slug"] = slug
    request.session.modified = True

    return redirect("/tableau-bord/")


@login_required
def quitter_ecole(request):
    """
    Supprime le slug de la session → retour au tableau de bord SaaS.
    Utile pour changer d'école sans se déconnecter.
    """
    request.session.pop("tenant_slug", None)
    request.session.modified = True
    return redirect("saas:tableau_bord")
