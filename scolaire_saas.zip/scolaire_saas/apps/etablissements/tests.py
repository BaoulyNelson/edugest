from datetime import date, timedelta
from decimal import Decimal
from io import BytesIO, StringIO
import tempfile
from unittest.mock import Mock, patch

from django.contrib.admin.sites import AdminSite
from django.contrib.auth.models import Permission
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import RequestFactory, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from PIL import Image

from apps.comptes.models import Utilisateur
from apps.etablissements.admin import AbonnementAdmin, DemandeChangementForfaitAdmin
from apps.etablissements.models import (
    Abonnement,
    ConfigurationSite,
    DemandeChangementForfait,
    Etablissement,
    PlanAbonnement,
    PeriodiciteFacturation,
    TypeEtablissement,
)
from apps.etablissements.forms import (
    FormulaireDemandeForfait,
    FormulaireAbonnement,
    FormulaireEtablissement,
)
from apps.etablissements.views import _creer_abonnement_en_attente
from apps.academique.models import (
    AnneeScolaire,
    Classe,
    PeriodeAcademique,
    StatutAnneeScolaire,
)
from apps.eleves.models import (
    Eleve,
    Inscription,
    Sexe,
    StatutEleve,
    StatutInscription,
)
from apps.finances.models import TypeFrais
from apps.enseignants.models import Enseignant, StatutEnseignant
from apps.securite.models import Role, UtilisateurRole
from apps.parametrage.models import (
    CoefficientsMatiere,
    CycleEnseignement,
    Matiere,
    Niveau,
    OptionPedagogique,
    ReglePassage,
    SystemeNotation,
    TypeDiscipline,
    TypeEvaluation,
)
from apps.etablissements.preconfiguration import preconfigurer_ecole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ModificationEtablissementProprietaireTests(TestCase):
    def setUp(self):
        self.proprietaire = Utilisateur.objects.create_user(
            email="proprietaire-edition@test.ht",
            password="test-password",
            nom="Propriétaire",
            prenom="Test",
        )
        self.autre_utilisateur = Utilisateur.objects.create_user(
            email="autre-edition@test.ht",
            password="test-password",
            nom="Autre",
            prenom="Utilisateur",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-a-modifier",
            nom="École initiale",
            ville="Port-au-Prince",
            cree_par=self.proprietaire,
        )

    def test_proprietaire_peut_afficher_le_formulaire_de_modification(self):
        self.client.force_login(self.proprietaire)

        response = self.client.get(
            reverse("saas:modifier_ecole", args=[self.ecole.slug])
        )

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "saas/modifier_ecole.html")
        self.assertEqual(response.context["ecole"], self.ecole)

        tableau_bord = self.client.get(reverse("saas:tableau_bord"))
        self.assertEqual(tableau_bord.status_code, 200)
        self.assertContains(
            tableau_bord,
            reverse("saas:modifier_ecole", args=[self.ecole.slug]),
        )

    def test_proprietaire_peut_modifier_les_informations_de_son_ecole(self):
        self.client.force_login(self.proprietaire)

        response = self.client.post(
            reverse("saas:modifier_ecole", args=[self.ecole.slug]),
            {
                "slug": self.ecole.slug,
                "nom": "École mise à jour",
                "nom_court": "EMU",
                "type_etablissement": TypeEtablissement.MIXTE,
                "pays": "HTI",
                "departement": "",
                "ville": "Jacmel",
                "adresse": "",
                "code_postal": "",
                "telephone": "",
                "telephone_secondaire": "",
                "email": "",
                "site_web": "",
                "couleur_principale": "#1a3c6e",
                "couleur_secondaire": "#ffffff",
                "devise_etablissement": "",
                "directeur_nom": "",
                "directeur_titre": "Directeur",
                "numero_agrement": "",
                "annee_fondation": "",
                "fuseau_horaire": "America/Port-au-Prince",
                "devise_monetaire": "HTG",
            },
        )

        self.assertRedirects(response, reverse("saas:tableau_bord"))
        self.ecole.refresh_from_db()
        self.assertEqual(self.ecole.nom, "École mise à jour")
        self.assertEqual(self.ecole.ville, "Jacmel")

    def test_un_autre_utilisateur_ne_peut_pas_modifier_lecole(self):
        self.client.force_login(self.autre_utilisateur)

        response = self.client.get(
            reverse("saas:modifier_ecole", args=[self.ecole.slug])
        )

        self.assertEqual(response.status_code, 404)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ChangementForfaitTests(TestCase):
    def setUp(self):
        self.proprietaire = Utilisateur.objects.create_user(
            email="proprietaire@test.ht",
            password="TestPass2026!",
            nom="Test",
            prenom="Propriétaire",
        )
        self.administrateur = Utilisateur.objects.create_user(
            email="admin@test.ht",
            password="TestPass2026!",
            nom="Admin",
            prenom="Scolaire",
            is_staff=True,
        )
        self.plan_actuel = self.creer_plan("ESSAI", "Essai")
        self.plan_demande = self.creer_plan("EQUIPE", "Équipe")
        self.ecole = Etablissement.objects.create(
            slug="ecole-test",
            nom="École de test",
            ville="Port-au-Prince",
            cree_par=self.proprietaire,
        )
        self.abonnement = Abonnement.objects.create(
            etablissement=self.ecole,
            plan=self.plan_actuel,
            date_debut=timezone.localdate(),
            en_periode_essai=True,
            date_fin_essai=timezone.localdate(),
        )
        self.client.force_login(self.proprietaire)

    @staticmethod
    def creer_plan(code, libelle):
        return PlanAbonnement.objects.create(
            code=code,
            libelle=libelle,
            prix_mensuel_htg=Decimal("2500.00"),
            prix_annuel_htg=Decimal("25000.00"),
            max_eleves=500,
            max_utilisateurs=20,
            max_classes=20,
            fonctionnalites={},
            est_actif=True,
            est_visible_public=True,
        )

    def test_proprietaire_peut_soumettre_une_demande_sans_changement_immediat(self):
        page = self.client.get(f"/saas/ecole/{self.ecole.slug}/abonnement/")
        self.assertEqual(page.status_code, 200)
        self.assertTemplateUsed(page, "saas/abonnement.html")

        response = self.client.post(
            f"/saas/ecole/{self.ecole.slug}/abonnement/",
            {
                "plan": str(self.plan_demande.pk),
                "periodicite": PeriodiciteFacturation.ANNUELLE,
            },
        )
        self.client.post(
            f"/saas/ecole/{self.ecole.slug}/abonnement/",
            {
                "plan": str(self.plan_demande.pk),
                "periodicite": PeriodiciteFacturation.ANNUELLE,
            },
        )

        self.assertEqual(response.status_code, 302)
        self.abonnement.refresh_from_db()
        self.assertEqual(self.abonnement.plan, self.plan_actuel)
        self.assertEqual(
            DemandeChangementForfait.objects.filter(
                abonnement=self.abonnement,
                plan=self.plan_demande,
                statut=DemandeChangementForfait.Statut.EN_ATTENTE,
                periodicite=PeriodiciteFacturation.ANNUELLE,
            ).count(),
            1,
        )
        self.assertIsNotNone(self.abonnement.demande_forfait_en_attente_id)

    def test_page_forfait_essai_ne_montre_pas_la_periodicite_ni_tarif_facture(self):
        self.abonnement.date_fin_essai = timezone.localdate() + timedelta(days=30)
        self.abonnement.save(update_fields=["date_fin_essai"])

        response = self.client.get(f"/saas/ecole/{self.ecole.slug}/abonnement/")

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Essai gratuit jusqu’au")
        self.assertNotContains(response, "HTG/mois ·")
        self.assertNotContains(response, "Facturation mensuelle")

    def test_essai_est_desactive_des_que_sa_date_de_fin_est_atteinte(self):
        self.assertTrue(
            self.abonnement.expirer_essai_si_necessaire(
                aujourd_hui=self.abonnement.date_fin_essai,
            )
        )

        self.abonnement.refresh_from_db()
        self.assertFalse(self.abonnement.est_actif)
        self.ecole.refresh_from_db()
        self.assertFalse(self.ecole.est_actif)

    def test_middleware_desactive_et_bloque_un_tenant_a_la_fin_de_lessai(self):
        response = self.client.get(
            "/tableau-bord/",
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 302)
        self.assertIn("activation_requise=ecole-test", response.url)
        self.abonnement.refresh_from_db()
        self.assertFalse(self.abonnement.est_actif)
        self.ecole.refresh_from_db()
        self.assertFalse(self.ecole.est_actif)

    def test_tableau_saas_desactive_et_affiche_lessai_echu(self):
        response = self.client.get("/saas/tableau-bord/")

        self.assertEqual(response.status_code, 200)
        self.abonnement.refresh_from_db()
        self.ecole.refresh_from_db()
        self.assertFalse(self.abonnement.est_actif)
        self.assertFalse(self.ecole.est_actif)
        self.assertContains(response, "Établissement inactif")
        self.assertNotContains(response, f"/saas/acceder/{self.ecole.slug}/")

    def test_action_acceder_desactive_lessai_echu(self):
        response = self.client.get(f"/saas/acceder/{self.ecole.slug}/")

        self.assertRedirects(response, "/saas/tableau-bord/")
        self.abonnement.refresh_from_db()
        self.ecole.refresh_from_db()
        self.assertFalse(self.abonnement.est_actif)
        self.assertFalse(self.ecole.est_actif)

    @patch("apps.etablissements.tasks.timezone.localdate")
    def test_tache_planifiee_desactive_les_essais_arrives_a_echeance(self, localdate):
        localdate.return_value = self.abonnement.date_fin_essai

        from apps.etablissements.tasks import expirer_essais_gratuits

        nombre_expire = expirer_essais_gratuits.run()

        self.assertEqual(nombre_expire, 1)
        self.abonnement.refresh_from_db()
        self.assertFalse(self.abonnement.est_actif)
        self.ecole.refresh_from_db()
        self.assertFalse(self.ecole.est_actif)

    def test_formulaire_admin_essai_masque_les_champs_de_facturation_payante(self):
        formulaire = FormulaireAbonnement(instance=self.abonnement)
        champs = set(formulaire.fields)

        self.assertEqual(formulaire.fields["est_actif"].label, "Abonnement actif")
        self.assertIn("établissement soit actif", formulaire.fields["est_actif"].help_text)
        self.assertIn("date_fin_essai", champs)
        self.assertIn("date_fin", champs)
        self.assertIn("periodicite", champs)
        self.assertIn("renouvellement_auto", champs)

        admin = AbonnementAdmin(Abonnement, AdminSite())
        noms_champs_admin = set(admin.get_fieldsets(None, self.abonnement)[0][1]["fields"])
        self.assertIn("date_fin_essai", noms_champs_admin)
        self.assertNotIn("date_fin", noms_champs_admin)
        self.assertNotIn("periodicite", noms_champs_admin)

    def test_formulaire_admin_paye_masque_le_champ_de_fin_d_essai(self):
        self.abonnement.en_periode_essai = False
        self.abonnement.date_fin = timezone.localdate() + timedelta(days=30)
        self.abonnement.save(update_fields=["en_periode_essai", "date_fin"])

        formulaire = FormulaireAbonnement(instance=self.abonnement)
        champs = set(formulaire.fields)

        self.assertIn("date_fin", champs)
        self.assertIn("periodicite", champs)
        self.assertIn("renouvellement_auto", champs)
        self.assertIn("date_fin_essai", champs)

    def test_sauvegarder_un_essai_conserve_les_dates_sans_les_effacer(self):
        self.abonnement.date_fin = timezone.localdate() + timedelta(days=30)
        self.abonnement.save(update_fields=["date_fin"])
        date_fin_paye = self.abonnement.date_fin
        date_fin_essai = self.abonnement.date_debut + timedelta(days=30)
        self.abonnement.date_fin_essai = date_fin_essai
        self.abonnement.save(update_fields=["date_fin_essai"])
        formulaire = FormulaireAbonnement(
            {
                "plan": str(self.plan_actuel.pk),
                "date_debut": self.abonnement.date_debut.isoformat(),
                "periodicite": PeriodiciteFacturation.MENSUELLE,
                "date_fin": date_fin_paye.isoformat(),
                "en_periode_essai": "on",
                "date_fin_essai": date_fin_essai.isoformat(),
                "est_actif": "on",
                "notes_internes": "",
            },
            instance=self.abonnement,
        )

        self.assertTrue(formulaire.is_valid(), formulaire.errors)
        abonnement = formulaire.save()
        self.assertEqual(abonnement.date_fin, date_fin_paye)
        self.assertEqual(abonnement.date_fin_essai, date_fin_essai)

    def test_admin_conserve_et_reaffiche_les_dates_apres_sauvegarde(self):
        self.administrateur.is_superuser = True
        self.administrateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.administrateur)
        url = reverse("admin:etablissements_abonnement_change", args=[self.abonnement.pk])
        date_debut = self.abonnement.date_debut
        nouvelle_fin_essai = date_debut + timedelta(days=30)

        response = self.client.post(
            url,
            {
                "etablissement": str(self.ecole.pk),
                "plan": str(self.plan_actuel.pk),
                "date_debut": date_debut.isoformat(),
                "en_periode_essai": "on",
                "date_fin_essai": nouvelle_fin_essai.isoformat(),
                "est_actif": "on",
                "souscrit_par": "",
                "notes_internes": "",
                "_save": "Enregistrer",
            },
        )

        self.assertEqual(response.status_code, 302)
        self.abonnement.refresh_from_db()
        self.assertEqual(self.abonnement.date_debut, date_debut)
        self.assertEqual(self.abonnement.date_fin_essai, nouvelle_fin_essai)

        fiche = self.client.get(url)
        self.assertEqual(fiche.status_code, 200)
        self.assertContains(fiche, f'value="{date_debut.isoformat()}"')
        self.assertContains(fiche, f'value="{nouvelle_fin_essai.isoformat()}"')

    def test_administrateur_approuve_apres_verification_et_met_a_jour_le_forfait(self):
        demande = DemandeChangementForfait.objects.create(
            abonnement=self.abonnement,
            plan=self.plan_demande,
            periodicite=PeriodiciteFacturation.ANNUELLE,
            demandeur=self.proprietaire,
        )
        self.abonnement.est_actif = False
        self.abonnement.demande_forfait_en_attente = demande
        self.abonnement.save(update_fields=["est_actif", "demande_forfait_en_attente"])
        request = RequestFactory().post("/admin/")
        request.user = self.administrateur
        request._messages = Mock()
        admin = DemandeChangementForfaitAdmin(
            DemandeChangementForfait,
            AdminSite(),
        )

        admin.approuver_apres_verification(
            request,
            DemandeChangementForfait.objects.filter(pk=demande.pk),
        )

        self.abonnement.refresh_from_db()
        demande.refresh_from_db()
        self.assertEqual(self.abonnement.plan, self.plan_demande)
        self.assertTrue(self.abonnement.est_actif)
        self.assertEqual(self.abonnement.periodicite, PeriodiciteFacturation.ANNUELLE)
        self.assertFalse(self.abonnement.en_periode_essai)
        self.assertIsNone(self.abonnement.date_fin_essai)
        self.assertGreater(self.abonnement.date_fin, self.abonnement.date_debut)
        self.assertEqual(demande.statut, DemandeChangementForfait.Statut.APPROUVEE)
        self.assertEqual(demande.traitee_par, self.administrateur)
        self.assertIsNone(self.abonnement.demande_forfait_en_attente_id)

    def test_selection_sur_tarifs_cree_un_abonnement_inactif_jusqua_approbation(self):
        nouvelle_ecole = Etablissement.objects.create(
            slug="nouvelle-ecole",
            nom="Nouvelle école",
            ville="Jacmel",
            cree_par=self.proprietaire,
        )

        _creer_abonnement_en_attente(
            nouvelle_ecole,
            self.proprietaire,
            self.plan_demande,
        )

        nouvel_abonnement = Abonnement.objects.get(etablissement=nouvelle_ecole)
        self.assertEqual(nouvel_abonnement.plan, self.plan_demande)
        self.assertFalse(nouvel_abonnement.est_actif)
        self.assertFalse(nouvel_abonnement.en_periode_essai)
        self.assertEqual(
            nouvel_abonnement.demande_forfait_en_attente.plan,
            self.plan_demande,
        )

    def test_selection_du_tarif_est_conservee_pendant_inscription_et_creation(self):
        response = self.client.get(
            f"/saas/inscription/?plan={self.plan_demande.code}&periodicite=annuelle"
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'src="/static/images/logo.png"')
        self.assertEqual(
            self.client.session["saas_plan_selectionne"],
            self.plan_demande.code,
        )
        self.assertEqual(
            self.client.session["saas_periodicite_selectionnee"],
            PeriodiciteFacturation.ANNUELLE,
        )
        creation = self.client.get("/saas/creer-ecole/")

        self.assertEqual(creation.status_code, 200)
        self.assertContains(creation, 'src="/static/images/logo.png"')
        self.assertEqual(
            creation.context["periodicite_selectionnee"],
            PeriodiciteFacturation.ANNUELLE,
        )
        self.assertEqual(
            creation.context["plan_selectionne"],
            self.plan_demande,
        )
        self.assertContains(creation, "HTG/an")

    def test_ecran_inscription_affiche_le_prix_annuel_du_plan_choisi(self):
        response = self.client.get(
            f"/saas/inscription/?plan={self.plan_demande.code}&periodicite=annuelle"
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["periodicite_selectionnee"],
            PeriodiciteFacturation.ANNUELLE,
        )
        self.assertEqual(
            response.context["plan_selectionne"].prix_annuel_htg,
            Decimal("25000.00"),
        )
        self.assertContains(response, "HTG/an")
        self.assertNotContains(response, "HTG/mois")

    def test_page_publique_affiche_un_seul_rythme_de_facturation(self):
        self.client.logout()
        response = self.client.get("/saas/?periodicite=annuelle")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["periodicite"], PeriodiciteFacturation.ANNUELLE)
        self.assertContains(response, ">25000<")
        self.assertContains(response, "HTG <small>/ an</small>")
        self.assertContains(
            response,
            f"/saas/inscription/?plan={self.plan_actuel.code}&amp;periodicite=annuelle",
        )
        self.assertNotContains(response, ">2500<")

        response_mensuelle = self.client.get("/saas/?periodicite=mensuelle")
        self.assertContains(response_mensuelle, "HTG <small>/ mois</small>")
        self.assertNotContains(response_mensuelle, "HTG <small>/ an</small>")

    def test_periodicite_annuelle_est_transmise_a_la_demande_d_abonnement(self):
        ecole = Etablissement.objects.create(
            slug="ecole-annuelle",
            nom="École annuelle",
            ville="Jacmel",
            cree_par=self.proprietaire,
        )

        _creer_abonnement_en_attente(
            ecole,
            self.proprietaire,
            self.plan_demande,
            PeriodiciteFacturation.ANNUELLE,
        )

        abonnement = Abonnement.objects.get(etablissement=ecole)
        self.assertEqual(abonnement.periodicite, PeriodiciteFacturation.ANNUELLE)
        self.assertEqual(
            abonnement.demande_forfait_en_attente.periodicite,
            PeriodiciteFacturation.ANNUELLE,
        )

    def test_csv_cree_et_met_a_jour_les_plans_de_maniere_idempotente(self):
        sortie = StringIO()

        call_command("importer_plans_abonnement", stdout=sortie)
        call_command("importer_plans_abonnement", stdout=StringIO())

        self.assertEqual(
            set(
                PlanAbonnement.objects.filter(
                    code__in=[
                        "BASIQUE",
                        "PRO",
                        "ENTREPRISE",
                        "ESSAI_GRATUIT",
                    ]
                ).values_list("code", flat=True)
            ),
            {"BASIQUE", "PRO", "ENTREPRISE", "ESSAI_GRATUIT"},
        )
        self.assertEqual(
            PlanAbonnement.objects.get(code="PRO").prix_annuel_htg,
            Decimal("50000.00"),
        )
        plan_gratuit = PlanAbonnement.objects.get(code="ESSAI_GRATUIT")
        self.assertEqual(plan_gratuit.prix_mensuel_htg, Decimal("0.00"))
        self.assertEqual(plan_gratuit.prix_annuel_htg, Decimal("0.00"))
        self.assertEqual(plan_gratuit.max_eleves, 200)
        self.assertEqual(plan_gratuit.max_utilisateurs, 10)
        self.assertTrue(plan_gratuit.est_visible_public)
        self.assertIn("4 plan(s) créé(s)", sortie.getvalue())

    def test_espace_ecole_est_bloque_tant_que_le_forfait_est_inactif(self):
        self.abonnement.est_actif = False
        self.abonnement.save(update_fields=["est_actif"])
        session = self.client.session
        session["tenant_slug"] = self.ecole.slug
        session.save()

        response = self.client.get("/tableau-bord/")

        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            response["Location"],
            f"/saas/tableau-bord/?activation_requise={self.ecole.slug}",
        )

    def test_proprietaire_ne_peut_pas_gerer_le_forfait_dune_autre_ecole(self):
        autre_ecole = Etablissement.objects.create(
            slug="autre-ecole",
            nom="Autre école",
            ville="Cap-Haïtien",
        )

        response = self.client.get(f"/saas/ecole/{autre_ecole.slug}/abonnement/")

        self.assertEqual(response.status_code, 404)

    def test_refus_admin_libere_la_demande_en_attente_sans_modifier_le_plan(self):
        self.abonnement.plan = self.plan_demande
        self.abonnement.est_actif = False
        self.abonnement.save(update_fields=["plan", "est_actif"])
        demande = DemandeChangementForfait.objects.create(
            abonnement=self.abonnement,
            plan=self.plan_demande,
            demandeur=self.proprietaire,
        )
        self.abonnement.demande_forfait_en_attente = demande
        self.abonnement.save(update_fields=["demande_forfait_en_attente"])
        request = RequestFactory().post("/admin/")
        request.user = self.administrateur
        request._messages = Mock()
        admin = DemandeChangementForfaitAdmin(
            DemandeChangementForfait,
            AdminSite(),
        )

        admin.refuser_demande(
            request,
            DemandeChangementForfait.objects.filter(pk=demande.pk),
        )

        self.abonnement.refresh_from_db()
        demande.refresh_from_db()
        self.assertEqual(self.abonnement.plan, self.plan_demande)
        self.assertIsNone(self.abonnement.demande_forfait_en_attente_id)
        self.assertEqual(demande.statut, DemandeChangementForfait.Statut.REFUSEE)
        self.assertTrue(
            FormulaireDemandeForfait(
                abonnement=self.abonnement,
            ).fields["plan"].queryset.filter(pk=self.plan_demande.pk).exists()
        )


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class SlugEtablissementTests(TestCase):
    def setUp(self):
        self.proprietaire = Utilisateur.objects.create_user(
            email="slug@test.ht",
            password="TestPass2026!",
            nom="Test",
            prenom="Slug",
        )
        self.client.force_login(self.proprietaire)
        self.ecole_existante = Etablissement.objects.create(
            slug="ecole-test",
            nom="École test",
            ville="Port-au-Prince",
        )

    def test_endpoint_propose_un_suffixe_numerique_pour_un_slug_pris(self):
        response = self.client.get(
            "/saas/slug-ecole-disponible/",
            {"slug": "ecole-test"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            "slug": "ecole-test-2",
            "disponible": False,
        })

    def test_formulaire_attribue_le_prochain_suffixe_si_un_slug_est_deja_pris(self):
        Etablissement.objects.create(
            slug="ecole-test-2",
            nom="Autre école test",
            ville="Jacmel",
        )
        form = FormulaireEtablissement()
        form.cleaned_data = {"slug": "ecole-test"}

        self.assertEqual(form.clean_slug(), "ecole-test-3")

    def test_formulaire_de_modification_garde_le_slug_de_son_ecole(self):
        form = FormulaireEtablissement(instance=self.ecole_existante)
        form.cleaned_data = {"slug": self.ecole_existante.slug}

        self.assertEqual(form.clean_slug(), "ecole-test")


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ImportPlanAdminTests(TestCase):
    def setUp(self):
        self.superuser = Utilisateur.objects.create_superuser(
            email="superuser-plans@example.com",
            password="test-password",
            nom="Super",
            prenom="User",
        )
        self.staff = Utilisateur.objects.create_user(
            email="staff-plans@example.com",
            password="test-password",
            nom="Staff",
            prenom="User",
            is_staff=True,
        )
        self.staff.user_permissions.add(
            Permission.objects.get(
                codename="view_planabonnement",
                content_type__app_label="etablissements",
            )
        )
        self.url = "/django-admin/etablissements/planabonnement/importer-csv/"

    def test_import_est_refuse_aux_staff_non_superusers(self):
        self.client.force_login(self.staff)

        liste = self.client.get("/django-admin/etablissements/planabonnement/")
        self.assertEqual(liste.status_code, 200)
        self.assertNotContains(liste, "Importer CSV")

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 403)

    def test_superuser_voit_le_lien_et_peut_importer_un_plan(self):
        self.client.force_login(self.superuser)

        liste = self.client.get("/django-admin/etablissements/planabonnement/")
        self.assertContains(liste, "Importer CSV")

        contenu = (
            "code;libelle;description;prix_mensuel_htg;prix_annuel_htg;"
            "max_eleves;max_utilisateurs;max_classes;stockage_go;fonctionnalites;"
            "est_actif;est_visible_public;ordre_affichage\n"
            "TEST;Plan test;;100;1000;50;10;5;2;{};true;true;1\n"
        )
        response = self.client.post(
            self.url,
            {
                "fichier_csv": SimpleUploadedFile(
                    "plans.csv",
                    contenu.encode("utf-8"),
                    content_type="text/csv",
                )
            },
        )

        self.assertEqual(response.status_code, 302)
        plan = PlanAbonnement.objects.get(code="TEST")
        self.assertEqual(plan.prix_annuel_htg, Decimal("1000"))


class PreconfigurationEcoleTests(TestCase):
    def setUp(self):
        self.proprietaire = Utilisateur.objects.create_user(
            email="preconfiguration@test.ht",
            password="test-password-123",
            nom="Propriétaire",
            prenom="Test",
        )

    def creer_ecole(self, type_etablissement, slug):
        return Etablissement.objects.create(
            slug=slug,
            nom=f"École {slug}",
            ville="Port-au-Prince",
            cree_par=self.proprietaire,
            type_etablissement=type_etablissement,
        )

    def test_primaire_recoit_son_profil_et_une_annee_brouillon_sans_classes(self):
        ecole = self.creer_ecole(TypeEtablissement.PRIMAIRE, "primaire-seed")

        preconfigurer_ecole(ecole)

        self.assertEqual(
            set(CycleEnseignement.tous_objets.filter(ecole=ecole).values_list("code", flat=True)),
            {"PRESCO", "FOND1", "FOND2"},
        )
        self.assertEqual(
            set(Niveau.tous_objets.filter(ecole=ecole).values_list("code", flat=True)),
            {"PRE1", "PRE2", "PRE3", "1AF", "2AF", "3AF", "4AF", "5AF", "6AF"},
        )
        self.assertEqual(
            set(Matiere.tous_objets.filter(ecole=ecole).values_list("code", flat=True)),
            {"KREYOL", "FRANCAIS", "MATH", "SCIENCES", "SOCIAUX"},
        )
        annee = AnneeScolaire.tous_objets.get(ecole=ecole)
        self.assertEqual(annee.statut, StatutAnneeScolaire.BROUILLON)
        self.assertFalse(annee.est_courante)
        self.assertEqual(annee.periodes.count(), 4)
        self.assertFalse(Classe.tous_objets.filter(ecole=ecole).exists())
        self.assertTrue(
            TypeFrais.tous_objets.filter(ecole=ecole, code="FOURNITURES").exists()
        )
        self.assertTrue(
            TypeFrais.tous_objets.filter(ecole=ecole, code="CANTINE").exists()
        )

    def test_secondaire_recoit_son_profil_personnalise(self):
        ecole = self.creer_ecole(TypeEtablissement.SECONDAIRE, "secondaire-seed")

        preconfigurer_ecole(ecole)

        self.assertEqual(
            set(CycleEnseignement.tous_objets.filter(ecole=ecole).values_list("code", flat=True)),
            {"SEC"},
        )
        self.assertEqual(
            set(Niveau.tous_objets.filter(ecole=ecole).values_list("code", flat=True)),
            {"NS1", "NS2", "NS3", "NS4"},
        )
        self.assertTrue(Matiere.tous_objets.filter(ecole=ecole, code="PHYS").exists())
        self.assertEqual(AnneeScolaire.tous_objets.filter(ecole=ecole).get().type_decoupage, "quadrimestriel")
        self.assertFalse(Classe.tous_objets.filter(ecole=ecole).exists())

    @patch(
        "apps.etablissements.preconfiguration.timezone.localdate",
        return_value=date(2028, 10, 15),
    )
    def test_profil_recalcule_les_dates_du_modele_pour_la_rentree_proposee(self, _):
        ecole = self.creer_ecole(
            TypeEtablissement.SECONDAIRE, "secondaire-dates-dynamiques"
        )

        preconfigurer_ecole(ecole)

        annee = AnneeScolaire.tous_objets.get(ecole=ecole)
        premiere_periode = PeriodeAcademique.tous_objets.get(
            ecole=ecole,
            annee_scolaire=annee,
            numero=1,
        )
        self.assertEqual(annee.libelle, "2028-2029")
        self.assertEqual(annee.date_debut, date(2028, 9, 1))
        self.assertEqual(annee.date_fin, date(2029, 6, 30))
        self.assertEqual(premiere_periode.date_debut, date(2028, 9, 1))
        self.assertIn("2028-2029", premiere_periode.libelle)

    def test_mixte_recoit_son_profil_de_niveaux_sans_classes(self):
        ecole = self.creer_ecole(TypeEtablissement.MIXTE, "mixte-seed")

        preconfigurer_ecole(ecole)

        self.assertEqual(Niveau.tous_objets.filter(ecole=ecole).count(), 13)
        self.assertTrue(Niveau.tous_objets.filter(ecole=ecole, code="1AF").exists())
        self.assertTrue(Niveau.tous_objets.filter(ecole=ecole, code="9AF").exists())
        self.assertFalse(Classe.tous_objets.filter(ecole=ecole).exists())

    def test_technique_recoit_options_et_niveaux_de_son_profil_sans_classes(self):
        ecole = self.creer_ecole(TypeEtablissement.TECHNIQUE, "technique-seed")

        preconfigurer_ecole(ecole)

        self.assertEqual(Niveau.tous_objets.filter(ecole=ecole).count(), 3)
        self.assertEqual(OptionPedagogique.tous_objets.filter(ecole=ecole).count(), 15)
        self.assertFalse(Classe.tous_objets.filter(ecole=ecole).exists())

    def test_universite_recoit_cycles_niveaux_et_semestres_sans_fausses_facultes(self):
        ecole = self.creer_ecole(
            TypeEtablissement.UNIVERSITE, "universite-seed"
        )

        preconfigurer_ecole(ecole)

        self.assertEqual(
            set(CycleEnseignement.tous_objets.filter(ecole=ecole).values_list("code", flat=True)),
            {"LICENCE", "MASTER", "DOCTORAT"},
        )
        self.assertEqual(Niveau.tous_objets.filter(ecole=ecole).count(), 9)
        annee = AnneeScolaire.tous_objets.get(ecole=ecole)
        self.assertEqual(annee.type_decoupage, "semestriel")
        self.assertEqual(annee.periodes.count(), 2)
        self.assertFalse(Classe.tous_objets.filter(ecole=ecole).exists())
        self.assertFalse(Matiere.tous_objets.filter(ecole=ecole).exists())
        self.assertTrue(
            TypeFrais.tous_objets.filter(ecole=ecole, code="LABORATOIRE").exists()
        )
        self.assertEqual(
            TypeFrais.tous_objets.get(ecole=ecole, code="SCOLARITE").frequence,
            "semestriel",
        )
        self.assertEqual(TypeEvaluation.tous_objets.filter(ecole=ecole).count(), 5)
        self.assertEqual(TypeDiscipline.tous_objets.filter(ecole=ecole).count(), 8)
        self.assertTrue(SystemeNotation.tous_objets.filter(ecole=ecole).exists())

    def test_etablissement_incomplet_ne_recoit_pas_de_structure_scolaire(self):
        ecole = self.creer_ecole(
            TypeEtablissement.INCOMPLET, "incomplet-seed"
        )

        preconfigurer_ecole(ecole)

        self.assertFalse(CycleEnseignement.tous_objets.filter(ecole=ecole).exists())
        self.assertFalse(Niveau.tous_objets.filter(ecole=ecole).exists())
        self.assertFalse(Matiere.tous_objets.filter(ecole=ecole).exists())
        self.assertFalse(AnneeScolaire.tous_objets.filter(ecole=ecole).exists())
        self.assertEqual(TypeEvaluation.tous_objets.filter(ecole=ecole).count(), 5)
        self.assertEqual(TypeDiscipline.tous_objets.filter(ecole=ecole).count(), 8)
        self.assertTrue(SystemeNotation.tous_objets.filter(ecole=ecole).exists())

    def test_preconfiguration_est_idempotente_et_ne_remplace_pas_les_donnees(self):
        ecole = self.creer_ecole(TypeEtablissement.PRIMAIRE, "idempotent-seed")

        preconfigurer_ecole(ecole)
        matiere = Matiere.tous_objets.get(ecole=ecole, code="MATH")
        matiere.libelle = "Mathématiques personnalisées"
        matiere.save(update_fields=["libelle"])
        preconfigurer_ecole(ecole)

        self.assertEqual(
            Matiere.tous_objets.filter(ecole=ecole, code="MATH").count(),
            1,
        )
        matiere.refresh_from_db()
        self.assertEqual(matiere.libelle, "Mathématiques personnalisées")
        self.assertEqual(TypeDiscipline.tous_objets.filter(ecole=ecole).count(), 8)

    def test_creation_dans_l_interface_applique_la_preconfiguration(self):
        self.client.force_login(self.proprietaire)
        donnees = {
            "slug": "nouvelle-primaire",
            "nom": "Nouvelle école primaire",
            "type_etablissement": TypeEtablissement.PRIMAIRE,
            "pays": "HTI",
            "ville": "Port-au-Prince",
            "couleur_principale": "#1a3c6e",
            "couleur_secondaire": "#ffffff",
            "directeur_titre": "Directeur",
            "fuseau_horaire": "America/Port-au-Prince",
            "devise_monetaire": "HTG",
        }

        with (
            patch("apps.etablissements.views._creer_abonnement_essai"),
            patch("apps.etablissements.views._initialiser_ecole"),
        ):
            response = self.client.post(reverse("saas:creer_ecole"), donnees)

        self.assertEqual(response.status_code, 302)
        ecole = Etablissement.objects.get(slug="nouvelle-primaire")
        self.assertEqual(Niveau.tous_objets.filter(ecole=ecole).count(), 9)
        self.assertEqual(Matiere.tous_objets.filter(ecole=ecole).count(), 5)
        annee = AnneeScolaire.tous_objets.get(ecole=ecole)
        self.assertEqual(annee.statut, StatutAnneeScolaire.BROUILLON)
        self.assertEqual(annee.periodes.count(), 4)
        self.assertFalse(Classe.tous_objets.filter(ecole=ecole).exists())
        self.assertEqual(PeriodeAcademique.tous_objets.filter(ecole=ecole).count(), 4)
        self.assertEqual(CoefficientsMatiere.tous_objets.filter(ecole=ecole).count(), 30)
        self.assertFalse(ReglePassage.tous_objets.filter(ecole=ecole).exists())


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class TableauBordSaasTests(TestCase):
    def setUp(self):
        self.proprietaire = Utilisateur.objects.create_user(
            email="tableau-bord@test.ht",
            password="tableau-bord-test-password",
            nom="Directeur",
            prenom="Test",
        )
        self.client.force_login(self.proprietaire)
        self.ecole = Etablissement.objects.create(
            slug="ecole-tableau-bord",
            nom="École du Tableau de Bord",
            ville="Port-au-Prince",
            type_etablissement=TypeEtablissement.PRIMAIRE,
            cree_par=self.proprietaire,
        )
        Etablissement.objects.create(
            slug="universite-tableau-bord",
            nom="Université du Tableau de Bord",
            ville="Cap-Haïtien",
            type_etablissement=TypeEtablissement.UNIVERSITE,
            cree_par=self.proprietaire,
        )

    def test_accueil_dirige_un_visiteur_vers_inscription(self):
        self.client.logout()

        response = self.client.get(reverse("saas:accueil"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["url_creation_espace"],
            reverse("saas:inscription"),
        )
        self.assertContains(
            response,
            f'href="{reverse("saas:inscription")}"',
        )

    def test_superuser_configure_le_nom_logo_et_coordonnees_du_site(self):
        administrateur = Utilisateur.objects.create_superuser(
            email="configuration-site@test.ht",
            password="MotDePasseValide!2026",
            nom="Admin",
            prenom="Site",
        )
        self.client.force_login(administrateur)
        logo = BytesIO()
        Image.new("RGB", (2, 2), color="blue").save(logo, format="PNG")

        with tempfile.TemporaryDirectory() as media_root:
            with override_settings(MEDIA_ROOT=media_root):
                response = self.client.post(
                    reverse("saas:configuration"),
                    {
                        "nom_site": "Portail Éducatif",
                        "slogan": "La réussite, ensemble",
                        "logo": SimpleUploadedFile(
                            "logo.png",
                            logo.getvalue(),
                            content_type="image/png",
                        ),
                        "email_contact": "aide@portail.example",
                        "telephone_contact": "+509 1234-5678",
                        "adresse": "Port-au-Prince, Haïti",
                        "site_web": "https://portail.example",
                    },
                )

                self.assertRedirects(response, reverse("saas:configuration"))
                configuration = ConfigurationSite.objects.get(pk=1)
                self.assertEqual(configuration.nom_site, "Portail Éducatif")
                self.assertEqual(
                    configuration.email_contact,
                    "aide@portail.example",
                )
                self.assertTrue(configuration.logo)

                accueil = self.client.get(reverse("saas:accueil"))
                self.assertContains(accueil, "Portail Éducatif")
                self.assertContains(accueil, configuration.logo.url)
                self.assertContains(accueil, "mailto:aide@portail.example")
                self.assertContains(accueil, "+509 1234-5678")
                self.assertContains(accueil, "https://portail.example")

    def test_configuration_du_site_est_reservee_au_superuser(self):
        self.client.force_login(self.proprietaire)

        response = self.client.get(reverse("saas:configuration"))

        self.assertEqual(response.status_code, 403)

    def test_superuser_peut_modifier_la_configuration_du_site_dans_admin_django(self):
        administrateur = Utilisateur.objects.create_superuser(
            email="configuration-admin@test.ht",
            password="MotDePasseValide!2026",
            nom="Admin",
            prenom="Site",
        )
        configuration = ConfigurationSite.objects.create(
            nom_site="Nom avant modification",
        )
        self.client.force_login(administrateur)

        response = self.client.get(
            reverse(
                "admin:etablissements_configurationsite_change",
                args=[configuration.pk],
            )
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Nom avant modification")
        self.assertNotContains(
            response,
            reverse("admin:etablissements_configurationsite_add"),
        )

    def test_accueil_dirige_un_utilisateur_sans_ecole_vers_creation_ecole(self):
        nouvel_utilisateur = Utilisateur.objects.create_user(
            email="sans-ecole-accueil@test.ht",
            password="TestPassword-2026!",
            nom="Nouvel",
            prenom="Utilisateur",
        )
        self.client.force_login(nouvel_utilisateur)

        response = self.client.get(reverse("saas:accueil"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["url_creation_espace"],
            reverse("saas:creer_ecole"),
        )
        self.assertContains(
            response,
            f'href="{reverse("saas:creer_ecole")}"',
        )

    def test_accueil_dirige_un_utilisateur_ayant_deja_une_ecole_vers_ses_ecoles(self):
        response = self.client.get(reverse("saas:accueil"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["url_creation_espace"],
            reverse("saas:tableau_bord"),
        )
        self.assertContains(
            response,
            f'href="{reverse("saas:tableau_bord")}"',
        )

    def test_accueil_dirige_un_membre_dune_ecole_rejointe_vers_ses_ecoles(self):
        membre = Utilisateur.objects.create_user(
            email="membre-accueil@test.ht",
            password="TestPassword-2026!",
            nom="Membre",
            prenom="Invité",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="secretaire-accueil",
            libelle="Secrétaire",
        )
        UtilisateurRole.tous_objets.create(
            ecole=self.ecole,
            utilisateur=membre,
            role=role,
        )
        self.client.force_login(membre)

        response = self.client.get(reverse("saas:accueil"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["url_creation_espace"],
            reverse("saas:tableau_bord"),
        )

    def test_tableau_bord_inclut_ecoles_rejointes_sans_donner_les_actions_proprietaire(self):
        membre = Utilisateur.objects.create_user(
            email="membre-tableau-bord@test.ht",
            password="MotDePasseSolide!2468",
            nom="Membre",
            prenom="Invité",
        )
        ecole_rejointe = Etablissement.objects.create(
            slug="ecole-rejointe-tableau-bord",
            nom="École rejointe",
            ville="Jacmel",
            cree_par=self.proprietaire,
        )
        autre_ecole = Etablissement.objects.create(
            slug="ecole-sans-lien-tableau-bord",
            nom="École sans lien",
            ville="Les Cayes",
        )
        role = Role.objects.create(
            ecole=ecole_rejointe,
            code="secretaire",
            libelle="Secrétaire",
        )
        UtilisateurRole.tous_objets.create(
            ecole=ecole_rejointe,
            utilisateur=membre,
            role=role,
        )
        self.client.force_login(membre)

        response = self.client.get(reverse("saas:tableau_bord"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(
            response,
            'src="/static/images/logo.png" alt=""',
        )
        ecoles = list(response.context["ecoles"])
        self.assertEqual(
            {ecole.slug for ecole in ecoles},
            {ecole_rejointe.slug},
        )
        ecole_vue = ecoles[0]
        self.assertFalse(ecole_vue.est_proprietaire)
        self.assertEqual(ecole_vue.roles_utilisateur_courant, ["Secrétaire"])
        self.assertContains(response, "École rejointe")
        self.assertContains(response, "Secrétaire")
        self.assertNotContains(
            response,
            reverse("saas:modifier_ecole", kwargs={"slug": ecole_rejointe.slug}),
        )
        self.assertNotContains(
            response,
            reverse("saas:gerer_abonnement", kwargs={"slug": ecole_rejointe.slug}),
        )
        self.assertNotContains(response, autre_ecole.slug)

        response = self.client.get(
            reverse("saas:acceder_ecole", kwargs={"slug": ecole_rejointe.slug})
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.session["tenant_slug"], ecole_rejointe.slug)

    def test_tableau_bord_exclut_les_roles_expires_ou_desactives(self):
        membre = Utilisateur.objects.create_user(
            email="membre-inactif-tableau-bord@test.ht",
            password="MotDePasseSolide!2468",
            nom="Membre",
            prenom="Inactif",
        )
        ecole_rejointe = Etablissement.objects.create(
            slug="ecole-role-expire-tableau-bord",
            nom="École avec rôle expiré",
            ville="Jacmel",
            cree_par=self.proprietaire,
        )
        role = Role.objects.create(
            ecole=ecole_rejointe,
            code="ancien-role",
            libelle="Ancien rôle",
        )
        UtilisateurRole.tous_objets.create(
            ecole=ecole_rejointe,
            utilisateur=membre,
            role=role,
            expire_le=timezone.localdate() - timedelta(days=1),
        )
        self.client.force_login(membre)

        response = self.client.get(reverse("saas:tableau_bord"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["nombre_ecoles_total"], 0)
        response = self.client.get(
            reverse("saas:acceder_ecole", kwargs={"slug": ecole_rejointe.slug})
        )
        self.assertRedirects(response, reverse("saas:tableau_bord"))

    def test_filtre_et_affiche_les_effectifs_actuels(self):
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 7),
            date_fin=date(2027, 7, 2),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="1AF",
            libelle="1re année fondamentale",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="1AF-A",
            libelle="1re AF — A",
        )
        eleve = Eleve.objects.create(
            ecole=self.ecole,
            nom="Élève",
            prenom="Premier",
            date_naissance=date(2015, 5, 1),
            sexe=Sexe.MASCULIN,
        )
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=eleve,
            annee_scolaire=annee,
            classe=classe,
            date_inscription=date(2026, 9, 7),
            statut=StatutInscription.VALIDEE,
        )
        Enseignant.objects.create(
            ecole=self.ecole,
            nom="Enseignant",
            prenom="Actif",
            sexe="F",
            statut=StatutEnseignant.ACTIF,
        )

        response = self.client.get(
            reverse("saas:tableau_bord"),
            {"recherche": "Port-au-Prince", "type": TypeEtablissement.PRIMAIRE},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["nombre_ecoles_total"], 2)
        self.assertEqual(response.context["nombre_ecoles_resultat"], 1)
        ecole_affichee = response.context["ecoles"][0]
        self.assertEqual(ecole_affichee.nombre_eleves, 1)
        self.assertEqual(ecole_affichee.nombre_enseignants, 1)
        self.assertEqual(ecole_affichee.nombre_classes, 1)
