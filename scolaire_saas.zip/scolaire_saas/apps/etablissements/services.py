"""Opérations de cycle de vie destructives pour un établissement."""

from django.apps import apps
from django.core.exceptions import FieldDoesNotExist
from django.db import DEFAULT_DB_ALIAS, transaction
from django.db.models import FileField, ForeignKey
from django.db.models.deletion import ProtectedError

from apps.etablissements.models import Etablissement


class SuppressionEtablissementBloquee(Exception):
    """La suppression impliquerait de retirer des données hors de l'école ciblée."""


def _fichiers_ecole(ecole: Etablissement, using: str):
    fichiers = {}
    for modele in apps.get_models():
        if modele is Etablissement:
            objets = modele._base_manager.using(using).filter(pk=ecole.pk)
        else:
            try:
                champ_ecole = modele._meta.get_field("ecole")
            except FieldDoesNotExist:
                continue
            if champ_ecole.remote_field.model is not Etablissement:
                continue
            objets = modele._base_manager.using(using).filter(ecole_id=ecole.pk)

        for champ in modele._meta.concrete_fields:
            if not isinstance(champ, FileField):
                continue
            for nom in objets.values_list(champ.attname, flat=True).iterator():
                if nom:
                    fichiers[(id(champ.storage), nom)] = (champ.storage, nom)
    return list(fichiers.values())


def _supprimer_fichiers_orphelins(fichiers, using: str) -> None:
    for stockage, nom in fichiers:
        encore_utilise = False
        for modele in apps.get_models():
            for champ in modele._meta.concrete_fields:
                if not isinstance(champ, FileField) or champ.storage is not stockage:
                    continue
                if modele._base_manager.using(using).filter(
                    **{champ.attname: nom}
                ).exists():
                    encore_utilise = True
                    break
            if encore_utilise:
                break
        if not encore_utilise:
            stockage.delete(nom)


def supprimer_ecole_definitivement(ecole: Etablissement) -> None:
    """Supprime les données protégées de cette école avant l'école elle-même."""
    using = ecole._state.db or DEFAULT_DB_ALIAS
    fichiers = _fichiers_ecole(ecole, using)
    en_cours = set()
    supprimes = set()

    def identifiant(objet):
        return (objet._meta.label_lower, objet.pk)

    def ecole_id_de(objet, visites=None):
        if objet.pk == ecole.pk and isinstance(objet, Etablissement):
            return ecole.pk

        visites = visites or set()
        cle = identifiant(objet)
        if cle in visites:
            return None
        visites.add(cle)

        for champ in objet._meta.fields:
            if not isinstance(champ, ForeignKey):
                continue
            if champ.remote_field.model is Etablissement:
                return getattr(objet, champ.attname)

        for champ in objet._meta.fields:
            if not isinstance(champ, ForeignKey):
                continue
            parent = getattr(objet, champ.name)
            if parent is not None:
                parent_ecole_id = ecole_id_de(parent, visites)
                if parent_ecole_id is not None:
                    return parent_ecole_id
        return None

    def supprimer_objet(objet):
        cle = identifiant(objet)
        if cle in supprimes:
            return
        if cle in en_cours:
            raise SuppressionEtablissementBloquee(
                "Des données liées entre elles empêchent la suppression."
            )

        en_cours.add(cle)
        try:
            while True:
                try:
                    objet.delete()
                    break
                except ProtectedError as erreur:
                    dependances = list(erreur.protected_objects)
                    if not dependances:
                        raise SuppressionEtablissementBloquee(
                            "Des données liées empêchent la suppression."
                        ) from erreur

                    for dependance in dependances:
                        if ecole_id_de(dependance) != ecole.pk:
                            raise SuppressionEtablissementBloquee(
                                "Des données liées à un autre compte ou établissement "
                                "empêchent la suppression."
                            ) from erreur
                        supprimer_objet(dependance)
        finally:
            en_cours.remove(cle)

        supprimes.add(cle)

    with transaction.atomic(using=using):
        supprimer_objet(ecole)
        transaction.on_commit(
            lambda: _supprimer_fichiers_orphelins(fichiers, using),
            using=using,
            robust=True,
        )
