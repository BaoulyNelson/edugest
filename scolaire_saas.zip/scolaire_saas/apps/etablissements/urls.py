from django.urls import path
from apps.etablissements import views   # ← corrigé

app_name = "saas"

urlpatterns = [
    path("",                              views.accueil_saas,      name="accueil"),
    path("inscription/",                  views.inscription_saas,  name="inscription"),
    path("slug-ecole-disponible/",        views.slug_ecole_disponible, name="slug_ecole_disponible"),
    path("creer-ecole/",                  views.creer_ecole,       name="creer_ecole"),
    path("tableau-bord/",                 views.tableau_bord_saas, name="tableau_bord"),
    path("configuration/",                views.configurer_site, name="configuration"),
    path("acceder/<slug:slug>/",          views.acceder_ecole,     name="acceder_ecole"),
    path("quitter/",                      views.quitter_ecole,     name="quitter_ecole"),
    path("ecole/<slug:slug>/modifier/",   views.modifier_ecole,    name="modifier_ecole"),    # ← ajouté
    path("ecole/<slug:slug>/abonnement/", views.gerer_abonnement,  name="gerer_abonnement"),  # ← ajouté
]