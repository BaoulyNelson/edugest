import csv
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.etablissements.models import PlanAbonnement


CHAMPS_REQUIS = {
    "code",
    "libelle",
    "description",
    "prix_mensuel_htg",
    "prix_annuel_htg",
    "max_eleves",
    "max_utilisateurs",
    "max_classes",
    "stockage_go",
    "fonctionnalites",
    "est_actif",
    "est_visible_public",
    "ordre_affichage",
}


def lire_booleen(valeur, champ):
    valeur = valeur.strip().lower()
    if valeur == "true":
        return True
    if valeur == "false":
        return False
    raise ValueError(f"« {champ} » doit valoir true ou false.")


def lire_entier_optionnel(valeur, champ):
    valeur = valeur.strip()
    if not valeur:
        return None
    resultat = int(valeur)
    if resultat < 0:
        raise ValueError(f"« {champ} » ne peut pas être négatif.")
    return resultat


class Command(BaseCommand):
    help = (
        "Crée ou met à jour les plans d'abonnement depuis "
        "data/plans_abonnement.csv."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "fichier",
            nargs="?",
            default=str(
                Path(__file__).resolve().parents[4]
                / "data"
                / "plans_abonnement.csv"
            ),
            help="Chemin du CSV (par défaut : data/plans_abonnement.csv).",
        )

    @transaction.atomic
    def handle(self, *args, **options):
        chemin = Path(options["fichier"])
        if not chemin.is_file():
            raise CommandError(f"Fichier introuvable : {chemin}")

        crees = 0
        mis_a_jour = 0
        try:
            with chemin.open(encoding="utf-8-sig", newline="") as fichier:
                lecteur = csv.DictReader(fichier)
                if not lecteur.fieldnames:
                    raise CommandError("Le CSV est vide ou ne contient pas d'en-tête.")

                champs_manquants = CHAMPS_REQUIS - set(lecteur.fieldnames)
                if champs_manquants:
                    liste = ", ".join(sorted(champs_manquants))
                    raise CommandError(f"Colonnes manquantes dans le CSV : {liste}")

                for numero_ligne, ligne in enumerate(lecteur, start=2):
                    try:
                        plan = self._enregistrer_plan(ligne)
                    except (ValueError, InvalidOperation, json.JSONDecodeError) as erreur:
                        raise CommandError(f"Ligne {numero_ligne} : {erreur}") from erreur
                    if plan:
                        crees += 1
                    else:
                        mis_a_jour += 1
        except UnicodeDecodeError as erreur:
            raise CommandError("Le CSV doit être encodé en UTF-8.") from erreur

        self.stdout.write(
            self.style.SUCCESS(
                f"Import terminé : {crees} plan(s) créé(s), "
                f"{mis_a_jour} mis à jour."
            )
        )

    @staticmethod
    def _enregistrer_plan(ligne):
        code = (ligne.get("code") or "").strip().upper()
        libelle = (ligne.get("libelle") or "").strip()
        if not code or not libelle:
            raise ValueError("« code » et « libelle » sont obligatoires.")

        prix_mensuel = Decimal(ligne["prix_mensuel_htg"].strip())
        prix_annuel = Decimal(ligne["prix_annuel_htg"].strip())
        if prix_mensuel < 0 or prix_annuel < 0:
            raise ValueError("Les prix ne peuvent pas être négatifs.")
        if prix_annuel > prix_mensuel * 12:
            raise ValueError("Le prix annuel ne peut pas dépasser 12 mensualités.")

        fonctionnalites = json.loads(ligne["fonctionnalites"])
        if not isinstance(fonctionnalites, dict) or any(
            not isinstance(valeur, bool)
            for valeur in fonctionnalites.values()
        ):
            raise ValueError(
                "« fonctionnalites » doit être un objet JSON contenant des booléens."
            )

        stockage_go = int(ligne["stockage_go"].strip())
        ordre_affichage = int(ligne["ordre_affichage"].strip())
        if stockage_go < 1 or ordre_affichage < 0:
            raise ValueError("Le stockage doit être positif et l'ordre non négatif.")

        defaults = {
            "libelle": libelle,
            "description": (ligne.get("description") or "").strip(),
            "prix_mensuel_htg": prix_mensuel,
            "prix_annuel_htg": prix_annuel,
            "max_eleves": lire_entier_optionnel(
                ligne.get("max_eleves") or "",
                "max_eleves",
            ),
            "max_utilisateurs": lire_entier_optionnel(
                ligne.get("max_utilisateurs") or "",
                "max_utilisateurs",
            ),
            "max_classes": lire_entier_optionnel(
                ligne.get("max_classes") or "",
                "max_classes",
            ),
            "stockage_go": stockage_go,
            "fonctionnalites": fonctionnalites,
            "est_actif": lire_booleen(ligne["est_actif"], "est_actif"),
            "est_visible_public": lire_booleen(
                ligne["est_visible_public"],
                "est_visible_public",
            ),
            "ordre_affichage": ordre_affichage,
        }
        _, cree = PlanAbonnement.objects.update_or_create(
            code=code,
            defaults=defaults,
        )
        return cree
