import csv
import io
import json
import re
from datetime import date
from pathlib import Path

from django.db import transaction
from django.utils import timezone

from apps.academique.models import (
    AnneeScolaire,
    PeriodeAcademique,
    StatutAnneeScolaire,
)
from apps.etablissements.models import TypeEtablissement
from apps.parametrage.models import (
    CoefficientsMatiere,
    CycleEnseignement,
    Matiere,
    Niveau,
    OptionPedagogique,
    SystemeNotation,
    TypeDiscipline,
    TypeEvaluation,
)


DOSSIER_DATA = Path(__file__).resolve().parents[2] / "data"
PRESETS_PAR_TYPE = {
    TypeEtablissement.PRIMAIRE: "primaire.json",
    TypeEtablissement.SECONDAIRE: "secondaire.json",
    TypeEtablissement.MIXTE: "mixte.json",
    TypeEtablissement.TECHNIQUE: "technique.json",
    TypeEtablissement.UNIVERSITE: "universite.json",
}


def _lire_csv(nom_fichier):
    contenu = (DOSSIER_DATA / nom_fichier).read_text(encoding="utf-8-sig")
    try:
        dialecte = csv.Sniffer().sniff(contenu[:2048], delimiters=",;\t")
    except csv.Error:
        dialecte = csv.excel
    return csv.DictReader(io.StringIO(contenu), dialect=dialecte)


def _valeurs_csv(modele, ligne, champs_exclus=()):
    valeurs = {}
    for nom, valeur in ligne.items():
        if nom in champs_exclus or not valeur:
            continue
        champ = modele._meta.get_field(nom)
        valeurs[nom] = champ.to_python(valeur.strip())
    return valeurs


def _preconfigurer_types_communs(ecole):
    for ligne in _lire_csv("04_types_evaluation.csv"):
        valeurs = _valeurs_csv(TypeEvaluation, ligne, {"code"})
        TypeEvaluation.tous_objets.get_or_create(
            ecole=ecole,
            code=ligne["code"].strip(),
            defaults=valeurs,
        )

    for ligne in _lire_csv("06_types_discipline.csv"):
        valeurs = _valeurs_csv(TypeDiscipline, ligne, {"code"})
        TypeDiscipline.tous_objets.get_or_create(
            ecole=ecole,
            code=ligne["code"].strip(),
            defaults=valeurs,
        )

    if ecole.pays == "HTI":
        for ligne in _lire_csv("05_systemes_notation.csv"):
            valeurs = _valeurs_csv(SystemeNotation, ligne, {"libelle"})
            SystemeNotation.tous_objets.get_or_create(
                ecole=ecole,
                libelle=ligne["libelle"].strip(),
                defaults=valeurs,
            )


def _ajuster_annee(valeur, annee_reference, annee_debut):
    if not isinstance(valeur, str):
        return valeur

    def remplacer(match):
        annee = int(match.group())
        if annee == annee_reference:
            return str(annee_debut)
        if annee == annee_reference + 1:
            return str(annee_debut + 1)
        return match.group()

    return re.sub(r"(?<!\d)20\d{2}(?!\d)", remplacer, valeur)


def _preconfigurer_profil(ecole):
    nom_fichier = PRESETS_PAR_TYPE.get(ecole.type_etablissement)
    if nom_fichier is None:
        return

    chemin = DOSSIER_DATA / nom_fichier
    try:
        preset = json.loads(chemin.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(
            f"Impossible de charger le profil de configuration {chemin}."
        ) from exc

    if preset.get("type_etablissement") != ecole.type_etablissement.upper():
        raise ValueError(
            f"Le profil {nom_fichier} ne correspond pas au type "
            f"d’établissement {ecole.type_etablissement}."
        )

    annees_json = preset.get("annees_scolaires", [])
    annee_reference = (
        int(annees_json[0]["libelle"].split("-")[0]) if annees_json else None
    )
    aujourd_hui = timezone.localdate()
    annee_debut = aujourd_hui.year if aujourd_hui.month >= 9 else aujourd_hui.year - 1

    cycles = {}
    for ligne in preset.get("cycles", []):
        cycle, _ = CycleEnseignement.tous_objets.get_or_create(
            ecole=ecole,
            code=ligne["code"],
            defaults={
                "libelle": ligne["libelle"],
                "ordre_affichage": ligne.get("ordre_affichage", 0),
            },
        )
        cycles[cycle.code] = cycle

    niveaux = {}
    for ligne in preset.get("niveaux", []):
        niveau, _ = Niveau.tous_objets.get_or_create(
            ecole=ecole,
            cycle=cycles[ligne["cycle"]],
            code=ligne["code"],
            defaults={
                "libelle": ligne["libelle"],
                "libelle_court": ligne.get("libelle_court", ""),
                "duree_annees": ligne.get("duree_annees", 1),
                "ordre_affichage": ligne.get("ordre_affichage", 0),
                "est_actif": ligne.get("est_actif", True),
            },
        )
        niveaux[niveau.code] = niveau

    matieres = {}
    for ligne in preset.get("matieres", []):
        matiere, _ = Matiere.tous_objets.get_or_create(
            ecole=ecole,
            code=ligne["code"],
            defaults={
                "libelle": ligne["libelle"],
                "libelle_court": ligne.get("libelle_court", ""),
                "type_matiere": ligne.get("type_matiere", "theorique"),
                "ordre_affichage": ligne.get("ordre_affichage", 0),
                "est_actif": ligne.get("est_actif", True),
            },
        )
        matieres[matiere.code] = matiere

    annees = {}
    for ligne in annees_json:
        valeurs = {
            cle: _ajuster_annee(valeur, annee_reference, annee_debut)
            for cle, valeur in ligne.items()
        }
        debut = date.fromisoformat(valeurs["date_debut"])
        fin = date.fromisoformat(valeurs["date_fin"])
        annee, _ = AnneeScolaire.tous_objets.get_or_create(
            ecole=ecole,
            libelle=valeurs["libelle"],
            defaults={
                "date_debut": debut,
                "date_fin": fin,
                "type_decoupage": valeurs["type_decoupage"],
                "statut": StatutAnneeScolaire.BROUILLON,
                "est_courante": False,
                "cree_par": ecole.cree_par,
            },
        )
        annees[ligne["libelle"]] = annee

    for ligne in preset.get("periodes", []):
        valeurs = {
            cle: _ajuster_annee(valeur, annee_reference, annee_debut)
            for cle, valeur in ligne.items()
        }
        PeriodeAcademique.tous_objets.get_or_create(
            ecole=ecole,
            annee_scolaire=annees[ligne["annee_scolaire"]],
            type_periode=ligne["type_periode"],
            numero=ligne["numero"],
            defaults={
                "libelle": valeurs["libelle"],
                "libelle_court": valeurs.get("libelle_court", ""),
                "date_debut": date.fromisoformat(valeurs["date_debut"]),
                "date_fin": date.fromisoformat(valeurs["date_fin"]),
                "poids_calcul": valeurs.get("poids_calcul", 1),
            },
        )

    for ligne in preset.get("options_pedagogiques", []):
        OptionPedagogique.tous_objets.get_or_create(
            ecole=ecole,
            niveau=niveaux[ligne["niveau"]],
            code=ligne["code"],
            defaults={
                "libelle": ligne["libelle"],
                "ordre_affichage": ligne.get("ordre_affichage", 0),
                "est_actif": ligne.get("est_actif", True),
            },
        )

    for ligne in preset.get("coefficients", []):
        CoefficientsMatiere.tous_objets.get_or_create(
            ecole=ecole,
            matiere=matieres[ligne["matiere"]],
            niveau=niveaux[ligne["niveau"]],
            annee_scolaire=annees[ligne["annee_scolaire"]],
            defaults={
                "coefficient": ligne.get("coefficient", 1),
                "est_obligatoire": ligne.get("est_obligatoire", True),
            },
        )


@transaction.atomic
def preconfigurer_ecole(ecole):
    """Ajoute les valeurs de départ du profil sans écraser les données existantes."""
    _preconfigurer_types_communs(ecole)
    _preconfigurer_profil(ecole)
    from apps.finances.preconfiguration import preconfigurer_types_frais

    preconfigurer_types_frais(ecole)
