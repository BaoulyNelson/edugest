"""
apps/etablissements/models.py
==============================
Cœur du système multitenant.
Etablissement = un tenant = une école.
Abonnement = le contrat SaaS associé.
"""

import uuid
import calendar
from datetime import date
from django.db import models
from apps.noyau.mixins import ContactUniqueMixin, UUIDPrimaryKeyMixin, HorodatageMixin


class PeriodiciteFacturation(models.TextChoices):
    MENSUELLE = "mensuelle", "Mensuelle"
    ANNUELLE = "annuelle", "Annuelle"


class ConfigurationSite(models.Model):
    """Identité et coordonnées globales de la plateforme SaaS."""

    id = models.PositiveSmallIntegerField(
        primary_key=True,
        default=1,
        editable=False,
    )
    nom_site = models.CharField(max_length=120, default="Scolaire SaaS")
    slogan = models.CharField(max_length=200, blank=True)
    logo = models.ImageField(
        upload_to="site/",
        null=True,
        blank=True,
        verbose_name="Logo du site",
    )
    email_contact = models.EmailField(default="contact@scolaire.ht")
    telephone_contact = models.CharField(max_length=30, blank=True)
    adresse = models.TextField(blank=True)
    site_web = models.URLField(blank=True)

    class Meta:
        verbose_name = "Configuration du site"
        verbose_name_plural = "Configuration du site"

    def save(self, *args, **kwargs):
        self.pk = 1
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.nom_site


def date_fin_periode_abonnement(date_debut: date, periodicite: str) -> date:
    nombre_mois = 12 if periodicite == PeriodiciteFacturation.ANNUELLE else 1
    mois_indexe = date_debut.month - 1 + nombre_mois
    annee = date_debut.year + mois_indexe // 12
    mois = mois_indexe % 12 + 1
    jour = min(date_debut.day, calendar.monthrange(annee, mois)[1])
    return date(annee, mois, jour)


class TypeEtablissement(models.TextChoices):
    PRIMAIRE = "primaire", "École Primaire"
    SECONDAIRE = "secondaire", "École Secondaire"
    TECHNIQUE = "technique", "École Technique / Professionnelle"
    MIXTE = "mixte", "Établissement Mixte (Fond. + Sec.)"
    UNIVERSITE = "universite", "Université / Institut Supérieur"
    INCOMPLET = "incomplet", "Établissement Incomplet"


class Etablissement(ContactUniqueMixin, UUIDPrimaryKeyMixin, HorodatageMixin):
    """
    Entité racine du système multitenant.
    INVARIANT : chaque établissement possède un slug unique — c'est son identité réseau.
    INVARIANT : est_actif=False bloque TOUT accès au tenant (TenantMiddleware).
    """
    slug = models.SlugField(
        max_length=80,
        unique=True,
        verbose_name="Identifiant URL",
        help_text="Sous-domaine unique. Ex: lycee-petion-cap → lycee-petion-cap.scolaire.ht",
    )
    nom = models.CharField(max_length=200, verbose_name="Nom officiel")
    nom_court = models.CharField(
        max_length=60,
        blank=True,
        verbose_name="Nom court",
        help_text="Affiché dans les en-têtes et bulletins.",
    )
    type_etablissement = models.CharField(
        max_length=20,
        choices=TypeEtablissement.choices,
        default=TypeEtablissement.MIXTE,
        verbose_name="Type d'établissement",
    )

    # ── Localisation ──────────────────────────────────────────────────────────
    pays = models.CharField(max_length=3, default="HTI", verbose_name="Code pays (ISO)")
    departement = models.CharField(max_length=50, blank=True, verbose_name="Département")
    ville = models.CharField(max_length=100, verbose_name="Ville")
    adresse = models.TextField(blank=True, verbose_name="Adresse complète")
    code_postal = models.CharField(max_length=20, blank=True)

    # ── Contacts ──────────────────────────────────────────────────────────────
    telephone = models.CharField(max_length=30, blank=True)
    telephone_secondaire = models.CharField(max_length=30, blank=True)
    email = models.EmailField(blank=True)
    site_web = models.URLField(blank=True)

    # ── Identité visuelle ─────────────────────────────────────────────────────
    logo = models.ImageField(
        upload_to="etablissements/logos/%Y/",
        null=True,
        blank=True,
        verbose_name="Logo",
    )
    couleur_principale = models.CharField(
        max_length=7,
        default="#1a3c6e",
        help_text="Couleur hexadécimale pour les bulletins et badges.",
    )
    couleur_secondaire = models.CharField(max_length=7, default="#ffffff")
    devise_etablissement = models.CharField(
        max_length=200,
        blank=True,
        verbose_name="Devise / Slogan",
        help_text="Ex: 'Excellence et Discipline'",
    )

    # ── Direction ─────────────────────────────────────────────────────────────
    directeur_nom = models.CharField(max_length=200, blank=True)
    directeur_titre = models.CharField(
        max_length=50,
        default="Directeur",
        verbose_name="Titre du directeur",
    )
    signature_directeur = models.ImageField(
        upload_to="etablissements/signatures/",
        null=True,
        blank=True,
        verbose_name="Signature numérisée",
    )
    sceau = models.ImageField(
        upload_to="etablissements/sceaux/",
        null=True,
        blank=True,
        verbose_name="Sceau / Cachet officiel",
    )

    # ── Informations légales ──────────────────────────────────────────────────
    numero_agrement = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="Numéro d'agrément MENFP",
    )
    annee_fondation = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        verbose_name="Année de fondation",
    )

    # ── Paramètres locaux ─────────────────────────────────────────────────────
    fuseau_horaire = models.CharField(
        max_length=50,
        default="America/Port-au-Prince",
    )
    devise_monetaire = models.CharField(
        max_length=5,
        default="HTG",
        verbose_name="Devise monétaire",
        help_text="Ex: HTG, USD, EUR",
    )
    langue_principale = models.CharField(max_length=5, default="fr")

    # ── Statut SaaS ───────────────────────────────────────────────────────────
    est_actif = models.BooleanField(
        default=True,
        db_index=True,
        verbose_name="Établissement actif",
        help_text="False = accès bloqué par TenantMiddleware.",
    )
    cree_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="etablissements_crees",
        verbose_name="Créé par",
    )

    class Meta:
        verbose_name = "Établissement"
        verbose_name_plural = "Établissements"
        ordering = ["nom"]

    def __str__(self):
        return f"{self.nom} ({self.slug})"

    @property
    def nom_affichage(self) -> str:
        """Retourne le nom court si disponible, sinon le nom complet."""
        return self.nom_court or self.nom

    def obtenir_annee_courante(self):
        """Retourne l'année scolaire active, ou None."""
        from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
        return (
            self.academique_anneescolaire_set
            .filter(statut=StatutAnneeScolaire.ACTIVE)
            .first()
        )


class PlanAbonnement(HorodatageMixin):
    """
    Définit les limites et fonctionnalités d'un plan SaaS.
    Modifiable sans redéploiement — tout est en base.
    """
    code = models.CharField(max_length=20, unique=True)
    libelle = models.CharField(max_length=80)
    description = models.TextField(blank=True)
    prix_mensuel_htg = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix mensuel (HTG)",
    )
    prix_annuel_htg = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix annuel (HTG)",
        help_text="Généralement prix_mensuel × 10 (2 mois offerts).",
    )

    # Limites quantitatives (null = illimité)
    max_eleves = models.PositiveIntegerField(
        null=True,
        blank=True,
        verbose_name="Élèves maximum",
    )
    max_utilisateurs = models.PositiveIntegerField(
        null=True,
        blank=True,
        verbose_name="Utilisateurs maximum",
    )
    max_classes = models.PositiveIntegerField(null=True, blank=True)
    stockage_go = models.PositiveSmallIntegerField(
        default=5,
        verbose_name="Stockage alloué (Go)",
    )

    # Fonctionnalités activables par plan
    fonctionnalites = models.JSONField(
        default=dict,
        verbose_name="Fonctionnalités",
        help_text="""
        Exemple :
        {
            "bulletins_pdf": true,
            "badges_impression": true,
            "api_acces": false,
            "rapports_avances": false,
            "multi_etablissements": false,
            "export_excel": true,
            "sms_notifications": false
        }
        """,
    )
    est_actif = models.BooleanField(default=True)
    est_visible_public = models.BooleanField(
        default=True,
        help_text="Affiché sur la page publique des tarifs.",
    )
    ordre_affichage = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Plan d'abonnement"
        verbose_name_plural = "Plans d'abonnement"
        ordering = ["ordre_affichage"]

    def __str__(self):
        return f"{self.libelle} ({self.code})"

    def a_fonctionnalite(self, code: str) -> bool:
        """Vérifie si une fonctionnalité est incluse dans ce plan."""
        return bool(self.fonctionnalites.get(code, False))


    @property
    def bulletins_pdf(self) -> bool:
        return self.a_fonctionnalite('bulletins_pdf')

    @property
    def badges_impression(self) -> bool:
        return self.a_fonctionnalite('badges_impression')

    @property
    def api_acces(self) -> bool:
        return self.a_fonctionnalite('api_acces')

    @property
    def rapports_avances(self) -> bool:
        return self.a_fonctionnalite('rapports_avances')

    @property
    def multi_etablissements(self) -> bool:
        return self.a_fonctionnalite('multi_etablissements')

    @property
    def export_excel(self) -> bool:
        return self.a_fonctionnalite('export_excel')

    @property
    def sms_notifications(self) -> bool:
        return self.a_fonctionnalite('sms_notifications')

    def verifier_limite_eleves(self, nb_actuel: int) -> bool:
        if self.max_eleves is None:
            return True  # Illimité
        return nb_actuel < self.max_eleves


class Abonnement(HorodatageMixin):
    """
    Contrat SaaS entre un établissement et la plateforme.
    INVARIANT : un seul abonnement actif par établissement.
    """
    etablissement = models.OneToOneField(
        Etablissement,
        on_delete=models.CASCADE,
        related_name="abonnement_actif",
    )
    plan = models.ForeignKey(
        PlanAbonnement,
        on_delete=models.PROTECT,
        related_name="abonnements",
    )
    date_debut = models.DateField(verbose_name="Début d'abonnement")
    date_fin = models.DateField(
        null=True,
        blank=True,
        verbose_name="Fin d'abonnement",
        help_text="Null si abonnement mensuel renouvelable automatiquement.",
    )
    periodicite = models.CharField(
        max_length=10,
        choices=PeriodiciteFacturation.choices,
        default=PeriodiciteFacturation.MENSUELLE,
        verbose_name="Périodicité de facturation",
    )
    demande_forfait_en_attente = models.OneToOneField(
        "DemandeChangementForfait",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name="Demande de forfait en attente",
    )
    est_actif = models.BooleanField(default=True, db_index=True)
    en_periode_essai = models.BooleanField(default=True)
    date_fin_essai = models.DateField(null=True, blank=True)
    renouvellement_auto = models.BooleanField(default=True)

    # Traçabilité commerciale
    souscrit_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    notes_internes = models.TextField(blank=True)

    class Meta:
        verbose_name = "Abonnement"
        verbose_name_plural = "Abonnements"

    def __str__(self):
        return f"{self.etablissement.slug} — {self.plan.code}"

    @property
    def est_en_essai(self) -> bool:
        from django.utils import timezone
        if not self.en_periode_essai:
            return False
        if self.date_fin_essai is None:
            return True
        return timezone.localdate() < self.date_fin_essai

    def expirer_essai_si_necessaire(self, aujourd_hui=None) -> bool:
        """Désactive l'abonnement dès que sa date de fin d'essai est atteinte."""
        from django.utils import timezone

        aujourd_hui = aujourd_hui or timezone.localdate()
        if not (
            self.est_actif
            and self.en_periode_essai
            and self.date_fin_essai
            and aujourd_hui >= self.date_fin_essai
        ):
            return False

        from django.db import transaction

        with transaction.atomic():
            self.est_actif = False
            self.save(update_fields=["est_actif", "modifie_le"])
            Etablissement.objects.filter(
                pk=self.etablissement_id,
                est_actif=True,
            ).update(est_actif=False, modifie_le=timezone.now())
        return True

    def a_fonctionnalite(self, code: str) -> bool:
        return self.plan.a_fonctionnalite(code)


class DemandeChangementForfait(UUIDPrimaryKeyMixin, HorodatageMixin):
    class Statut(models.TextChoices):
        EN_ATTENTE = "en_attente", "En attente"
        APPROUVEE = "approuvee", "Approuvée"
        REFUSEE = "refusee", "Refusée"

    abonnement = models.ForeignKey(
        Abonnement,
        on_delete=models.CASCADE,
        related_name="demandes_forfait",
    )
    plan = models.ForeignKey(
        PlanAbonnement,
        on_delete=models.PROTECT,
        related_name="demandes_forfait",
    )
    periodicite = models.CharField(
        max_length=10,
        choices=PeriodiciteFacturation.choices,
        default=PeriodiciteFacturation.MENSUELLE,
    )
    demandeur = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.SET_NULL,
        null=True,
        related_name="demandes_changement_forfait",
    )
    statut = models.CharField(
        max_length=12,
        choices=Statut.choices,
        default=Statut.EN_ATTENTE,
        db_index=True,
    )
    traitee_le = models.DateTimeField(null=True, blank=True)
    traitee_par = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="demandes_forfait_traitees",
    )
    commentaire_admin = models.CharField(max_length=500, blank=True)

    class Meta:
        verbose_name = "Demande de changement de forfait"
        verbose_name_plural = "Demandes de changement de forfait"
        ordering = ["-cree_le"]

    def __str__(self):
        return f"{self.abonnement.etablissement.slug} → {self.plan.libelle} ({self.get_statut_display()})"