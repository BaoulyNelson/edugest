"""Formulaires de création d'établissement."""
from django import forms
from apps.etablissements.models import Etablissement

from django import forms
from apps.etablissements.models import (
    Abonnement,
    ConfigurationSite,
    DemandeChangementForfait,
    Etablissement,
    PlanAbonnement,
)

W  = lambda: {"class": "form-control"}
WS = lambda: {"class": "form-select"}


class FormulaireConfigurationSite(forms.ModelForm):
    class Meta:
        model = ConfigurationSite
        fields = [
            "nom_site",
            "slogan",
            "logo",
            "email_contact",
            "telephone_contact",
            "adresse",
            "site_web",
        ]
        widgets = {
            "nom_site": forms.TextInput(attrs=W()),
            "slogan": forms.TextInput(attrs=W()),
            "email_contact": forms.EmailInput(attrs=W()),
            "telephone_contact": forms.TextInput(attrs=W()),
            "adresse": forms.Textarea(attrs={**W(), "rows": 3}),
            "site_web": forms.URLInput(attrs=W()),
        }


# ── FormulaireEtablissement — version complète corrigée ──────────────────────

class FormulaireEtablissement(forms.ModelForm):
    class Meta:
        model = Etablissement
        fields = [
            # Identité
            "slug", "nom", "nom_court", "type_etablissement",
            # Localisation
            "pays", "departement", "ville", "adresse", "code_postal",
            # Contacts
            "telephone", "telephone_secondaire", "email", "site_web",
            # Identité visuelle
            "logo", "couleur_principale", "couleur_secondaire", "devise_etablissement",
            # Direction
            "directeur_nom", "directeur_titre", "signature_directeur", "sceau",
            # Légal
            "numero_agrement", "annee_fondation",
            # Paramètres locaux
            "fuseau_horaire", "devise_monetaire",
        ]
        widgets = {
            "adresse":             forms.Textarea(attrs={**W(), "rows": 2}),
            "devise_etablissement":forms.TextInput(attrs={**W(), "placeholder": "Excellence et Discipline"}),
            "type_etablissement":  forms.Select(attrs=WS()),
            "couleur_principale":  forms.TextInput(attrs={"class": "form-control form-control-color", "type": "color"}),
            "couleur_secondaire":  forms.TextInput(attrs={"class": "form-control form-control-color", "type": "color"}),
            **{f: forms.TextInput(attrs=W()) for f in [
                "slug", "nom", "nom_court", "pays", "departement", "ville",
                "code_postal", "telephone", "telephone_secondaire",
                "email", "site_web", "directeur_nom", "directeur_titre",
                "numero_agrement", "fuseau_horaire", "devise_monetaire",
            ]},
        }
        help_texts = {
            "slug": "Identifiant URL unique. Ex: lycee-petion-cap",
            "couleur_principale": "Utilisée dans les bulletins et badges.",
            "signature_directeur": "Image PNG/JPG transparente recommandée.",
        }

    def clean_slug(self):
        slug = self.cleaned_data.get("slug", "").lower().strip()
        queryset = Etablissement.objects.all()
        if self.instance.pk:
            queryset = queryset.exclude(pk=self.instance.pk)

        slug_base = slug[:80].rstrip("-")
        slug_disponible = slug_base
        suffixe = 2
        while queryset.filter(slug=slug_disponible).exists():
            suffix = f"-{suffixe}"
            slug_disponible = f"{slug_base[:80 - len(suffix)].rstrip('-')}{suffix}"
            suffixe += 1
        return slug_disponible


# ── FormulairePlanAbonnement — ABSENT ────────────────────────────────────────

class FormulairePlanAbonnement(forms.ModelForm):
    class Meta:
        model = PlanAbonnement
        fields = [
            "code", "libelle", "description",
            "prix_mensuel_htg", "prix_annuel_htg",
            "max_eleves", "max_utilisateurs", "max_classes", "stockage_go",
            "fonctionnalites",
            "est_actif", "est_visible_public", "ordre_affichage",
        ]
        widgets = {
            "code":             forms.TextInput(attrs={**W(), "placeholder": "STARTER"}),
            "libelle":          forms.TextInput(attrs=W()),
            "description":      forms.Textarea(attrs={**W(), "rows": 3}),
            "prix_mensuel_htg": forms.NumberInput(attrs={**W(), "step": "0.01", "min": "0"}),
            "prix_annuel_htg":  forms.NumberInput(attrs={**W(), "step": "0.01", "min": "0"}),
            "max_eleves":       forms.NumberInput(attrs={**W(), "min": "1", "placeholder": "Vide = illimité"}),
            "max_utilisateurs": forms.NumberInput(attrs={**W(), "min": "1", "placeholder": "Vide = illimité"}),
            "max_classes":      forms.NumberInput(attrs={**W(), "min": "1", "placeholder": "Vide = illimité"}),
            "stockage_go":      forms.NumberInput(attrs={**W(), "min": "1"}),
            "fonctionnalites":  forms.Textarea(attrs={**W(), "rows": 6,
                "placeholder": '{"bulletins_pdf": true, "export_excel": true}'}),
            "ordre_affichage":  forms.NumberInput(attrs={**W(), "min": "0"}),
        }

    def clean_fonctionnalites(self):
        import json
        data = self.cleaned_data.get("fonctionnalites")
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except json.JSONDecodeError:
                raise forms.ValidationError("JSON invalide. Vérifiez la syntaxe.")
        if not isinstance(data, dict):
            raise forms.ValidationError("Les fonctionnalités doivent être un objet JSON.")
        # Valider que toutes les valeurs sont des booléens
        for cle, val in data.items():
            if not isinstance(val, bool):
                raise forms.ValidationError(f"La valeur de « {cle} » doit être true ou false.")
        return data

    def clean(self):
        cleaned = super().clean()
        mensuel = cleaned.get("prix_mensuel_htg")
        annuel  = cleaned.get("prix_annuel_htg")
        if mensuel and annuel and annuel > mensuel * 12:
            raise forms.ValidationError(
                "Le prix annuel ne peut pas dépasser 12 × le prix mensuel."
            )
        return cleaned


# ── FormulaireAbonnement — ABSENT ────────────────────────────────────────────

class FormulaireAbonnement(forms.ModelForm):
    class Meta:
        model = Abonnement
        fields = [
            "plan", "date_debut", "periodicite", "date_fin", "est_actif", "souscrit_par",
            "en_periode_essai", "date_fin_essai",
            "renouvellement_auto", "notes_internes",
        ]
        labels = {
            "est_actif": "Abonnement actif",
        }
        widgets = {
            "plan":             forms.Select(attrs=WS()),
            "date_debut":       forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "date_fin":         forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "date_fin_essai":   forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "notes_internes":   forms.Textarea(attrs={**W(), "rows": 2}),
        }
        help_texts = {
            "est_actif": (
                "L'accès exige aussi que l'établissement soit actif et que "
                "la période d'essai ou l'abonnement soit valide."
            ),
            "date_fin":       "Date de fin de la période payée. Sans objet pendant l’essai gratuit.",
            "date_fin_essai": "Laisser vide pour un essai sans limite de durée.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Afficher uniquement les plans actifs
        self.fields["plan"].queryset = PlanAbonnement.objects.filter(est_actif=True)
        self.fields["souscrit_par"].required = False

    def clean(self):
        cleaned = super().clean()
        debut = cleaned.get("date_debut")
        fin = cleaned.get("date_fin")
        if debut and fin and fin <= debut:
            raise forms.ValidationError("La date de fin doit être postérieure à la date de début.")
        fin_essai = cleaned.get("date_fin_essai")
        if fin_essai and debut and fin_essai < debut:
            raise forms.ValidationError("La fin d'essai ne peut pas précéder le début d'abonnement.")
        return cleaned


class FormulaireDemandeForfait(forms.ModelForm):
    class Meta:
        model = DemandeChangementForfait
        fields = ["plan", "periodicite"]
        widgets = {
            "plan": forms.Select(attrs=WS()),
            "periodicite": forms.Select(attrs=WS()),
        }

    def __init__(self, *args, abonnement, **kwargs):
        super().__init__(*args, **kwargs)
        self.abonnement = abonnement
        plans = PlanAbonnement.objects.filter(
            est_actif=True,
            est_visible_public=True,
        )
        if abonnement.est_actif:
            plans = plans.exclude(pk=abonnement.plan_id)
        self.fields["plan"].queryset = plans.order_by(
            "ordre_affichage",
            "prix_mensuel_htg",
        )
        self.fields["plan"].label_from_instance = (
            lambda plan: (
                f"{plan.libelle} — {plan.prix_mensuel_htg} HTG/mois "
                f"ou {plan.prix_annuel_htg} HTG/an"
            )
        )

    def clean_plan(self):
        plan = self.cleaned_data["plan"]
        if plan.pk == self.abonnement.plan_id:
            raise forms.ValidationError("Ce forfait est déjà celui de votre établissement.")
        return plan