from django.contrib import admin
from apps.noyau.admin import AdminTenant
from apps.parametrage.models import (
    CoefficientsMatiere,
    BaremeMatierePeriode,
    BaremeEvaluationPeriode,
    CycleEnseignement,
    Matiere,
    Mention,
    Niveau,
    OptionPedagogique,
    ReglePassage,
    Section,
    SystemeNotation,
    TypeDiscipline,
    TypeEvaluation,
)

admin.site.register(
    (
        CycleEnseignement,
        Niveau,
        Section,
        OptionPedagogique,
        Matiere,
        CoefficientsMatiere,
        BaremeMatierePeriode,
        BaremeEvaluationPeriode,
        TypeEvaluation,
        SystemeNotation,
        Mention,
        ReglePassage,
        TypeDiscipline,
    ),
    AdminTenant,
)
