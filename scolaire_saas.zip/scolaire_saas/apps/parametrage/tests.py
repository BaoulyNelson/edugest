from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.etablissements.models import Etablissement
from apps.parametrage.models import CycleEnseignement, Niveau
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ListeNiveauxTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="niveaux-liste@example.com",
            password="test-password",
            nom="Niveaux",
            prenom="Admin",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-niveaux-liste",
            nom="École niveaux",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.url = reverse("parametrage:niveaux")
        self.cycles = {
            code: CycleEnseignement.objects.create(
                ecole=self.ecole,
                code=code,
                libelle=libelle,
            )
            for code, libelle in (
                ("FOND", "Fondamental"),
                ("SECONDAIRE", "Secondaire"),
            )
        }
        Niveau.objects.create(
            ecole=self.ecole,
            cycle=self.cycles["FOND"],
            code="1AF",
            libelle="Première année fondamentale",
            libelle_court="1re AF",
            ordre_affichage=1,
        )
        Niveau.objects.create(
            ecole=self.ecole,
            cycle=self.cycles["FOND"],
            code="2AF",
            libelle="Deuxième année fondamentale",
            libelle_court="2e AF",
            ordre_affichage=2,
            est_actif=False,
        )
        Niveau.objects.create(
            ecole=self.ecole,
            cycle=self.cycles["SECONDAIRE"],
            code="NS1",
            libelle="Nouveau secondaire I",
            ordre_affichage=3,
        )

    def get_liste(self, params=None):
        return self.client.get(
            self.url,
            params or {},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

    def test_filtre_par_recherche_cycle_et_statut(self):
        response = self.get_liste(
            {"q": "fondamentale", "cycle": str(self.cycles["FOND"].pk), "statut": "actif"}
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["total_niveaux"], 1)
        self.assertEqual(response.context["niveaux"][0].code, "1AF")

    def test_affiche_les_niveaux_par_pages(self):
        response = self.get_liste({"per_page": "10"})

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["total_niveaux"], 3)
        self.assertEqual(len(response.context["niveaux"]), 3)

    def test_exporte_la_selection_csv(self):
        niveau = Niveau.objects.get(ecole=self.ecole, code="1AF")

        response = self.get_liste({"export": "csv", "ids": [str(niveau.pk)]})

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "text/csv; charset=utf-8")
        contenu = response.content.decode("utf-8-sig")
        self.assertIn("FOND;1AF;Première année fondamentale", contenu)
        self.assertNotIn("NS1", contenu)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AccesIndexParametrageTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="parametrage-sans-permission@example.com",
            nom="Paramétrage",
            prenom="Test",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-acces-parametrage",
            nom="École accès paramétrage",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

    def test_index_refuse_sans_permission_de_parametrage(self):
        response = self.client.get(reverse("parametrage:index"))

        self.assertEqual(response.status_code, 403)

    def test_index_est_accessible_avec_permission_de_parametrage(self):
        permission = PermissionGranulaire.objects.create(
            code="parametrage.modifier.etablissement",
            description="Modifier le paramétrage de l'établissement.",
            module="parametrage",
            action="modifier",
            portee="etablissement",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="directeur-parametrage-test",
            libelle="Directeur",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.utilisateur,
            role=role,
        )

        response = self.client.get(reverse("parametrage:index"))

        self.assertEqual(response.status_code, 200)

# Create your tests here.
