from django.apps import AppConfig

class ParametrageConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.parametrage"
    verbose_name = "Parametrage ultra-flexible du systeme"
