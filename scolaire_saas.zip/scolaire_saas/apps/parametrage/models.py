"""
apps/parametrage/models.py
===========================
Moteur de paramétrage ultra-flexible.
RIEN n'est codé en dur : cycles, niveaux, matières, coefficients,
types d'évaluation, règles de passage — tout est configurable par école.

Principe : une école haïtienne utilise "Fondamental 1–6 + Secondaire 1–7",
une école française utilise "CP–CM2 + 6e–Terminale".
Le modèle ne connaît aucune de ces valeurs à l'avance.
"""

from decimal import Decimal, ROUND_HALF_UP
from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.noyau.mixins import (
    TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin
)


# ─── Système éducatif ────────────────────────────────────────────────────────

class CycleEnseignement(TenantModelMixin, HorodatageMixin, OrdreMixin):
    """
    Découpage de premier niveau du système éducatif.
    Exemples HT : Fondamental, Secondaire, Technique.
    Exemples FR : École, Collège, Lycée.
    """
    code = models.CharField(max_length=20, verbose_name="Code court")
    libelle = models.CharField(max_length=100, verbose_name="Libellé")
    description = models.TextField(blank=True)
    couleur = models.CharField(
        max_length=7,
        default="#1a3c6e",
        help_text="Couleur hexadécimale pour l'interface.",
    )

    class Meta:
        verbose_name = "Cycle d'enseignement"
        verbose_name_plural = "Cycles d'enseignement"
        unique_together = [("ecole", "code")]
        ordering = ["ecole", "ordre_affichage"]

    def __str__(self):
        return f"{self.libelle} ({self.code})"


class Niveau(TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin):
    """
    Niveau scolaire à l'intérieur d'un cycle.
    Exemples HT Fondamental : 1re AF, 2e AF, ..., 6e AF.
    Exemples HT Secondaire  : 7e AF, 8e AF, ..., Philo.
    """
    cycle = models.ForeignKey(
        CycleEnseignement,
        on_delete=models.PROTECT,
        related_name="niveaux",
    )
    code = models.CharField(max_length=20)
    libelle = models.CharField(max_length=100)
    libelle_court = models.CharField(max_length=20, blank=True)
    duree_annees = models.PositiveSmallIntegerField(
        default=1,
        verbose_name="Durée (années)",
    )

    class Meta:
        verbose_name = "Niveau"
        verbose_name_plural = "Niveaux"
        unique_together = [("ecole", "cycle", "code")]
        ordering = ["ecole", "cycle", "ordre_affichage"]

    def __str__(self):
        return f"{self.cycle.code} — {self.libelle}"


class Section(TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin):
    """
    Subdivision d'un niveau. Exemples : Section A, B, C ou Sciences, Lettres.
    Optionnel : certaines écoles n'ont pas de sections.
    """
    niveau = models.ForeignKey(
        Niveau,
        on_delete=models.PROTECT,
        related_name="sections",
    )
    code = models.CharField(max_length=10)
    libelle = models.CharField(max_length=50)

    class Meta:
        verbose_name = "Section"
        unique_together = [("ecole", "niveau", "code")]

    def __str__(self):
        return f"{self.libelle} ({self.code})"


class OptionPedagogique(TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin):
    """
    Option de spécialisation. Exemples : Sciences-Maths, Lettres, Commerce, Agriculture.
    Surtout utilisé dans le secondaire technique / professionnel.
    """
    niveau = models.ForeignKey(
        Niveau,
        on_delete=models.PROTECT,
        related_name="options",
    )
    code = models.CharField(max_length=20)
    libelle = models.CharField(max_length=100)

    class Meta:
        verbose_name = "Option pédagogique"
        unique_together = [("ecole", "niveau", "code")]

    def __str__(self):
        return f"{self.libelle} ({self.code})"


# ─── Matières ────────────────────────────────────────────────────────────────

class TypeMatiere(models.TextChoices):
    THEORIQUE = "theorique", "Théorique"
    PRATIQUE = "pratique", "Travaux Pratiques"
    SPORT = "sport", "Éducation Physique"
    ART = "art", "Arts / Musique"
    LANGUE = "langue", "Langue"
    RELIGION = "religion", "Éducation Religieuse / Morale"


class Matiere(TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin):
    """
    Matière enseignée — définie par l'école, pas par le système.
    Une matière peut avoir des coefficients différents selon le niveau.
    """
    code = models.CharField(max_length=20, verbose_name="Code")
    libelle = models.CharField(max_length=100, verbose_name="Libellé complet")
    libelle_court = models.CharField(
        max_length=20,
        blank=True,
        verbose_name="Libellé court (bulletin)",
    )
    type_matiere = models.CharField(
        max_length=15,
        choices=TypeMatiere.choices,
        default=TypeMatiere.THEORIQUE,
    )
    couleur = models.CharField(max_length=7, default="#3b82f6")

    class Meta:
        verbose_name = "Matière"
        verbose_name_plural = "Matières"
        unique_together = [("ecole", "code")]
        ordering = ["ecole", "ordre_affichage"]

    def __str__(self):
        return f"{self.libelle} ({self.code})"
    
        # Dans Matiere
    def save(self, *args, **kwargs):
        if not self.code:
            from apps.noyau.utilitaires import generer_code_matiere
            self.code = generer_code_matiere(self.ecole, self.libelle)
        super().save(*args, **kwargs)


class ModeCalculMatiere(models.TextChoices):
    POINTS = "points", "Addition des points"
    PONDERATION = "ponderation", "Pondération en pourcentage"


class MethodeArrondiNotation(models.TextChoices):
    DEMI_SUPERIEUR = "half_up", "Au plus proche, demi au supérieur"
    DEMI_PAIR = "half_even", "Au plus proche, demi au chiffre pair"
    TRONCATURE = "down", "Troncature"
    SUPERIEUR = "ceiling", "Toujours au supérieur"


class CoefficientsMatiere(TenantModelMixin, HorodatageMixin):
    """
    Coefficient d'une matière pour un niveau et une année scolaire données.
    Permet de modifier les coefficients d'une année à l'autre sans affecter l'historique.

    NOTE CRITIQUE : quand une note est saisie, le coefficient est COPIÉ dans Note.coefficient_applique.
    Ce modèle définit le coefficient de référence, pas le coefficient figé.
    """
    matiere = models.ForeignKey(
        Matiere,
        on_delete=models.PROTECT,
        related_name="coefficients",
    )
    niveau = models.ForeignKey(
        Niveau,
        on_delete=models.PROTECT,
        related_name="coefficients_matieres",
    )
    annee_scolaire = models.ForeignKey(
        "academique.AnneeScolaire",
        on_delete=models.PROTECT,
        related_name="coefficients_matieres",
    )
    coefficient = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        default=Decimal("1.00"),
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    bareme_total = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        default=Decimal("100.00"),
        validators=[MinValueValidator(Decimal("0.01"))],
        verbose_name="Barème total de la matière",
        help_text="Total de points attribués aux composantes de cette matière.",
    )
    mode_calcul = models.CharField(
        max_length=15,
        choices=ModeCalculMatiere.choices,
        default=ModeCalculMatiere.POINTS,
        verbose_name="Méthode de calcul de la matière",
    )
    est_obligatoire = models.BooleanField(
        default=True,
        help_text="Si False, la matière est optionnelle (non comptée dans la moyenne si absente).",
    )

    class Meta:
        verbose_name = "Coefficient de matière"
        verbose_name_plural = "Coefficients de matières"
        unique_together = [("ecole", "matiere", "niveau", "annee_scolaire")]

    def __str__(self):
        return f"{self.matiere.code} × {self.coefficient} (Niv. {self.niveau.code})"


class BaremeEvaluationMatiere(TenantModelMixin, HorodatageMixin):
    """Maximum de saisie et éventuelle pondération d'une composante."""

    coefficient_matiere = models.ForeignKey(
        CoefficientsMatiere,
        on_delete=models.CASCADE,
        related_name="baremes_evaluations",
    )
    type_evaluation = models.ForeignKey(
        "parametrage.TypeEvaluation",
        on_delete=models.PROTECT,
        related_name="baremes_matieres",
    )
    points_max = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Maximum de la composante",
    )
    poids_pourcentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Pondération en pourcentage",
    )

    class Meta:
        verbose_name = "Composante du barème de matière"
        verbose_name_plural = "Composantes des barèmes de matière"
        unique_together = [("ecole", "coefficient_matiere", "type_evaluation")]
        ordering = ["type_evaluation__ordre_affichage"]

    def clean(self):
        super().clean()
        if self.coefficient_matiere_id and self.type_evaluation_id:
            if self.coefficient_matiere.ecole_id != self.ecole_id:
                raise ValidationError(
                    "Le barème et son coefficient doivent appartenir à la même école."
                )
            if self.type_evaluation.ecole_id != self.ecole_id:
                raise ValidationError(
                    "Le type d'évaluation doit appartenir à la même école."
                )

    def __str__(self):
        return (
            f"{self.type_evaluation.libelle} : {self.points_max} "
            f"({self.coefficient_matiere.matiere.code})"
        )


class BaremeMatierePeriode(TenantModelMixin, HorodatageMixin):
    """Barème de composantes d'une matière pour une période précise."""

    coefficient_matiere = models.ForeignKey(
        CoefficientsMatiere,
        on_delete=models.CASCADE,
        related_name="baremes_periodes",
    )
    periode = models.ForeignKey(
        "academique.PeriodeAcademique",
        on_delete=models.PROTECT,
        related_name="baremes_matieres",
    )
    bareme_total = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
        verbose_name="Barème de la période",
    )
    mode_calcul = models.CharField(
        max_length=15,
        choices=ModeCalculMatiere.choices,
        default=ModeCalculMatiere.POINTS,
        verbose_name="Méthode de calcul",
    )

    class Meta:
        verbose_name = "Barème de matière par période"
        verbose_name_plural = "Barèmes de matière par période"
        unique_together = [("ecole", "coefficient_matiere", "periode")]

    def clean(self):
        super().clean()
        if self.coefficient_matiere_id and self.periode_id:
            if self.coefficient_matiere.ecole_id != self.ecole_id:
                raise ValidationError(
                    "Le barème et son coefficient doivent appartenir à la même école."
                )
            if self.periode.ecole_id != self.ecole_id:
                raise ValidationError(
                    "La période doit appartenir à la même école."
                )
            if (
                self.coefficient_matiere.annee_scolaire_id
                != self.periode.annee_scolaire_id
            ):
                raise ValidationError(
                    "La période et le coefficient doivent appartenir à la même année scolaire."
                )

    def __str__(self):
        return (
            f"{self.coefficient_matiere.matiere.code} — "
            f"{self.periode.libelle} ({self.bareme_total})"
        )


class BaremeEvaluationPeriode(TenantModelMixin, HorodatageMixin):
    """Maximum et pondération d'une composante pour une période précise."""

    bareme_periode = models.ForeignKey(
        BaremeMatierePeriode,
        on_delete=models.CASCADE,
        related_name="composantes",
    )
    type_evaluation = models.ForeignKey(
        "parametrage.TypeEvaluation",
        on_delete=models.PROTECT,
        related_name="baremes_periodes",
    )
    points_max = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Maximum de la composante",
    )
    poids_pourcentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Pondération en pourcentage",
    )

    class Meta:
        verbose_name = "Composante du barème de matière par période"
        verbose_name_plural = "Composantes des barèmes de matière par période"
        unique_together = [("ecole", "bareme_periode", "type_evaluation")]
        ordering = ["type_evaluation__ordre_affichage"]

    def clean(self):
        super().clean()
        if self.bareme_periode_id and self.type_evaluation_id:
            if self.bareme_periode.ecole_id != self.ecole_id:
                raise ValidationError(
                    "La composante et son barème doivent appartenir à la même école."
                )
            if (
                self.bareme_periode.coefficient_matiere.ecole_id
                != self.ecole_id
            ):
                raise ValidationError(
                    "Le barème et son coefficient doivent appartenir à la même école."
                )
            if self.type_evaluation.ecole_id != self.ecole_id:
                raise ValidationError(
                    "Le type d'évaluation doit appartenir à la même école."
                )


# ─── Types d'évaluation ──────────────────────────────────────────────────────

class TypeEvaluation(TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin):
    """
    Définit les types de notes possibles pour l'école.
    Exemples : Interrogation, Devoir, Composition, Examen officiel, TP, Projet.
    Les maxima et pondérations sont configurés par matière.
    """
    code = models.CharField(max_length=20)
    libelle = models.CharField(max_length=80)
    poids = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        default=Decimal("1.00"),
        help_text=(
            "Conservé pour les anciennes notes. Les nouvelles évaluations "
            "utilisent les points configurés par matière."
        ),
    )
    compte_dans_moyenne = models.BooleanField(
        default=True,
        help_text="False = note informative uniquement (ex: devoirs non notés).",
    )
    est_obligatoire = models.BooleanField(
        default=False,
        help_text="True = doit être saisie pour tous les élèves.",
    )
    note_max_defaut = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("10.00"),
        verbose_name="Note maximale par défaut",
        help_text=(
            "Maximum utilisé pour les évaluations informatives. Pour les "
            "évaluations comptant dans la moyenne, le maximum dépend de la matière."
        ),
    )
    couleur = models.CharField(max_length=7, default="#6366f1")
    icone = models.CharField(max_length=50, blank=True)

    class Meta:
        verbose_name = "Type d'évaluation"
        verbose_name_plural = "Types d'évaluation"
        unique_together = [("ecole", "code")]


# ─── Système de notation ─────────────────────────────────────────────────────

class SystemeNotation(TenantModelMixin, HorodatageMixin):
    """
    Définit la base de notation et les mentions pour l'école.
    Un seul système peut être actif par école.
    """
    libelle = models.CharField(max_length=60)
    base_notation = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("10.00"),
        verbose_name="Base des moyennes",
        help_text=(
            "Les moyennes sont exprimées sur cette base : par exemple, "
            "78,4/100 correspond à 7,84/10."
        ),
    )
    note_passage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("5.00"),
        verbose_name="Note de passage",
        help_text="Moyenne minimale pour être considéré admis.",
    )
    methode_arrondi = models.CharField(
        max_length=12,
        choices=MethodeArrondiNotation.choices,
        default=MethodeArrondiNotation.DEMI_SUPERIEUR,
        verbose_name="Règle d’arrondi des moyennes",
    )
    est_courant = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Système de notation"
        verbose_name_plural = "Systèmes de notation"

    def clean(self):
        super().clean()
        if self.base_notation <= 0:
            raise ValidationError("La base des moyennes doit être supérieure à zéro.")
        if self.note_passage < 0 or self.note_passage >= self.base_notation:
            raise ValidationError(
                "La note de passage doit être positive ou nulle et inférieure à la base."
            )
        if self.pk:
            ancien = type(self).objects.filter(pk=self.pk).values(
                "base_notation",
                "note_passage",
            ).first()
            if ancien and (
                ancien["base_notation"] != self.base_notation
                or ancien["note_passage"] != self.note_passage
            ):
                nombre_mentions_suggerees = self.mentions.filter(
                    est_suggeree=True
                ).count()
                if nombre_mentions_suggerees > 1:
                    intervalles = nombre_mentions_suggerees - 1
                    seuils = [
                        (
                            self.note_passage
                            + (self.base_notation - self.note_passage)
                            * Decimal(position)
                            / Decimal(intervalles)
                        ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                        for position in range(intervalles + 1)
                    ]
                    if len(set(seuils)) != len(seuils):
                        raise ValidationError(
                            "La plage entre la note de passage et la base est trop "
                            "petite pour répartir les mentions suggérées."
                        )

    def save(self, *args, **kwargs):
        from django.db import transaction
        from django.utils import timezone

        self.clean()
        with transaction.atomic():
            ancien = (
                type(self).objects.filter(pk=self.pk)
                .values("base_notation", "note_passage")
                .first()
                if self.pk
                else None
            )
            if self.base_notation <= 0:
                raise ValidationError(
                    "La base des moyennes doit être supérieure à zéro."
                )
            if self.note_passage < 0 or self.note_passage >= self.base_notation:
                raise ValidationError(
                    "La note de passage doit être positive ou nulle et inférieure à la base."
                )

            super().save(*args, **kwargs)
            if not ancien or (
                ancien["base_notation"] == self.base_notation
                and ancien["note_passage"] == self.note_passage
            ):
                return

            suggestions = list(
                self.mentions.filter(est_suggeree=True).order_by(
                    "ordre_affichage", "pk"
                )
            )
            if not suggestions:
                return

            nombres_intervalles = len(suggestions) - 1
            seuils_superieurs = [
                (
                    self.note_passage
                    + (self.base_notation - self.note_passage)
                    * Decimal(position)
                    / Decimal(nombres_intervalles)
                ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                for position in range(nombres_intervalles + 1)
            ] if nombres_intervalles else []
            maintenant = timezone.now()
            for index, mention in enumerate(suggestions):
                mention.moyenne_min = (
                    Decimal("0")
                    if nombres_intervalles == 0 or index == 0
                    else seuils_superieurs[index - 1]
                )
                mention.moyenne_max = (
                    self.note_passage if index == 0
                    else self.base_notation if nombres_intervalles == 0
                    else seuils_superieurs[index]
                )
                mention.modifie_le = maintenant
            Mention.objects.bulk_update(
                suggestions,
                ["moyenne_min", "moyenne_max", "modifie_le"],
            )


class Mention(TenantModelMixin, HorodatageMixin, OrdreMixin):
    """
    Libellé descriptif associé à une tranche de moyennes.
    La décision d'admission est calculée séparément selon le seuil de passage.
    """
    systeme_notation = models.ForeignKey(
        SystemeNotation,
        on_delete=models.CASCADE,
        related_name="mentions",
    )
    libelle = models.CharField(max_length=50)
    libelle_court = models.CharField(max_length=10, blank=True)
    moyenne_min = models.DecimalField(max_digits=5, decimal_places=2)
    moyenne_max = models.DecimalField(max_digits=5, decimal_places=2)
    couleur = models.CharField(max_length=7, default="#22c55e")
    est_suggeree = models.BooleanField(
        default=False,
        editable=False,
        verbose_name="Mention générée depuis les suggestions",
    )

    class Meta:
        verbose_name = "Mention"
        verbose_name_plural = "Mentions"
        ordering = ["-moyenne_min"]


# ─── Règles de passage ───────────────────────────────────────────────────────

class ReglePassage(TenantModelMixin, HorodatageMixin):
    """
    Règles métier de passage de classe.
    Exemple HT : 50% pour passer, mais certaines matières sont éliminatoires.
    Entièrement configurable par école et par niveau.
    """
    niveau = models.ForeignKey(
        Niveau,
        on_delete=models.PROTECT,
        related_name="regles_passage",
    )
    libelle = models.CharField(max_length=100)
    moyenne_passage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text=(
            "Seuil spécifique à ce niveau. Laisser vide pour utiliser la note "
            "de passage du système de notation."
        ),
    )
    # Matières éliminatoires : si note < seuil, refus quelle que soit la moyenne
    matieres_eliminatoires = models.ManyToManyField(
        Matiere,
        blank=True,
        related_name="regles_eliminatoire",
        verbose_name="Matières éliminatoires",
    )
    seuil_eliminatoire = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Seuil en dessous duquel une matière éliminatoire entraîne le refus.",
    )
    nb_matieres_insuffisantes_max = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        help_text="Nombre max de matières sous la note de passage (tolérance).",
    )
    est_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Règle de passage"
        verbose_name_plural = "Règles de passage"


# ─── Types de discipline ─────────────────────────────────────────────────────

class TypeDiscipline(TenantModelMixin, HorodatageMixin, OrdreMixin, ActivableMixin):
    """
    Types de sanctions et distinctions disciplinaires configurables.
    Exemples : Avertissement, Blâme, Félicitations, Tableau d'honneur.
    """
    code = models.CharField(max_length=20)
    libelle = models.CharField(max_length=80)
    gravite = models.CharField(
        max_length=15,
        choices=[
            ("distinction", "Distinction"),
            ("information", "Information"),
            ("avertissement", "Avertissement"),
            ("sanction", "Sanction grave"),
        ],
    )
    apparait_bulletin = models.BooleanField(
        default=False,
        help_text="True = apparaît dans le bulletin scolaire.",
    )

    class Meta:
        verbose_name = "Type de discipline"
        unique_together = [("ecole", "code")]