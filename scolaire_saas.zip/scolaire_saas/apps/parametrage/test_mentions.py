from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.etablissements.models import Etablissement
from apps.notes.services import ServiceCalculMoyenne
from apps.parametrage.forms import FormulaireMention, FormulaireReglePassage
from apps.parametrage.models import Mention, SystemeNotation


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class MentionsSuggereesTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="mentions-suggerees@example.com",
            password="test-password",
            nom="Mentions",
            prenom="Admin",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-mentions-suggerees",
            nom="École mentions",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.systeme = SystemeNotation.objects.create(
            ecole=self.ecole,
            libelle="Système /10",
            base_notation=Decimal("10.00"),
            note_passage=Decimal("5.00"),
            est_courant=True,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug
        self.url = reverse("parametrage:creer_mentions_suggerees")

    def test_cree_six_mentions_adaptees_a_la_base_et_au_seuil(self):
        response = self.client.post(self.url)

        self.assertRedirects(response, reverse("parametrage:systeme_notation"))
        mentions = list(
            Mention.objects.filter(
                ecole=self.ecole,
                systeme_notation=self.systeme,
            ).order_by("moyenne_min")
        )
        self.assertEqual(len(mentions), 6)
        self.assertTrue(all(mention.est_suggeree for mention in mentions))
        self.assertEqual(
            [mention.libelle for mention in mentions],
            [
                "Insuffisant",
                "Passable",
                "Assez bien",
                "Bien",
                "Très bien",
                "Excellent",
            ],
        )
        self.assertEqual(
            [mention.moyenne_min for mention in mentions],
            [
                Decimal("0.00"),
                Decimal("5.00"),
                Decimal("6.00"),
                Decimal("7.00"),
                Decimal("8.00"),
                Decimal("9.00"),
            ],
        )
        self.assertEqual(
            [mention.moyenne_max for mention in mentions],
            [
                Decimal("5.00"),
                Decimal("6.00"),
                Decimal("7.00"),
                Decimal("8.00"),
                Decimal("9.00"),
                Decimal("10.00"),
            ],
        )

    def test_adapte_les_seuils_a_une_base_sur_vingt(self):
        self.systeme.base_notation = Decimal("20.00")
        self.systeme.note_passage = Decimal("10.00")
        self.systeme.save()

        self.client.post(self.url)

        mentions = Mention.objects.filter(
            ecole=self.ecole,
            systeme_notation=self.systeme,
        ).order_by("moyenne_min")
        self.assertEqual(
            list(mentions.values_list("moyenne_min", flat=True)),
            [
                Decimal("0.00"),
                Decimal("10.00"),
                Decimal("12.00"),
                Decimal("14.00"),
                Decimal("16.00"),
                Decimal("18.00"),
            ],
        )
        self.assertEqual(
            list(mentions.values_list("moyenne_max", flat=True)),
            [
                Decimal("10.00"),
                Decimal("12.00"),
                Decimal("14.00"),
                Decimal("16.00"),
                Decimal("18.00"),
                Decimal("20.00"),
            ],
        )

    def test_modification_systeme_recalcule_les_mentions_suggerees(self):
        self.client.post(self.url)
        self.systeme.base_notation = Decimal("20.00")
        self.systeme.note_passage = Decimal("10.00")
        self.systeme.save()

        mentions = Mention.objects.filter(
            ecole=self.ecole,
            systeme_notation=self.systeme,
            est_suggeree=True,
        ).order_by("ordre_affichage")
        self.assertEqual(
            list(mentions.values_list("moyenne_min", flat=True)),
            [
                Decimal("0.00"),
                Decimal("10.00"),
                Decimal("12.00"),
                Decimal("14.00"),
                Decimal("16.00"),
                Decimal("18.00"),
            ],
        )
        self.assertEqual(
            list(mentions.values_list("moyenne_max", flat=True)),
            [
                Decimal("10.00"),
                Decimal("12.00"),
                Decimal("14.00"),
                Decimal("16.00"),
                Decimal("18.00"),
                Decimal("20.00"),
            ],
        )

    def test_modification_systeme_ne_change_pas_les_mentions_manuelles(self):
        mention = Mention.objects.create(
            ecole=self.ecole,
            systeme_notation=self.systeme,
            libelle="Distinction",
            moyenne_min=Decimal("8.50"),
            moyenne_max=Decimal("9.50"),
            est_suggeree=False,
        )
        self.systeme.base_notation = Decimal("20")
        self.systeme.note_passage = Decimal("10")
        self.systeme.save()

        mention.refresh_from_db()
        self.assertEqual(mention.moyenne_min, Decimal("8.50"))
        self.assertEqual(mention.moyenne_max, Decimal("9.50"))

    def test_refuse_une_base_trop_petite_pour_les_mentions_suggerees(self):
        self.client.post(self.url)
        self.systeme.base_notation = Decimal("5.02")
        self.systeme.note_passage = Decimal("5.00")

        with self.assertRaises(ValidationError):
            self.systeme.save()

        self.systeme.refresh_from_db()
        self.assertEqual(self.systeme.base_notation, Decimal("10.00"))

    def test_les_seuils_partages_attribuent_la_mention_superieure(self):
        self.client.post(self.url)
        service = ServiceCalculMoyenne()

        self.assertEqual(
            service._obtenir_mention(Decimal("5.00"), self.ecole).libelle,
            "Passable",
        )
        self.assertEqual(
            service._obtenir_mention(Decimal("6.00"), self.ecole).libelle,
            "Assez bien",
        )
        self.assertEqual(
            service._obtenir_mention(Decimal("10.00"), self.ecole).libelle,
            "Excellent",
        )

    def test_refuse_de_dupliquer_les_mentions_existantes(self):
        Mention.objects.create(
            ecole=self.ecole,
            systeme_notation=self.systeme,
            libelle="Mention personnalisée",
            moyenne_min=Decimal("0"),
            moyenne_max=Decimal("10"),
        )

        response = self.client.post(self.url, follow=True)

        self.assertEqual(
            Mention.objects.filter(
                ecole=self.ecole,
                systeme_notation=self.systeme,
            ).count(),
            1,
        )
        self.assertContains(response, "Des mentions existent déjà")

    def test_generation_des_mentions_exige_post(self):
        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 405)
        self.assertFalse(Mention.objects.filter(ecole=self.ecole).exists())

    def test_mention_ne_contient_pas_de_decision_admission_redondante(self):
        formulaire = FormulaireMention()

        self.assertNotIn("est_admis", formulaire.fields)

    def test_seuil_de_regle_peut_etre_vide_pour_reprendre_le_seuil_global(self):
        formulaire = FormulaireReglePassage()

        self.assertFalse(formulaire.fields["moyenne_passage"].required)
        self.assertIn(
            "note de passage du système",
            formulaire.fields["moyenne_passage"].help_text,
        )
