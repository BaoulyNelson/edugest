from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.etablissements.models import Etablissement
from apps.parametrage.models import (
    CycleEnseignement,
    Niveau,
    OptionPedagogique,
    Section,
)
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ConfirmationsSuppressionParametrageTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="suppression-parametrage@example.com",
            nom="Suppression",
            prenom="Test",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-suppression-parametrage",
            nom="École suppression",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        permission = PermissionGranulaire.objects.create(
            code="parametrage.modifier.etablissement",
            description="Modifier le paramétrage de l'établissement.",
            module="parametrage",
            action="modifier",
            portee="etablissement",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="responsable-parametrage",
            libelle="Responsable",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.utilisateur,
            role=role,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="SECONDAIRE",
            libelle="Secondaire",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="NS1",
            libelle="Nouveau secondaire I",
        )
        self.option = OptionPedagogique.objects.create(
            ecole=self.ecole,
            niveau=niveau,
            code="SCI",
            libelle="Sciences",
        )
        self.section = Section.objects.create(
            ecole=self.ecole,
            niveau=niveau,
            code="A",
            libelle="Section A",
        )

    def test_confirmation_suppression_option_charge_le_template(self):
        response = self.client.get(
            reverse("parametrage:supprimer_option", args=[self.option.pk])
        )

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "parametrage/confirm_suppression.html")
        self.assertContains(response, str(self.option))

    def test_confirmation_suppression_section_charge_le_template(self):
        response = self.client.get(
            reverse("parametrage:supprimer_section", args=[self.section.pk])
        )

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "parametrage/confirm_suppression.html")
        self.assertContains(response, str(self.section))
