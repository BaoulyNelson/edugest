from datetime import date

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.academique.models import (
    AnneeScolaire,
    Classe,
    MatiereClasse,
    StatutAnneeScolaire,
)
from apps.etablissements.models import Etablissement
from apps.parametrage.forms import FormulaireCoefficient, FormulaireSystemeNotation
from apps.parametrage.models import (
    CoefficientsMatiere,
    CycleEnseignement,
    Matiere,
    Niveau,
)
from apps.enseignants.models import Enseignant
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ListeCoefficientsTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="coefficients-liste@example.com",
            nom="Coefficients",
            prenom="Admin",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-coefficients-liste",
            nom="École coefficients",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        permission = PermissionGranulaire.objects.create(
            code="parametrage.modifier.etablissement",
            description="Modifier le paramétrage de l'établissement.",
            module="parametrage",
            action="modifier",
            portee="etablissement",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="responsable-coefficients",
            libelle="Responsable",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.utilisateur,
            role=role,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug
        self.url = reverse("parametrage:coefficients")

        self.annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
            est_courante=True,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="LICENCE",
            libelle="Licence",
        )
        self.niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="L1",
            libelle="Première année",
        )
        self.matiere = Matiere.objects.create(
            ecole=self.ecole,
            code="MATH",
            libelle="Mathématiques",
        )

    def test_filtre_affiche_les_niveaux_actifs_sans_coefficient_existant(self):
        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            list(response.context["niveaux"].values_list("pk", flat=True)),
            [self.niveau.pk],
        )
        self.assertContains(response, "LICENCE — Première année")
        self.assertFalse(response.context["coefficients"].exists())

    def test_formulaire_coefficient_ne_definit_pas_le_bareme_des_notes(self):
        formulaire = FormulaireCoefficient(ecole=self.ecole)

        self.assertNotIn("note_max", formulaire.fields)
        self.assertIn("coefficient", formulaire.fields)

    def test_creation_coefficient_peut_preselectionner_matiere_et_niveau(self):
        response = self.client.get(
            reverse("parametrage:creer_coefficient"),
            {
                "matiere": self.matiere.pk,
                "niveau": self.niveau.pk,
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["form"]["matiere"].value(),
            self.matiere.pk,
        )
        self.assertEqual(
            response.context["form"]["niveau"].value(),
            self.niveau.pk,
        )
        self.assertEqual(
            response.context["form"]["annee_scolaire"].value(),
            self.annee.pk,
        )

    def test_creation_coefficient_revient_a_la_grille_apres_sauvegarde(self):
        retour = "/notes/saisie/5/14/2/"
        response = self.client.post(
            reverse("parametrage:creer_coefficient"),
            {
                "matiere": self.matiere.pk,
                "niveau": self.niveau.pk,
                "annee_scolaire": self.annee.pk,
                "coefficient": "2.00",
                "est_obligatoire": "on",
                "retour": retour,
            },
        )

        self.assertRedirects(response, retour, fetch_redirect_response=False)

    def test_base_du_systeme_est_presentee_comme_base_des_moyennes(self):
        formulaire = FormulaireSystemeNotation()

        self.assertEqual(formulaire.fields["base_notation"].label, "Base des moyennes")
        self.assertIn("78,4/100", formulaire.fields["base_notation"].help_text)

    def test_enseignant_peut_configurer_le_bareme_de_sa_matiere(self):
        coefficient = CoefficientsMatiere.objects.create(
            ecole=self.ecole,
            matiere=self.matiere,
            niveau=self.niveau,
            annee_scolaire=self.annee,
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            niveau=self.niveau,
            code="L1-A",
            libelle="Première année A",
        )
        enseignant_utilisateur = get_user_model().objects.create_user(
            email="enseignant-bareme@example.com",
            nom="Enseignant",
            prenom="Test",
        )
        enseignant = Enseignant.objects.create(
            ecole=self.ecole,
            utilisateur=enseignant_utilisateur,
            nom="Enseignant",
            prenom="Test",
            sexe="M",
        )
        MatiereClasse.objects.create(
            ecole=self.ecole,
            classe=classe,
            matiere=self.matiere,
            enseignant=enseignant,
        )
        permission = PermissionGranulaire.objects.create(
            code="notes.saisir.propres_classes",
            description="Saisir les notes de ses propres classes.",
            module="notes",
            action="saisir",
            portee="propres_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="enseignant-baremes",
            libelle="Enseignant",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=enseignant_utilisateur,
            role=role,
        )
        self.client.force_login(enseignant_utilisateur)
        url = reverse(
            "parametrage:configurer_bareme_coefficient",
            args=(coefficient.pk,),
        )

        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

    def test_enseignant_ne_peut_pas_configurer_une_matiere_non_attribuee(self):
        coefficient = CoefficientsMatiere.objects.create(
            ecole=self.ecole,
            matiere=self.matiere,
            niveau=self.niveau,
            annee_scolaire=self.annee,
        )
        enseignant_utilisateur = get_user_model().objects.create_user(
            email="enseignant-sans-affectation@example.com",
            nom="Enseignant",
            prenom="Sans affectation",
        )
        permission = PermissionGranulaire.objects.create(
            code="notes.saisir.propres_classes",
            description="Saisir les notes de ses propres classes.",
            module="notes",
            action="saisir",
            portee="propres_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="enseignant-sans-affectation",
            libelle="Enseignant",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=enseignant_utilisateur,
            role=role,
        )
        self.client.force_login(enseignant_utilisateur)
        url = reverse(
            "parametrage:configurer_bareme_coefficient",
            args=(coefficient.pk,),
        )

        response = self.client.get(url)

        self.assertEqual(response.status_code, 403)
