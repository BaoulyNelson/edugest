"""Vues de paramétrage de l'école."""
import csv
from decimal import Decimal, ROUND_HALF_UP

from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db.models import Q
from django.db import transaction
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST
from apps.noyau.decorateurs import (
    requiert_tenant,
    requiert_permission,
    requiert_une_permission,
)
from apps.academique.models import (
    Classe,
    MatiereClasse,
    PeriodeAcademique,
    StatutAnneeScolaire,
)
from apps.parametrage.models import (
    CycleEnseignement, Niveau, Matiere, OptionPedagogique, Section, TypeEvaluation,
    CoefficientsMatiere, SystemeNotation, Mention, ReglePassage, TypeDiscipline,
)
from apps.parametrage import forms


# ════════════════════════════════════════════════════════════════════
# INDEX
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def index_parametrage(request):
    ecole = request.etablissement  # ← une seule fois, propre
    annee_active = request.annee_scolaire_courante

    contexte = {
        "nb_cycles":       CycleEnseignement.objects.filter(ecole=ecole).count(),
        "nb_niveaux":      Niveau.objects.filter(ecole=ecole, est_actif=True).count(),
        "nb_matieres":     Matiere.objects.filter(ecole=ecole, est_actif=True).count(),
        "nb_types_eval":   TypeEvaluation.objects.filter(ecole=ecole, est_actif=True).count(),
        "nb_types_discipline": TypeDiscipline.objects.filter(
            ecole=ecole, est_actif=True
        ).count(),
        "nb_coefficients": CoefficientsMatiere.objects.filter(
                               ecole=ecole, annee_scolaire=annee_active
                           ).count() if annee_active else 0,
        "nb_regles":       ReglePassage.objects.filter(ecole=ecole, est_active=True).count(),
        "systeme_actif":   SystemeNotation.objects.filter(ecole=ecole, est_courant=True).first(),
        "annee_active":    annee_active,
        "nb_sections": Section.objects.filter(ecole=ecole, est_actif=True).count(),
        "nb_options":  OptionPedagogique.objects.filter(ecole=ecole, est_actif=True).count(),
    }
    return render(request, "parametrage/index.html", contexte)

# ════════════════════════════════════════════════════════════════════
# CYCLES
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_cycles(request):
    q = request.GET.get("q", "").strip()
    cycles = CycleEnseignement.objects.filter(
        ecole=request.etablissement
    ).prefetch_related("niveaux")
    if q:
        from django.db.models import Q
        cycles = cycles.filter(Q(code__icontains=q) | Q(libelle__icontains=q))
    return render(request, "parametrage/cycles.html", {"cycles": cycles, "q": q})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_cycle(request):
    retour_niveau = (
        request.GET.get("depuis_niveau") == "1"
        or request.POST.get("depuis_niveau") == "1"
    )
    if request.method == "POST":
        form = forms.FormulaireCycle(request.POST)
        if form.is_valid():
            cycle = form.save(commit=False)
            cycle.ecole = request.etablissement
            cycle.save()
            messages.success(request, f"Cycle « {cycle.libelle} » créé.")
            if retour_niveau:
                return redirect("parametrage:creer_niveau")
            return redirect("parametrage:cycles")
    else:
        form = forms.FormulaireCycle()
    return render(
        request,
        "parametrage/form_cycle.html",
        {"form": form, "retour_niveau": retour_niveau},
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_cycle(request, pk):
    cycle = get_object_or_404(CycleEnseignement, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireCycle(request.POST, instance=cycle)
        if form.is_valid():
            form.save()
            messages.success(request, f"Cycle « {cycle.libelle} » mis à jour.")
            return redirect("parametrage:cycles")
    else:
        form = forms.FormulaireCycle(instance=cycle)
    return render(request, "parametrage/form_cycle.html", {"form": form, "objet": cycle})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_cycle(request, pk):
    cycle = get_object_or_404(CycleEnseignement, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        try:
            libelle = cycle.libelle
            cycle.delete()
            messages.success(request, f"Cycle « {libelle} » supprimé.")
        except Exception:
            messages.error(request, "Impossible de supprimer ce cycle : il est utilisé par des niveaux.")
        return redirect("parametrage:cycles")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": cycle.libelle,
        "retour_url": "parametrage:cycles",
    })


# ════════════════════════════════════════════════════════════════════
# NIVEAUX
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_niveaux(request):
    q = request.GET.get("q", "").strip()
    cycle_id = request.GET.get("cycle", "").strip()
    statut = request.GET.get("statut", "").strip()
    per_page = request.GET.get("per_page", "10")
    if per_page not in {"10", "20", "50"}:
        per_page = "10"

    niveaux = Niveau.objects.filter(ecole=request.etablissement).select_related(
        "cycle"
    )
    cycles = CycleEnseignement.objects.filter(ecole=request.etablissement)
    if q:
        from django.db.models import Q

        niveaux = niveaux.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(libelle_court__icontains=q)
            | Q(cycle__libelle__icontains=q)
            | Q(cycle__code__icontains=q)
        )

    if cycle_id:
        try:
            cycle_pk = CycleEnseignement._meta.pk.to_python(cycle_id)
        except (TypeError, ValueError):
            cycle_pk = None
        if cycle_pk is not None and cycles.filter(pk=cycle_pk).exists():
            niveaux = niveaux.filter(cycle_id=cycle_pk)
        else:
            cycle_id = ""

    if statut in {"actif", "inactif"}:
        niveaux = niveaux.filter(est_actif=(statut == "actif"))
    else:
        statut = ""

    niveaux = niveaux.order_by("cycle__ordre_affichage", "ordre_affichage", "code")
    ids = request.GET.getlist("ids")
    if request.GET.get("export") == "csv":
        if ids:
            try:
                ids = [Niveau._meta.pk.to_python(niveau_id) for niveau_id in ids]
            except (TypeError, ValueError):
                return HttpResponseBadRequest("Identifiant de niveau invalide.")
            niveaux = niveaux.filter(pk__in=ids)
        response = HttpResponse(content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = 'attachment; filename="niveaux.csv"'
        response.write("\ufeff")
        writer = csv.writer(response, delimiter=";")
        writer.writerow(
            ["cycle", "code", "libelle", "libelle_court", "duree_annees", "ordre_affichage", "est_actif"]
        )

        def proteger_formule(valeur):
            valeur = str(valeur or "")
            if valeur.lstrip().startswith(("=", "+", "-", "@")):
                return "'" + valeur
            return valeur

        for niveau in niveaux:
            writer.writerow(
                [
                    proteger_formule(niveau.cycle.code),
                    proteger_formule(niveau.code),
                    proteger_formule(niveau.libelle),
                    proteger_formule(niveau.libelle_court),
                    niveau.duree_annees,
                    niveau.ordre_affichage,
                    "true" if niveau.est_actif else "false",
                ]
            )
        return response

    paginator = Paginator(niveaux, int(per_page))
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "parametrage/niveaux.html",
        {
            "niveaux": page_obj.object_list,
            "page_obj": page_obj,
            "cycles": cycles,
            "q": q,
            "filtre_cycle": cycle_id,
            "filtre_statut": statut,
            "per_page": per_page,
            "total_niveaux": paginator.count,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_niveau(request):
    if request.method == "POST":
        form = forms.FormulaireNiveau(request.POST, ecole=request.etablissement)
        if form.is_valid():
            niveau = form.save(commit=False)
            niveau.ecole = request.etablissement
            niveau.save()
            messages.success(request, f"Niveau « {niveau.libelle} » créé.")
            return redirect("parametrage:niveaux")
    else:
        form = forms.FormulaireNiveau(ecole=request.etablissement)
    return render(
        request,
        "parametrage/form_niveau.html",
        {
            "form": form,
            "cycles_disponibles": form.fields["cycle"].queryset.exists(),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_niveau(request, pk):
    niveau = get_object_or_404(Niveau, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireNiveau(request.POST, instance=niveau, ecole=request.etablissement)
        if form.is_valid():
            form.save()
            messages.success(request, f"Niveau « {niveau.libelle} » mis à jour.")
            return redirect("parametrage:niveaux")
    else:
        form = forms.FormulaireNiveau(instance=niveau, ecole=request.etablissement)
    return render(request, "parametrage/form_niveau.html", {"form": form, "objet": niveau})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_niveau(request, pk):
    niveau = get_object_or_404(Niveau, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        try:
            libelle = niveau.libelle
            niveau.delete()
            messages.success(request, f"Niveau « {libelle} » supprimé.")
        except Exception:
            messages.error(request, "Impossible de supprimer ce niveau : il est utilisé par des classes ou coefficients.")
        return redirect("parametrage:niveaux")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": niveau.libelle,
        "retour_url": "parametrage:niveaux",
    })


# ════════════════════════════════════════════════════════════════════
# MATIÈRES
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_matieres(request):
    from django.db.models import Q

    q = request.GET.get("q", "").strip()
    type_matiere = request.GET.get("type", "")
    statut = request.GET.get("statut", "")
    matieres = Matiere.objects.filter(ecole=request.etablissement)
    if q:
        matieres = matieres.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(libelle_court__icontains=q)
        )
    if type_matiere in dict(Matiere._meta.get_field("type_matiere").choices):
        matieres = matieres.filter(type_matiere=type_matiere)
    else:
        type_matiere = ""
    if statut in {"actif", "inactif"}:
        matieres = matieres.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    matieres = matieres.order_by("ordre_affichage")
    return render(request, "parametrage/matieres.html", {
        "matieres": matieres,
        "q": q,
        "filtre_type": type_matiere,
        "filtre_statut": statut,
        "type_choices": Matiere._meta.get_field("type_matiere").choices,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_matiere(request):
    if request.method == "POST":
        form = forms.FormulaireMatiere(request.POST)
        if form.is_valid():
            m = form.save(commit=False)
            m.ecole = request.etablissement
            m.save()
            messages.success(request, f"Matière « {m.libelle} » créée.")
            return redirect("parametrage:matieres")
    else:
        form = forms.FormulaireMatiere()
    return render(request, "parametrage/form_matiere.html", {"form": form})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_matiere(request, pk):
    matiere = get_object_or_404(Matiere, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireMatiere(request.POST, instance=matiere)
        if form.is_valid():
            form.save()
            messages.success(request, f"Matière « {matiere.libelle} » mise à jour.")
            return redirect("parametrage:matieres")
    else:
        form = forms.FormulaireMatiere(instance=matiere)
    return render(request, "parametrage/form_matiere.html", {"form": form, "objet": matiere})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_matiere(request, pk):
    matiere = get_object_or_404(Matiere, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        try:
            libelle = matiere.libelle
            matiere.delete()
            messages.success(request, f"Matière « {libelle} » supprimée.")
        except Exception:
            messages.error(request, "Impossible de supprimer cette matière : elle est utilisée par des coefficients ou règles.")
        return redirect("parametrage:matieres")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": matiere.libelle,
        "retour_url": "parametrage:matieres",
    })


# ════════════════════════════════════════════════════════════════════
# TYPES D'ÉVALUATION
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_types_eval(request):
    from django.db.models import Q

    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    types = TypeEvaluation.objects.filter(ecole=request.etablissement)
    if q:
        types = types.filter(Q(code__icontains=q) | Q(libelle__icontains=q))
    if statut in {"actif", "inactif"}:
        types = types.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    return render(request, "parametrage/types_evaluation.html", {
        "types": types.order_by("ordre_affichage"),
        "q": q,
        "filtre_statut": statut,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_type_eval(request):
    if request.method == "POST":
        form = forms.FormulaireTypeEvaluation(request.POST)
        if form.is_valid():
            t = form.save(commit=False)
            t.ecole = request.etablissement
            t.save()
            messages.success(request, f"Type « {t.libelle} » créé.")
            return redirect("parametrage:types_evaluation")
    else:
        form = forms.FormulaireTypeEvaluation()
    return render(request, "parametrage/form_type_eval.html", {"form": form})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_type_eval(request, pk):
    type_eval = get_object_or_404(TypeEvaluation, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireTypeEvaluation(request.POST, instance=type_eval)
        if form.is_valid():
            form.save()
            messages.success(request, f"Type « {type_eval.libelle} » mis à jour.")
            return redirect("parametrage:types_evaluation")
    else:
        form = forms.FormulaireTypeEvaluation(instance=type_eval)
    return render(request, "parametrage/form_type_eval.html", {"form": form, "objet": type_eval})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_type_eval(request, pk):
    type_eval = get_object_or_404(TypeEvaluation, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        try:
            libelle = type_eval.libelle
            type_eval.delete()
            messages.success(request, f"Type « {libelle} » supprimé.")
        except Exception:
            messages.error(request, "Impossible de supprimer ce type : il est utilisé par des notes existantes.")
        return redirect("parametrage:types_evaluation")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": type_eval.libelle,
        "retour_url": "parametrage:types_evaluation",
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_types_discipline(request):
    from django.db.models import Q

    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    types = TypeDiscipline.objects.filter(ecole=request.etablissement)
    if q:
        types = types.filter(Q(code__icontains=q) | Q(libelle__icontains=q))
    if statut in {"actif", "inactif"}:
        types = types.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    types = types.order_by("ordre_affichage", "libelle")
    return render(
        request,
        "parametrage/types_discipline.html",
        {"types": types, "q": q, "filtre_statut": statut},
    )


# ════════════════════════════════════════════════════════════════════
# COEFFICIENTS
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_coefficients(request):
    from django.db.models import Q

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    coefficients = (CoefficientsMatiere.objects
                    .filter(annee_scolaire=annee)
                    .select_related("matiere", "niveau", "niveau__cycle")
                    .prefetch_related("baremes_evaluations", "baremes_periodes")
                    .order_by("niveau__cycle__ordre_affichage", "niveau__ordre_affichage", "matiere__ordre_affichage")
                    ) if annee else CoefficientsMatiere.objects.none()
    nb_periodes = annee.periodes.count() if annee else 0
    niveaux = Niveau.objects.filter(
        ecole=request.etablissement,
        est_actif=True,
    ).select_related("cycle").order_by(
        "cycle__ordre_affichage", "ordre_affichage"
    ) if annee else Niveau.objects.none()
    if q:
        coefficients = coefficients.filter(
            Q(matiere__libelle__icontains=q)
            | Q(matiere__code__icontains=q)
            | Q(niveau__libelle__icontains=q)
            | Q(niveau__code__icontains=q)
        )
    if niveau_id:
        try:
            niveau_pk = Niveau._meta.pk.to_python(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            coefficients = coefficients.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""
    return render(request, "parametrage/coefficients.html", {
        "coefficients": coefficients,
        "annee": annee,
        "nb_periodes": nb_periodes,
        "niveaux": niveaux,
        "q": q,
        "filtre_niveau": niveau_id,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_coefficient(request):
    annee = request.annee_scolaire_courante
    if not annee or not annee.est_modifiable:
        annee = None
    retour = request.POST.get("retour") or request.GET.get("retour", "")
    if not url_has_allowed_host_and_scheme(
        retour,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        retour = ""

    if request.method == "POST":
        form = forms.FormulaireCoefficient(request.POST, ecole=request.etablissement, annee=annee)
        if form.is_valid():
            coef = form.save(commit=False)
            coef.ecole = request.etablissement
            coef.save()
            messages.success(request, f"Coefficient créé pour « {coef.matiere.libelle} ».")
            return redirect(retour or "parametrage:coefficients")
    else:
        form = forms.FormulaireCoefficient(ecole=request.etablissement, annee=annee)
        initial = {}
        for field_name in ("matiere", "niveau"):
            field = form.fields[field_name]
            value = request.GET.get(field_name)
            if value:
                try:
                    object_pk = field.queryset.model._meta.pk.to_python(value)
                except (TypeError, ValueError):
                    continue
                selected = field.queryset.filter(pk=object_pk).first()
                if selected:
                    initial[field_name] = selected
        form.initial.update(initial)
    return render(
        request,
        "parametrage/form_coefficient.html",
        {"form": form, "annee": annee, "retour_url": retour},
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_coefficient(request, pk):
    coef = get_object_or_404(
        CoefficientsMatiere.objects.filter(
            annee_scolaire__statut__in=(
                StatutAnneeScolaire.BROUILLON,
                StatutAnneeScolaire.ACTIVE,
            ),
            annee_scolaire__verrou_administratif=False,
        ),
        pk=pk,
        ecole=request.etablissement,
    )
    if request.method == "POST":
        form = forms.FormulaireCoefficient(request.POST, instance=coef, ecole=request.etablissement)
        if form.is_valid():
            form.save()
            messages.success(request, "Coefficient mis à jour.")
            return redirect("parametrage:coefficients")
    else:
        form = forms.FormulaireCoefficient(instance=coef, ecole=request.etablissement)
    return render(request, "parametrage/form_coefficient.html", {"form": form, "objet": coef})


@login_required
@requiert_tenant
@requiert_une_permission(
    "parametrage.modifier.etablissement",
    "notes.saisir.propres_classes",
    "notes.saisir.toutes_classes",
)
def configurer_bareme_coefficient(request, pk):
    coefficient = get_object_or_404(
        CoefficientsMatiere.objects.filter(
            annee_scolaire__statut__in=(
                StatutAnneeScolaire.BROUILLON,
                StatutAnneeScolaire.ACTIVE,
            ),
            annee_scolaire__verrou_administratif=False,
        ),
        pk=pk,
        ecole=request.etablissement,
    )
    from apps.securite.rbac import moteur_rbac

    if not moteur_rbac.possede_permission(
        request.user,
        request.etablissement,
        "parametrage.modifier.etablissement",
    ):
        peut_configurer = moteur_rbac.possede_permission(
            request.user,
            request.etablissement,
            "notes.saisir.toutes_classes",
        )
        a_acces_a_ses_classes = moteur_rbac.possede_permission(
            request.user,
            request.etablissement,
            "notes.saisir.propres_classes",
        )
        if not peut_configurer and a_acces_a_ses_classes:
            classes_matiere = MatiereClasse.objects.filter(
                ecole=request.etablissement,
                classe__niveau=coefficient.niveau,
                classe__annee_scolaire=coefficient.annee_scolaire,
                matiere=coefficient.matiere,
            ).filter(
                Q(enseignant__utilisateur=request.user)
                | Q(
                    affectations_enseignants__enseignant__utilisateur=request.user,
                    affectations_enseignants__est_active=True,
                )
            ).values("classe_id")
            peut_configurer = Classe.objects.filter(
                ecole=request.etablissement,
                niveau=coefficient.niveau,
                annee_scolaire=coefficient.annee_scolaire,
            ).filter(
                Q(enseignant_titulaire__utilisateur=request.user)
                | Q(pk__in=classes_matiere)
            ).exists()
        if not peut_configurer:
            raise PermissionDenied(
                "Vous ne pouvez configurer que les barèmes des matières "
                "et niveaux qui vous sont attribués."
            )
    types_evaluation = TypeEvaluation.objects.filter(
        ecole=request.etablissement,
        est_actif=True,
    ).order_by("ordre_affichage")
    periodes = PeriodeAcademique.objects.filter(
        ecole=request.etablissement,
        annee_scolaire=coefficient.annee_scolaire,
    ).order_by("numero")
    periode_id = (
        request.POST.get("periode")
        if request.method == "POST"
        else request.GET.get("periode")
    )
    periode = None
    if periode_id:
        try:
            periode_pk = PeriodeAcademique._meta.pk.to_python(periode_id)
        except (TypeError, ValueError):
            periode_pk = None
        if periode_pk is not None:
            periode = periodes.filter(pk=periode_pk).first()
        if periode is None:
            messages.error(request, "La période sélectionnée est invalide.")
            return redirect("parametrage:configurer_bareme_coefficient", pk=pk)

    form = (
        forms.FormulaireBaremeMatiere(
            request.POST if request.method == "POST" else None,
            coefficient_matiere=coefficient,
            periode=periode,
            types_evaluation=types_evaluation,
        )
        if periode
        else None
    )
    if request.method == "POST" and form and form.is_valid():
        form.save()
        messages.success(
            request,
            f"Barème de {coefficient.matiere.libelle} enregistré "
            f"pour {periode.libelle}.",
        )
        return redirect(
            f"{request.path}?periode={periode.pk}"
        )
    return render(
        request,
        "parametrage/form_bareme_matiere.html",
        {
            "coefficient": coefficient,
            "form": form,
            "periodes": periodes,
            "selected_periode": periode,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_coefficient(request, pk):
    coef = get_object_or_404(CoefficientsMatiere, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        libelle = f"{coef.matiere.libelle} — {coef.niveau.libelle}"
        coef.delete()
        messages.success(request, f"Coefficient « {libelle} » supprimé.")
        return redirect("parametrage:coefficients")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": f"{coef.matiere.libelle} — {coef.niveau.libelle}",
        "retour_url": "parametrage:coefficients",
    })


# ════════════════════════════════════════════════════════════════════
# RÈGLES DE PASSAGE
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def liste_regles_passage(request):
    from django.db.models import Q

    systeme_notation = SystemeNotation.objects.filter(
        ecole=request.etablissement,
        est_courant=True,
    ).first()
    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    statut = request.GET.get("statut", "")
    regles = (ReglePassage.objects.filter(ecole=request.etablissement)
              .select_related("niveau")
              .prefetch_related("matieres_eliminatoires"))
    niveaux = Niveau.objects.filter(ecole=request.etablissement).order_by(
        "cycle__ordre_affichage", "ordre_affichage"
    )
    if q:
        regles = regles.filter(
            Q(libelle__icontains=q)
            | Q(niveau__libelle__icontains=q)
            | Q(niveau__code__icontains=q)
            | Q(matieres_eliminatoires__libelle__icontains=q)
        ).distinct()
    if niveau_id:
        try:
            niveau_pk = Niveau._meta.pk.to_python(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            regles = regles.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""
    if statut in {"actif", "inactif"}:
        regles = regles.filter(est_active=(statut == "actif"))
    else:
        statut = ""
    return render(request, "parametrage/regles_passage.html", {
        "regles": regles,
        "niveaux": niveaux,
        "q": q,
        "filtre_niveau": niveau_id,
        "filtre_statut": statut,
        "systeme_notation": systeme_notation,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_regle_passage(request):
    if request.method == "POST":
        form = forms.FormulaireReglePassage(request.POST, ecole=request.etablissement)
        if form.is_valid():
            regle = form.save(commit=False)
            regle.ecole = request.etablissement
            regle.save()
            form.save_m2m()
            messages.success(request, f"Règle « {regle.libelle} » créée.")
            return redirect("parametrage:regles_passage")
    else:
        form = forms.FormulaireReglePassage(ecole=request.etablissement)
    systeme_notation = SystemeNotation.objects.filter(
        ecole=request.etablissement,
        est_courant=True,
    ).first()
    return render(request, "parametrage/form_regle_passage.html", {
        "form": form,
        "systeme_notation": systeme_notation,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_regle_passage(request, pk):
    regle = get_object_or_404(ReglePassage, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireReglePassage(request.POST, instance=regle, ecole=request.etablissement)
        if form.is_valid():
            form.save()
            messages.success(request, f"Règle « {regle.libelle} » mise à jour.")
            return redirect("parametrage:regles_passage")
    else:
        form = forms.FormulaireReglePassage(instance=regle, ecole=request.etablissement)
    systeme_notation = SystemeNotation.objects.filter(
        ecole=request.etablissement,
        est_courant=True,
    ).first()
    return render(request, "parametrage/form_regle_passage.html", {
        "form": form,
        "objet": regle,
        "systeme_notation": systeme_notation,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_regle_passage(request, pk):
    regle = get_object_or_404(ReglePassage, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        try:
            libelle = regle.libelle
            regle.delete()
            messages.success(request, f"Règle « {libelle} » supprimée.")
        except Exception:
            messages.error(request, "Impossible de supprimer cette règle.")
        return redirect("parametrage:regles_passage")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": regle.libelle,
        "retour_url": "parametrage:regles_passage",
    })

# ── Sections ──────────────────────────────────────────────────────────
@login_required
@requiert_tenant
def liste_sections(request):
    from django.db.models import Q

    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    statut = request.GET.get("statut", "")
    sections = Section.objects.filter(ecole=request.etablissement).select_related("niveau")
    niveaux = Niveau.objects.filter(ecole=request.etablissement).order_by(
        "cycle__ordre_affichage", "ordre_affichage"
    )
    if q:
        sections = sections.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(niveau__code__icontains=q)
            | Q(niveau__libelle__icontains=q)
        )
    if niveau_id:
        try:
            niveau_pk = Niveau._meta.pk.to_python(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            sections = sections.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""
    if statut in {"actif", "inactif"}:
        sections = sections.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    sections = sections.order_by("niveau__ordre_affichage", "ordre_affichage")
    return render(request, "parametrage/sections/liste.html", {
        "sections": sections, "niveaux": niveaux, "q": q,
        "filtre_niveau": niveau_id, "filtre_statut": statut,
    })

@login_required
@requiert_tenant
def creer_section(request):
    if request.method == "POST":
        form = forms.FormulaireSection(request.POST, ecole=request.etablissement)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.ecole = request.etablissement
            obj.save()
            messages.success(request, "Section créée avec succès.")
            return redirect("parametrage:sections")
    else:
        form = forms.FormulaireSection(ecole=request.etablissement)
    return render(request, "parametrage/sections/form.html", {"form": form, "titre": "Nouvelle section"})

@login_required
@requiert_tenant
def modifier_section(request, pk):
    obj = get_object_or_404(Section, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireSection(request.POST, instance=obj, ecole=request.etablissement)
        if form.is_valid():
            form.save()
            messages.success(request, "Section modifiée.")
            return redirect("parametrage:sections")
    else:
        form = forms.FormulaireSection(instance=obj, ecole=request.etablissement)
    return render(request, "parametrage/sections/form.html", {"form": form, "titre": "Modifier la section"})

@login_required
@requiert_tenant
def supprimer_section(request, pk):
    obj = get_object_or_404(Section, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        obj.delete()
        messages.success(request, "Section supprimée.")
        return redirect("parametrage:sections")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": str(obj),
        "retour_url": "parametrage:sections",
    })


# ── Options pédagogiques ───────────────────────────────────────────────
@login_required
@requiert_tenant
def liste_options(request):
    from django.db.models import Q

    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    statut = request.GET.get("statut", "")
    options = OptionPedagogique.objects.filter(ecole=request.etablissement).select_related("niveau")
    niveaux = Niveau.objects.filter(ecole=request.etablissement).order_by(
        "cycle__ordre_affichage", "ordre_affichage"
    )
    if q:
        options = options.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(niveau__code__icontains=q)
            | Q(niveau__libelle__icontains=q)
        )
    if niveau_id:
        try:
            niveau_pk = Niveau._meta.pk.to_python(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            options = options.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""
    if statut in {"actif", "inactif"}:
        options = options.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    options = options.order_by("niveau__ordre_affichage", "ordre_affichage")
    return render(request, "parametrage/options/liste.html", {
        "options": options, "niveaux": niveaux, "q": q,
        "filtre_niveau": niveau_id, "filtre_statut": statut,
    })

@login_required
@requiert_tenant
def creer_option(request):
    if request.method == "POST":
        form = forms.FormulaireOptionPedagogique(request.POST, ecole=request.etablissement)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.ecole = request.etablissement
            obj.save()
            messages.success(request, "Option pédagogique créée.")
            return redirect("parametrage:options_pedagogiques")
    else:
        form = forms.FormulaireOptionPedagogique(ecole=request.etablissement)
    return render(request, "parametrage/options/form.html", {"form": form, "titre": "Nouvelle option"})

@login_required
@requiert_tenant
def modifier_option(request, pk):
    obj = get_object_or_404(OptionPedagogique, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireOptionPedagogique(request.POST, instance=obj, ecole=request.etablissement)
        if form.is_valid():
            form.save()
            messages.success(request, "Option modifiée.")
            return redirect("parametrage:options_pedagogiques")
    else:
        form = forms.FormulaireOptionPedagogique(instance=obj, ecole=request.etablissement)
    return render(request, "parametrage/options/form.html", {"form": form, "titre": "Modifier l'option"})

@login_required
@requiert_tenant
def supprimer_option(request, pk):
    obj = get_object_or_404(OptionPedagogique, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        obj.delete()
        messages.success(request, "Option supprimée.")
        return redirect("parametrage:options_pedagogiques")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": str(obj),
        "retour_url": "parametrage:options_pedagogiques",
    })
# ════════════════════════════════════════════════════════════════════
# SYSTÈME DE NOTATION
# ════════════════════════════════════════════════════════════════════

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def systeme_notation(request):
    from django.db.models import Q

    systeme = SystemeNotation.objects.filter(ecole=request.etablissement, est_courant=True).first()
    q = request.GET.get("q", "").strip()
    mentions = Mention.objects.filter(
        ecole=request.etablissement, systeme_notation=systeme
    ).order_by("-moyenne_min") if systeme else Mention.objects.none()
    if q:
        mentions = mentions.filter(
            Q(libelle__icontains=q) | Q(libelle_court__icontains=q)
        )
    return render(request, "parametrage/systeme_notation.html", {
        "systeme": systeme,
        "mentions": mentions,
        "q": q,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_systeme_notation(request):
    # Pas de get_object_or_404 — on accepte qu'il n'existe pas encore
    systeme = SystemeNotation.objects.filter(
        ecole=request.etablissement,
        est_courant=True,
    ).first()  # None si pas encore créé — c'est normal

    if request.method == "POST":
        form = forms.FormulaireSystemeNotation(request.POST, instance=systeme)
        if form.is_valid():
            if systeme is None:
                # Première création
                s = form.save(commit=False)
                s.ecole = request.etablissement
                s.save()
            else:
                form.save()
            messages.success(request, "Système de notation enregistré.")
            return redirect("parametrage:systeme_notation")
    else:
        form = forms.FormulaireSystemeNotation(instance=systeme)

    return render(request, "parametrage/form_systeme_notation.html", {
        "form": form,
        "est_creation": systeme is None,  # utile pour le titre du template
    })

@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_mention(request):
    systeme = get_object_or_404(SystemeNotation, ecole=request.etablissement, est_courant=True)
    if request.method == "POST":
        form = forms.FormulaireMention(request.POST)
        if form.is_valid():
            mention = form.save(commit=False)
            mention.ecole = request.etablissement
            mention.systeme_notation = systeme
            mention.save()
            messages.success(request, f"Mention « {mention.libelle} » créée.")
            return redirect("parametrage:systeme_notation")
    else:
        form = forms.FormulaireMention()
    return render(request, "parametrage/form_mention.html", {"form": form, "systeme": systeme})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
@require_POST
@transaction.atomic
def creer_mentions_suggerees(request):
    systeme = get_object_or_404(
        SystemeNotation,
        ecole=request.etablissement,
        est_courant=True,
    )
    mentions = Mention.objects.filter(
        ecole=request.etablissement,
        systeme_notation=systeme,
    )
    if mentions.exists():
        messages.error(
            request,
            "Des mentions existent déjà. Supprimez-les avant d'ajouter le modèle suggéré.",
        )
        return redirect("parametrage:systeme_notation")

    base = systeme.base_notation
    passage = systeme.note_passage
    intervalle = base - passage
    if intervalle <= Decimal("0"):
        messages.error(
            request,
            "La base doit être supérieure à la note de passage pour créer les mentions.",
        )
        return redirect("parametrage:systeme_notation")

    centieme = Decimal("0.01")
    seuils = [
        (passage + intervalle * Decimal(position) / Decimal("5")).quantize(
            centieme,
            rounding=ROUND_HALF_UP,
        )
        for position in range(6)
    ]
    if len(set(seuils)) != len(seuils):
        messages.error(
            request,
            "L'écart entre la note de passage et la base est trop petit pour "
            "répartir les mentions suggérées. Vous pouvez ajouter les mentions "
            "individuellement ou ajuster le système de notation.",
        )
        return redirect("parametrage:systeme_notation")

    suggestions = [
        ("Passable", "P", "#22c55e"),
        ("Assez bien", "AB", "#14b8a6"),
        ("Bien", "B", "#3b82f6"),
        ("Très bien", "TB", "#8b5cf6"),
        ("Excellent", "EXC", "#f59e0b"),
    ]
    objets = [
        Mention(
            ecole=request.etablissement,
            systeme_notation=systeme,
            libelle="Insuffisant",
            libelle_court="INS",
            moyenne_min=Decimal("0"),
            moyenne_max=passage,
            couleur="#ef4444",
            ordre_affichage=1,
            est_suggeree=True,
        )
    ]
    for ordre, (libelle, court, couleur) in enumerate(
        suggestions,
        start=2,
    ):
        index = ordre - 2
        objets.append(
            Mention(
                ecole=request.etablissement,
                systeme_notation=systeme,
                libelle=libelle,
                libelle_court=court,
                moyenne_min=seuils[index],
                moyenne_max=seuils[index + 1],
                couleur=couleur,
                ordre_affichage=ordre,
                est_suggeree=True,
            )
        )

    Mention.objects.bulk_create(objets)
    messages.success(
        request,
        "Les six mentions suggérées ont été ajoutées. Vous pouvez les modifier "
        "selon le règlement de votre établissement.",
    )
    return redirect("parametrage:systeme_notation")


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_mention(request, pk):
    mention = get_object_or_404(Mention, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireMention(request.POST, instance=mention)
        if form.is_valid():
            form.save()
            messages.success(request, f"Mention « {mention.libelle} » mise à jour.")
            return redirect("parametrage:systeme_notation")
    else:
        form = forms.FormulaireMention(instance=mention)
    return render(request, "parametrage/form_mention.html", {"form": form, "objet": mention})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def supprimer_mention(request, pk):
    mention = get_object_or_404(Mention, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        libelle = mention.libelle
        mention.delete()
        messages.success(request, f"Mention « {libelle} » supprimée.")
        return redirect("parametrage:systeme_notation")
    return render(request, "parametrage/confirm_suppression.html", {
        "libelle": mention.libelle,
        "retour_url": "parametrage:systeme_notation",
    })