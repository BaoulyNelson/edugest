"""
Applique un preset JSON à une école — sans aucune traduction.

Dans le JSON, chaque section porte le nom de son modèle et chaque ligne utilise EXACTEMENT les noms
de champs du modèle. Les liens vers un autre enregistrement s'écrivent avec son code (ou son libellé
pour une année) :
    "cycle": "FOND1"            ->  Niveau.cycle            = le cycle de code FOND1
    "niveau": "1AF"             ->  Classe.niveau           = le niveau de code 1AF
    "annee_scolaire": "2026-2027"
    "matiere": "MATH"

Usage (racine du projet, venv activé) :
    python manage.py appliquer_preset --ecole <slug> --preset primaire --simulation
    python manage.py appliquer_preset --ecole <slug> --preset primaire

Règles :
  * tout est vérifié AVANT d'écrire : champ inconnu, champ d'identification manquant, section inconnue ;
  * tout ou rien : à la moindre erreur, rien n'est enregistré ;
  * relancer est sans danger : ce qui existe déjà n'est pas recréé ni modifié ;
  * l'année n'est jamais activée (ServiceAnneeScolaire.activer, qui exige des classes).
"""
import json
from pathlib import Path

from django.apps import apps
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

# (section JSON, "app.Modele", champs qui identifient une ligne, {champ lien: ("app.Modele", champ de recherche)})
SECTIONS = [
    ("cycles", "parametrage.CycleEnseignement", ["code"], {}),
    ("niveaux", "parametrage.Niveau", ["code"],
     {"cycle": ("parametrage.CycleEnseignement", "code")}),
    ("matieres", "parametrage.Matiere", ["code"], {}),
    ("annees_scolaires", "academique.AnneeScolaire", ["libelle"], {}),
    ("periodes", "academique.PeriodeAcademique", ["annee_scolaire", "type_periode", "numero"],
     {"annee_scolaire": ("academique.AnneeScolaire", "libelle")}),
    ("coefficients", "parametrage.CoefficientsMatiere", ["matiere", "niveau", "annee_scolaire"],
     {"matiere": ("parametrage.Matiere", "code"),
      "niveau": ("parametrage.Niveau", "code"),
      "annee_scolaire": ("academique.AnneeScolaire", "libelle")}),
    ("options_pedagogiques", "parametrage.OptionPedagogique", ["niveau", "code"],
     {"niveau": ("parametrage.Niveau", "code")}),
    ("classes", "academique.Classe", ["annee_scolaire", "code"],
     {"annee_scolaire": ("academique.AnneeScolaire", "libelle"),
      "niveau": ("parametrage.Niveau", "code")}),
]
METADONNEES = {"type_etablissement", "libelle"}  # décrivent le preset, ne vont dans aucun modèle


class Command(BaseCommand):
    help = "Applique un preset JSON (noms de champs identiques à ceux des modèles)."

    def add_arguments(self, parser):
        parser.add_argument("--ecole", required=True, help="Slug de l'établissement")
        parser.add_argument("--preset", required=True, help="Nom (presets/<nom>.json) ou chemin du JSON")
        parser.add_argument("--simulation", action="store_true", help="Teste sans rien enregistrer")

    # ── Chargement et vérification ───────────────────────────────────────────
    def charger(self, argument):
        chemin = Path(argument)
        if not chemin.exists() and chemin.suffix == "":
            chemin = Path("presets") / f"{argument}.json"
        if not chemin.exists():
            raise CommandError(f"Preset introuvable : {argument}")
        try:
            return json.loads(chemin.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise CommandError(f"JSON invalide ({chemin}) : {exc}")

    def verifier(self, preset):
        """Contrôle tout le fichier avant la moindre écriture."""
        erreurs = []
        connues = {s[0] for s in SECTIONS} | METADONNEES
        for cle in sorted(set(preset) - connues):
            erreurs.append(f"Section inconnue : « {cle} » (sections valides : {', '.join(s[0] for s in SECTIONS)})")
        for nom, chemin, cles, liens in SECTIONS:
            Modele = apps.get_model(chemin)
            champs = {f.name for f in Modele._meta.concrete_fields} - {"id", "ecole"}
            for i, ligne in enumerate(preset.get(nom, []), start=1):
                for champ, valeur in ligne.items():
                    if champ in champs and Modele._meta.get_field(champ).choices and not Modele._meta.get_field(champ).is_relation:
                        valides = [str(c[0]) for c in Modele._meta.get_field(champ).flatchoices]
                        if str(valeur) not in valides:
                            erreurs.append(f"{nom}[{i}] : {champ} = « {valeur} » invalide (valeurs du modèle : {', '.join(valides)})")
                for inconnu in sorted(set(ligne) - champs):
                    erreurs.append(f"{nom}[{i}] : champ « {inconnu} » absent du modèle {Modele.__name__}")
                for manquant in [c for c in cles if c not in ligne]:
                    erreurs.append(f"{nom}[{i}] : champ « {manquant} » obligatoire")
        if erreurs:
            raise CommandError("Preset invalide, rien n'a été enregistré :\n  " + "\n  ".join(erreurs[:25])
                               + (f"\n  … et {len(erreurs) - 25} autre(s)" if len(erreurs) > 25 else ""))

    # ── Exécution ────────────────────────────────────────────────────────────
    def handle(self, *args, **options):
        from apps.etablissements.models import Etablissement
        from apps.noyau.middleware import definir_tenant_courant

        preset = self.charger(options["preset"])
        self.verifier(preset)
        try:
            self.ecole = Etablissement._base_manager.get(slug=options["ecole"])
        except Etablissement.DoesNotExist:
            dispo = ", ".join(Etablissement._base_manager.values_list("slug", flat=True))
            raise CommandError(f"École « {options['ecole']} » introuvable. Disponibles : {dispo}")

        self.stdout.write(f"\nPreset : {preset.get('libelle', '?')} [{preset.get('type_etablissement', '?')}]")
        self.erreurs, self.compteurs = [], {}
        definir_tenant_courant(self.ecole)
        try:
            with transaction.atomic():
                for section in SECTIONS:
                    self.appliquer_section(preset, *section)
                if self.erreurs or options["simulation"]:
                    transaction.set_rollback(True)
        finally:
            definir_tenant_courant(None)

        self.stdout.write("\nRésumé (créés / déjà présents) :")
        for nom, (c, e) in self.compteurs.items():
            self.stdout.write(f"  {nom:<22} {c} / {e}")
        if self.erreurs:
            for e in self.erreurs:
                self.stdout.write(self.style.ERROR("  " + e))
            raise CommandError(f"{len(self.erreurs)} erreur(s) : rien n'a été enregistré.")
        if options["simulation"]:
            self.stdout.write(self.style.WARNING("SIMULATION : rien n'a été enregistré."))
        else:
            self.stdout.write(self.style.SUCCESS(
                "Terminé. L'année n'est pas activée : activez-la dans l'application (elle exige au moins une classe)."))

    def appliquer_section(self, preset, nom, chemin, cles, liens):
        lignes = preset.get(nom, [])
        if not lignes:
            return
        Modele = apps.get_model(chemin)
        self.compteurs[nom] = [0, 0]
        for i, ligne in enumerate(lignes, start=1):
            try:
                with transaction.atomic():
                    data = {}
                    for champ, valeur in ligne.items():
                        if champ in liens:
                            cible, recherche = liens[champ]
                            data[champ] = self.trouver(apps.get_model(cible), recherche, valeur)
                        elif valeur is not None:
                            data[champ] = Modele._meta.get_field(champ).to_python(valeur)
                    cherche = {c: data.pop(c) for c in cles}
                    _, cree = Modele._base_manager.get_or_create(ecole=self.ecole, **cherche, defaults=data)
                    self.compteurs[nom][0 if cree else 1] += 1
            except Exception as exc:
                self.erreurs.append(f"{nom}[{i}] : {exc}")

    def trouver(self, Cible, recherche, valeur):
        try:
            return Cible._base_manager.get(ecole=self.ecole, **{recherche: valeur})
        except ObjectDoesNotExist:
            raise ValueError(f"{Cible.__name__} « {valeur} » introuvable (vérifiez qu'il est défini plus haut dans le preset ou déjà importé)")
        except MultipleObjectsReturned:
            raise ValueError(f"plusieurs {Cible.__name__} avec {recherche} = « {valeur} »")
