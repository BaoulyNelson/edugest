"""
Import de la structure initiale d'une école depuis des fichiers CSV.

Usage (à la racine du projet, venv activé) :
    python manage.py importer_parametrage --ecole <slug> --simulation   # essai : n'enregistre rien
    python manage.py importer_parametrage --ecole <slug>                # import réel

Ordre : cycles -> niveaux -> matières -> types d'évaluation -> système de notation
        -> types de discipline -> années scolaires -> classes.
Les liens (niveau -> cycle, classe -> année et niveau) sont écrits dans les CSV par
libellé ou code, et traduits ici. Relancer la commande est sans danger : ce qui existe
déjà n'est pas recréé.
"""
import csv
import io
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.academique.models import AnneeScolaire, Classe
from apps.eleves.models import Eleve
from apps.parametrage.models import (
    CycleEnseignement, Niveau, Matiere, TypeEvaluation, SystemeNotation, TypeDiscipline,
)


class Command(BaseCommand):
    help = "Importe cycles, niveaux, matières, types d'évaluation, notation, discipline, années et classes."

    def add_arguments(self, parser):
        parser.add_argument("--ecole", required=True, help="Slug de l'école (ex. ideph)")
        parser.add_argument("--dossier", default="donnees", help="Dossier des CSV (défaut : donnees)")
        parser.add_argument("--simulation", action="store_true", help="Teste sans rien enregistrer")

    # ── Outils ────────────────────────────────────────────────────────────────

    def lire(self, nom):
        chemin = self.dossier / nom
        if not chemin.exists():
            self.stdout.write(self.style.WARNING(f"  {nom} introuvable : ignoré"))
            return []
        texte = chemin.read_text(encoding="utf-8-sig")
        try:
            dialecte = csv.Sniffer().sniff(texte[:2048], delimiters=",;\t")
        except csv.Error:
            dialecte = csv.excel
        return list(csv.DictReader(io.StringIO(texte), dialect=dialecte))

    def champs(self, Modele, ligne, exclus=()):
        """Convertit chaque cellule selon le type du champ (Decimal, int, date, booléen…)."""
        noms = {f.name for f in Modele._meta.concrete_fields}
        data = {}
        for cle, val in ligne.items():
            cle = (cle or "").strip()
            if cle in exclus:
                continue
            if cle not in noms:
                self.ignorees.add(f"{Modele.__name__}.{cle}")
                continue
            val = (val or "").strip()
            if val == "":
                continue
            data[cle] = Modele._meta.get_field(cle).to_python(val)
        return data

    def importer(self, fichier, Modele, cles, liens=None):
        """
        cles  : champs qui identifient un enregistrement (évite les doublons)
        liens : {colonne: (ModeleCible, champ_de_recherche)} pour les clés étrangères
        """
        liens = liens or {}
        crees = existants = 0
        self.stdout.write(f"{fichier} → {Modele.__name__}")
        for num, ligne in enumerate(self.lire(fichier), start=2):
            try:
                with transaction.atomic():  # une ligne en erreur n'annule pas les autres
                    data = self.champs(Modele, ligne, exclus=set(liens))
                    for col, (Cible, champ) in liens.items():
                        valeur = (ligne.get(col) or "").strip()
                        if valeur:
                            data[col] = Cible._base_manager.get(ecole=self.ecole, **{champ: valeur})
                    cherche = {c: data.pop(c) for c in cles}
                    _, cree = Modele._base_manager.get_or_create(
                        ecole=self.ecole, **cherche, defaults=data
                    )
                    crees += cree
                    existants += not cree
            except Exception as exc:
                self.erreurs.append(f"{fichier} ligne {num} : {exc}")
        self.stdout.write(f"  {crees} créé(s), {existants} déjà présent(s)")

    # ── Commande ──────────────────────────────────────────────────────────────

    def handle(self, *args, **options):
        self.dossier = Path(options["dossier"])
        self.ignorees, self.erreurs = set(), []

        Ecole = Eleve._meta.get_field("ecole").related_model
        try:
            self.ecole = Ecole._base_manager.get(slug=options["ecole"])
        except Ecole.DoesNotExist:
            dispo = ", ".join(Ecole._base_manager.values_list("slug", flat=True))
            raise CommandError(f"École « {options['ecole']} » introuvable. Disponibles : {dispo}")

        with transaction.atomic():
            self.importer("01_cycles.csv", CycleEnseignement, ["code"])
            self.importer("02_niveaux.csv", Niveau, ["cycle", "code"],
                          liens={"cycle": (CycleEnseignement, "code")})
            self.importer("03_matieres.csv", Matiere, ["code"])
            self.importer("04_types_evaluation.csv", TypeEvaluation, ["code"])
            self.importer("05_systemes_notation.csv", SystemeNotation, ["libelle"])
            self.importer("06_types_discipline.csv", TypeDiscipline, ["code"])
            self.importer("07_annees_scolaires.csv", AnneeScolaire, ["libelle"])
            self.importer("08_classes.csv", Classe, ["annee_scolaire", "code"],
                          liens={"annee_scolaire": (AnneeScolaire, "libelle"),
                                 "niveau": (Niveau, "code")})
            if options["simulation"]:
                transaction.set_rollback(True)

        if self.ignorees:
            self.stdout.write(self.style.WARNING("Colonnes ignorées (absentes du modèle) : " + ", ".join(sorted(self.ignorees))))
        for e in self.erreurs:
            self.stdout.write(self.style.ERROR(e))
        if options["simulation"]:
            self.stdout.write(self.style.WARNING("SIMULATION : rien n'a été enregistré."))
        else:
            self.stdout.write(self.style.SUCCESS(f"Terminé — {len(self.erreurs)} erreur(s)."))
