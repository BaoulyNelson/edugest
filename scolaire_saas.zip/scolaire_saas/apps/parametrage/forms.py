"""Formulaires de paramétrage."""
from django import forms
from decimal import Decimal
from apps.academique.models import (
    AnneeScolaire,
    PeriodeAcademique,
    StatutAnneeScolaire,
)
from apps.parametrage.models import (
    CycleEnseignement, Niveau, Matiere, OptionPedagogique, Section,
    TypeEvaluation, CoefficientsMatiere,
    BaremeEvaluationMatiere,
    BaremeEvaluationPeriode, BaremeMatierePeriode,
    ModeCalculMatiere, ReglePassage, SystemeNotation, Mention,
)

# ── Helpers ──────────────────────────────────────────────────────────────────

def fc(**extra):
    """form-control avec attributs optionnels."""
    return {"class": "form-control", **extra}

def fc_select(**extra):
    return {"class": "form-select", **extra}

def fc_number(**extra):
    return {"class": "form-control", "step": "0.01", **extra}

def fc_color():
    return {"class": "form-control form-control-color", "type": "color"}


# ── Cycles ───────────────────────────────────────────────────────────────────

class FormulaireCycle(forms.ModelForm):
    class Meta:
        model  = CycleEnseignement
        fields = ["code", "libelle", "description", "ordre_affichage", "couleur"]
        widgets = {
            "code":             forms.TextInput(attrs=fc(placeholder="ex: FOND")),
            "libelle":          forms.TextInput(attrs=fc(placeholder="ex: Fondamental")),
            "description":      forms.Textarea(attrs={**fc(), "rows": 2}),
            "ordre_affichage":  forms.NumberInput(attrs=fc()),
            "couleur":          forms.TextInput(attrs=fc_color()),
        }
        labels = {
            "code":            "Code court",
            "ordre_affichage": "Ordre d'affichage",
        }


# ── Niveaux ──────────────────────────────────────────────────────────────────

class FormulaireNiveau(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["cycle"].queryset = (
                CycleEnseignement.objects.filter(ecole=ecole).order_by("ordre_affichage")
            )
        self.fields["cycle"].widget.attrs.update(fc_select())

    class Meta:
        model  = Niveau
        fields = ["cycle", "code", "libelle", "libelle_court", "duree_annees", "ordre_affichage", "est_actif"]
        widgets = {
            "code":            forms.TextInput(attrs=fc(placeholder="ex: 6AF")),
            "libelle":         forms.TextInput(attrs=fc(placeholder="ex: 6e Année Fondamentale")),
            "libelle_court":   forms.TextInput(attrs=fc(placeholder="ex: 6e AF")),
            "duree_annees":    forms.NumberInput(attrs=fc()),
            "ordre_affichage": forms.NumberInput(attrs=fc()),
        }
        labels = {
            "libelle_court":   "Libellé court (bulletin)",
            "duree_annees":    "Durée (années)",
            "ordre_affichage": "Ordre d'affichage",
            "est_actif":       "Niveau actif",
        }


# ── Matières ─────────────────────────────────────────────────────────────────




class FormulaireMatiere(forms.ModelForm):
    class Meta:
        model  = Matiere
        fields = ["code", "libelle", "libelle_court", "type_matiere",
                  "ordre_affichage", "couleur", "est_actif"]
        widgets = {
            "code": forms.TextInput(attrs={
                **fc(),
                "placeholder": "Généré depuis le libellé — modifiable",
                "class": "form-control",
            }),
            "libelle":         forms.TextInput(attrs=fc(placeholder="ex: Mathématiques")),
            "libelle_court":   forms.TextInput(attrs=fc(placeholder="ex: Maths")),
            "type_matiere":    forms.Select(attrs=fc_select()),
            "ordre_affichage": forms.NumberInput(attrs=fc()),
            "couleur":         forms.TextInput(attrs=fc_color()),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            # Code figé après création (unique_together)
            self.fields["code"].widget.attrs.update({
                "readonly": True,
                "class": "form-control bg-light text-muted",
                "title": "Le code ne peut pas être modifié après création.",
            })

    def clean_code(self):
        if self.instance.pk:
            return self.instance.code   # ignorer toute tentative de modification
        return self.cleaned_data.get("code") or ""

# ── Types d'évaluation ────────────────────────────────────────────────────────

class FormulaireTypeEvaluation(forms.ModelForm):
    class Meta:
        model  = TypeEvaluation
        fields = [
            "code", "libelle", "note_max_defaut",
            "compte_dans_moyenne", "est_obligatoire", "couleur", "ordre_affichage",
        ]
        widgets = {
            "code":               forms.TextInput(attrs=fc(placeholder="ex: COMP")),
            "libelle":            forms.TextInput(attrs=fc(placeholder="ex: Composition")),
            "note_max_defaut":    forms.NumberInput(attrs=fc_number()),
            "couleur":            forms.TextInput(attrs=fc_color()),
            "ordre_affichage":    forms.NumberInput(attrs=fc()),
        }
        labels = {
            "note_max_defaut":    "Maximum indicatif par défaut",
            "compte_dans_moyenne":"Compte dans la moyenne",
            "est_obligatoire":    "Obligatoire pour tous les élèves",
            "ordre_affichage":    "Ordre d'affichage",
        }
        help_texts = {
            "note_max_defaut": (
                "Utilisé pour les évaluations informatives. Pour les composantes "
                "comptant dans la moyenne, le maximum est défini par matière."
            ),
        }


# ── Coefficients ─────────────────────────────────────────────────────────────

class FormulaireCoefficient(forms.ModelForm):
    def __init__(self, *args, ecole=None, annee=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["matiere"].queryset = (
                Matiere.objects.filter(ecole=ecole, est_actif=True).order_by("ordre_affichage")
            )
            self.fields["niveau"].queryset = (
                Niveau.objects.filter(ecole=ecole, est_actif=True)
                .select_related("cycle")
                .order_by("cycle__ordre_affichage", "ordre_affichage")
            )
            annees = AnneeScolaire.objects.filter(
                ecole=ecole,
                statut__in=(
                    StatutAnneeScolaire.BROUILLON,
                    StatutAnneeScolaire.ACTIVE,
                ),
                verrou_administratif=False,
            )
            if annee:
                annees = annees.filter(pk=annee.pk)
            self.fields["annee_scolaire"].queryset = annees
        if annee:
            self.fields["annee_scolaire"].initial = annee
            self.fields["annee_scolaire"].widget.attrs["readonly"] = True

        for f in ["matiere", "niveau", "annee_scolaire"]:
            self.fields[f].widget.attrs.update(fc_select())

    class Meta:
        model = CoefficientsMatiere
        fields = ["matiere", "niveau", "annee_scolaire", "coefficient", "est_obligatoire"]
        widgets = {
            "coefficient": forms.NumberInput(attrs=fc_number()),
        }
        labels = {
            "est_obligatoire": "Matière obligatoire",
        }


class FormulaireBaremeMatiere(forms.Form):
    """Configure le barème et la méthode de calcul d'une matière."""

    def __init__(
        self,
        *args,
        coefficient_matiere,
        periode=None,
        types_evaluation=None,
        **kwargs,
    ):
        self.coefficient_matiere = coefficient_matiere
        self.periode = periode
        self.bareme_periode = (
            BaremeMatierePeriode.objects.filter(
                ecole=coefficient_matiere.ecole,
                coefficient_matiere=coefficient_matiere,
                periode=periode,
            ).first()
            if periode
            else None
        )
        self.types_evaluation = list(
            types_evaluation
            if types_evaluation is not None
            else TypeEvaluation.objects.filter(
                ecole=coefficient_matiere.ecole,
                est_actif=True,
            ).order_by("ordre_affichage")
        )
        super().__init__(*args, **kwargs)
        if self.bareme_periode:
            composantes_config = {
                config.type_evaluation_id: config
                for config in self.bareme_periode.composantes.all()
            }
        elif periode:
            composantes_config = {
                config.type_evaluation_id: config
                for config in BaremeEvaluationMatiere.objects.filter(
                    ecole=coefficient_matiere.ecole,
                    coefficient_matiere=coefficient_matiere,
                )
            }
        else:
            composantes_config = {
                config.type_evaluation_id: config
                for config in coefficient_matiere.baremes_evaluations.all()
            }

        facteur_periode = Decimal("1")
        bareme_periode_initial = (
            self.bareme_periode.bareme_total
            if self.bareme_periode
            else coefficient_matiere.bareme_total
        )
        if periode and not self.bareme_periode:
            total_poids = sum(
                (
                    period.poids_calcul
                    for period in periode.annee_scolaire.periodes.all()
                ),
                Decimal("0"),
            )
            if total_poids:
                facteur_periode = periode.poids_calcul / total_poids
                bareme_periode_initial = (
                    coefficient_matiere.bareme_total
                    * facteur_periode
                ).quantize(Decimal("0.01"))

        self.fields["mode_calcul"] = forms.ChoiceField(
            label="Méthode de calcul",
            choices=ModeCalculMatiere.choices,
            initial=(
                self.bareme_periode.mode_calcul
                if self.bareme_periode
                else coefficient_matiere.mode_calcul
            ),
            widget=forms.Select(attrs=fc_select()),
        )
        self.fields["bareme_total"] = forms.DecimalField(
            label=(
                "Barème de cette période"
                if periode
                else "Barème total annuel de la matière"
            ),
            min_value=Decimal("0.01"),
            max_digits=7,
            decimal_places=2,
            initial=bareme_periode_initial,
            widget=forms.NumberInput(attrs=fc_number(min="0.01")),
        )
        for type_evaluation in self.types_evaluation:
            config = composantes_config.get(type_evaluation.pk)
            self.fields[self.maximum_field_name(type_evaluation)] = forms.DecimalField(
                label=type_evaluation.libelle,
                required=False,
                min_value=Decimal("0.00"),
                max_digits=7,
                decimal_places=2,
                initial=(
                    (config.points_max * facteur_periode).quantize(
                        Decimal("0.01")
                    )
                    if config
                    and periode
                    and not self.bareme_periode
                    and coefficient_matiere.mode_calcul == ModeCalculMatiere.POINTS
                    else config.points_max if config else Decimal("0.00")
                ),
                widget=forms.NumberInput(
                    attrs=fc_number(min="0", disabled=not type_evaluation.compte_dans_moyenne)
                ),
            )
            self.fields[self.weight_field_name(type_evaluation)] = forms.DecimalField(
                label=type_evaluation.libelle,
                required=False,
                min_value=Decimal("0.00"),
                max_value=Decimal("100.00"),
                max_digits=5,
                decimal_places=2,
                initial=(
                    config.poids_pourcentage
                    if config and config.poids_pourcentage is not None
                    else Decimal("0.00")
                ),
                widget=forms.NumberInput(
                    attrs=fc_number(
                        min="0",
                        max="100",
                        disabled=not type_evaluation.compte_dans_moyenne,
                    )
                ),
            )
        self.composantes = [
            (
                type_evaluation,
                self[self.maximum_field_name(type_evaluation)],
                self[self.weight_field_name(type_evaluation)],
            )
            for type_evaluation in self.types_evaluation
        ]

    @staticmethod
    def maximum_field_name(type_evaluation):
        return f"maximum_{type_evaluation.pk}"

    @staticmethod
    def weight_field_name(type_evaluation):
        return f"poids_{type_evaluation.pk}"

    def clean(self):
        cleaned = super().clean()
        bareme_total = cleaned.get("bareme_total")
        if bareme_total is None:
            return cleaned

        mode_calcul = cleaned.get("mode_calcul")
        if mode_calcul == ModeCalculMatiere.POINTS:
            total_attribue = sum(
                (
                    cleaned.get(self.maximum_field_name(type_evaluation))
                    or Decimal("0")
                    for type_evaluation in self.types_evaluation
                    if type_evaluation.compte_dans_moyenne
                ),
                Decimal("0"),
            )
            valeur_attendue = bareme_total
            libelle_total = (
                "le barème de la période"
                if self.periode
                else "le barème total de la matière"
            )
        elif mode_calcul == ModeCalculMatiere.PONDERATION:
            total_attribue = sum(
                (
                    cleaned.get(self.weight_field_name(type_evaluation))
                    or Decimal("0")
                    for type_evaluation in self.types_evaluation
                    if type_evaluation.compte_dans_moyenne
                ),
                Decimal("0"),
            )
            valeur_attendue = Decimal("100.00")
            libelle_total = "100 % de pondération"
            for type_evaluation in self.types_evaluation:
                if not type_evaluation.compte_dans_moyenne:
                    continue
                weight = cleaned.get(self.weight_field_name(type_evaluation)) or Decimal("0")
                maximum = cleaned.get(self.maximum_field_name(type_evaluation)) or Decimal("0")
                if weight > 0 and maximum <= 0:
                    self.add_error(
                        self.maximum_field_name(type_evaluation),
                        "Un maximum supérieur à zéro est requis pour une composante pondérée.",
                    )
        else:
            return cleaned

        if total_attribue != valeur_attendue:
            self.add_error(
                None,
                f"Le total configuré ({total_attribue}) doit être égal à "
                f"{libelle_total} ({valeur_attendue}).",
            )
        elif total_attribue <= 0:
            self.add_error(
                None,
                "Configurez au moins une composante comptant dans la moyenne.",
            )
        if self.periode:
            baremes_autres_periodes = BaremeMatierePeriode.objects.filter(
                ecole=self.coefficient_matiere.ecole,
                coefficient_matiere=self.coefficient_matiere,
            ).exclude(periode=self.periode)
            total_autres_periodes = sum(
                baremes_autres_periodes.values_list("bareme_total", flat=True),
                Decimal("0"),
            )
            total_annuel_configure = total_autres_periodes + bareme_total
            if total_annuel_configure > self.coefficient_matiere.bareme_total:
                self.add_error(
                    "bareme_total",
                    "Le total configuré pour les périodes dépasse le barème annuel "
                    f"de {self.coefficient_matiere.bareme_total} points.",
                )
        return cleaned

    def save(self):
        from django.db import transaction

        if not self.is_valid():
            raise ValueError("Le formulaire de barème doit être valide avant l'enregistrement.")

        with transaction.atomic():
            coefficient = self.coefficient_matiere
            if self.periode:
                bareme_periode, _ = BaremeMatierePeriode.objects.update_or_create(
                    ecole=coefficient.ecole,
                    coefficient_matiere=coefficient,
                    periode=self.periode,
                    defaults={
                        "bareme_total": self.cleaned_data["bareme_total"],
                        "mode_calcul": self.cleaned_data["mode_calcul"],
                    },
                )
                bareme_periode.full_clean()
                bareme_periode.save()
                BaremeEvaluationPeriode.objects.filter(
                    ecole=coefficient.ecole,
                    bareme_periode=bareme_periode,
                ).delete()
            else:
                coefficient.bareme_total = self.cleaned_data["bareme_total"]
                coefficient.mode_calcul = self.cleaned_data["mode_calcul"]
                coefficient.save()
                BaremeEvaluationMatiere.objects.filter(
                    ecole=coefficient.ecole,
                    coefficient_matiere=coefficient,
                ).delete()

            configurations = []
            for type_evaluation in self.types_evaluation:
                maximum = self.cleaned_data.get(
                    self.maximum_field_name(type_evaluation)
                )
                weight = self.cleaned_data.get(
                    self.weight_field_name(type_evaluation)
                )
                if (
                    type_evaluation.compte_dans_moyenne
                    and (
                        (maximum is not None and maximum > 0)
                        or (weight is not None and weight > 0)
                    )
                ):
                    configuration_data = {
                        "ecole": coefficient.ecole,
                        "type_evaluation": type_evaluation,
                        "points_max": maximum or Decimal("0"),
                        "poids_pourcentage": (
                            weight
                            if self.cleaned_data["mode_calcul"]
                            == ModeCalculMatiere.PONDERATION
                            else None
                        ),
                    }
                    if self.periode:
                        configurations.append(
                            BaremeEvaluationPeriode(
                                bareme_periode=bareme_periode,
                                **configuration_data,
                            )
                        )
                    else:
                        configurations.append(
                            BaremeEvaluationMatiere(
                                coefficient_matiere=coefficient,
                                **configuration_data,
                            )
                        )
            if self.periode:
                for configuration in configurations:
                    configuration.full_clean()
                BaremeEvaluationPeriode.objects.bulk_create(configurations)
            else:
                BaremeEvaluationMatiere.objects.bulk_create(configurations)
        return coefficient


# ── Règles de passage ────────────────────────────────────────────────────────

class FormulaireReglePassage(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["niveau"].queryset = (
                Niveau.objects.filter(ecole=ecole, est_actif=True)
                .select_related("cycle")
                .order_by("cycle__ordre_affichage", "ordre_affichage")
            )
            self.fields["matieres_eliminatoires"].queryset = (
                Matiere.objects.filter(ecole=ecole, est_actif=True).order_by("ordre_affichage")
            )

        self.fields["niveau"].widget.attrs.update(fc_select())
        # Checkbox list pour les matières éliminatoires
        self.fields["matieres_eliminatoires"].widget = forms.CheckboxSelectMultiple()
        self.fields["matieres_eliminatoires"].required = False

    class Meta:
        model  = ReglePassage
        fields = [
            "niveau", "libelle", "moyenne_passage",
            "matieres_eliminatoires", "seuil_eliminatoire",
            "nb_matieres_insuffisantes_max", "est_active",
        ]
        widgets = {
            "libelle":                      forms.TextInput(attrs=fc(placeholder="ex: Règle Fondamental")),
            "moyenne_passage":              forms.NumberInput(attrs=fc_number()),
            "seuil_eliminatoire":           forms.NumberInput(attrs=fc_number()),
            "nb_matieres_insuffisantes_max": forms.NumberInput(attrs=fc()),
        }
        labels = {
            "moyenne_passage":               "Seuil spécifique à ce niveau (facultatif)",
            "matieres_eliminatoires":        "Matières éliminatoires",
            "seuil_eliminatoire":            "Seuil éliminatoire (note minimale)",
            "nb_matieres_insuffisantes_max": "Nombre max de matières insuffisantes toléré",
            "est_active":                    "Règle active",
        }
        help_texts = {
            "moyenne_passage": (
                "Laisser vide pour reprendre la note de passage du système de notation."
            ),
            "seuil_eliminatoire":            "En dessous de ce seuil dans une matière éliminatoire → refus automatique.",
            "nb_matieres_insuffisantes_max": "Laisser vide = aucune tolérance.",
        }

    def clean(self):
        cleaned = super().clean()
        elim   = cleaned.get("matieres_eliminatoires")
        seuil  = cleaned.get("seuil_eliminatoire")

        # Si des matières éliminatoires sont choisies, le seuil est obligatoire
        if elim and elim.exists() and seuil is None:
            self.add_error(
                "seuil_eliminatoire",
                "Un seuil éliminatoire est requis quand des matières éliminatoires sont définies.",
            )
        return cleaned

class FormulaireSection(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["niveau"].queryset = Niveau.objects.filter(ecole=ecole, est_actif=True)

    class Meta:
        model = Section
        fields = ["niveau", "code", "libelle", "ordre_affichage"]
        widgets = {
            "niveau":          forms.Select(attrs={"class": "form-select"}),
            "code":            forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex: A, B, S"}),
            "libelle":         forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex: Section A"}),
            "ordre_affichage": forms.NumberInput(attrs={"class": "form-control"}),
        }


class FormulaireOptionPedagogique(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["niveau"].queryset = Niveau.objects.filter(ecole=ecole, est_actif=True)

    class Meta:
        model = OptionPedagogique
        fields = ["niveau", "code", "libelle", "ordre_affichage"]
        widgets = {
            "niveau":          forms.Select(attrs={"class": "form-select"}),
            "code":            forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex: SM, LH, COM"}),
            "libelle":         forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex: Sciences-Maths"}),
            "ordre_affichage": forms.NumberInput(attrs={"class": "form-control"}),
        }
# ── Système de notation ───────────────────────────────────────────────────────

class FormulaireSystemeNotation(forms.ModelForm):
    class Meta:
        model  = SystemeNotation
        fields = [
            "libelle",
            "base_notation",
            "note_passage",
            "methode_arrondi",
            "est_courant",
        ]
        widgets = {
            "libelle":        forms.TextInput(attrs=fc(placeholder="ex: Système haïtien /10")),
            "base_notation":  forms.NumberInput(attrs=fc_number()),
            "note_passage":   forms.NumberInput(attrs=fc_number()),
            "methode_arrondi": forms.Select(attrs=fc_select()),
        }
        labels = {
            "base_notation":  "Base des moyennes",
            "note_passage":   "Note de passage",
            "methode_arrondi": "Règle d’arrondi",
            "est_courant":    "Système actif",
        }
        help_texts = {
            "base_notation":  (
                "Les moyennes finales sont exprimées sur cette base. "
                "Exemple : 78,4/100 équivaut à 7,84/10."
            ),
            "note_passage":   "Moyenne minimale, exprimée sur la base choisie ci-dessus.",
            "methode_arrondi": (
                "Les calculs conservent quatre décimales; l'affichage du bulletin "
                "est arrondi à deux décimales."
            ),
        }

    def clean(self):
        cleaned = super().clean()
        base    = cleaned.get("base_notation")
        passage = cleaned.get("note_passage")
        if base and passage and passage >= base:
            self.add_error(
                "note_passage",
                f"La note de passage ({passage}) doit être inférieure à la base ({base}).",
            )
        return cleaned


# ── Mentions ──────────────────────────────────────────────────────────────────

class FormulaireMention(forms.ModelForm):
    class Meta:
        model  = Mention
        fields = ["libelle", "libelle_court", "moyenne_min", "moyenne_max", "couleur", "ordre_affichage"]
        widgets = {
            "libelle":         forms.TextInput(attrs=fc(placeholder="ex: Excellent")),
            "libelle_court":   forms.TextInput(attrs=fc(placeholder="ex: Exc.")),
            "moyenne_min":     forms.NumberInput(attrs=fc_number()),
            "moyenne_max":     forms.NumberInput(attrs=fc_number()),
            "couleur":         forms.TextInput(attrs=fc_color()),
            "ordre_affichage": forms.NumberInput(attrs=fc()),
        }
        labels = {
            "libelle_court":   "Libellé court",
            "moyenne_min":     "Moyenne minimale",
            "moyenne_max":     "Moyenne maximale",
            "ordre_affichage": "Ordre d'affichage",
        }

    def clean(self):
        cleaned = super().clean()
        min_val = cleaned.get("moyenne_min")
        max_val = cleaned.get("moyenne_max")
        if min_val is not None and max_val is not None and min_val >= max_val:
            self.add_error(
                "moyenne_max",
                f"La moyenne max ({max_val}) doit être supérieure à la moyenne min ({min_val}).",
            )
        return cleaned