from django.urls import path
from apps.parametrage import views

app_name = "parametrage"

urlpatterns = [

    # ── Index ────────────────────────────────────────────────────────
    path("", views.index_parametrage, name="index"),

    # ── Cycles ───────────────────────────────────────────────────────
    path("cycles/",                          views.liste_cycles,    name="cycles"),
    path("cycles/creer/",                    views.creer_cycle,     name="creer_cycle"),
    path("cycles/<int:pk>/modifier/",        views.modifier_cycle,  name="modifier_cycle"),
    path("cycles/<int:pk>/supprimer/",       views.supprimer_cycle, name="supprimer_cycle"),

    # ── Niveaux ──────────────────────────────────────────────────────
    path("niveaux/",                         views.liste_niveaux,    name="niveaux"),
    path("niveaux/creer/",                   views.creer_niveau,     name="creer_niveau"),
    path("niveaux/<int:pk>/modifier/",       views.modifier_niveau,  name="modifier_niveau"),
    path("niveaux/<int:pk>/supprimer/",      views.supprimer_niveau, name="supprimer_niveau"),

    # ── Matières ─────────────────────────────────────────────────────
    path("matieres/",                        views.liste_matieres,    name="matieres"),
    path("matieres/creer/",                  views.creer_matiere,     name="creer_matiere"),
    path("matieres/<int:pk>/modifier/",      views.modifier_matiere,  name="modifier_matiere"),
    path("matieres/<int:pk>/supprimer/",     views.supprimer_matiere, name="supprimer_matiere"),

    # ── Types d'évaluation ───────────────────────────────────────────
    path("types-evaluation/",               views.liste_types_eval,    name="types_evaluation"),
    path("types-evaluation/creer/",         views.creer_type_eval,     name="creer_type_eval"),
    path("types-evaluation/<int:pk>/modifier/",  views.modifier_type_eval,  name="modifier_type_eval"),
    path("types-evaluation/<int:pk>/supprimer/", views.supprimer_type_eval, name="supprimer_type_eval"),

    # ── Types de discipline ──────────────────────────────────────────
    path("types-discipline/", views.liste_types_discipline, name="types_discipline"),

    # ── Coefficients ─────────────────────────────────────────────────
    path("coefficients/",                   views.liste_coefficients,   name="coefficients"),
    path("coefficients/creer/",             views.creer_coefficient,    name="creer_coefficient"),
    path("coefficients/<int:pk>/modifier/", views.modifier_coefficient, name="modifier_coefficient"),
    path("coefficients/<int:pk>/bareme/", views.configurer_bareme_coefficient, name="configurer_bareme_coefficient"),
    path("coefficients/<int:pk>/supprimer/",views.supprimer_coefficient,name="supprimer_coefficient"),

    # ── Règles de passage ─────────────────────────────────────────────
    path("regles-passage/",                      views.liste_regles_passage,   name="regles_passage"),
    path("regles-passage/creer/",                views.creer_regle_passage,    name="creer_regle_passage"),
    path("regles-passage/<int:pk>/modifier/",    views.modifier_regle_passage, name="modifier_regle_passage"),
    path("regles-passage/<int:pk>/supprimer/",   views.supprimer_regle_passage,name="supprimer_regle_passage"),


    # ── Sections ─────────────────────────────────────────────────────
    path("sections/",                         views.liste_sections,    name="sections"),
    path("sections/creer/",                   views.creer_section,     name="creer_section"),
    path("sections/<int:pk>/modifier/",       views.modifier_section,  name="modifier_section"),
    path("sections/<int:pk>/supprimer/",      views.supprimer_section, name="supprimer_section"),

    # ── Options pédagogiques ──────────────────────────────────────────
    path("options-pedagogiques/",                         views.liste_options,    name="options_pedagogiques"),
    path("options-pedagogiques/creer/",                   views.creer_option,     name="creer_option"),
    path("options-pedagogiques/<int:pk>/modifier/",       views.modifier_option,  name="modifier_option"),
    path("options-pedagogiques/<int:pk>/supprimer/",      views.supprimer_option, name="supprimer_option"),
    # ── Système de notation ───────────────────────────────────────────
    path("systeme-notation/",                    views.systeme_notation,         name="systeme_notation"),
    path("systeme-notation/modifier/",           views.modifier_systeme_notation,name="modifier_systeme_notation"),
    path("systeme-notation/mentions/creer/",     views.creer_mention,            name="creer_mention"),
    path("systeme-notation/mentions/suggestions/", views.creer_mentions_suggerees, name="creer_mentions_suggerees"),
    path("systeme-notation/mentions/<int:pk>/modifier/",  views.modifier_mention,  name="modifier_mention"),
    path("systeme-notation/mentions/<int:pk>/supprimer/", views.supprimer_mention, name="supprimer_mention"),
]