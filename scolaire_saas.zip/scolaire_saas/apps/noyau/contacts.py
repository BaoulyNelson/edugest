import re

from django.apps import apps
from django.core.exceptions import ValidationError

from apps.noyau.models import ContactUnique


CHAMPS_CONTACT = {
    "comptes.Utilisateur": {
        "email": ContactUnique.TYPE_EMAIL,
        "telephone": ContactUnique.TYPE_TELEPHONE,
    },
    "enseignants.Enseignant": {
        "email": ContactUnique.TYPE_EMAIL,
        "telephone": ContactUnique.TYPE_TELEPHONE,
    },
    "etablissements.Etablissement": {
        "email": ContactUnique.TYPE_EMAIL,
        "telephone": ContactUnique.TYPE_TELEPHONE,
        "telephone_secondaire": ContactUnique.TYPE_TELEPHONE,
    },
    "eleves.Eleve": {
        "telephone_parent1": ContactUnique.TYPE_TELEPHONE,
    },
}


def normaliser_contact(type_contact, valeur):
    valeur = (valeur or "").strip()
    if not valeur:
        return ""
    if type_contact == ContactUnique.TYPE_EMAIL:
        return valeur.casefold()
    return "".join(re.findall(r"\d", valeur))


def valeurs_contact(instance):
    valeurs = {}
    for champ, type_contact in CHAMPS_CONTACT.get(instance._meta.label, {}).items():
        valeur = normaliser_contact(type_contact, getattr(instance, champ, ""))
        if valeur:
            valeurs[champ] = (type_contact, valeur)
    return valeurs


def portee_contact(instance):
    ecole_id = getattr(instance, "ecole_id", None)
    return str(ecole_id) if ecole_id is not None else "global"


def verifier_contacts_uniques(instance):
    valeurs = valeurs_contact(instance)
    erreurs = {}
    source_modele = instance._meta.label_lower
    source_pk = str(instance.pk) if instance.pk else None
    portee = portee_contact(instance)

    for champ, (type_contact, valeur) in valeurs.items():
        doublon = ContactUnique.objects.filter(
            type_contact=type_contact,
            valeur_normalisee=valeur,
            portee=portee,
        )
        if source_pk:
            doublon = doublon.exclude(
                modele_source=source_modele,
                identifiant_source=source_pk,
                champ_source=champ,
            )
        if doublon.exists():
            label = (
                "adresse email"
                if type_contact == ContactUnique.TYPE_EMAIL
                else "numéro de téléphone"
            )
            erreurs[champ] = f"Cette {label} est déjà utilisée par une autre fiche."

    for champ, (type_contact, valeur) in valeurs.items():
        if any(
            autre_champ != champ
            and autre_type == type_contact
            and autre_valeur == valeur
            for autre_champ, (autre_type, autre_valeur) in valeurs.items()
        ):
            erreurs[champ] = "Cette coordonnée est déjà utilisée dans une autre fiche."

    if erreurs:
        raise ValidationError(erreurs)


def synchroniser_contacts(instance, **kwargs):
    if instance.pk is None:
        return

    source_modele = instance._meta.label_lower
    source_pk = str(instance.pk)
    contacts = valeurs_contact(instance)
    ContactUnique.objects.filter(
        modele_source=source_modele,
        identifiant_source=source_pk,
    ).exclude(champ_source__in=contacts).delete()

    for champ, (type_contact, valeur) in contacts.items():
        ContactUnique.objects.update_or_create(
            modele_source=source_modele,
            identifiant_source=source_pk,
            champ_source=champ,
            defaults={
                "type_contact": type_contact,
                "valeur_normalisee": valeur,
            "portee": portee_contact(instance),
            },
        )


def supprimer_contacts(instance, **kwargs):
    if instance.pk is None:
        return
    ContactUnique.objects.filter(
        modele_source=instance._meta.label_lower,
        identifiant_source=str(instance.pk),
    ).delete()


def installer_signaux_contacts():
    from django.db.models.signals import post_delete, post_save

    for label in CHAMPS_CONTACT:
        model = apps.get_model(label)
        post_save.connect(
            synchroniser_contacts,
            sender=model,
            dispatch_uid=f"contact_unique_save_{label}",
        )
        post_delete.connect(
            supprimer_contacts,
            sender=model,
            dispatch_uid=f"contact_unique_delete_{label}",
        )
