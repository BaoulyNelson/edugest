"""Vues publiques de l'application noyau."""

from django.shortcuts import render
from apps.noyau.vues_tableau_bord import tableau_bord


def _reponse_erreur(request, template, status):
    return render(request, template, status=status)


def erreur_403(request, exception=None):
    return _reponse_erreur(request, "erreurs/403.html", 403)


def erreur_404(request, exception=None):
    return _reponse_erreur(request, "erreurs/404.html", 404)


def erreur_500(request):
    return _reponse_erreur(request, "erreurs/500.html", 500)
