from django.apps import AppConfig

class NoyauConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.noyau"
    verbose_name = "Infrastructure transversale multitenant"

    def ready(self):
        from apps.noyau.contacts import installer_signaux_contacts

        installer_signaux_contacts()
