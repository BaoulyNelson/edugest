"""Import CSV protégé pour les listes de configuration de l'établissement."""

import csv
import io

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import IntegrityError, transaction
from django.http import HttpResponse
from django.shortcuts import render
from django.urls import reverse
from django.utils.text import slugify

from apps.noyau.decorateurs import requiert_tenant
from apps.noyau.import_csv import IMPORTS_CSV
from apps.securite.rbac import moteur_rbac

_IGNORER = object()


def _convertir_valeur(champ, valeur, ecole, champ_recherche=None):
    valeur = (valeur or "").strip()
    if not valeur:
        if champ.has_default():
            return _IGNORER
        if champ.null:
            return None
        if champ.blank:
            return ""
        raise ValueError(f"Le champ « {champ.verbose_name} » est obligatoire.")

    if champ.is_relation and champ.many_to_one:
        cible = champ.remote_field.model
        champ_recherche = champ_recherche or cible._meta.pk.name
        valeur_recherchee = (
            cible._meta.pk.to_python(valeur)
            if champ_recherche == cible._meta.pk.name
            else valeur
        )
        objets = cible._default_manager.filter(
            **{champ_recherche: valeur_recherchee}
        )
        if any(f.name == "ecole" for f in cible._meta.fields):
            objets = objets.filter(ecole=ecole)
        try:
            return objets.get()
        except cible.DoesNotExist as exc:
            raise ValueError(
                f"Valeur « {valeur} » introuvable pour « {champ.verbose_name} » "
                "dans cet établissement."
            ) from exc
    return champ.to_python(valeur)


def _champ_requis_dans_entete(spec, nom):
    if nom in spec.optional_fields:
        return False
    nom_champ = nom[:-3] if nom.endswith("_id") else nom
    champ = spec.model._meta.get_field(nom_champ)
    return not (champ.has_default() or champ.null or champ.blank)


@login_required
@requiert_tenant
def importer_csv(request, modele):
    spec = IMPORTS_CSV.get(modele)
    if spec is None:
        raise PermissionDenied("Cet import CSV n'est pas disponible.")
    if not moteur_rbac.possede_permission(
        utilisateur=request.user,
        ecole=request.etablissement,
        code_permission=spec.permission,
    ):
        raise PermissionDenied(f"Vous n'avez pas la permission : {spec.permission}")

    if request.method == "GET" and request.GET.get("modele_csv") == "1":
        response = HttpResponse(content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = (
            f'attachment; filename="{slugify(spec.model._meta.verbose_name_plural)}.csv"'
        )
        response.write("\ufeff")
        csv.writer(response, delimiter=";").writerow(spec.fields)
        return response

    resultats = None
    if request.method == "POST":
        fichier = request.FILES.get("fichier_csv")
        if not fichier:
            messages.error(request, "Sélectionnez un fichier CSV.")
        else:
            try:
                contenu = fichier.read().decode("utf-8-sig")
                try:
                    dialecte = csv.Sniffer().sniff(
                        contenu[:2048], delimiters=",;\t"
                    )
                except csv.Error:
                    dialecte = csv.excel
                lecteur = csv.DictReader(io.StringIO(contenu), dialect=dialecte)
                entetes = set(lecteur.fieldnames or [])
                alias_par_champ = {
                    champ.removesuffix("_id"): (colonne, champ_recherche)
                    for colonne, champ, champ_recherche in spec.relation_aliases
                }
                champs_manquants = {
                    nom
                    for nom in spec.fields
                    if nom not in entetes
                    and _champ_requis_dans_entete(spec, nom)
                    and (
                        nom.removesuffix("_id") not in alias_par_champ
                        or alias_par_champ[nom.removesuffix("_id")][0] not in entetes
                    )
                }
                if champs_manquants:
                    manquants = [
                        f"{nom} (ou {alias_par_champ[nom.removesuffix('_id')][0]})"
                        if nom.removesuffix("_id") in alias_par_champ
                        else nom
                        for nom in sorted(champs_manquants)
                    ]
                    raise ValueError(
                        "Colonnes manquantes : " + ", ".join(manquants)
                    )
                crees, existants, erreurs = 0, 0, []
                for numero, ligne in enumerate(lecteur, start=2):
                    try:
                        with transaction.atomic():
                            donnees = {}
                            for nom in spec.fields:
                                colonne = nom
                                champ_recherche = None
                                champ_nom = nom.removesuffix("_id")
                                if colonne not in ligne and champ_nom in alias_par_champ:
                                    colonne, champ_recherche = alias_par_champ[champ_nom]
                                if colonne not in ligne or ligne[colonne] is None:
                                    continue
                                champ = spec.model._meta.get_field(champ_nom)
                                valeur = _convertir_valeur(
                                    champ,
                                    ligne[colonne],
                                    request.etablissement,
                                    champ_recherche=champ_recherche,
                                )
                                if valeur is not _IGNORER:
                                    donnees[champ_nom] = valeur
                            donnees["ecole"] = request.etablissement
                            cle = {
                                nom: donnees[nom]
                                for nom in spec.identity_fields
                                if nom in donnees
                            }
                            if (
                                len(cle) == len(spec.identity_fields)
                                and spec.model.objects.filter(
                                    ecole=request.etablissement, **cle
                                ).exists()
                            ):
                                existants += 1
                                continue
                            instance = spec.model(**donnees)
                            instance.full_clean()
                            instance.save()
                        crees += 1
                    except (
                        ValidationError,
                        ValueError,
                        TypeError,
                        IntegrityError,
                        OverflowError,
                    ) as erreur:
                        erreurs.append(f"Ligne {numero} : {erreur}")
                resultats = {
                    "crees": crees,
                    "existants": existants,
                    "erreurs": erreurs,
                }
            except (UnicodeDecodeError, csv.Error, ValueError) as erreur:
                messages.error(request, f"Import impossible : {erreur}")

    return render(
        request,
        "noyau/importer_csv.html",
        {
            "nom_modele": spec.model._meta.verbose_name,
            "champs": spec.fields,
            "url_modele": reverse("importer_csv", kwargs={"modele": modele})
            + "?modele_csv=1",
            "retour_url": spec.return_url,
            "resultats": resultats,
        },
    )
