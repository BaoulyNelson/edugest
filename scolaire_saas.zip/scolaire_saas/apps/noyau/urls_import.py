from django.urls import path

from apps.noyau.import_views import importer_csv

urlpatterns = [
    path("importer/<slug:modele>/", importer_csv, name="importer_csv"),
]
