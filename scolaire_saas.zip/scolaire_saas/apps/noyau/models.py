from django.db import models


class ContactUnique(models.Model):
    TYPE_EMAIL = "email"
    TYPE_TELEPHONE = "telephone"
    TYPES = [
        (TYPE_EMAIL, "Adresse email"),
        (TYPE_TELEPHONE, "Numéro de téléphone"),
    ]

    type_contact = models.CharField(max_length=12, choices=TYPES)
    valeur_normalisee = models.CharField(max_length=320)
    portee = models.CharField(max_length=64, default="global")
    modele_source = models.CharField(max_length=100)
    identifiant_source = models.CharField(max_length=64)
    champ_source = models.CharField(max_length=40)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["type_contact", "valeur_normalisee", "portee"],
                name="unique_contact_normalise",
            ),
            models.UniqueConstraint(
                fields=["modele_source", "identifiant_source", "champ_source"],
                name="unique_contact_source",
            ),
        ]
