"""Vue du tableau de bord principal."""

import json
from collections import defaultdict
from datetime import date, datetime, time
from decimal import Decimal

from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Count, DecimalField, ExpressionWrapper, F, Q, Sum
from django.db.models.functions import TruncMonth
from django.shortcuts import render
from django.utils import timezone
from django.utils.formats import date_format
from django.utils.formats import number_format

from apps.noyau.decorateurs import requiert_tenant


@login_required
@requiert_tenant
def tableau_bord(request):
    """Tableau de bord principal — adapté selon le rôle de l'utilisateur."""
    contexte = _construire_contexte_tableau_bord(
        request.etablissement,
        request.user,
        request.annee_scolaire_courante,
    )
    return render(request, "tableau_bord/index.html", contexte)


def _mois_debut_a_fin(debut: date, fin: date) -> list[date]:
    mois = debut.replace(day=1)
    dernier_mois = fin.replace(day=1)
    resultat = []
    while mois <= dernier_mois:
        resultat.append(mois)
        if mois.month == 12:
            mois = date(mois.year + 1, 1, 1)
        else:
            mois = date(mois.year, mois.month + 1, 1)
    return resultat


def _preparer_graphique_mensuel(mois_annee, valeurs, format_valeur):
    maximum = max(valeurs.values(), default=0)
    points = [
        {
            "label": date_format(mois, "M Y"),
            "valeur": valeurs.get(mois, 0),
            "valeur_affichee": format_valeur(valeurs.get(mois, 0)),
            "hauteur": round(valeurs.get(mois, 0) / maximum * 100) if maximum else 0,
        }
        for mois in mois_annee
    ]
    return {"points": points, "a_donnees": bool(maximum)}


def _cle_mois(valeur):
    if isinstance(valeur, datetime):
        valeur = valeur.date()
    return valeur.replace(day=1)


def _construire_contexte_tableau_bord(ecole, utilisateur, annee) -> dict:
    from apps.academique.models import Classe, PeriodeAcademique
    from apps.eleves.models import Inscription, Sexe, StatutInscription
    from apps.finances.models import FraisEleve, Paiement, StatutPaiement
    from apps.notes.models import MoyenneGenerale

    stats = {
        "nb_eleves": 0,
        "nb_classes": 0,
        "nb_bulletins_publies": 0,
        "montant_encaisse": Decimal("0.00"),
        "taux_recouvrement": 0,
        "taux_remplissage": None,
        "a_capacite": False,
    }
    graphiques = {
        "inscriptions": {"points": [], "a_donnees": False},
        "paiements": {"points": [], "a_donnees": False},
        "resultats": {"points": [], "a_donnees": False, "labels": [], "valeurs": []},
        "genres": {"labels": [], "valeurs": [], "elements": [], "a_donnees": False},
        "recouvrement": {"labels": [], "valeurs": [], "a_donnees": False},
    }
    classes_capacite = []

    if annee:
        mois_annee = _mois_debut_a_fin(annee.date_debut, annee.date_fin)
        debut, fin = annee.date_debut, annee.date_fin

        inscriptions = Inscription.objects.filter(
            ecole=ecole,
            annee_scolaire=annee,
            statut=StatutInscription.VALIDEE,
        )
        stats["nb_eleves"] = inscriptions.count()
        stats["nb_classes"] = annee.classes.filter(ecole=ecole, est_actif=True).count()
        repartition_genres = dict(
            inscriptions.values("eleve__sexe")
            .annotate(total=Count("pk"))
            .values_list("eleve__sexe", "total")
        )
        genres_labels = [
            Sexe.FEMININ.label,
            Sexe.MASCULIN.label,
            "Non renseigné",
        ]
        genres_valeurs = [
            repartition_genres.get(Sexe.FEMININ, 0),
            repartition_genres.get(Sexe.MASCULIN, 0),
            sum(
                total
                for sexe, total in repartition_genres.items()
                if sexe not in (Sexe.MASCULIN, Sexe.FEMININ)
            ),
        ]
        genres_total = sum(genres_valeurs)
        genres_couleurs = ["#ec4899", "#3b82f6", "#aab5c2"]
        graphiques["genres"] = {
            "labels": genres_labels,
            "valeurs": genres_valeurs,
            "couleurs": genres_couleurs,
            "elements": [
                {
                    "label": label,
                    "valeur": valeur,
                    "pourcentage": (
                        f"{valeur / genres_total * 100:.2f}%"
                        if genres_total
                        else "0.00%"
                    ),
                    "couleur": couleur,
                }
                for label, valeur, couleur in zip(
                    genres_labels,
                    genres_valeurs,
                    genres_couleurs,
                )
            ],
            "a_donnees": any(genres_valeurs),
        }

        classes = (
            Classe.objects.filter(ecole=ecole, annee_scolaire=annee, est_actif=True)
            .annotate(
                nb_inscrits=Count(
                    "inscriptions",
                    filter=Q(inscriptions__statut=StatutInscription.VALIDEE),
                )
            )
            .order_by("code")
        )
        classes_avec_capacite = [classe for classe in classes if classe.capacite_max]
        capacite_totale = sum(classe.capacite_max for classe in classes_avec_capacite)
        inscrits_capacites = sum(
            classe.nb_inscrits for classe in classes_avec_capacite
        )
        stats["taux_remplissage"] = (
            min(round(inscrits_capacites / capacite_totale * 100), 100)
            if capacite_totale
            else None
        )
        stats["a_capacite"] = bool(capacite_totale)
        classes_capacite = [
            {
                "code": classe.code,
                "inscrits": classe.nb_inscrits,
                "capacite": classe.capacite_max,
                "taux": min(
                    round(classe.nb_inscrits / classe.capacite_max * 100),
                    100,
                ),
            }
            for classe in classes_avec_capacite[:8]
        ]

        inscriptions_par_mois = defaultdict(int)
        for ligne in (
            inscriptions.filter(
                date_inscription__range=(debut, fin)
            )
            .annotate(mois=TruncMonth("date_inscription"))
            .values("mois")
            .annotate(total=Count("pk"))
        ):
            inscriptions_par_mois[_cle_mois(ligne["mois"])] = ligne["total"]
        graphiques["inscriptions"] = _preparer_graphique_mensuel(
            mois_annee,
            inscriptions_par_mois,
            lambda valeur: str(valeur),
        )

        paiements = Paiement.objects.filter(
            ecole=ecole,
            frais_eleve__inscription__annee_scolaire=annee,
            est_annule=False,
            statut__in=(StatutPaiement.PARTIEL, StatutPaiement.COMPLET),
        )
        stats["montant_encaisse"] = (
            paiements.aggregate(total=Sum("montant_paye"))["total"]
            or Decimal("0.00")
        )
        total_facture = (
            FraisEleve.objects.filter(
                ecole=ecole,
                inscription__annee_scolaire=annee,
            ).aggregate(total=Sum("montant_net"))["total"]
            or Decimal("0.00")
        )
        montant_recouvrable = min(stats["montant_encaisse"], total_facture)
        montant_restant = max(total_facture - montant_recouvrable, Decimal("0.00"))
        stats["taux_recouvrement"] = (
            round(float(montant_recouvrable / total_facture * 100), 1)
            if total_facture
            else 0
        )
        graphiques["recouvrement"] = {
            "labels": ["Encaissé", "À recouvrer"],
            "valeurs": [float(montant_recouvrable), float(montant_restant)],
            "valeurs_affichees": [
                number_format(montant_recouvrable, decimal_pos=0),
                number_format(montant_restant, decimal_pos=0),
            ],
            "a_donnees": total_facture > 0,
        }
        agrégats_mensuels = {}
        for index, mois in enumerate(mois_annee):
            if mois.month == 12:
                prochain_mois = date(mois.year + 1, 1, 1)
            else:
                prochain_mois = date(mois.year, mois.month + 1, 1)
            debut_mois = timezone.make_aware(datetime.combine(mois, time.min))
            debut_prochain_mois = timezone.make_aware(
                datetime.combine(prochain_mois, time.min)
            )
            agrégats_mensuels[f"mois_{index}"] = Sum(
                "montant_paye",
                filter=Q(
                    date_paiement__gte=debut_mois,
                    date_paiement__lt=debut_prochain_mois,
                ),
            )
        totaux_mensuels = paiements.aggregate(**agrégats_mensuels)
        paiements_par_mois = {
            mois: totaux_mensuels[f"mois_{index}"] or Decimal("0.00")
            for index, mois in enumerate(mois_annee)
        }
        graphiques["paiements"] = _preparer_graphique_mensuel(
            mois_annee,
            paiements_par_mois,
            lambda valeur: number_format(valeur, decimal_pos=0),
        )

        moyennes_publiees = MoyenneGenerale.objects.filter(
            ecole=ecole,
            inscription__annee_scolaire=annee,
            est_publiee=True,
        )
        stats["nb_bulletins_publies"] = moyennes_publiees.count()
        periodes = (
            PeriodeAcademique.objects.filter(ecole=ecole, annee_scolaire=annee)
            .annotate(
                moyenne_publiee=Avg(
                    ExpressionWrapper(
                        F("moyennes_generales__moyenne")
                        * 100
                        / F("moyennes_generales__base_calcul"),
                        output_field=DecimalField(max_digits=7, decimal_places=2),
                    ),
                    filter=Q(moyennes_generales__est_publiee=True),
                ),
            )
            .order_by("numero")
        )
        points_resultats = []
        for periode in periodes:
            pourcentage = (
                round(float(periode.moyenne_publiee), 1)
                if periode.moyenne_publiee is not None
                else 0
            )
            points_resultats.append(
                {
                    "label": periode.libelle_court or periode.libelle,
                    "valeur": pourcentage,
                    "valeur_affichee": f"{pourcentage:g} %",
                    "hauteur": pourcentage,
                }
            )
        graphiques["resultats"] = {
            "points": points_resultats,
            "labels": [point["label"] for point in points_resultats],
            "valeurs": [point["valeur"] for point in points_resultats],
            "a_donnees": any(point["valeur"] for point in points_resultats),
        }

    return {
        "annee_courante": annee,
        "stats": stats,
        "graphiques": graphiques,
        "graphiques_json": json.loads(json.dumps(graphiques, default=float)),
        "classes_capacite": classes_capacite,
    }
