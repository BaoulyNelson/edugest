from django.contrib import admin
from django.db import models


class AdminTenant(admin.ModelAdmin):
    """Configuration commune pour administrer les données de tous les tenants."""

    @staticmethod
    def _champs_texte(modele):
        return [
            champ.name
            for champ in modele._meta.get_fields()
            if champ.concrete and isinstance(champ, (models.CharField, models.TextField))
        ]

    def get_list_display(self, request):
        if self.list_display:
            return super().get_list_display(request)

        noms_prioritaires = (
            "code",
            "libelle",
            "nom",
            "prenom",
            "matricule",
            "statut",
            "annee_scolaire",
            "classe",
            "matiere",
            "eleve",
            "enseignant",
            "date",
            "numero",
            "type",
            "est_actif",
        )
        champs = {champ.name for champ in self.model._meta.fields}
        colonnes = ["__str__", "ecole"]
        colonnes.extend(
            nom for nom in noms_prioritaires
            if nom in champs and nom not in colonnes and len(colonnes) < 7
        )
        return tuple(colonnes)

    def get_list_filter(self, request):
        if self.list_filter:
            return super().get_list_filter(request)

        filtres = ["ecole"]
        for champ in self.model._meta.fields:
            if champ.name == "ecole":
                continue
            if champ.is_relation or champ.choices:
                filtres.append(champ.name)
        return tuple(filtres)

    def get_search_fields(self, request):
        if self.search_fields:
            return super().get_search_fields(request)

        champs_recherche = []
        for champ in self.model._meta.fields:
            if champ.name == "ecole":
                continue
            if isinstance(champ, (models.CharField, models.TextField)):
                champs_recherche.append(champ.name)
            elif champ.is_relation and champ.related_model:
                for champ_lie in self._champs_texte(champ.related_model):
                    champs_recherche.append(f"{champ.name}__{champ_lie}")
        return tuple(champs_recherche)

    def get_list_select_related(self, request):
        if self.list_select_related:
            return super().get_list_select_related(request)

        relations = ["ecole"]
        relations.extend(
            champ.name
            for champ in self.model._meta.fields
            if champ.is_relation and champ.many_to_one and champ.name != "ecole"
        )
        return tuple(relations)
