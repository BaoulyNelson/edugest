"""Template tags personnalisés du projet."""
from django import template
from django.utils.safestring import mark_safe
from decimal import Decimal

register = template.Library()

@register.filter
def afficher_note(valeur, base="10"):
    """Affiche une note avec 2 décimales. Ex: {{ note|afficher_note }} → 7.50"""
    if valeur is None: return "—"
    try: return f"{Decimal(str(valeur)):.2f}"
    except: return str(valeur)

@register.filter
def statut_badge(statut):
    """Retourne une classe Bootstrap selon le statut."""
    mapping = {
        "actif":"success","active":"success","valide":"success","publie":"primary","complet":"success",
        "brouillon":"secondary","en_attente":"warning","ouverte":"info",
        "cloturee":"warning","suspendu":"danger","annule":"danger","archive":"dark",
    }
    return mapping.get(statut, "secondary")

@register.filter
def devise(montant, symbole="HTG"):
    """Formate un montant financier. Ex: {{ montant|devise:"HTG" }}"""
    if montant is None: return "—"
    try: return f"{Decimal(str(montant)):,.2f} {symbole}"
    except: return str(montant)

@register.simple_tag(takes_context=True)
def url_active(context, url_name):
    """Retourne 'active' si l'URL courante correspond."""
    request = context.get("request")
    if not request: return ""
    from django.urls import reverse, NoReverseMatch
    try:
        return "active" if request.path.startswith(reverse(url_name)) else ""
    except NoReverseMatch:
        return ""

@register.filter
def pourcentage(valeur, total):
    """Calcule un pourcentage. Ex: {{ paye|pourcentage:total }}"""
    try:
        v, t = Decimal(str(valeur)), Decimal(str(total))
        if t == 0: return "0%"
        return f"{(v/t*100):.1f}%"
    except: return "—"
