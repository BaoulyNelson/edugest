from django.urls import path

from apps.noyau import views

app_name = "tableau_bord"
urlpatterns = [
    path("", views.tableau_bord, name="index"),
]
