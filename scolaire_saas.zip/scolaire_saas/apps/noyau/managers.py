"""
apps/noyau/managers.py
======================
TenantManager : filtre automatiquement tous les QuerySets sur le tenant courant.
C'est la seule ligne de défense ORM contre les fuites de données inter-tenant.

RÈGLE ABSOLUE : tout modèle qui contient un champ `ecole` DOIT utiliser TenantManager
comme manager par défaut. Aucune exception sans justification documentée.
"""

from django.db import models
from apps.noyau.middleware import obtenir_tenant_courant


class TenantQuerySet(models.QuerySet):
    """
    QuerySet étendu avec méthodes utilitaires pour le contexte multitenant.
    """

    def du_tenant_courant(self):
        """Filtre explicite sur le tenant actif — pour les cas où on veut être explicite."""
        tenant = obtenir_tenant_courant()
        if tenant is None:
            raise RuntimeError(
                "Aucun tenant actif. "
                "Vérifier que TenantMiddleware est configuré ou utiliser sans_filtre_tenant()."
            )
        return self.filter(ecole=tenant)

    def actifs(self):
        """Filtre les objets non supprimés (soft delete)."""
        return self.filter(supprime_le__isnull=True)

    def supprimes(self):
        """Retourne uniquement les objets soft-deleted."""
        return self.filter(supprime_le__isnull=False)


class TenantManager(models.Manager):
    """
    Manager par défaut pour tous les modèles multitenant.

    Comportement :
    - Si un tenant est actif (requête HTTP normale) : filtre automatique sur ecole_id
    - Si aucun tenant actif (tâche Celery, migration, shell) : retourne TOUT le queryset
      → ATTENTION : dans ce cas, le code appelant est responsable du filtrage

    Pour un bypass explicite (admin cross-tenant, rapports globaux) :
    → Utiliser MonModele.tous_objets.all()
    """

    def get_queryset(self) -> TenantQuerySet:
        tenant = obtenir_tenant_courant()
        qs = TenantQuerySet(self.model, using=self._db)
        if tenant is not None:
            return qs.filter(ecole=tenant)
        return qs

    def actifs(self) -> TenantQuerySet:
        """Raccourci : objets du tenant courant non supprimés."""
        return self.get_queryset().actifs()

    def sans_filtre_tenant(self) -> TenantQuerySet:
        """
        Bypass du filtre tenant.
        Usage légitime : migrations, tâches système, rapports cross-tenant.
        NE PAS utiliser dans des vues HTTP sans justification documentée.
        """
        return TenantQuerySet(self.model, using=self._db)