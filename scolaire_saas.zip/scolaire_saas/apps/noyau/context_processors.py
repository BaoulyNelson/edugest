"""Injecte le tenant et l'année de travail dans les templates."""

from apps.noyau.middleware import obtenir_tenant_courant


def configuration_site(request):
    from apps.etablissements.models import ConfigurationSite

    return {
        "configuration_site": (
            ConfigurationSite.objects.filter(pk=1).first()
            or ConfigurationSite()
        ),
    }


def etablissement_courant(request):
    contexte = {
        "etablissement": None,
        "annee_courante": None,
        "annees_scolaires": [],
        "abonnement_actif": None,
        "roles_utilisateur_courant": [],
        "permissions_utilisateur_courant": set(),
    }

    etablissement = obtenir_tenant_courant()
    if not etablissement:
        return contexte

    contexte["etablissement"] = etablissement
    if getattr(request.user, "is_authenticated", False):
        from apps.academique.models import AnneeScolaire
        from apps.securite.models import UtilisateurRole

        contexte["annee_courante"] = getattr(
            request, "annee_scolaire_courante", None
        )
        contexte["annees_scolaires"] = AnneeScolaire.objects.filter(
            ecole=etablissement
        ).order_by("-date_debut", "-pk")
        attributions = (
            UtilisateurRole.tous_objets.filter(
                ecole=etablissement,
                utilisateur=request.user,
                est_actif=True,
                role__est_actif=True,
            )
            .select_related("role")
            .order_by("role__libelle")
        )
        attributions = [
            attribution
            for attribution in attributions
            if attribution.est_valide
        ]
        contexte["roles_utilisateur_courant"] = [
            attribution.role.libelle for attribution in attributions
        ]

        from apps.securite.models import PERMISSIONS_PAR_ROLE
        from apps.securite.rbac import moteur_rbac

        permissions = moteur_rbac.obtenir_toutes_permissions(
            request.user, etablissement
        )
        if request.user.is_superuser:
            permissions.update(
                permission
                for permissions_role in PERMISSIONS_PAR_ROLE.values()
                for permission in permissions_role
            )
        contexte["permissions_utilisateur_courant"] = permissions

    try:
        contexte["abonnement_actif"] = getattr(etablissement, "abonnement_actif", None)
    except Exception:
        pass

    return contexte
