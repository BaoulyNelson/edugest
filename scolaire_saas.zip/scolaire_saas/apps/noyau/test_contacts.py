from datetime import date

from django.core.exceptions import ValidationError
from django.test import TestCase

from apps.comptes.models import Utilisateur
from apps.eleves.models import Eleve
from apps.etablissements.models import Etablissement
from apps.enseignants.models import Enseignant


class UniciteContactsGlobaleTests(TestCase):
    def setUp(self):
        self.utilisateur = Utilisateur.objects.create_user(
            email="contact@example.com",
            password="test-password",
            nom="Test",
            prenom="Compte",
            telephone="+509 1234-5678",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-contacts",
            nom="École des contacts",
            ville="Port-au-Prince",
        )

    def test_email_est_unique_entre_compte_etablissement_et_enseignant(self):
        with self.assertRaises(ValidationError):
            Etablissement.objects.create(
                slug="ecole-email-duplique",
                nom="École email dupliqué",
                ville="Port-au-Prince",
                email=" CONTACT@example.com ",
            )

        with self.assertRaises(ValidationError):
            Enseignant.tous_objets.create(
                ecole=self.ecole,
                matricule="ENS-CONTACT",
                nom="Enseignant",
                prenom="Test",
                sexe="M",
                email="contact@example.com",
            )

    def test_telephone_normalise_est_unique_entre_fiches(self):
        with self.assertRaises(ValidationError):
            Etablissement.objects.create(
                slug="ecole-telephone-duplique",
                nom="École téléphone dupliqué",
                ville="Port-au-Prince",
                telephone="(509) 1234-5678",
            )

        with self.assertRaises(ValidationError):
            Eleve.tous_objets.create(
                ecole=self.ecole,
                matricule="ELEVE-CONTACT",
                nom="Élève",
                prenom="Test",
                date_naissance=date(2015, 1, 1),
                sexe="F",
                telephone_parent1="+509-1234-5678",
            )

    def test_coordonnees_vides_peuvent_etre_reutilisees(self):
        autre_ecole = Etablissement.objects.create(
            slug="ecole-sans-contact",
            nom="École sans contact",
            ville="Cap-Haïtien",
        )

        self.assertEqual(autre_ecole.email, "")
        self.assertEqual(autre_ecole.telephone, "")
