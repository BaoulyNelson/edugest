from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import RequestFactory, TestCase, override_settings
from django.urls import get_resolver, reverse
from django.utils import timezone

from apps.noyau.views import erreur_403, erreur_404, erreur_500
from apps.etablissements.models import Etablissement
from apps.academique.models import (
    AnneeScolaire,
    Classe,
    PeriodeAcademique,
    StatutAnneeScolaire,
)
from apps.eleves.models import Eleve, Inscription, StatutInscription
from apps.finances.models import FraisEleve, Paiement, TypeFrais
from apps.notes.models import MoyenneGenerale
from apps.parametrage.models import (
    CoefficientsMatiere,
    CycleEnseignement,
    Matiere,
    Niveau,
    ReglePassage,
    TypeDiscipline,
)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class PagesErreurTests(TestCase):
    def setUp(self):
        self.request = RequestFactory().get("/")

    def test_handlers_django_pointent_vers_les_pages_personnalisees(self):
        resolver = get_resolver()

        self.assertIs(resolver.resolve_error_handler(403), erreur_403)
        self.assertIs(resolver.resolve_error_handler(404), erreur_404)
        self.assertIs(resolver.resolve_error_handler(500), erreur_500)

    def test_page_403_presente_un_message_convivial_sans_details_techniques(self):
        response = erreur_403(self.request, "permission interne confidentielle")

        self.assertEqual(response.status_code, 403)
        self.assertContains(
            response,
            "Cette page vous est inaccessible",
            status_code=403,
        )
        self.assertNotContains(
            response,
            "permission interne confidentielle",
            status_code=403,
        )

    def test_page_404_preserve_le_statut_http(self):
        response = erreur_404(self.request)

        self.assertEqual(response.status_code, 404)
        self.assertContains(response, "On ne trouve pas cette page", status_code=404)

    def test_page_500_preserve_le_statut_http(self):
        response = erreur_500(self.request)

        self.assertEqual(response.status_code, 500)
        self.assertContains(
            response,
            "Nous rencontrons un problème",
            status_code=500,
        )


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class TableauBordTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="dashboard-test@example.com",
            password="test-password",
            nom="Tableau",
            prenom="Admin",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-dashboard-test",
            nom="École tableau de bord",
            ville="Port-au-Prince",
            couleur_principale="#7a35c1",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )

    def test_tableau_de_bord_affiche_les_evolutions_de_annee(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="LICENCE",
            libelle="Licence",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="L1",
            libelle="Licence 1",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            niveau=niveau,
            code="L1-A",
            libelle="Licence 1 - Groupe A",
            capacite_max=2,
        )
        eleve = Eleve.objects.create(
            ecole=self.ecole,
            nom="Jean",
            prenom="Marie",
            date_naissance=date(2010, 5, 15),
            sexe="F",
        )
        inscription = Inscription.objects.create(
            ecole=self.ecole,
            eleve=eleve,
            annee_scolaire=self.annee,
            classe=classe,
            statut=StatutInscription.VALIDEE,
            date_inscription=date(2026, 9, 15),
        )
        periode = PeriodeAcademique.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            numero=1,
            libelle="Premier trimestre",
            libelle_court="T1",
            type_periode="trimestre",
            date_debut=date(2026, 9, 1),
            date_fin=date(2026, 12, 20),
        )
        MoyenneGenerale.objects.create(
            ecole=self.ecole,
            inscription=inscription,
            periode=periode,
            total_points_ponderes=Decimal("15.0000"),
            total_coefficients=Decimal("1.0000"),
            moyenne=Decimal("15.0000"),
            base_calcul=Decimal("20.00"),
            est_publiee=True,
        )
        type_frais = TypeFrais.objects.create(
            ecole=self.ecole,
            code="SCOLARITE",
            libelle="Frais de scolarité",
        )
        frais_eleve = FraisEleve.objects.create(
            ecole=self.ecole,
            inscription=inscription,
            type_frais=type_frais,
            montant_brut=Decimal("500.00"),
            montant_net=Decimal("500.00"),
            assigne_par=self.utilisateur,
        )
        Paiement.objects.create(
            ecole=self.ecole,
            frais_eleve=frais_eleve,
            numero_recu="REC-DASH-001",
            montant_paye=Decimal("500.00"),
            date_paiement=timezone.make_aware(datetime(2026, 9, 20, 12)),
            caissier=self.utilisateur,
        )
        response = self.client.get(
            reverse("tableau_bord:index"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["stats"]["nb_eleves"], 1)
        self.assertEqual(response.context["stats"]["nb_classes"], 1)
        self.assertEqual(response.context["stats"]["nb_bulletins_publies"], 1)
        self.assertEqual(response.context["stats"]["montant_encaisse"], Decimal("500.00"))
        self.assertEqual(response.context["stats"]["taux_recouvrement"], 100)
        self.assertEqual(response.context["stats"]["taux_remplissage"], 50)
        self.assertEqual(
            response.context["graphiques"]["inscriptions"]["points"][0]["valeur"],
            1,
        )
        self.assertEqual(
            response.context["graphiques"]["resultats"]["points"][0]["valeur"],
            75,
        )
        self.assertEqual(
            response.context["graphiques"]["genres"]["elements"][1],
            {
                "label": "Masculin",
                "valeur": 0,
                "pourcentage": "0.00%",
                "couleur": "#3b82f6",
            },
        )
        self.assertEqual(
            response.context["graphiques"]["genres"]["elements"][0]["pourcentage"],
            "100.00%",
        )
        self.assertEqual(
            response.context["graphiques_json"]["genres"]["labels"],
            ["Féminin", "Masculin", "Non renseigné"],
        )
        self.assertEqual(
            response.context["graphiques"]["recouvrement"]["valeurs"],
            [500.0, 0.0],
        )
        self.assertEqual(
            response.context["graphiques"]["paiements"]["points"][0]["valeur"],
            Decimal("500.00"),
        )
        self.assertContains(response, "Progression des résultats par période")
        self.assertContains(response, "Répartition par sexe")
        self.assertContains(response, "Remplissage des classes")
        self.assertContains(response, "chart.js@4.4.7")
        self.assertContains(response, 'data-school-color="#7a35c1"')


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ImportCSVTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="import-superuser@example.com",
            password="test-password",
            nom="Import",
            prenom="Admin",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-import-csv",
            nom="École import CSV",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.url = reverse("importer_csv", kwargs={"modele": "cycles"})

    def fichier_cycle(self):
        return SimpleUploadedFile(
            "cycles.csv",
            (
                "code;libelle;description;couleur;ordre_affichage\n"
                "FOND;Fondamental;;#123456;1\n"
            ).encode("utf-8"),
            content_type="text/csv",
        )

    def test_importe_un_cycle_et_ignore_le_doublon_a_la_reimportation(self):
        response = self.client.post(
            self.url,
            {"fichier_csv": self.fichier_cycle()},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            CycleEnseignement.objects.filter(ecole=self.ecole, code="FOND").count(),
            1,
        )
        self.assertContains(response, "1 ligne(s) importée(s)")

        response = self.client.post(
            self.url,
            {"fichier_csv": self.fichier_cycle()},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            CycleEnseignement.objects.filter(ecole=self.ecole, code="FOND").count(),
            1,
        )
        self.assertContains(response, "1 déjà présente(s) ignorée(s)")

    def test_modele_csv_telecharge_les_entetes_attendues(self):
        response = self.client.get(
            f"{self.url}?modele_csv=1",
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("code;libelle;description", response.content.decode("utf-8-sig"))

    def test_importe_le_fichier_niveaux_fourni_avec_les_codes_de_cycle(self):
        for code in ("PRESCO", "PRIMAIRE", "FONDAMENTAL", "SECONDAIRE"):
            CycleEnseignement.objects.create(
                ecole=self.ecole,
                code=code,
                libelle=code.title(),
            )
        fichier_csv = (
            Path(__file__).resolve().parents[2] / "data" / "02_niveaux.csv"
        )
        url = reverse("importer_csv", kwargs={"modele": "niveaux"})

        response = self.client.post(
            url,
            {
                "fichier_csv": SimpleUploadedFile(
                    fichier_csv.name,
                    fichier_csv.read_bytes(),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Niveau.objects.filter(ecole=self.ecole).count(), 16)
        niveau = Niveau.objects.get(ecole=self.ecole, code="PRE1")
        self.assertEqual(niveau.cycle.code, "PRESCO")
        self.assertTrue(niveau.est_actif)

    def test_importe_une_matiere_sans_colonne_est_actif(self):
        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "matieres"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    "matieres.csv",
                    b"code;libelle\nMATH;Mathematiques\n",
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        matiere = Matiere.objects.get(ecole=self.ecole, code="MATH")
        self.assertTrue(matiere.est_actif)
        self.assertContains(response, "1 ligne(s) importée(s)")

    def test_importe_le_csv_des_types_de_discipline_depuis_le_parametrage(self):
        response = self.client.get(
            reverse("parametrage:index"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertContains(
            response,
            reverse("parametrage:types_discipline"),
        )

        response = self.client.get(
            reverse("parametrage:types_discipline"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(
            response,
            reverse("importer_csv", kwargs={"modele": "types-discipline"}),
        )

        fichier_csv = (
            Path(__file__).resolve().parents[2]
            / "data"
            / "06_types_discipline.csv"
        )
        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "types-discipline"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    fichier_csv.name,
                    fichier_csv.read_bytes(),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            TypeDiscipline.objects.filter(ecole=self.ecole).count(),
            8,
        )
        self.assertTrue(
            TypeDiscipline.objects.filter(
                ecole=self.ecole,
                code="AVERT",
                gravite="avertissement",
                apparait_bulletin=True,
            ).exists()
        )
        self.assertContains(response, "8 ligne(s) importée(s)")

    def test_importe_un_coefficient_avec_codes_de_reference(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="PRE1",
            libelle="Première année",
        )
        matiere = Matiere.objects.create(
            ecole=self.ecole,
            code="MATH",
            libelle="Mathématiques",
        )
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut="2026-09-01",
            date_fin="2027-06-30",
        )
        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "coefficients"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    "coefficients.csv",
                    (
                        "matiere;niveau;annee_scolaire;coefficient\n"
                        "MATH;PRE1;2026-2027;2\n"
                    ).encode("utf-8"),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        coefficient = CoefficientsMatiere.objects.get(ecole=self.ecole)
        self.assertEqual(coefficient.matiere, matiere)
        self.assertEqual(coefficient.niveau, niveau)
        self.assertEqual(coefficient.annee_scolaire, annee)
        self.assertContains(response, "1 ligne(s) importée(s)")

    def test_importe_une_regle_de_passage_avec_code_de_niveau(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="PRE1",
            libelle="Première année",
        )
        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "regles-passage"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    "regles-passage.csv",
                    (
                        "niveau;libelle;moyenne_passage\n"
                        "PRE1;Règle générale;5\n"
                    ).encode("utf-8"),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        regle = ReglePassage.objects.get(ecole=self.ecole)
        self.assertEqual(regle.niveau, niveau)
        self.assertEqual(str(regle.moyenne_passage), "5.00")
        self.assertContains(response, "1 ligne(s) importée(s)")

    def test_importe_une_regle_sans_seuil_specifique(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="PRE1",
            libelle="Première année",
        )
        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "regles-passage"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    "regles-passage.csv",
                    b"niveau;libelle\nPRE1;Regle generale\n",
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(
            ReglePassage.objects.filter(
                ecole=self.ecole,
                niveau__code="PRE1",
                moyenne_passage__isnull=True,
            ).exists()
        )
        self.assertContains(response, "1 ligne(s) importée(s)")

    def test_importe_une_periode_avec_libelle_annee_scolaire(self):
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut="2026-09-07",
            date_fin="2027-06-25",
        )
        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "periodes"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    "periodes.csv",
                    (
                        "annee_scolaire,numero,libelle,libelle_court,type_periode,"
                        "date_debut,date_fin,poids_calcul\n"
                        "2026-2027,1,1er Trimestre 2026-2027,T1,trimestre,"
                        "2026-09-07,2026-12-18,1.00\n"
                    ).encode("utf-8"),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        periode = PeriodeAcademique.objects.get(ecole=self.ecole)
        self.assertEqual(periode.annee_scolaire, annee)
        self.assertEqual(periode.numero, 1)
        self.assertEqual(periode.type_periode, "trimestre")
        self.assertContains(response, "1 ligne(s) importée(s)")

    def test_importe_une_classe_avec_libelle_annee_et_code_niveau(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="LICENCE",
            libelle="Licence",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="L1",
            libelle="Licence 1",
        )
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut="2026-09-01",
            date_fin="2027-06-30",
        )

        response = self.client.post(
            reverse("importer_csv", kwargs={"modele": "classes"}),
            {
                "fichier_csv": SimpleUploadedFile(
                    "classes_universite.csv",
                    (
                        "annee_scolaire,niveau,code,libelle,capacite_max,est_actif\n"
                        "2026-2027,L1,L1-INFO-A,"
                        "Licence 1 Informatique - Groupe A,40,true\n"
                    ).encode("utf-8"),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertIsNotNone(response.context["resultats"])
        self.assertEqual(response.context["resultats"]["erreurs"], [])
        classe = Classe.objects.get(ecole=self.ecole, code="L1-INFO-A")
        self.assertEqual(classe.annee_scolaire, annee)
        self.assertEqual(classe.niveau, niveau)
        self.assertEqual(classe.capacite_max, 40)
        self.assertContains(response, "1 ligne(s) importée(s)")

    def test_importe_les_fichiers_csv_du_cursus_esih(self):
        donnees = Path(__file__).resolve().parents[2] / "data"
        fichiers = (
            ("cycles", "12_cycles_esih.csv", 2),
            ("niveaux", "13_niveaux_esih.csv", 6),
            ("matieres", "14_matieres_esih.csv", 25),
        )

        for modele, nom_fichier, nombre_lignes in fichiers:
            fichier = donnees / nom_fichier
            with self.subTest(fichier=nom_fichier):
                response = self.client.post(
                    reverse("importer_csv", kwargs={"modele": modele}),
                    {
                        "fichier_csv": SimpleUploadedFile(
                            fichier.name,
                            fichier.read_bytes(),
                            content_type="text/csv",
                        )
                    },
                    HTTP_X_TENANT_SLUG=self.ecole.slug,
                )

                self.assertEqual(response.status_code, 200)
                resultats = response.context["resultats"]
                self.assertEqual(resultats["crees"], nombre_lignes)
                self.assertEqual(resultats["erreurs"], [])

        self.assertEqual(
            Niveau.objects.filter(ecole=self.ecole, cycle__code="DUT").count(),
            2,
        )
        self.assertEqual(
            Niveau.objects.filter(ecole=self.ecole, cycle__code="INTEGRE").count(),
            4,
        )
        self.assertEqual(Matiere.objects.filter(ecole=self.ecole).count(), 25)
