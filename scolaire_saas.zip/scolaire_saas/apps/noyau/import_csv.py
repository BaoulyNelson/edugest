"""Configuration des imports CSV disponibles depuis les listes de l'école."""

from dataclasses import dataclass

from apps.academique.models import Classe, PeriodeAcademique
from apps.finances.models import TypeFrais
from apps.parametrage.models import (
    CoefficientsMatiere,
    CycleEnseignement,
    Matiere,
    Mention,
    Niveau,
    OptionPedagogique,
    ReglePassage,
    Section,
    TypeDiscipline,
    TypeEvaluation,
)


@dataclass(frozen=True)
class ImportCSVSpec:
    model: type
    fields: tuple[str, ...]
    return_url: str
    permission: str = "parametrage.modifier.etablissement"
    identity_fields: tuple[str, ...] = ()
    relation_aliases: tuple[tuple[str, str, str], ...] = ()
    optional_fields: tuple[str, ...] = ()


IMPORTS_CSV = {
    "cycles": ImportCSVSpec(
        CycleEnseignement,
        ("code", "libelle", "description", "couleur", "ordre_affichage"),
        "parametrage:cycles",
        identity_fields=("code",),
    ),
    "niveaux": ImportCSVSpec(
        Niveau,
        ("cycle_id", "code", "libelle", "libelle_court", "duree_annees", "ordre_affichage", "est_actif"),
        "parametrage:niveaux",
        identity_fields=("cycle", "code"),
        relation_aliases=(("cycle", "cycle_id", "code"),),
        optional_fields=("est_actif",),
    ),
    "sections": ImportCSVSpec(
        Section,
        ("niveau_id", "code", "libelle", "ordre_affichage", "est_actif"),
        "parametrage:sections",
        identity_fields=("niveau", "code"),
    ),
    "options": ImportCSVSpec(
        OptionPedagogique,
        ("niveau_id", "code", "libelle", "ordre_affichage", "est_actif"),
        "parametrage:options_pedagogiques",
        identity_fields=("niveau", "code"),
    ),
    "matieres": ImportCSVSpec(
        Matiere,
        ("code", "libelle", "libelle_court", "type_matiere", "couleur", "ordre_affichage", "est_actif"),
        "parametrage:matieres",
        identity_fields=("code",),
    ),
    "types-evaluation": ImportCSVSpec(
        TypeEvaluation,
        ("code", "libelle", "poids", "compte_dans_moyenne", "est_obligatoire", "note_max_defaut", "couleur", "icone", "ordre_affichage", "est_actif"),
        "parametrage:types_evaluation",
        identity_fields=("code",),
    ),
    "types-discipline": ImportCSVSpec(
        TypeDiscipline,
        ("code", "libelle", "gravite", "apparait_bulletin", "ordre_affichage", "est_actif"),
        "parametrage:index",
        identity_fields=("code",),
    ),
    "coefficients": ImportCSVSpec(
        CoefficientsMatiere,
        ("matiere_id", "niveau_id", "annee_scolaire_id", "coefficient", "est_obligatoire"),
        "parametrage:coefficients",
        identity_fields=("matiere", "niveau", "annee_scolaire"),
        relation_aliases=(
            ("matiere", "matiere_id", "code"),
            ("niveau", "niveau_id", "code"),
            ("annee_scolaire", "annee_scolaire_id", "libelle"),
        ),
    ),
    "regles-passage": ImportCSVSpec(
        ReglePassage,
        ("niveau_id", "libelle", "moyenne_passage", "seuil_eliminatoire", "nb_matieres_insuffisantes_max", "est_active"),
        "parametrage:regles_passage",
        relation_aliases=(("niveau", "niveau_id", "code"),),
    ),
    "mentions": ImportCSVSpec(
        Mention,
        ("systeme_notation_id", "libelle", "libelle_court", "moyenne_min", "moyenne_max", "couleur", "ordre_affichage"),
        "parametrage:systeme_notation",
        identity_fields=("systeme_notation", "libelle"),
    ),
    "classes": ImportCSVSpec(
        Classe,
        ("annee_scolaire_id", "niveau_id", "section_id", "option_id", "code", "libelle", "capacite_max", "salle", "enseignant_titulaire_id"),
        "academique:liste_classes",
        identity_fields=("annee_scolaire", "code"),
        relation_aliases=(
            ("annee_scolaire", "annee_scolaire_id", "libelle"),
            ("niveau", "niveau_id", "code"),
        ),
    ),
    "periodes": ImportCSVSpec(
        PeriodeAcademique,
        ("annee_scolaire_id", "numero", "libelle", "libelle_court", "type_periode", "date_debut", "date_fin", "poids_calcul"),
        "academique:liste_periodes",
        identity_fields=("annee_scolaire", "type_periode", "numero"),
        relation_aliases=(
            ("annee_scolaire", "annee_scolaire_id", "libelle"),
        ),
    ),
    "types-frais": ImportCSVSpec(
        TypeFrais,
        ("code", "libelle", "description", "frequence", "montant_defaut", "est_obligatoire", "bloque_bulletin", "est_actif", "ordre_affichage"),
        "finances:types_frais",
        permission="parametrage.modifier.etablissement",
        identity_fields=("code",),
    ),
}
