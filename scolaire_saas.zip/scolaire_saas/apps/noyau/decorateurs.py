"""
apps/noyau/decorateurs.py
=========================
Décorateurs réutilisables pour les vues Django.
"""

from functools import wraps
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect
from django.contrib import messages


def requiert_tenant(vue_func):
    """
    Garantit qu'un tenant est actif dans la requête.
    À utiliser sur toutes les vues qui accèdent à des données tenant.
    """
    @wraps(vue_func)
    def wrapper(request, *args, **kwargs):
        if not getattr(request, "etablissement", None):
            raise PermissionDenied("Aucun établissement actif pour cette requête.")
        if getattr(request.user, "is_authenticated", False) and not hasattr(
            request, "annee_scolaire_courante"
        ):
            from apps.academique.services import obtenir_annee_scolaire_selectionnee

            request.annee_scolaire_courante = obtenir_annee_scolaire_selectionnee(
                request
            )
        return vue_func(request, *args, **kwargs)
    return wrapper


def requiert_permission(code_permission: str):
    """
    Vérifie qu'un utilisateur possède une permission RBAC avant d'accéder à la vue.

    Usage :
        @requiert_permission("notes.saisir.propres_classes")
        def vue_saisie_notes(request):
            ...

    Si la permission est absente → PermissionDenied (→ page 403).
    """
    return requiert_une_permission(code_permission)


def requiert_une_permission(*codes_permissions: str):
    """Autorise l'accès si l'utilisateur possède au moins une permission indiquée."""
    if not codes_permissions:
        raise ValueError("Au moins un code de permission est requis.")

    def decorateur(vue_func):
        @wraps(vue_func)
        def wrapper(request, *args, **kwargs):
            from apps.securite.rbac import moteur_rbac

            if not request.user.is_authenticated:
                return redirect("comptes:connexion")

            if not any(
                moteur_rbac.possede_permission(
                    utilisateur=request.user,
                    ecole=request.etablissement,
                    code_permission=code_permission,
                )
                for code_permission in codes_permissions
            ):
                raise PermissionDenied(
                    "Vous n'avez aucune des permissions requises : "
                    + ", ".join(codes_permissions)
                )
            return vue_func(request, *args, **kwargs)
        return wrapper
    return decorateur


def annee_active_requise(vue_func):
    """
    Vérifie qu'une année scolaire est active dans l'établissement.
    Redirige vers le paramétrage si aucune année active.
    """
    @wraps(vue_func)
    def wrapper(request, *args, **kwargs):
        from apps.academique.models import StatutAnneeScolaire

        annee_active = getattr(request, "annee_scolaire_courante", None)

        if not annee_active or annee_active.statut != StatutAnneeScolaire.ACTIVE:
            messages.warning(
                request,
                "L’année sélectionnée n’est pas active. "
                "Choisissez l’année active avant de continuer.",
            )
            return redirect("academique:liste_annees")

        request.annee_scolaire_courante = annee_active
        return vue_func(request, *args, **kwargs)
    return wrapper


def gerer_erreur_metier(vue_func):
    """
    Capture les exceptions métier et les convertit en messages utilisateur.
    Évite de polluer les vues avec des try/except répétitifs.

    Usage :
        @gerer_erreur_metier
        def vue_inscrire_eleve(request, ...):
            ...  # peut lever RegleMetierError, TransitionInterditError, etc.
    """
    @wraps(vue_func)
    def wrapper(request, *args, **kwargs):
        from apps.noyau.exceptions import ErreurMetierBase

        try:
            return vue_func(request, *args, **kwargs)
        except ErreurMetierBase as exc:
            messages.error(request, str(exc))
            return redirect(request.META.get("HTTP_REFERER", "/"))
    return wrapper