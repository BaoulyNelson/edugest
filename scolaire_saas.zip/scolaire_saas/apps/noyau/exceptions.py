"""
apps/noyau/exceptions.py
========================
Hiérarchie d'exceptions métier du projet.
Toute erreur levée par un service doit hériter d'une de ces classes.

Convention : les exceptions métier ne sont jamais des RuntimeError ou ValueError bruts.
Cela permet aux vues de les capturer proprement et d'afficher un message utilisateur.
"""


class ErreurMetierBase(Exception):
    """
    Exception racine pour toutes les erreurs métier.
    Toujours construite avec un message utilisateur lisible.
    """
    code_erreur: str = "ERREUR_METIER"

    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self):
        return self.message


class TransitionInterditError(ErreurMetierBase):
    """
    Transition d'état non autorisée par la machine à états.
    Exemple : tenter de clôturer une année déjà archivée.
    """
    code_erreur = "TRANSITION_INTERDITE"


class RegleMetierError(ErreurMetierBase):
    """
    Violation d'une règle métier (garde non satisfaite).
    Exemple : inscrire un élève après verrouillage administratif.
    """
    code_erreur = "REGLE_METIER"


class ErreurCalcul(ErreurMetierBase):
    """
    Erreur dans le moteur de calcul de moyennes.
    Exemple : coefficients à zéro, données manquantes.
    """
    code_erreur = "ERREUR_CALCUL"


class ErreurTenant(ErreurMetierBase):
    """
    Problème de contexte tenant.
    Exemple : tenant manquant dans une tâche Celery mal configurée.
    """
    code_erreur = "ERREUR_TENANT"


class LimiteAbonnementError(ErreurMetierBase):
    """
    L'action dépasse les limites du plan d'abonnement.
    Exemple : ajouter un 501e élève sur un plan limité à 500.
    """
    code_erreur = "LIMITE_ABONNEMENT"


class AccesRefuseError(ErreurMetierBase):
    """
    L'utilisateur n'a pas la permission d'effectuer cette action.
    Distinct de PermissionDenied Django — celui-ci est une erreur métier explicite.
    """
    code_erreur = "ACCES_REFUSE"


class DonneesInvalidesError(ErreurMetierBase):
    """
    Les données soumises ne respectent pas les contraintes métier.
    Distinct de ValidationError Django — pour les validations complexes multi-champs.
    """
    code_erreur = "DONNEES_INVALIDES"


class OperationImpossibleError(ErreurMetierBase):
    """
    L'opération est structurellement impossible dans l'état actuel du système.
    Exemple : générer un bulletin sans notes validées.
    """
    code_erreur = "OPERATION_IMPOSSIBLE"