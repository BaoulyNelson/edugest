"""Générateurs de codes uniques pour les entités métier."""
import random
import string
import datetime
from django.db.models import Max
from django.utils import timezone


def _generer_depuis_prefixe(model_class, ecole, champ: str, prefixe: str) -> str:
    """
    Noyau commun à tous les générateurs de séquence.
    Utilise Max() — résistant aux trous laissés par le soft-delete.
    Format : {PREFIXE}-{SEQ:04d}  ou  {PREFIXE}-{ANNEE}-{SEQ:04d}
    """
    manager = (
        getattr(model_class, "tous_objets", None)  # ← nom réel dans ton projet
        or getattr(model_class, "tous", None)
        or model_class._default_manager
    )

    filtre  = {f"{champ}__startswith": prefixe, "ecole": ecole}
    dernier = (
        manager
        .filter(**filtre)
        .aggregate(Max(champ))[f"{champ}__max"]
    )
    if dernier:
        try:
            sequence = int(dernier.split("-")[-1]) + 1
        except (ValueError, IndexError):
            sequence = 1
    else:
        sequence = 1
    return f"{prefixe}{sequence:04d}"


def generer_matricule_eleve(ecole, date_inscription=None) -> str:
    """
    BET-2026-0042
    Préfixe = nom court de l'école (3 lettres) + année d'inscription.
    """
    from apps.eleves.models import Eleve

    code  = (getattr(ecole, "nom_court", None) or ecole.nom[:3]).upper().strip()
    annee = (date_inscription or datetime.date.today()).year
    return _generer_depuis_prefixe(Eleve, ecole, "matricule", f"{code}-{annee}-")


def generer_matricule_enseignant(ecole) -> str:
    """
    ENS-2026-0007
    Séquence globale par école — pas par année (les enseignants durent plusieurs ans).
    """
    from apps.enseignants.models import Enseignant

    annee = timezone.now().year
    return _generer_depuis_prefixe(Enseignant, ecole, "matricule", f"ENS-{annee}-")


def generer_numero_licence(ecole) -> str:
    """
    PROV-2026-384912
    Provisoire — à remplacer par le vrai numéro MENFP délivré par le ministère.
    Préfixe PROV garantit qu'on ne confond jamais avec un vrai numéro officiel.
    """
    annee   = timezone.now().year
    suffixe = "".join(random.choices(string.digits, k=6))
    return f"PROV-{annee}-{suffixe}"


def generer_code_matiere(ecole, libelle: str) -> str:
    """
    'Mathématiques' → 'MATH'
    'Mathématiques Avancées' (collision) → 'MATH-2'
    """
    import unicodedata, re
    from apps.parametrage.models import Matiere

    norme    = unicodedata.normalize("NFD", libelle.upper())
    norme    = "".join(c for c in norme if unicodedata.category(c) != "Mn")
    norme    = re.sub(r"[^A-Z0-9]", "", norme)
    base     = norme[:4] or "MAT"
    candidat = base
    compteur = 2
    while Matiere.objects.filter(ecole=ecole, code=candidat).exists():
        candidat = f"{base}-{compteur}"
        compteur += 1
    return candidat