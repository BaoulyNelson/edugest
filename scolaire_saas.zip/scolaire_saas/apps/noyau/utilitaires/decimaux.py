"""
apps/noyau/utilitaires/decimaux.py
===================================
Arithmétique décimale fiable pour les calculs de moyennes.
JAMAIS de float dans les calculs académiques — uniquement Decimal.
"""

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation


# Précisions standard du projet
PRECISION_MOYENNE = Decimal("0.0001")     # 4 décimales : 5.6500
PRECISION_AFFICHAGE = Decimal("0.01")     # 2 décimales : 5.65
PRECISION_FINANCIER = Decimal("0.01")     # 2 décimales pour les montants


def arrondir_moyenne(valeur: Decimal) -> Decimal:
    """Arrondit une moyenne à 4 décimales (règle ROUND_HALF_UP)."""
    return valeur.quantize(PRECISION_MOYENNE, rounding=ROUND_HALF_UP)


def arrondir_affichage(valeur: Decimal) -> Decimal:
    """Arrondit pour l'affichage à 2 décimales."""
    return valeur.quantize(PRECISION_AFFICHAGE, rounding=ROUND_HALF_UP)


def arrondir_montant(valeur: Decimal) -> Decimal:
    """Arrondit un montant financier à 2 décimales."""
    return valeur.quantize(PRECISION_FINANCIER, rounding=ROUND_HALF_UP)


def vers_decimal(valeur, defaut: Decimal = Decimal("0")) -> Decimal:
    """
    Convertit n'importe quelle valeur numérique en Decimal.
    Retourne `defaut` si la conversion échoue.
    NE PAS passer de float directement — utiliser str(float_val) avant.
    """
    if isinstance(valeur, Decimal):
        return valeur
    if valeur is None:
        return defaut
    try:
        # Passer par str évite les erreurs de représentation float
        return Decimal(str(valeur))
    except (InvalidOperation, ValueError):
        return defaut


def calculer_pourcentage(obtenu: Decimal, total: Decimal) -> Decimal:
    """
    Calcule un pourcentage avec protection division par zéro.
    Retourne Decimal("0") si total == 0.
    """
    if total == Decimal("0"):
        return Decimal("0")
    return arrondir_affichage((obtenu / total) * Decimal("100"))


def normaliser_sur_base(
    points_obtenus: Decimal,
    points_max: Decimal,
    base: Decimal,
) -> Decimal:
    """
    Ramène une note à une base donnée.
    Exemple : 678/1200 × 10 = 5.6500

    Validation : points_max > 0, base > 0.
    """
    if points_max <= Decimal("0"):
        raise ValueError(f"points_max doit être > 0, reçu : {points_max}")
    if base <= Decimal("0"):
        raise ValueError(f"base doit être > 0, reçue : {base}")
    if points_obtenus < Decimal("0"):
        raise ValueError(f"points_obtenus ne peut pas être négatif : {points_obtenus}")

    resultat = (points_obtenus / points_max) * base
    return arrondir_moyenne(resultat)


# ─── Tests inline de régression ──────────────────────────────────────────────
# Ces assertions s'exécutent à l'import — échouent silencieusement en prod
# mais sont capturées par pytest en CI.
assert normaliser_sur_base(
    Decimal("678"), Decimal("1200"), Decimal("10")
) == Decimal("5.6500"), "Régression : 678/1200×10 doit valoir 5.6500"

assert vers_decimal("5.65") == Decimal("5.65")
assert vers_decimal(None) == Decimal("0")
assert vers_decimal("invalide") == Decimal("0")