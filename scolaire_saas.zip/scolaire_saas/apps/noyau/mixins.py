"""
apps/noyau/mixins.py
====================
Mixins abstraits réutilisables sur tous les modèles du projet.
Chaque mixin est indépendant et composable.
"""

import uuid
from django.db import models
from django.utils import timezone
from apps.noyau.managers import TenantManager


class ContactUniqueMixin:
    def clean(self):
        super().clean()
        from apps.noyau.contacts import verifier_contacts_uniques

        verifier_contacts_uniques(self)

    def save(self, *args, **kwargs):
        from django.db import router, transaction
        from apps.noyau.contacts import verifier_contacts_uniques

        verifier_contacts_uniques(self)
        using = kwargs.get("using") or router.db_for_write(type(self), instance=self)
        with transaction.atomic(using=using):
            return super().save(*args, **kwargs)


class UUIDPrimaryKeyMixin(models.Model):
    """
    Remplace la PK auto-incrémentée par un UUID v4.
    Recommandé pour les modèles exposés dans des URLs (élèves, bulletins, paiements).
    Avantage : pas d'énumération possible, safe pour les APIs publiques.
    """
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        verbose_name="Identifiant unique",
    )

    class Meta:
        abstract = True


class HorodatageMixin(models.Model):
    """
    Champs d'audit temporel — présents sur TOUS les modèles métier.
    auto_now_add et auto_now sont intentionnels : pas de manipulation manuelle.
    """
    cree_le = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créé le",
        db_index=True,
    )
    modifie_le = models.DateTimeField(
        auto_now=True,
        verbose_name="Modifié le",
    )

    class Meta:
        abstract = True


class SuppressionDouce(models.Model):
    """
    Soft delete : les objets supprimés restent physiquement en base.
    Jamais de DELETE SQL sur les données métier — toujours soft delete.

    INVARIANT : une fois supprime_le est non-null, l'objet est considéré supprimé
    et ne doit plus apparaître dans les QuerySets filtrés (.actifs()).
    """
    supprime_le = models.DateTimeField(
        null=True,
        blank=True,
        db_index=True,
        verbose_name="Supprimé le",
    )
    supprime_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
        verbose_name="Supprimé par",
    )

    class Meta:
        abstract = True

    @property
    def est_supprime(self) -> bool:
        return self.supprime_le is not None

    def supprimer(self, utilisateur=None, sauvegarder: bool = True) -> None:
        """
        Marque l'objet comme supprimé.
        Ne pas appeler .delete() directement — utiliser cette méthode.
        """
        if self.est_supprime:
            return  # Idempotent : déjà supprimé, aucune action

        self.supprime_le = timezone.now()
        self.supprime_par = utilisateur
        if sauvegarder:
            self.save(update_fields=["supprime_le", "supprime_par"])

    def restaurer(self, sauvegarder: bool = True) -> None:
        """Annule un soft delete."""
        self.supprime_le = None
        self.supprime_par = None
        if sauvegarder:
            self.save(update_fields=["supprime_le", "supprime_par"])


class TenantModelMixin(models.Model):
    """
    Mixin principal pour tous les modèles multitenant.
    Fournit :
    - Le champ FK `ecole` vers Etablissement
    - Le TenantManager comme manager par défaut
    - Le manager `tous_objets` pour les accès cross-tenant légitimes

    RÈGLE : Tout modèle contenant des données isolées par école DOIT hériter de ce mixin.
    """
    ecole = models.ForeignKey(
        "etablissements.Etablissement",
        on_delete=models.CASCADE,
        related_name="%(app_label)s_%(class)s_set",
        verbose_name="École",
        db_index=True,
    )

    objects = TenantManager()
    tous_objets = models.Manager()  # Manager non filtré — usage système uniquement

    class Meta:
        abstract = True

    def verifier_appartenance_tenant(self, etablissement) -> bool:
        """Vérifie que cet objet appartient bien à l'établissement donné."""
        return self.ecole_id == etablissement.pk


class TenantObjectMixin:
    """
    Mixin pour les vues Django basées sur des classes (CBV).
    Garantit que l'objet récupéré appartient au tenant courant.
    À combiner avec DetailView, UpdateView, DeleteView.

    Usage :
        class VueDetailEleve(TenantObjectMixin, DetailView):
            model = Eleve
    """

    def get_queryset(self):
        """Filtre automatiquement sur le tenant de la requête."""
        qs = super().get_queryset()
        if hasattr(self.request, "etablissement") and self.request.etablissement:
            return qs.filter(ecole=self.request.etablissement)
        return qs.none()  # Sécurité : si pas de tenant, rien

    def get_object(self, queryset=None):
        """Double vérification après récupération de l'objet."""
        from django.core.exceptions import PermissionDenied
        obj = super().get_object(queryset)
        if hasattr(obj, "ecole") and obj.ecole != self.request.etablissement:
            raise PermissionDenied(
                "Accès refusé : cet objet n'appartient pas à votre établissement."
            )
        return obj


class OrdreMixin(models.Model):
    """
    Champ d'ordre d'affichage pour les listes triables.
    Utilisé pour : niveaux, matières, options, sections.
    """
    ordre_affichage = models.PositiveSmallIntegerField(
        default=0,
        db_index=True,
        verbose_name="Ordre d'affichage",
    )

    class Meta:
        abstract = True
        ordering = ["ordre_affichage"]


class ActivableMixin(models.Model):
    """
    Permet de désactiver un élément sans le supprimer.
    Utilisé pour : matières, types d'évaluation, frais.
    """
    est_actif = models.BooleanField(
        default=True,
        db_index=True,
        verbose_name="Actif",
    )

    class Meta:
        abstract = True