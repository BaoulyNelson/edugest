"""
apps/noyau/middleware.py
========================
TenantMiddleware : identifie et injecte le tenant courant dans chaque requête.
Les routes publiques passent librement. Les routes protégées exigent un tenant valide.
"""

import threading
import logging
from django.http import Http404

logger = logging.getLogger("apps.noyau")

_contexte_local = threading.local()


def obtenir_tenant_courant():
    """Retourne l'établissement actif pour le thread courant. None si hors contexte tenant."""
    return getattr(_contexte_local, "etablissement", None)


def definir_tenant_courant(etablissement) -> None:
    """Pose le tenant dans le contexte local du thread courant."""
    _contexte_local.etablissement = etablissement


class TenantMiddleware:
    """
    Identifie le tenant depuis le sous-domaine ou le header X-Tenant-Slug.

    Logique :
    1. Route publique → passe directement, aucun tenant requis.
    2. Route protégée + slug trouvé → injecte l'établissement dans request et thread.
    3. Route protégée + pas de slug → redirige vers /saas/ (évite un 404 brutal).

    En développement local (localhost / 127.0.0.1) :
    - Option A : header HTTP  X-Tenant-Slug: mon-ecole
    - Option B : session["tenant_slug"] = "mon-ecole"  (posé au login)
    - Option C : modifier /etc/hosts → 127.0.0.1  mon-ecole.localhost
    """

    # ── Préfixes toujours publics (assets, debug, admin Django) ──────
    PREFIXES_PUBLICS = (
        "/static/",
        "/media/",
        "/__debug__/",
        "/django-admin/",
        "/sante/",
        "/saas/",      # ← toutes les sous-routes SaaS sont publiques
        "/comptes/",   # ← profil, déconnexion, mot de passe aussi
        "/securite/invitations/",  # Acceptation publique via jeton d'invitation
    )

    # ── Routes exactes publiques (SaaS, auth) ────────────────────────
    ROUTES_PUBLIQUES = (
        "/",
        "/comptes/connexion/",
        "/comptes/inscription/",
        "/comptes/mot-de-passe-oublie/",
    )

    DOMAINES_LOCAUX = ("127.0.0.1", "localhost", "0.0.0.0")
    DOMAINE_RACINE  = "scolaire.ht"

    def __init__(self, get_response):
        self.get_response = get_response

    # ── Point d'entrée principal ──────────────────────────────────────
    def __call__(self, request):
        # Nettoyage systématique : évite toute fuite du thread précédent
        definir_tenant_courant(None)
        request.etablissement = None

        # Étape 1 — routes publiques : on passe sans chercher de tenant
        if self._est_route_publique(request.path):
            return self.get_response(request)

        # Étape 2 — routes protégées : le slug est obligatoire
        slug = self._extraire_slug(request)

        if not slug:
            # Pas de slug identifiable → redirection douce vers l'accueil SaaS
            # (plutôt qu'un 404 qui déroute l'utilisateur)
            from django.shortcuts import redirect
            return redirect("/saas/")

        # Étape 3 — chargement de l'établissement (Http404 si inconnu/inactif)
        etablissement = self._charger_etablissement(slug)
        abonnement = getattr(etablissement, "abonnement_actif", None)
        if abonnement:
            abonnement.expirer_essai_si_necessaire()
        if abonnement and not abonnement.est_actif:
            from django.shortcuts import redirect
            from django.urls import reverse
            destination = reverse("saas:tableau_bord")
            return redirect(f"{destination}?activation_requise={etablissement.slug}")
        definir_tenant_courant(etablissement)
        request.etablissement = etablissement
        if getattr(request.user, "is_authenticated", False):
            from apps.academique.services import obtenir_annee_scolaire_selectionnee

            request.annee_scolaire_courante = obtenir_annee_scolaire_selectionnee(
                request
            )

        reponse = self.get_response(request)

        # Nettoyage après la réponse : libère le contexte thread
        definir_tenant_courant(None)
        return reponse

    # ── Helpers ───────────────────────────────────────────────────────

    def _est_route_publique(self, path: str) -> bool:
        """
        Retourne True si le chemin ne nécessite pas de tenant.
        Vérifie d'abord les routes exactes, puis les préfixes.
        """
        # Route exacte (ex: "/saas/", "/comptes/connexion/")
        if path in self.ROUTES_PUBLIQUES:
            return True

        # Préfixe (ex: "/static/", "/media/")
        return any(path.startswith(prefixe) for prefixe in self.PREFIXES_PUBLICS)

    def _extraire_slug(self, request) -> str | None:
        """
        Résout le slug du tenant depuis plusieurs sources, par ordre de priorité :
        1. Sous-domaine de l'host (production)
        2. Header X-Tenant-Slug (dev local, API, mobile)
        3. Session Django (posé au login pour dev local)
        """
        host = request.get_host().split(":")[0].lower()

        # ── Dev local : localhost ou 127.0.0.1 ───────────────────────
        # Pas de sous-domaine possible → header ou session uniquement
        if host in self.DOMAINES_LOCAUX:
            slug = request.headers.get("X-Tenant-Slug", "").strip()
            if slug:
                return slug
            return request.session.get("tenant_slug")

        # ── Production : mon-ecole.scolaire.ht ───────────────────────
        if host.endswith(f".{self.DOMAINE_RACINE}"):
            slug = host[: -(len(self.DOMAINE_RACINE) + 1)]
            if slug:
                return slug

        # ── Dev avec /etc/hosts : mon-ecole.localhost ─────────────────
        if host.endswith(".localhost"):
            slug = host[: -len(".localhost")]
            if slug:
                return slug

        # ── Fallback universel : header X-Tenant-Slug ─────────────────
        slug = request.headers.get("X-Tenant-Slug", "").strip()
        if slug:
            return slug

        # ── Dernier recours : session ─────────────────────────────────
        return request.session.get("tenant_slug")

    def _charger_etablissement(self, slug: str):
        """
        Charge l'établissement depuis la base. Lève Http404 si inconnu ou inactif.
        Le select_related évite les requêtes N+1 sur abonnement et plan.
        """
        from apps.etablissements.models import Etablissement
        try:
            return Etablissement.objects.select_related(
                "abonnement_actif",
                "abonnement_actif__plan",
            ).get(slug=slug, est_actif=True)
        except Etablissement.DoesNotExist:
            logger.warning("Tenant inconnu ou inactif : slug=%r", slug)
            raise Http404(
                f"L'établissement « {slug} » est introuvable ou désactivé. "
                "Vérifiez l'adresse ou contactez votre administrateur."
            )