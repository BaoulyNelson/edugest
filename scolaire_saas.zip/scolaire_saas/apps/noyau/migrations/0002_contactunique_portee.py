from django.db import migrations, models


def definir_portees_existantes(apps, schema_editor):
    ContactUnique = apps.get_model("noyau", "ContactUnique")
    ecole_par_modele = {}
    for label in ("eleves.Eleve", "enseignants.Enseignant"):
        try:
            modele = apps.get_model(label)
        except LookupError:
            continue
        ecole_par_modele[label.lower()] = modele

    for contact in ContactUnique.objects.all().iterator():
        modele = ecole_par_modele.get(contact.modele_source.lower())
        if modele is None:
            continue
        ecole_id = (
            modele.objects.filter(pk=contact.identifiant_source)
            .values_list("ecole_id", flat=True)
            .first()
        )
        if ecole_id is not None:
            ContactUnique.objects.filter(pk=contact.pk).update(portee=str(ecole_id))


class Migration(migrations.Migration):
    dependencies = [
        ("noyau", "0001_initial"),
        ("eleves", "0001_initial"),
        ("enseignants", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="contactunique",
            name="portee",
            field=models.CharField(default="global", max_length=64),
        ),
        migrations.RunPython(
            definir_portees_existantes,
            migrations.RunPython.noop,
        ),
        migrations.RemoveConstraint(
            model_name="contactunique",
            name="unique_contact_normalise",
        ),
        migrations.AddConstraint(
            model_name="contactunique",
            constraint=models.UniqueConstraint(
                fields=("type_contact", "valeur_normalisee", "portee"),
                name="unique_contact_normalise",
            ),
        ),
    ]
