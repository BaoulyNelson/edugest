from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="ContactUnique",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "type_contact",
                    models.CharField(
                        choices=[
                            ("email", "Adresse email"),
                            ("telephone", "Numéro de téléphone"),
                        ],
                        max_length=12,
                    ),
                ),
                ("valeur_normalisee", models.CharField(max_length=320)),
                ("modele_source", models.CharField(max_length=100)),
                ("identifiant_source", models.CharField(max_length=64)),
                ("champ_source", models.CharField(max_length=40)),
            ],
        ),
        migrations.AddConstraint(
            model_name="contactunique",
            constraint=models.UniqueConstraint(
                fields=("type_contact", "valeur_normalisee"),
                name="unique_contact_normalise",
            ),
        ),
        migrations.AddConstraint(
            model_name="contactunique",
            constraint=models.UniqueConstraint(
                fields=("modele_source", "identifiant_source", "champ_source"),
                name="unique_contact_source",
            ),
        ),
    ]
