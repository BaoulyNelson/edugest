"""Fonctions partagées de lecture et de validation des fichiers CSV."""

import csv
import io


def lire_csv(fichier, champs_requis):
    try:
        contenu = fichier.read().decode("utf-8-sig")
    except UnicodeDecodeError as erreur:
        raise ValueError("Le fichier doit être encodé en UTF-8.") from erreur

    try:
        dialecte = csv.Sniffer().sniff(contenu[:2048], delimiters=",;\t")
    except csv.Error:
        dialecte = csv.excel

    lecteur = csv.DictReader(io.StringIO(contenu), dialect=dialecte)
    if not lecteur.fieldnames:
        raise ValueError("Le fichier CSV est vide ou sans en-tête.")
    manquants = set(champs_requis) - set(lecteur.fieldnames)
    if manquants:
        raise ValueError("Colonnes manquantes : " + ", ".join(sorted(manquants)))
    return lecteur


def lire_booleen(valeur, champ):
    valeur = (valeur or "").strip().lower()
    if valeur in {"true", "1", "oui", "yes"}:
        return True
    if valeur in {"false", "0", "non", "no", ""}:
        return False
    raise ValueError(f"« {champ} » doit être vrai/faux (oui/non, 1/0).")
