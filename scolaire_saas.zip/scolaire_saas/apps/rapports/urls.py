from django.urls import path
from apps.rapports import views

app_name = "rapports"
urlpatterns = [
    path("", views.index_rapports, name="index"),
    path("academique/", views.rapport_academique, name="academique"),
    path("financier/", views.rapport_financier, name="financier"),
    path("eleves/", views.rapport_eleves, name="eleves"),
    path("exporter/<str:type_rapport>/", views.exporter, name="exporter"),
]
