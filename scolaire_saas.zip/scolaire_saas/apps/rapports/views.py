"""Vues de reporting et statistiques."""
from decimal import Decimal

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from apps.noyau.decorateurs import requiert_tenant, requiert_permission

@login_required
@requiert_tenant
@requiert_permission("rapports.exporter.etablissement")
def index_rapports(request):
    return render(request, "rapports/index.html")


@login_required
@requiert_tenant
@requiert_permission("rapports.exporter.etablissement")
def rapport_academique(request):
    annee = request.annee_scolaire_courante
    stats = {}
    if annee:
        from apps.eleves.models import Inscription, StatutInscription
        from apps.notes.models import MoyenneGenerale
        stats["nb_eleves"] = Inscription.objects.filter(annee_scolaire=annee, statut=StatutInscription.VALIDEE).count()
        stats["nb_admis"] = MoyenneGenerale.objects.filter(inscription__annee_scolaire=annee, est_admis=True, est_publiee=True).count()
        stats["nb_classes"] = annee.classes.filter(est_actif=True).count()
    return render(request, "rapports/academique.html", {"annee": annee, "stats": stats})


@login_required
@requiert_tenant
@requiert_permission("rapports.exporter.etablissement")
def rapport_financier(request):
    annee = request.annee_scolaire_courante
    from django.db.models import Q, Sum, Count
    from apps.finances.models import FraisEleve, Paiement
    stats = {
        "total_du": Decimal("0.00"),
        "total_paye": Decimal("0.00"),
        "solde_global": Decimal("0.00"),
        "nombre_frais": 0,
        "nombre_paiements": 0,
        "taux_recouvrement": 0,
    }
    repartition = []
    if annee:
        frais_annee = FraisEleve.objects.filter(inscription__annee_scolaire=annee)
        total_frais = frais_annee.aggregate(
            total=Sum("montant_net"), nombre=Count("id")
        )
        paiements_annee = Paiement.objects.filter(
            frais_eleve__inscription__annee_scolaire=annee,
            est_annule=False,
            statut__in=["partiel", "complet"],
        )
        total_paiements = paiements_annee.aggregate(
            total=Sum("montant_paye"), nombre=Count("id")
        )
        stats["total_du"] = total_frais["total"] or Decimal("0.00")
        stats["total_paye"] = total_paiements["total"] or Decimal("0.00")
        stats["solde_global"] = max(
            stats["total_du"] - stats["total_paye"], Decimal("0.00")
        )
        stats["nombre_frais"] = total_frais["nombre"] or 0
        stats["nombre_paiements"] = total_paiements["nombre"] or 0
        if stats["total_du"] > 0:
            stats["taux_recouvrement"] = min(
                round(stats["total_paye"] * 100 / stats["total_du"]), 100
            )

        dues_par_type = frais_annee.values(
            "type_frais_id", "type_frais__libelle"
        ).annotate(total_du=Sum("montant_net"))
        paiements_par_type = {
            ligne["frais_eleve__type_frais_id"]: ligne["total_paye"]
            for ligne in paiements_annee.values(
                "frais_eleve__type_frais_id"
            ).annotate(total_paye=Sum("montant_paye"))
        }
        for ligne in dues_par_type:
            du = ligne["total_du"] or Decimal("0.00")
            paye = paiements_par_type.get(
                ligne["type_frais_id"], Decimal("0.00")
            ) or Decimal("0.00")
            repartition.append({
                "libelle": ligne["type_frais__libelle"],
                "total_du": du,
                "total_paye": paye,
                "solde": max(du - paye, Decimal("0.00")),
                "taux": min(round(paye * 100 / du), 100) if du else 0,
            })
        repartition.sort(key=lambda ligne: ligne["total_du"], reverse=True)
    return render(
        request,
        "rapports/financier.html",
        {"annee": annee, "stats": stats, "repartition": repartition},
    )


@login_required
@requiert_tenant
@requiert_permission("rapports.exporter.etablissement")
def rapport_eleves(request):
    from apps.eleves.models import (
        Eleve,
        Inscription,
        Sexe,
        StatutEleve,
        StatutInscription,
    )
    from django.db.models import Count
    eleves = Eleve.objects.filter(supprime_le__isnull=True)
    stats = list(
        eleves.values("statut").annotate(nb=Count("id")).order_by("statut")
    )
    statuts = dict(StatutEleve.choices)
    for ligne in stats:
        ligne["libelle"] = statuts.get(ligne["statut"], ligne["statut"])
    nombre_eleves = eleves.count()
    eleves_par_sexe = {
        ligne["sexe"]: ligne["nb"]
        for ligne in eleves.values("sexe").annotate(nb=Count("id"))
    }
    sexes = [
        {"libelle": libelle, "nombre": eleves_par_sexe.get(code, 0)}
        for code, libelle in Sexe.choices
    ]
    for sexe in sexes:
        sexe["part"] = (
            round(sexe["nombre"] * 100 / nombre_eleves) if nombre_eleves else 0
        )

    annee = request.annee_scolaire_courante
    inscriptions = Inscription.objects.none()
    if annee:
        inscriptions = Inscription.objects.filter(
            annee_scolaire=annee,
            statut=StatutInscription.VALIDEE,
        )
    inscriptions_par_classe = list(
        inscriptions.values("classe__code", "classe__libelle")
        .annotate(nombre=Count("id"))
        .order_by("-nombre", "classe__code")[:6]
    )
    return render(
        request,
        "rapports/eleves.html",
        {
            "stats": stats,
            "nombre_eleves": nombre_eleves,
            "nombre_actifs": eleves.filter(statut=StatutEleve.ACTIF).count(),
            "nombre_inscrits": inscriptions.count(),
            "annee": annee,
            "sexes": sexes,
            "inscriptions_par_classe": inscriptions_par_classe,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("rapports.exporter.etablissement")
def exporter(request, type_rapport):
    """Export CSV/Excel générique."""
    import csv
    from django.http import HttpResponse
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f"attachment; filename=rapport_{type_rapport}.csv"
    writer = csv.writer(response)
    writer.writerow([f"Export {type_rapport} — {request.etablissement.nom}"])
    return response
