from django.apps import AppConfig

class RapportsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.rapports"
    verbose_name = "Tableaux de bord et exports"
