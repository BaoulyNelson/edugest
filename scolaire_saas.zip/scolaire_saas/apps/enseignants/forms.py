"""Formulaires de gestion des enseignants."""
from django import forms
from apps.enseignants.models import Enseignant, AffectationEnseignant
from apps.etablissements.forms import WS

W = lambda: {"class": "form-control"}

class FormulaireEnseignant(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Matricule : jamais requis dans le form — généré par save()
        self.fields["matricule"].required = False
        self.fields["matricule"].widget.attrs.update({
            "readonly":    True,
            "class":       "form-control bg-light text-muted",
            "placeholder": "Généré automatiquement",
        })
        if self.instance.pk:
            # En édition : afficher la valeur figée
            self.fields["matricule"].help_text = "Le matricule ne peut pas être modifié."
        else:
            # En création : champ vide, sera rempli par save()
            self.fields["matricule"].help_text = "Attribué automatiquement à l'enregistrement."

        # Licence MENFP : éditable mais pas obligatoire
        self.fields["numero_licence_menfp"].required = False

    def clean_matricule(self):
        # Bloquer toute modification en édition même si readonly bypassé (curl, etc.)
        if self.instance.pk:
            return self.instance.matricule
        return self.cleaned_data.get("matricule") or ""

    class Meta:
        model = Enseignant
        fields = [
            "matricule", "nom", "prenom", "date_naissance", "sexe", "nationalite",
            "photo", "telephone", "email", "adresse",
            "specialite_principale", "annees_experience",
            "numero_licence_menfp", "type_contrat", "date_embauche", "salaire_mensuel",
        ]
        widgets = {
            "date_naissance":        forms.DateInput(attrs={**W(), "type": "date"}),
            "date_embauche":         forms.DateInput(attrs={**W(), "type": "date"}),
            "sexe":                  forms.Select(attrs=WS()),
            "type_contrat":          forms.Select(attrs=WS()),
            "specialite_principale": forms.Select(attrs=WS()),
            "adresse":               forms.Textarea(attrs={**W(), "rows": 2}),
            "salaire_mensuel":       forms.NumberInput(attrs=W()),
            "annees_experience":     forms.NumberInput(attrs=W()),
            "numero_licence_menfp":  forms.TextInput(attrs={
                **W(),
                "placeholder": "Provisoire généré — remplacer par le N° officiel MENFP",
            }),
            **{f: forms.TextInput(attrs=W()) for f in [
                "nom", "prenom", "nationalite", "telephone", "email",
            ]},
        }  
    
    
class FormulaireEnseignantRapide(forms.ModelForm):
    class Meta:
        model = Enseignant
        fields = ["nom", "prenom", "sexe"]
        widgets = {
            "nom": forms.TextInput(attrs={"class": "form-control"}),
            "prenom": forms.TextInput(attrs={"class": "form-control"}),
            "sexe": forms.Select(attrs={"class": "form-select"}),
        }


class FormulaireAffectation(forms.ModelForm):
    def __init__(self, *args, ecole=None, enseignant_initial=None, **kwargs):
        super().__init__(*args, **kwargs)

        if ecole:
            from apps.academique.models import MatiereClasse
            self.fields["enseignant"].queryset = Enseignant.objects.filter(
                ecole=ecole, statut="actif", supprime_le__isnull=True
            )
            self.fields["matiere_classe"].queryset = MatiereClasse.objects.filter(
                ecole=ecole
            )

        if enseignant_initial:
            # 1. Champ visible grisé juste pour l'affichage
            self.fields["enseignant_affiche"] = forms.CharField(
                label="Enseignant",
                required=False,
                initial=enseignant_initial.nom_complet,
                widget=forms.TextInput(attrs={
                    "class": "form-control bg-light text-muted",
                    "disabled": True,
                }),
            )
            # 2. Champ caché qui soumet vraiment la valeur
            self.fields["enseignant"].widget = forms.HiddenInput()
            self.fields["enseignant"].initial = enseignant_initial.pk
            self.fields["enseignant"].required = True

            # 3. Mettre enseignant_affiche en premier, enseignant (hidden) juste après
            field_order = ["enseignant_affiche", "enseignant"] + [
                f for f in self.fields if f not in ("enseignant_affiche", "enseignant")
            ]
            self.fields = {k: self.fields[k] for k in field_order}

    class Meta:
        model = AffectationEnseignant
        fields = ["enseignant", "matiere_classe", "est_principale", "date_debut", "date_fin"]
        widgets = {
            "date_debut": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "date_fin":   forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "enseignant":   forms.Select(attrs={"class": "form-control"}),
            "matiere_classe":   forms.Select(attrs={"class": "form-control"}),
        }