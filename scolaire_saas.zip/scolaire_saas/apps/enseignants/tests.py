from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.etablissements.models import Etablissement
from apps.enseignants.models import Enseignant
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AssociationCompteEnseignantTests(TestCase):
    def setUp(self):
        utilisateur = get_user_model().objects.create_user(
            email="responsable-association@example.com",
            nom="Responsable",
            prenom="École",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-association-enseignants",
            nom="École association enseignants",
            ville="Port-au-Prince",
            cree_par=utilisateur,
        )
        permission = PermissionGranulaire.objects.create(
            code="parametrage.modifier.etablissement",
            description="Gérer le paramétrage de l'école.",
            module="parametrage",
            action="modifier",
            portee="etablissement",
        )
        role_responsable = Role.objects.create(
            ecole=self.ecole,
            code="responsable-association",
            libelle="Responsable",
        )
        role_responsable.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=role_responsable,
        )
        self.client.force_login(utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

        self.role_enseignant = Role.objects.create(
            ecole=self.ecole,
            code="enseignant",
            libelle="Enseignant",
            est_systeme=True,
        )
        self.compte = get_user_model().objects.create_user(
            email="enseignant-invite@example.com",
            nom="Invité",
            prenom="Enseignant",
        )
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.compte,
            role=self.role_enseignant,
        )

    def test_page_presente_les_comptes_enseignants_sans_profil(self):
        response = self.client.get(reverse("enseignants:associer_comptes"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.compte.email)
        self.assertContains(response, "Attribuer un profil")

    def test_cree_un_profil_lie_au_compte_selectionne(self):
        response = self.client.post(
            reverse("enseignants:associer_comptes"),
            {
                "compte": str(self.compte.pk),
                "action": "creer",
                "nom": "Enseignant",
                "prenom": "Invité",
                "sexe": "M",
                "nationalite": "Haïtienne",
                "specialite_principale": "autre",
                "annees_experience": "0",
                "type_contrat": "permanent",
            },
        )

        self.assertEqual(
            response.status_code,
            302,
            str(response.context["formulaire"].errors)
            if response.context and response.context.get("formulaire")
            else response.content[:500],
        )
        profil = Enseignant.objects.get(ecole=self.ecole, utilisateur=self.compte)
        self.assertRedirects(
            response,
            reverse("enseignants:detail", kwargs={"pk": profil.pk}),
        )
        self.assertEqual(profil.nom, "Enseignant")
        self.assertEqual(profil.email, "")
        response_detail = self.client.get(response.url)
        self.assertContains(response_detail, self.compte.email)

    def test_associe_un_profil_existant_non_lie(self):
        profil = Enseignant.objects.create(
            ecole=self.ecole,
            nom="PROFIL",
            prenom="Existant",
            sexe="F",
        )

        response = self.client.post(
            reverse("enseignants:associer_comptes"),
            {
                "compte": str(self.compte.pk),
                "action": "associer",
                "profil": str(profil.pk),
            },
        )

        self.assertRedirects(response, reverse("enseignants:associer_comptes"))
        profil.refresh_from_db()
        self.assertEqual(profil.utilisateur, self.compte)

    def test_refuse_un_compte_sans_role_enseignant(self):
        autre_compte = get_user_model().objects.create_user(
            email="autre-role@example.com",
            nom="Autre",
            prenom="Rôle",
        )

        response = self.client.post(
            reverse("enseignants:associer_comptes"),
            {
                "compte": str(autre_compte.pk),
                "action": "creer",
                "nom": "Autre",
                "prenom": "Rôle",
                "sexe": "M",
            },
        )

        self.assertEqual(response.status_code, 404)
        self.assertFalse(
            Enseignant.objects.filter(
                ecole=self.ecole,
                utilisateur=autre_compte,
            ).exists()
        )

    def test_page_est_refusee_sans_permission_de_gestion(self):
        self.client.force_login(self.compte)

        response = self.client.get(reverse("enseignants:associer_comptes"))

        self.assertEqual(response.status_code, 403)

    def test_liste_accepte_un_enseignant_sans_compte_utilisateur(self):
        enseignant = Enseignant.objects.create(
            ecole=self.ecole,
            nom="Sans",
            prenom="Compte",
            sexe="F",
        )

        response = self.client.get(reverse("enseignants:liste"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Compte Sans")
        response_detail = self.client.get(
            reverse("enseignants:detail", kwargs={"pk": enseignant.pk})
        )

        self.assertEqual(response_detail.status_code, 200)
        self.assertContains(response_detail, "Email")
        self.assertContains(response_detail, "—")
