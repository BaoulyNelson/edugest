from django.urls import path
from apps.enseignants import views

app_name = "enseignants"
urlpatterns = [
    path("", views.liste_enseignants, name="liste"),
    path("creer/", views.creer_enseignant, name="creer"),
    path("profils-comptes/", views.associer_comptes_enseignants, name="associer_comptes"),
    path("importer/", views.importer_enseignants, name="importer"),
    path("<uuid:pk>/", views.detail_enseignant, name="detail"),
    path("<uuid:pk>/modifier/", views.modifier_enseignant, name="modifier"),
    path("affectations/", views.liste_affectations, name="affectations"),
    path("affectations/creer/", views.creer_affectation, name="creer_affectation"),
    path("emploi-du-temps/", views.emploi_du_temps, name="emploi_du_temps"),
]
