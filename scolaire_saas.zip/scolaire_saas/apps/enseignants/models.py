"""
apps/enseignants/models.py
===========================
Gestion des enseignants, de leurs affectations par année et de leurs charges horaires.
"""

from django.db import models
from apps.noyau.mixins import (
    ContactUniqueMixin, UUIDPrimaryKeyMixin, TenantModelMixin,
    HorodatageMixin, SuppressionDouce, ActivableMixin
)


class Specialite(models.TextChoices):
    MATHEMATIQUES = "maths", "Mathématiques"
    SCIENCES = "sciences", "Sciences Naturelles"
    FRANCAIS = "francais", "Français / Littérature"
    CREOLE = "creole", "Créole Haïtien"
    ANGLAIS = "anglais", "Anglais"
    ESPAGNOL = "espagnol", "Espagnol"
    HISTOIRE_GEO = "hist_geo", "Histoire & Géographie"
    PHYSIQUE_CHIMIE = "phys_chim", "Physique-Chimie"
    INFORMATIQUE = "info", "Informatique / Technologie"
    EDUCATION_PHYSIQUE = "ep", "Éducation Physique"
    MUSIQUE_ART = "arts", "Arts / Musique"
    RELIGION = "religion", "Éducation Religieuse"
    AUTRE = "autre", "Autre"


class StatutEnseignant(models.TextChoices):
    ACTIF = "actif", "Actif"
    CONGE = "conge", "En congé"
    SUSPENDU = "suspendu", "Suspendu"
    INACTIF = "inactif", "Inactif"
    RETRAITE = "retraite", "Retraité"


class Enseignant(
    ContactUniqueMixin,
    UUIDPrimaryKeyMixin,
    TenantModelMixin,
    HorodatageMixin,
    SuppressionDouce,
):
    """
    Profil d'un enseignant dans l'établissement.
    Peut être lié à un compte Utilisateur (connexion au système) ou non (enseignant sans accès).
    """
    # Lien optionnel vers le compte utilisateur système
    utilisateur = models.OneToOneField(
        "comptes.Utilisateur",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="profil_enseignant",
        verbose_name="Compte utilisateur",
        help_text="Si renseigné, l'enseignant peut se connecter au système.",
    )

    # ── Identité ──────────────────────────────────────────────────────────────
    matricule = models.CharField(
    max_length=30,
    blank=True,   # ← permet la soumission sans valeur
    verbose_name="Matricule interne",
    help_text="Généré automatiquement à la création.",
)
    nom = models.CharField(max_length=80)
    prenom = models.CharField(max_length=80)
    date_naissance = models.DateField(null=True, blank=True)
    sexe = models.CharField(max_length=1, choices=[("M", "Masculin"), ("F", "Féminin")])
    nationalite = models.CharField(max_length=50, default="Haïtienne")
    photo = models.ImageField(
        upload_to="enseignants/photos/%Y/",
        null=True,
        blank=True,
    )

    # ── Contacts ──────────────────────────────────────────────────────────────
    telephone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    adresse = models.TextField(blank=True)

    # ── Qualifications ────────────────────────────────────────────────────────
    specialite_principale = models.CharField(
        max_length=20,
        choices=Specialite.choices,
        default=Specialite.AUTRE,
    )

    annees_experience = models.PositiveSmallIntegerField(default=0)
    numero_licence_menfp = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="N° Licence MENFP",
    )

    # ── Contrat ───────────────────────────────────────────────────────────────
    type_contrat = models.CharField(
        max_length=20,
        choices=[
            ("permanent", "Permanent"),
            ("vacataire", "Vacataire"),
            ("contractuel", "Contractuel"),
            ("benevole", "Bénévole"),
        ],
        default="permanent",
    )
    date_embauche = models.DateField(null=True, blank=True)
    salaire_mensuel = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )

    statut = models.CharField(
        max_length=15,
        choices=StatutEnseignant.choices,
        default=StatutEnseignant.ACTIF,
        db_index=True,
    )

    class Meta:
        verbose_name = "Enseignant"
        verbose_name_plural = "Enseignants"
        unique_together = [("ecole", "matricule")]
        ordering = ["nom", "prenom"]
        

    def __str__(self):
        return f"{self.prenom} {self.nom} [{self.matricule}]"
    
    
    # Enseignant.save()
    def save(self, *args, **kwargs):
        if not self.matricule:
            from apps.noyau.utilitaires import generer_matricule_enseignant
            self.matricule = generer_matricule_enseignant(self.ecole)
        if not self.numero_licence_menfp:
            from apps.noyau.utilitaires import generer_numero_licence
            self.numero_licence_menfp = generer_numero_licence(self.ecole)
        super().save(*args, **kwargs)

    @property
    def nom_complet(self) -> str:
        return f"{self.prenom} {self.nom}"


class AffectationEnseignant(TenantModelMixin, HorodatageMixin):
    """
    Affecte un enseignant à une matière dans une classe pour une année donnée.
    Remplace les affectations de l'année précédente (pas de copie automatique).
    """
    enseignant = models.ForeignKey(
        Enseignant,
        on_delete=models.PROTECT,
        related_name="affectations",
    )
    matiere_classe = models.ForeignKey(
        "academique.MatiereClasse",
        on_delete=models.CASCADE,
        related_name="affectations_enseignants",
    )
    est_principale = models.BooleanField(
        default=True,
        help_text="False si l'enseignant est remplaçant.",
    )
    date_debut = models.DateField()
    date_fin = models.DateField(null=True, blank=True)
    est_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Affectation d'enseignant"
        verbose_name_plural = "Affectations d'enseignants"


class CreneauHoraire(TenantModelMixin, HorodatageMixin):
    """
    Créneau dans l'emploi du temps hebdomadaire.
    Définit quand un enseignant est dans quelle salle pour quelle matière.
    """
    JOURS = [
        (1, "Lundi"),
        (2, "Mardi"),
        (3, "Mercredi"),
        (4, "Jeudi"),
        (5, "Vendredi"),
        (6, "Samedi"),
    ]

    affectation = models.ForeignKey(
        AffectationEnseignant,
        on_delete=models.CASCADE,
        related_name="creneaux",
    )
    annee_scolaire = models.ForeignKey(
        "academique.AnneeScolaire",
        on_delete=models.CASCADE,
    )
    jour = models.PositiveSmallIntegerField(choices=JOURS)
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    salle = models.CharField(max_length=50, blank=True)

    class Meta:
        verbose_name = "Créneau horaire"
        verbose_name_plural = "Créneaux horaires"
        ordering = ["jour", "heure_debut"]
