from django.contrib import admin
from apps.enseignants.models import AffectationEnseignant, CreneauHoraire, Enseignant
from apps.noyau.admin import AdminTenant

admin.site.register((Enseignant, AffectationEnseignant, CreneauHoraire), AdminTenant)
