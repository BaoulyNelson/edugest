"""Vues de gestion des enseignants."""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from apps.noyau.decorateurs import requiert_tenant, requiert_permission
from apps.enseignants.models import Enseignant, AffectationEnseignant


# À REMPLACER dans apps/enseignants/views.py : l'ancienne fonction liste_enseignants.
# Ajouter ces imports tout en haut du fichier :
import csv
from django.core.paginator import Paginator
from django.http import HttpResponse
from apps.enseignants.models import Enseignant, AffectationEnseignant, Specialite, StatutEnseignant


@login_required
@requiert_tenant
def liste_enseignants(request):
    """Liste filtrable, paginée et exportable des enseignants."""
    q = request.GET.get("q", "").strip()
    filtre_specialite = request.GET.get("specialite", "")
    filtre_sexe = request.GET.get("sexe", "")
    filtre_statut = request.GET.get("statut", "")
    filtre_contrat = request.GET.get("type_contrat", "")
    per_page = request.GET.get("per_page", "10")
    if per_page not in ("10", "20", "50"):
        per_page = "10"

    enseignants = Enseignant.objects.filter(
        supprime_le__isnull=True
    ).select_related("utilisateur").order_by("nom", "prenom")
    if q:
        enseignants = enseignants.filter(
            Q(nom__icontains=q)
            | Q(prenom__icontains=q)
            | Q(matricule__icontains=q)
            | Q(email__icontains=q)
            | Q(utilisateur__email__icontains=q)
            | Q(telephone__icontains=q)
        )
    if filtre_specialite:
        enseignants = enseignants.filter(specialite_principale=filtre_specialite)
    if filtre_sexe:
        enseignants = enseignants.filter(sexe=filtre_sexe)
    if filtre_statut:
        enseignants = enseignants.filter(statut=filtre_statut)
    if filtre_contrat:
        enseignants = enseignants.filter(type_contrat=filtre_contrat)

    # ── Export CSV (même format que l'import) : tout le filtre, ou seulement la sélection (?ids=…)
    if request.GET.get("export") == "csv":
        ids = request.GET.getlist("ids")
        if ids:
            enseignants = enseignants.filter(pk__in=ids)
        reponse = HttpResponse(content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = 'attachment; filename="enseignants.csv"'
        reponse.write("﻿")  # BOM : Excel lit correctement les accents
        w = csv.writer(reponse)
        w.writerow(
            [
                "matricule",
                "nom",
                "prenom",
                "date_naissance",
                "sexe",
                "nationalite",
                "telephone",
                "email",
                "adresse",
                "specialite_principale",
                "annees_experience",
                "numero_licence_menfp",
                "type_contrat",
                "date_embauche",
                "salaire_mensuel",
                "statut",
            ]
        )
        for e in enseignants:
            w.writerow(
                [
                    e.matricule,
                    e.nom,
                    e.prenom,
                    e.date_naissance or "",
                    e.sexe,
                    e.nationalite,
                    e.telephone,
                    e.email or (e.utilisateur.email if e.utilisateur else ""),
                    e.adresse,
                    e.specialite_principale,
                    e.annees_experience,
                    e.numero_licence_menfp,
                    e.type_contrat,
                    e.date_embauche or "",
                    e.salaire_mensuel if e.salaire_mensuel is not None else "",
                    e.statut,
                ]
            )
        return reponse

    paginator = Paginator(enseignants, int(per_page))
    page_obj = paginator.get_page(request.GET.get("page"))

    return render(
        request,
        "enseignants/liste.html",
        {
            "enseignants": page_obj,
            "page_obj": page_obj,
            "total_enseignants": paginator.count,
            "q": q,
            "per_page": per_page,
            "filtre_specialite": filtre_specialite,
            "filtre_sexe": filtre_sexe,
            "filtre_statut": filtre_statut,
            "filtre_contrat": filtre_contrat,
            "specialite_choices": Specialite.choices,
            "sexe_choices": Enseignant._meta.get_field("sexe").choices,
            "statut_choices": StatutEnseignant.choices,
            "contrat_choices": Enseignant._meta.get_field("type_contrat").choices,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def associer_comptes_enseignants(request):
    from apps.comptes.models import Utilisateur
    from apps.securite.models import UtilisateurRole
    from apps.enseignants import forms

    attributions = UtilisateurRole.tous_objets.filter(
        ecole=request.etablissement,
        est_actif=True,
        role__code="enseignant",
        role__est_actif=True,
    ).filter(Q(expire_le__isnull=True) | Q(expire_le__gte=timezone.localdate()))
    comptes = (
        Utilisateur.objects.filter(
            pk__in=attributions.values("utilisateur_id"),
            est_actif=True,
        )
        .exclude(profil_enseignant__isnull=False)
        .order_by("nom", "prenom", "email")
    )
    profils_disponibles = Enseignant.objects.filter(
        ecole=request.etablissement,
        utilisateur__isnull=True,
        supprime_le__isnull=True,
    ).order_by("nom", "prenom")
    compte_id = request.GET.get("compte") or request.POST.get("compte")
    compte_selectionne = None
    formulaire = None
    action = request.GET.get("action") or request.POST.get("action", "")
    profil_id = request.POST.get("profil")
    erreurs_association = None

    if compte_id:
        compte_selectionne = get_object_or_404(comptes, pk=compte_id)

    if request.method == "POST":
        if not compte_selectionne:
            messages.error(request, "Sélectionnez un compte enseignant.")
            return redirect("enseignants:associer_comptes")

        if action == "associer":
            with transaction.atomic():
                compte_selectionne = get_object_or_404(
                    comptes.select_for_update(),
                    pk=compte_selectionne.pk,
                )
                profil = get_object_or_404(
                    profils_disponibles.select_for_update(),
                    pk=profil_id,
                )
                profil.utilisateur = compte_selectionne
                profil.save(update_fields=["utilisateur", "modifie_le"])
            messages.success(
                request,
                f"Le profil de {profil.nom_complet} est maintenant associé "
                f"au compte {compte_selectionne.email}.",
            )
            return redirect("enseignants:associer_comptes")

        if action == "creer":
            donnees_initiales = {
                "nom": compte_selectionne.nom,
                "prenom": compte_selectionne.prenom,
                "email": "",
            }
            formulaire = forms.FormulaireEnseignant(
                request.POST,
                request.FILES,
                initial=donnees_initiales,
            )
            if formulaire.is_valid():
                with transaction.atomic():
                    compte_selectionne = get_object_or_404(
                        comptes.select_for_update(),
                        pk=compte_selectionne.pk,
                    )
                    if hasattr(compte_selectionne, "profil_enseignant"):
                        messages.error(
                            request,
                            "Ce compte est déjà associé à un profil enseignant.",
                        )
                        return redirect("enseignants:associer_comptes")
                    profil = formulaire.save(commit=False)
                    profil.ecole = request.etablissement
                    profil.utilisateur = compte_selectionne
                    profil.save()
                messages.success(
                    request,
                    f"Le profil de {profil.nom_complet} a été créé et associé "
                    f"au compte {compte_selectionne.email}.",
                )
                return redirect("enseignants:detail", pk=profil.pk)
        else:
            messages.error(request, "Choisissez une action valide.")
            return redirect("enseignants:associer_comptes")
    elif compte_selectionne and action == "creer":
        formulaire = forms.FormulaireEnseignant(
            initial={
                "nom": compte_selectionne.nom,
                "prenom": compte_selectionne.prenom,
                "email": "",
                "nationalite": "Haïtienne",
                "specialite_principale": Specialite.AUTRE,
                "annees_experience": 0,
                "type_contrat": "permanent",
            }
        )

    return render(
        request,
        "enseignants/associer_comptes.html",
        {
            "comptes": comptes,
            "profils_disponibles": profils_disponibles,
            "compte_selectionne": compte_selectionne,
            "formulaire": formulaire,
            "action": action,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_enseignant(request):
    from apps.enseignants import forms

    if request.method == "POST":
        form = forms.FormulaireEnseignant(request.POST, request.FILES)
        if form.is_valid():
            e = form.save(commit=False)
            e.ecole = request.etablissement
            e.save()
            messages.success(request, f"Enseignant {e.nom_complet} créé.")
            return redirect("enseignants:detail", pk=e.pk)
    else:
        form = forms.FormulaireEnseignant()
    return render(request, "enseignants/form.html", {"form": form})


@login_required
@requiert_tenant
def detail_enseignant(request, pk):
    enseignant = get_object_or_404(Enseignant, pk=pk, ecole=request.etablissement)
    affectations = enseignant.affectations.select_related(
        "matiere_classe__matiere", "matiere_classe__classe"
    )
    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    if q:
        affectations = affectations.filter(
            Q(matiere_classe__classe__code__icontains=q)
            | Q(matiere_classe__classe__libelle__icontains=q)
            | Q(matiere_classe__matiere__libelle__icontains=q)
        )
    if statut == "actif":
        affectations = affectations.filter(est_active=True)
    elif statut == "inactif":
        affectations = affectations.filter(est_active=False)
    else:
        statut = ""
    return render(
        request,
        "enseignants/detail.html",
        {
            "enseignant": enseignant,
            "affectations": affectations,
            "q": q,
            "filtre_statut": statut,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_enseignant(request, pk):
    enseignant = get_object_or_404(Enseignant, pk=pk, ecole=request.etablissement)
    from apps.enseignants import forms

    if request.method == "POST":
        form = forms.FormulaireEnseignant(
            request.POST, request.FILES, instance=enseignant
        )
        if form.is_valid():
            form.save()
            messages.success(request, "Dossier enseignant mis à jour.")
            return redirect("enseignants:detail", pk=pk)
    else:
        form = forms.FormulaireEnseignant(instance=enseignant)
    return render(
        request, "enseignants/form.html", {"form": form, "enseignant": enseignant}
    )


@login_required
@requiert_tenant
def liste_affectations(request):
    from apps.academique.models import Classe

    q = request.GET.get("q", "").strip()
    classe_id = request.GET.get("classe", "")
    statut = request.GET.get("statut", "actif")
    classes = Classe.objects.filter(ecole=request.etablissement).order_by("code")
    affectations = AffectationEnseignant.objects.filter(
        ecole=request.etablissement
    ).select_related(
        "enseignant", "matiere_classe__matiere", "matiere_classe__classe"
    )
    if q:
        affectations = affectations.filter(
            Q(enseignant__nom__icontains=q)
            | Q(enseignant__prenom__icontains=q)
            | Q(enseignant__matricule__icontains=q)
            | Q(matiere_classe__classe__code__icontains=q)
            | Q(matiere_classe__matiere__libelle__icontains=q)
        )
    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            affectations = affectations.filter(matiere_classe__classe_id=classe_pk)
        else:
            classe_id = ""
    if statut == "actif":
        affectations = affectations.filter(est_active=True)
    elif statut == "inactif":
        affectations = affectations.filter(est_active=False)
    else:
        statut = ""
    return render(
        request,
        "enseignants/affectations.html",
        {
            "affectations": affectations,
            "classes": classes,
            "q": q,
            "filtre_classe": classe_id,
            "filtre_statut": statut,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_affectation(request):
    from apps.enseignants import forms

    # Récupère l'enseignant depuis l'URL si on vient de sa page de détail
    enseignant_pk = request.GET.get("enseignant")
    enseignant_initial = None
    if enseignant_pk:
        enseignant_initial = get_object_or_404(
            Enseignant, pk=enseignant_pk, ecole=request.etablissement
        )

    if request.method == "POST":
        form = forms.FormulaireAffectation(
            request.POST,
            ecole=request.etablissement,
            enseignant_initial=enseignant_initial,
        )
        if form.is_valid():
            a = form.save(commit=False)
            a.ecole = request.etablissement
            a.save()
            messages.success(request, "Affectation créée.")
            return redirect("enseignants:affectations")
    else:
        form = forms.FormulaireAffectation(
            ecole=request.etablissement,
            enseignant_initial=enseignant_initial,   # ← nouveau
        )
    return render(request, "enseignants/form_affectation.html", {
        "form": form,
        "enseignant": enseignant_initial,            # ← pour le titre de la page
    })


@login_required
@requiert_tenant
def emploi_du_temps(request):
    from apps.enseignants.models import CreneauHoraire
    from apps.academique.models import Classe

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    classe_id = request.GET.get("classe", "")
    jour = request.GET.get("jour", "")
    creneaux = (
        CreneauHoraire.objects.filter(
            ecole=request.etablissement, annee_scolaire=annee
        ).select_related(
            "affectation__enseignant",
            "affectation__matiere_classe__matiere",
            "affectation__matiere_classe__classe",
        )
        if annee
        else CreneauHoraire.objects.none()
    )
    classes = Classe.objects.filter(
        ecole=request.etablissement, annee_scolaire=annee
    ).order_by("code") if annee else Classe.objects.none()
    if q:
        creneaux = creneaux.filter(
            Q(affectation__enseignant__nom__icontains=q)
            | Q(affectation__enseignant__prenom__icontains=q)
            | Q(affectation__matiere_classe__matiere__libelle__icontains=q)
            | Q(affectation__matiere_classe__classe__code__icontains=q)
            | Q(salle__icontains=q)
        )
    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            creneaux = creneaux.filter(
                affectation__matiere_classe__classe_id=classe_pk
            )
        else:
            classe_id = ""
    jour_values = {str(value) for value, _ in CreneauHoraire.JOURS}
    if jour in jour_values:
        creneaux = creneaux.filter(jour=jour)
    else:
        jour = ""
    return render(
        request,
        "enseignants/emploi_du_temps.html",
        {
            "creneaux": creneaux,
            "annee": annee,
            "classes": classes,
            "jour_choices": CreneauHoraire.JOURS,
            "q": q,
            "filtre_classe": classe_id,
            "filtre_jour": jour,
        },
    )

# À COLLER dans apps/enseignants/views.py (en bas, avant le « from django.shortcuts import render » final).
# Ajouter aussi dans apps/enseignants/urls.py :
#     path("importer/", views.importer_enseignants, name="importer"),
# (vérifier que cette ligne est placée avant les routes avec <uuid:pk> / <pk>)


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def importer_enseignants(request):
    """Import CSV d'enseignants en masse (même logique que l'import des élèves)."""
    import csv, io, datetime, unicodedata
    from decimal import Decimal, InvalidOperation
    from apps.enseignants.models import Specialite, StatutEnseignant

    def norm(texte):
        """minuscules, sans accents ni espaces superflus : « Éducation Physique » -> « education physique »."""
        texte = unicodedata.normalize("NFKD", (texte or "").strip().lower())
        return "".join(c for c in texte if not unicodedata.combining(c))

    CONTRATS = [
        ("permanent", "Permanent"),
        ("vacataire", "Vacataire"),
        ("contractuel", "Contractuel"),
        ("benevole", "Bénévole"),
    ]

    def table_choix(choices):
        """Accepte le code OU le libellé : « maths » comme « Mathématiques »."""
        t = {}
        for code, libelle in choices:
            t[norm(code)] = code
            t[norm(libelle)] = code
        return t

    CH_SPEC = table_choix(Specialite.choices)
    CH_CONTRAT = table_choix(CONTRATS)
    CH_STATUT = table_choix(StatutEnseignant.choices)
    CH_SEXE = {
        "m": "M",
        "masculin": "M",
        "homme": "M",
        "f": "F",
        "feminin": "F",
        "femme": "F",
    }

    ALIAS = {
        "matricule": "matricule",
        "nom": "nom",
        "nom_famille": "nom",
        "prenom": "prenom",
        "prenoms": "prenom",
        "date_naissance": "date_naissance",
        "date naissance": "date_naissance",
        "sexe": "sexe",
        "nationalite": "nationalite",
        "telephone": "telephone",
        "email": "email",
        "adresse": "adresse",
        "specialite_principale": "specialite_principale",
        "specialite": "specialite_principale",
        "annees_experience": "annees_experience",
        "annees experience": "annees_experience",
        "numero_licence_menfp": "numero_licence_menfp",
        "licence_menfp": "numero_licence_menfp",
        "type_contrat": "type_contrat",
        "type contrat": "type_contrat",
        "date_embauche": "date_embauche",
        "date embauche": "date_embauche",
        "salaire_mensuel": "salaire_mensuel",
        "salaire mensuel": "salaire_mensuel",
        "statut": "statut",
    }

    def lire_date(valeur):
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
            try:
                return datetime.datetime.strptime(valeur, fmt).date()
            except ValueError:
                continue
        raise ValueError(f"date invalide « {valeur} »")

    def lire_choix(valeur, table, nom_champ):
        code = table.get(norm(valeur))
        if not code:
            raise ValueError(f"{nom_champ} inconnu : « {valeur} »")
        return code

    if request.method == "POST" and request.FILES.get("fichier_csv"):
        texte = request.FILES["fichier_csv"].read().decode("utf-8-sig")
        try:
            dialecte = csv.Sniffer().sniff(texte[:2048], delimiters=",;\t")
        except csv.Error:
            dialecte = csv.excel
        reader = csv.DictReader(io.StringIO(texte), dialect=dialecte)

        nb_crees, nb_existants, erreurs, ignorees = 0, 0, [], set()

        for num, brut in enumerate(reader, start=2):  # ligne 1 = en-têtes
            try:
                ligne = {}
                for cle, val in brut.items():
                    cle_norm = norm(cle)
                    champ = ALIAS.get(cle_norm)
                    if not champ:
                        if cle_norm and cle_norm != "photo":
                            ignorees.add(cle)
                        continue
                    ligne[champ] = (val or "").strip()

                if not ligne.get("nom") or not ligne.get("prenom"):
                    raise ValueError("nom ou prénom manquant")
                ligne["nom"] = ligne["nom"].upper()
                matricule = ligne.pop("matricule", "")

                # Conversions typées (une valeur vide -> défaut du modèle)
                ligne["sexe"] = CH_SEXE.get(norm(ligne.get("sexe", "")), None)
                if not ligne["sexe"]:
                    raise ValueError("sexe invalide (M ou F)")
                for champ in ("date_naissance", "date_embauche"):
                    if ligne.get(champ):
                        ligne[champ] = lire_date(ligne[champ])
                if ligne.get("specialite_principale"):
                    ligne["specialite_principale"] = lire_choix(
                        ligne["specialite_principale"], CH_SPEC, "spécialité"
                    )
                if ligne.get("type_contrat"):
                    ligne["type_contrat"] = lire_choix(
                        ligne["type_contrat"], CH_CONTRAT, "type de contrat"
                    )
                if ligne.get("statut"):
                    ligne["statut"] = lire_choix(ligne["statut"], CH_STATUT, "statut")
                if ligne.get("annees_experience"):
                    ligne["annees_experience"] = int(ligne["annees_experience"])
                if ligne.get("salaire_mensuel"):
                    try:
                        ligne["salaire_mensuel"] = Decimal(
                            ligne["salaire_mensuel"].replace(" ", "").replace(",", ".")
                        )
                    except InvalidOperation:
                        raise ValueError(
                            f"salaire invalide « {ligne['salaire_mensuel']} »"
                        )
                if ligne.get("telephone"):
                    ligne["telephone"] = "".join(
                        c for c in ligne["telephone"] if c.isdigit() or c == "+"
                    )

                ligne = {k: v for k, v in ligne.items() if v not in ("", None)}

                if matricule:
                    cherche = {"matricule": matricule}
                else:  # anti-doublon quand on réimporte le même fichier
                    cherche = {"nom": ligne["nom"], "prenom": ligne["prenom"]}
                    if ligne.get("date_naissance"):
                        cherche["date_naissance"] = ligne["date_naissance"]

                # Matricule et N° de licence vides : Enseignant.save() les génère
                _, cree = Enseignant.objects.get_or_create(
                    ecole=request.etablissement,
                    **cherche,
                    defaults=ligne,
                )
                if cree:
                    nb_crees += 1
                else:
                    nb_existants += 1
            except Exception as exc:
                erreurs.append(f"ligne {num} : {exc}")

        messages.success(
            request,
            f"{nb_crees} enseignant(s) importé(s), {nb_existants} déjà existant(s), {len(erreurs)} erreur(s).",
        )
        if erreurs:
            messages.warning(
                request,
                "Détail : "
                + " ; ".join(erreurs[:5])
                + (" …" if len(erreurs) > 5 else ""),
            )
        if ignorees:
            messages.info(
                request,
                "Colonnes non reconnues (ignorées) : " + ", ".join(sorted(ignorees)),
            )
        return redirect("enseignants:liste")
    return render(request, "enseignants/importer.html")
