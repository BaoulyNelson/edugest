import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("academique", "0002_initial"),
    ]

    operations = [
        migrations.AlterField(
            model_name="anneescolaire",
            name="libelle",
            field=models.CharField(
                help_text="Format obligatoire : année de début-année de fin (ex. 2026-2027).",
                max_length=20,
                validators=[
                    django.core.validators.RegexValidator(
                        message="Saisissez deux années au format AAAA-AAAA (ex. 2026-2027).",
                        regex=r"\A[0-9]{4}-[0-9]{4}\Z",
                    )
                ],
                verbose_name="Libellé",
            ),
        ),
    ]
