"""
apps/academique/models.py
==========================
Gestion du cycle de vie académique.
AnneeScolaire = la "saison" du système, avec machine à états stricte.
Classe = regroupement d'élèves pour une année donnée.
"""

from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, RegexValidator
from apps.noyau.mixins import TenantModelMixin, HorodatageMixin, ActivableMixin


# ─── Machine à états : AnneeScolaire ────────────────────────────────────────

class StatutAnneeScolaire(models.TextChoices):
    BROUILLON = "brouillon", "Brouillon"
    ACTIVE = "active", "Active"
    CLOTUREE = "cloturee", "Clôturée"
    ARCHIVEE = "archivee", "Archivée"


# Matrice des transitions autorisées — immuable par conception
TRANSITIONS_ANNEE_SCOLAIRE: dict[str, list[str]] = {
    StatutAnneeScolaire.BROUILLON: [StatutAnneeScolaire.ACTIVE],
    StatutAnneeScolaire.ACTIVE:    [StatutAnneeScolaire.CLOTUREE],
    StatutAnneeScolaire.CLOTUREE:  [StatutAnneeScolaire.ARCHIVEE],
    StatutAnneeScolaire.ARCHIVEE:  [],  # État terminal
}


class AnneeScolaire(TenantModelMixin, HorodatageMixin):
    """
    Cycle de vie de l'année scolaire.
    INVARIANT : une seule année avec statut=ACTIVE par école à tout moment.
    INVARIANT : toutes les transitions passent par ServiceAnneeScolaire — jamais directement.
    INVARIANT : verrou_administratif=True bloque inscriptions et modifications de masse.
    """
    libelle = models.CharField(
        max_length=20,
        verbose_name="Libellé",
        help_text="Format obligatoire : année de début-année de fin (ex. 2026-2027).",
        validators=[
            RegexValidator(
                regex=r"\A[0-9]{4}-[0-9]{4}\Z",
                message="Saisissez deux années au format AAAA-AAAA (ex. 2026-2027).",
            )
        ],
    )
    date_debut = models.DateField(verbose_name="Date de début")
    date_fin = models.DateField(verbose_name="Date de fin")
    statut = models.CharField(
        max_length=15,
        choices=StatutAnneeScolaire.choices,
        default=StatutAnneeScolaire.BROUILLON,
        db_index=True,
    )
    est_courante = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name="Année courante",
        help_text="Une seule année peut être courante par école.",
    )
    verrou_administratif = models.BooleanField(
        default=False,
        verbose_name="Verrouillage administratif",
        help_text="Bloque toutes les inscriptions et modifications de masse.",
    )
    date_ouverture_officielle = models.DateField(null=True, blank=True)
    date_cloture_officielle = models.DateField(null=True, blank=True)
    type_decoupage = models.CharField(
        max_length=20,
        choices=[
            ("trimestriel", "Trimestriel (3 périodes)"),
            ("semestriel", "Semestriel (2 périodes)"),
            ("quadrimestriel", "Quadrimestriel (4 périodes)"),
            ("annuel", "Annuel (1 seule période)"),
            ("personnalise", "Personnalisé"),
        ],
        default="trimestriel",
        verbose_name="Type de découpage",
    )
    cree_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    notes_internes = models.TextField(blank=True)

    class Meta:
        verbose_name = "Année Scolaire"
        verbose_name_plural = "Années Scolaires"
        unique_together = [("ecole", "libelle")]
        ordering = ["-date_debut"]

    def __str__(self):
        return f"{self.ecole.nom_court or self.ecole.nom} — {self.libelle}"

    def clean(self):
        super().clean()
        if (
            isinstance(self.libelle, str)
            and len(self.libelle) == 9
            and self.libelle[4] == "-"
            and self.libelle[:4].isdigit()
            and self.libelle[5:].isdigit()
            and int(self.libelle[5:]) <= int(self.libelle[:4])
        ):
            raise ValidationError(
                {"libelle": "L’année de fin doit être postérieure à l’année de début."}
            )

    def peut_transitionner_vers(self, nouveau_statut: str) -> bool:
        """Vérifie si la transition est autorisée par la matrice."""
        return nouveau_statut in TRANSITIONS_ANNEE_SCOLAIRE.get(self.statut, [])

    @property
    def est_modifiable(self) -> bool:
        """Seules les années en brouillon ou actives, non verrouillées, sont modifiables."""
        return (
            self.statut in (
                StatutAnneeScolaire.BROUILLON,
                StatutAnneeScolaire.ACTIVE,
            )
            and not self.verrou_administratif
        )

    @property
    def accepte_inscriptions(self) -> bool:
        """Les inscriptions ne sont possibles que sur une année active et non verrouillée."""
        return (
            self.statut == StatutAnneeScolaire.ACTIVE
            and not self.verrou_administratif
        )


# ─── Machine à états : PeriodeAcademique ────────────────────────────────────

class StatutPeriode(models.TextChoices):
    OUVERTE = "ouverte", "Ouverte (saisie active)"
    CLOTUREE = "cloturee", "Clôturée (calculs en cours)"
    PUBLIEE = "publiee", "Publiée (résultats définitifs)"


TRANSITIONS_PERIODE: dict[str, list[str]] = {
    StatutPeriode.OUVERTE:   [StatutPeriode.CLOTUREE],
    StatutPeriode.CLOTUREE:  [StatutPeriode.PUBLIEE, StatutPeriode.OUVERTE],
    # On peut rouvrir une période close (avant publication) si erreur
    StatutPeriode.PUBLIEE:   [],  # État terminal — données immuables
}


class PeriodeAcademique(TenantModelMixin, HorodatageMixin):
    """
    Découpage d'une année scolaire en périodes évaluées.
    Le type (trimestre/semestre) est défini par l'école — pas codé en dur.

    INVARIANT : statut=PUBLIEE → aucune note ne peut être modifiée dans cette période.
    INVARIANT : statut=CLOTUREE ou PUBLIEE → aucune nouvelle note ne peut être saisie.
    """
    annee_scolaire = models.ForeignKey(
        AnneeScolaire,
        on_delete=models.PROTECT,
        related_name="periodes",
        verbose_name="Année scolaire",
    )
    numero = models.PositiveSmallIntegerField(
        verbose_name="Numéro",
        help_text="1, 2, 3 pour trimestres ; 1, 2 pour semestres.",
    )
    libelle = models.CharField(
        max_length=80,
        verbose_name="Libellé",
        help_text="Ex: 1er Trimestre 2024-2025",
    )
    libelle_court = models.CharField(max_length=20, blank=True)
    type_periode = models.CharField(
        max_length=20,
        verbose_name="Type",
        help_text="trimestre | semestre | quadrimestre | annuel",
    )
    date_debut = models.DateField()
    date_fin = models.DateField()
    statut = models.CharField(
        max_length=10,
        choices=StatutPeriode.choices,
        default=StatutPeriode.OUVERTE,
        db_index=True,
    )
    poids_calcul = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        default=Decimal("1.00"),
        validators=[MinValueValidator(Decimal("0.01"))],
        verbose_name="Poids pour la moyenne annuelle",
        help_text="Poids relatif de cette période dans le calcul de la moyenne annuelle.",
    )
    date_cloture = models.DateTimeField(null=True, blank=True)
    date_publication = models.DateTimeField(null=True, blank=True)
    cloture_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    publiee_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )

    class Meta:
        verbose_name = "Période Académique"
        verbose_name_plural = "Périodes Académiques"
        unique_together = [("ecole", "annee_scolaire", "type_periode", "numero")]
        ordering = ["annee_scolaire", "numero"]

    def __str__(self):
        return f"{self.libelle} ({self.statut})"

    def peut_transitionner_vers(self, nouveau_statut: str) -> bool:
        return nouveau_statut in TRANSITIONS_PERIODE.get(self.statut, [])

    @property
    def accepte_saisie_notes(self) -> bool:
        """La saisie est possible seulement si la période est ouverte."""
        return self.statut == StatutPeriode.OUVERTE

    @property
    def est_finale(self) -> bool:
        """Une période publiée est en état terminal — données figées."""
        return self.statut == StatutPeriode.PUBLIEE


# ─── Classe ──────────────────────────────────────────────────────────────────

class Classe(TenantModelMixin, HorodatageMixin, ActivableMixin):
    """
    Regroupement d'élèves pour une année scolaire et un niveau donnés.
    Une classe est créée pour chaque année — pas de réutilisation entre années.
    """
    annee_scolaire = models.ForeignKey(
        AnneeScolaire,
        on_delete=models.PROTECT,
        related_name="classes",
    )
    niveau = models.ForeignKey(
        "parametrage.Niveau",
        on_delete=models.PROTECT,
        related_name="classes",
    )
    section = models.ForeignKey(
        "parametrage.Section",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="classes",
    )
    option = models.ForeignKey(
        "parametrage.OptionPedagogique",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="classes",
    )
    code = models.CharField(
        max_length=20,
        verbose_name="Code classe",
        help_text="Ex: 3eA, Term-Sciences, 6AF-B",
    )
    libelle = models.CharField(max_length=100, verbose_name="Libellé complet")
    capacite_max = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        verbose_name="Capacité maximale",
        help_text="Null = pas de limite.",
    )
    salle = models.CharField(max_length=50, blank=True, verbose_name="Salle assignée")
    enseignant_titulaire = models.ForeignKey(
        "enseignants.Enseignant",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="classes_titulaire",
        verbose_name="Enseignant titulaire",
    )
    # Matières assignées à cette classe (via CoefficientsMatiere du niveau)
    matieres = models.ManyToManyField(
        "parametrage.Matiere",
        through="MatiereClasse",
        related_name="classes",
        blank=True,
    )

    class Meta:
        verbose_name = "Classe"
        verbose_name_plural = "Classes"
        unique_together = [("ecole", "annee_scolaire", "code")]
        ordering = ["niveau__ordre_affichage", "code"]

    def __str__(self):
        return f"{self.code} — {self.annee_scolaire.libelle}"

    def nb_inscrits(self) -> int:
        """Retourne le nombre d'inscrits validés dans cette classe."""
        from apps.eleves.models import StatutInscription
        return self.inscriptions.filter(
            statut=StatutInscription.VALIDEE
        ).count()

    @property
    def est_pleine(self) -> bool:
        if self.capacite_max is None:
            return False
        return self.nb_inscrits() >= self.capacite_max


class MatiereClasse(TenantModelMixin, HorodatageMixin):
    """
    Association matière ↔ classe pour une année donnée.
    Permet de personnaliser les matières par classe au-delà du niveau.
    """
    classe = models.ForeignKey(Classe, on_delete=models.CASCADE)
    matiere = models.ForeignKey("parametrage.Matiere", on_delete=models.PROTECT)
    enseignant = models.ForeignKey(
        "enseignants.Enseignant",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="attributions_classes",
    )
    coefficient_override = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Si renseigné, écrase le coefficient du niveau pour cette classe.",
    )

    class Meta:
        verbose_name = "Matière de classe"
        unique_together = [("ecole", "classe", "matiere")]
        
    def __str__(self):
        return f"{self.matiere.libelle} — {self.classe.libelle}"
            # ← ajouter ceci
