# urls.py — version complète corrigée

from django.urls import path
from apps.academique import views

app_name = "academique"

urlpatterns = [
    # Années scolaires
    path("annees/selectionner/",            views.selectionner_annee, name="selectionner_annee"),
    path("annees/",                          views.liste_annees,    name="liste_annees"),
    path("annees/creer/",                    views.creer_annee,     name="creer_annee"),
    path("annees/<int:pk>/",                 views.detail_annee,    name="detail_annee"),
    path("annees/<int:pk>/modifier/",        views.modifier_annee,  name="modifier_annee"),   # ← ajouté
    path("annees/<int:pk>/activer/",         views.activer_annee,   name="activer_annee"),
    path("annees/<int:pk>/cloturer/",        views.cloturer_annee,  name="cloturer_annee"),
    path("annees/<int:pk>/archiver/",        views.archiver_annee,  name="archiver_annee"),   # ← ajouté

    # Périodes académiques
    path("periodes/",                        views.liste_periodes,   name="liste_periodes"),
    path("periodes/<int:pk>/cloturer/",      views.cloturer_periode, name="cloturer_periode"),
    path("periodes/<int:pk>/rouvrir/",       views.rouvrir_periode,  name="rouvrir_periode"),  # ← ajouté
    path("periodes/<int:pk>/publier/",       views.publier_periode,  name="publier_periode"),

    # Classes
    path("classes/",                         views.liste_classes,          name="liste_classes"),
    path("classes/creer/",                   views.creer_classe,           name="creer_classe"),
    path("referentiels/creation-rapide/",     views.creation_rapide_referentiel, name="creation_rapide_referentiel"),
    path("classes/<int:pk>/",                views.detail_classe,          name="detail_classe"),
    path("classes/<int:pk>/modifier/",       views.modifier_classe,        name="modifier_classe"),
    path("classes/<int:pk>/matieres/",       views.matieres_classe,        name="matieres_classe"),
    path("classes/<int:pk>/matieres/ajouter/",                             # ← ajouté
         views.ajouter_matiere_classe,       name="ajouter_matiere_classe"),
    path("classes/<int:pk>/matieres/<int:matiere_pk>/retirer/",            # ← ajouté
         views.retirer_matiere_classe,       name="retirer_matiere_classe"),
]