"""Vues de gestion académique."""
import csv
from datetime import date

from django.utils import timezone
from django.views.decorators.http import require_POST
from django.utils.http import url_has_allowed_host_and_scheme
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.core.paginator import Paginator
from django.db.models import Count, Prefetch, Q
from django.http import HttpResponse, HttpResponseBadRequest, JsonResponse
from django.urls import reverse
from django.views.decorators.http import require_http_methods
from apps.noyau.decorateurs import requiert_tenant, requiert_permission, gerer_erreur_metier
from apps.academique.models import (
    AnneeScolaire,
    MatiereClasse,
    PeriodeAcademique,
    Classe,
    StatutAnneeScolaire,
)
from apps.academique.services import (
    ServiceAnneeScolaire,
    ServicePeriodeAcademique,
    proposer_annee_scolaire,
    selectionner_annee_scolaire,
)
from apps.academique import forms


@login_required
@requiert_tenant
def liste_annees(request):
    if not AnneeScolaire.objects.filter(ecole=request.etablissement).exists():
        proposition = proposer_annee_scolaire(
            request.etablissement, request.user
        )
        selectionner_annee_scolaire(request, proposition.pk)
    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    annees = (
        AnneeScolaire.objects.filter(ecole=request.etablissement)
        .prefetch_related("periodes")
        .annotate(nb_classes_actives=Count("classes", filter=Q(classes__est_actif=True)))
    )
    if q:
        annees = annees.filter(libelle__icontains=q)
    if statut in dict(StatutAnneeScolaire.choices):
        annees = annees.filter(statut=statut)
    return render(
        request,
        "academique/annees.html",
        {
            "annees": annees,
            "q": q,
            "filtre_statut": statut,
            "statut_choices": StatutAnneeScolaire.choices,
        },
    )


@login_required
@requiert_tenant
@require_POST
def selectionner_annee(request):
    annee = selectionner_annee_scolaire(
        request, request.POST.get("annee_scolaire")
    )
    if annee is None:
        messages.error(request, "Cette année scolaire n’appartient pas à votre établissement.")
    else:
        messages.success(request, f"Année de travail sélectionnée : {annee.libelle}.")

    destination = request.META.get("HTTP_REFERER", "")
    if not url_has_allowed_host_and_scheme(
        destination, allowed_hosts={request.get_host()}
    ):
        destination = reverse("academique:liste_annees")
    return redirect(destination)


@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.activer.etablissement")
def creer_annee(request):
    aujourd_hui = timezone.localdate()
    annee_debut = aujourd_hui.year if aujourd_hui.month >= 9 else aujourd_hui.year - 1
    initial = {
        "libelle": f"{annee_debut}-{annee_debut + 1}",
        "date_debut": date(annee_debut, 9, 1),
        "date_fin": date(annee_debut + 1, 6, 30),
        "type_decoupage": "trimestriel",
    }
    if request.method == "POST":
        form = forms.FormulaireAnneeScolaire(request.POST)
        if form.is_valid():
            if AnneeScolaire.objects.filter(
                ecole=request.etablissement,
                libelle=form.cleaned_data["libelle"],
            ).exists():
                form.add_error("libelle", "Cette année existe déjà.")
            else:
                annee = form.save(commit=False)
                annee.ecole = request.etablissement
                annee.cree_par = request.user
                annee.statut = StatutAnneeScolaire.BROUILLON
                annee.est_courante = False
                annee.verrou_administratif = False
                annee.save()
                selectionner_annee_scolaire(request, annee.pk)
                messages.success(
                    request,
                    "Année créée en brouillon. Configurez ses classes et ses périodes, "
                    "puis activez-la quand elle est prête.",
                )
                return redirect("academique:liste_annees")
    else:
        form = forms.FormulaireAnneeScolaire(initial=initial)
    return render(request, "academique/form_annee.html", {"form": form})


@login_required
@requiert_tenant
def detail_annee(request, pk):
    annee = get_object_or_404(AnneeScolaire, pk=pk, ecole=request.etablissement)
    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    periodes = annee.periodes.all()
    if q:
        periodes = periodes.filter(
            Q(libelle__icontains=q) | Q(libelle_court__icontains=q)
        )
    if statut in dict(PeriodeAcademique._meta.get_field("statut").choices):
        periodes = periodes.filter(statut=statut)
    else:
        statut = ""
    return render(
        request,
        "academique/detail_annee.html",
        {
            "annee": annee,
            "nb_classes_actives": annee.classes.filter(est_actif=True).count(),
            "periodes": periodes,
            "q": q,
            "filtre_statut": statut,
            "statut_choices": PeriodeAcademique._meta.get_field("statut").choices,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.activer.etablissement")
@gerer_erreur_metier
@require_POST
def activer_annee(request, pk):
    annee = get_object_or_404(
        AnneeScolaire, pk=pk, ecole=request.etablissement
    )
    ServiceAnneeScolaire(request.user).activer(annee)
    selectionner_annee_scolaire(request, annee.pk)
    messages.success(request, f"L’année scolaire {annee.libelle} est active.")
    return redirect("academique:liste_annees")


@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.cloturer.etablissement")
@gerer_erreur_metier
@require_POST
def cloturer_annee(request, pk):
    annee = get_object_or_404(
        AnneeScolaire, pk=pk, ecole=request.etablissement
    )
    ServiceAnneeScolaire(request.user).cloturer(annee)
    messages.success(request, f"L’année scolaire {annee.libelle} est clôturée.")
    return redirect("academique:liste_annees")


@login_required
@requiert_tenant
def liste_periodes(request):
    from apps.academique.forms import FormulairePeriode

    annee = request.annee_scolaire_courante

    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    periodes = (
        PeriodeAcademique.objects.filter(annee_scolaire=annee)
        if annee else []
    )
    if annee:
        if q:
            periodes = periodes.filter(
                Q(libelle__icontains=q) | Q(libelle_court__icontains=q)
            )
        if statut in dict(PeriodeAcademique._meta.get_field("statut").choices):
            periodes = periodes.filter(statut=statut)
        else:
            statut = ""

    if request.method == "POST" and annee and annee.est_modifiable:
        form = FormulairePeriode(request.POST)

        if form.is_valid():
            periode = form.save(commit=False)
            periode.ecole = request.etablissement
            periode.annee_scolaire = annee
            periode.save()

            messages.success(
                request,
                f"Période « {periode.libelle} » créée."
            )

            return redirect('academique:liste_periodes')

        messages.error(request, "Corrigez les erreurs.")

    else:
        if request.method == "POST":
            messages.error(
                request,
                "Les périodes ne peuvent être modifiées que pour une année "
                "en brouillon ou active.",
            )
        form = FormulairePeriode()

    return render(request, "academique/periodes.html", {
        "periodes": periodes,
        "annee": annee,
        "form": form,
        "q": q,
        "filtre_statut": statut,
        "statut_choices": PeriodeAcademique._meta.get_field("statut").choices,
    })

@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.cloturer.etablissement")
@gerer_erreur_metier
def cloturer_periode(request, pk):
    periode = get_object_or_404(PeriodeAcademique, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        service = ServicePeriodeAcademique(request.user)
        service.cloturer(periode)
        messages.success(request, f"{periode.libelle} clôturée. Notes verrouillées.")
    return redirect("academique:liste_periodes")


@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.cloturer.etablissement")
@gerer_erreur_metier
def publier_periode(request, pk):
    periode = get_object_or_404(PeriodeAcademique, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        service = ServicePeriodeAcademique(request.user)
        service.publier(periode)
        messages.success(request, f"{periode.libelle} publiée.")
    return redirect("academique:liste_periodes")


@login_required
@requiert_tenant
def liste_classes(request):
    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    filtre_niveau = request.GET.get("niveau", "")
    filtre_statut = request.GET.get("statut", "")
    per_page = request.GET.get("per_page", "10")
    if per_page not in ("10", "20", "50"):
        per_page = "10"

    if annee:
        from apps.academique.models import MatiereClasse
        from apps.enseignants.models import AffectationEnseignant
        from apps.parametrage.models import Niveau

        niveaux = Niveau.objects.filter(
            ecole=request.etablissement,
            classes__annee_scolaire=annee,
        ).distinct().order_by("ordre_affichage", "code")
        classes_qs = Classe.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=annee,
        )
        if q:
            classes_qs = classes_qs.filter(
                Q(code__icontains=q)
                | Q(libelle__icontains=q)
                | Q(niveau__code__icontains=q)
                | Q(niveau__libelle__icontains=q)
                | Q(enseignant_titulaire__nom__icontains=q)
                | Q(enseignant_titulaire__prenom__icontains=q)
                | Q(matiereclasse__enseignant__nom__icontains=q)
                | Q(matiereclasse__enseignant__prenom__icontains=q)
                | Q(
                    matiereclasse__affectations_enseignants__enseignant__nom__icontains=q
                )
                | Q(
                    matiereclasse__affectations_enseignants__enseignant__prenom__icontains=q
                )
                | Q(matiereclasse__matiere__libelle__icontains=q)
            )
        if filtre_niveau:
            try:
                niveau_pk = Niveau._meta.pk.to_python(filtre_niveau)
            except (TypeError, ValueError):
                niveau_pk = None
            if niveau_pk and niveaux.filter(pk=niveau_pk).exists():
                classes_qs = classes_qs.filter(niveau_id=niveau_pk)
            else:
                filtre_niveau = ""
        if filtre_statut == "actif":
            classes_qs = classes_qs.filter(est_actif=True)
        elif filtre_statut == "inactif":
            classes_qs = classes_qs.filter(est_actif=False)
        classes_qs = classes_qs.distinct().order_by("niveau__ordre_affichage", "code")

        matieres_classes = MatiereClasse.objects.select_related(
            "matiere", "enseignant"
        ).prefetch_related(
            Prefetch(
                "affectations_enseignants",
                queryset=AffectationEnseignant.objects.filter(
                    ecole=request.etablissement,
                    est_active=True,
                ).select_related("enseignant"),
                to_attr="affectations_actives",
            )
        )
        if request.GET.get("export") == "csv":
            ids = request.GET.getlist("ids")
            if ids:
                try:
                    ids = [Classe._meta.pk.to_python(classe_id) for classe_id in ids]
                except (TypeError, ValueError):
                    return HttpResponseBadRequest("Identifiant de classe invalide.")
                classes_qs = classes_qs.filter(pk__in=ids)
            classes = list(
                classes_qs
                .select_related("niveau", "enseignant_titulaire")
                .prefetch_related(
                    Prefetch(
                        "matiereclasse_set",
                        queryset=matieres_classes,
                        to_attr="matieres_avec_affectations",
                    )
                )
            )
        else:
            paginator = Paginator(classes_qs, int(per_page))
            page_obj = paginator.get_page(request.GET.get("page"))
            classes = list(
                page_obj.object_list.select_related(
                    "niveau", "enseignant_titulaire"
                ).prefetch_related(
                    Prefetch(
                        "matiereclasse_set",
                        queryset=matieres_classes,
                        to_attr="matieres_avec_affectations",
                    )
                )
            )

        for classe in classes:
            equipe_pedagogique = {}
            if classe.enseignant_titulaire_id:
                equipe_pedagogique[classe.enseignant_titulaire_id] = {
                    "enseignant": classe.enseignant_titulaire,
                    "est_titulaire": True,
                    "matieres": {},
                }
            for matiere_classe in classe.matieres_avec_affectations:
                enseignants_matiere = []
                if matiere_classe.enseignant_id:
                    enseignants_matiere.append(matiere_classe.enseignant)
                enseignants_matiere.extend(
                    affectation.enseignant
                    for affectation in matiere_classe.affectations_actives
                )
                for enseignant in enseignants_matiere:
                    pedagogique = equipe_pedagogique.setdefault(
                        enseignant.pk,
                        {
                            "enseignant": enseignant,
                            "est_titulaire": False,
                            "matieres": {},
                        },
                    )
                    pedagogique["matieres"][matiere_classe.matiere_id] = (
                        matiere_classe.matiere
                    )
            classe.equipe_pedagogique = sorted(
                (
                    {
                        **pedagogique,
                        "matieres": list(pedagogique["matieres"].values()),
                    }
                    for pedagogique in equipe_pedagogique.values()
                ),
                key=lambda item: (
                    not item["est_titulaire"],
                    item["enseignant"].nom,
                    item["enseignant"].prenom,
                ),
            )

        if request.GET.get("export") == "csv":
            response = HttpResponse(content_type="text/csv; charset=utf-8")
            response["Content-Disposition"] = 'attachment; filename="classes.csv"'
            response.write("\ufeff")
            writer = csv.writer(response, delimiter=";")
            writer.writerow(
                (
                    "annee_scolaire",
                    "code",
                    "libelle",
                    "niveau",
                    "equipe_pedagogique",
                    "capacite_max",
                    "salle",
                    "statut",
                )
            )

            def proteger_formule(valeur):
                valeur = str(valeur or "")
                if valeur.lstrip().startswith(("=", "+", "-", "@")):
                    return "'" + valeur
                return valeur

            for classe in classes:
                equipe = " | ".join(
                    f"{item['enseignant'].nom_complet}"
                    f"{' (Titulaire)' if item['est_titulaire'] else ''}"
                    f"{' — ' + ', '.join(matiere.libelle for matiere in item['matieres']) if item['matieres'] else ''}"
                    for item in classe.equipe_pedagogique
                )
                writer.writerow(
                    proteger_formule(valeur)
                    for valeur in (
                        classe.annee_scolaire.libelle,
                        classe.code,
                        classe.libelle,
                        classe.niveau.libelle,
                        equipe,
                        classe.capacite_max,
                        classe.salle,
                        "active" if classe.est_actif else "inactive",
                    )
                )
            return response

    else:
        classes = []
        niveaux = []
        paginator = Paginator([], int(per_page))
        page_obj = paginator.get_page(1)
    return render(
        request,
        "academique/classes.html",
        {
            "classes": classes,
            "annee": annee,
            "q": q,
            "niveaux": niveaux,
            "filtre_niveau": filtre_niveau,
            "filtre_statut": filtre_statut,
            "per_page": per_page,
            "page_obj": page_obj,
            "total_classes": paginator.count,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_classe(request):
    annee_pk = request.GET.get("annee") or getattr(
        request.annee_scolaire_courante, "pk", None
    )
    if request.method == "POST":
        annee_pk = request.POST.get("annee_scolaire")

    annee_preselectionnee = AnneeScolaire.objects.filter(
        ecole=request.etablissement,
        pk=annee_pk,
        statut__in=(
            StatutAnneeScolaire.BROUILLON,
            StatutAnneeScolaire.ACTIVE,
        ),
    ).first()

    if request.method == "POST":
        form = forms.FormulaireClasse(request.POST, ecole=request.etablissement)
        if form.is_valid():
            classe = form.save(commit=False)
            classe.ecole = request.etablissement
            classe.save()
            messages.success(request, f"Classe {classe.code} créée.")
            if classe.annee_scolaire.statut == StatutAnneeScolaire.BROUILLON:
                return redirect("academique:detail_annee", pk=classe.annee_scolaire.pk)
            return redirect("academique:liste_classes")
    else:
        initial = (
            {"annee_scolaire": annee_preselectionnee.pk}
            if annee_preselectionnee
            else {}
        )
        form = forms.FormulaireClasse(ecole=request.etablissement, initial=initial)
    return render(
        request,
        "academique/form_classe.html",
        {
            "form": form,
            "annee_preselectionnee": annee_preselectionnee,
            "niveaux_disponibles": form.fields["niveau"].queryset.exists(),
            "peut_creer_annee": request.user.is_superuser
            or _possede_permission(request, "annee_scolaire.activer.etablissement"),
        },
    )


def _possede_permission(request, code_permission):
    from apps.securite.rbac import moteur_rbac

    return moteur_rbac.possede_permission(
        utilisateur=request.user,
        ecole=request.etablissement,
        code_permission=code_permission,
    )


@login_required
@requiert_tenant
@require_http_methods(["GET", "POST"])
def creation_rapide_referentiel(request):
    from apps.parametrage import forms as parametrage_forms
    from apps.parametrage.models import (
        CycleEnseignement,
        Matiere,
        Niveau,
        OptionPedagogique,
        Section,
    )
    from apps.enseignants.forms import FormulaireEnseignantRapide

    type_objet = request.GET.get("type") or request.POST.get("type")
    permissions = {
        "annee": "annee_scolaire.activer.etablissement",
        "cycle": "parametrage.modifier.etablissement",
        "niveau": "parametrage.modifier.etablissement",
        "matiere": "parametrage.modifier.etablissement",
        "classe": "parametrage.modifier.etablissement",
        "section": "parametrage.modifier.etablissement",
        "option": "parametrage.modifier.etablissement",
        "enseignant": "parametrage.modifier.etablissement",
    }
    if type_objet not in permissions:
        return HttpResponseBadRequest("Type de référence invalide.")
    if not _possede_permission(request, permissions[type_objet]):
        raise PermissionDenied("Vous ne pouvez pas créer ce type de référence.")

    annee_debut = (
        timezone.localdate().year
        if timezone.localdate().month >= 9
        else timezone.localdate().year - 1
    )
    formulaires = {
        "annee": lambda data=None: forms.FormulaireAnneeScolaireRapide(
            data,
            initial={
                "libelle": f"{annee_debut}-{annee_debut + 1}",
                "date_debut": date(annee_debut, 9, 1),
                "date_fin": date(annee_debut + 1, 6, 30),
                "type_decoupage": "trimestriel",
            },
        ),
        "cycle": lambda data=None: parametrage_forms.FormulaireCycle(
            data,
            initial={"ordre_affichage": 0, "couleur": "#1a3c6e"},
        ),
        "matiere": lambda data=None: parametrage_forms.FormulaireMatiere(
            data,
            initial={
                "ordre_affichage": 0,
                "couleur": "#3b82f6",
                "type_matiere": "theorique",
            },
        ),
        "niveau": lambda data=None: parametrage_forms.FormulaireNiveau(
            data,
            ecole=request.etablissement,
            initial={"cycle": request.GET.get("cycle") or request.POST.get("cycle")},
        ),
        "classe": lambda data=None: forms.FormulaireClasseRapide(
            data,
            ecole=request.etablissement,
            initial={
                "annee_scolaire": request.GET.get("annee")
                or request.POST.get("annee")
                or getattr(request.annee_scolaire_courante, "pk", None)
            },
        ),
        "section": lambda data=None: forms.FormulaireSectionRapide(
            data,
            ecole=request.etablissement,
            initial={"niveau": request.GET.get("niveau") or request.POST.get("niveau")},
        ),
        "option": lambda data=None: forms.FormulaireOptionRapide(
            data,
            ecole=request.etablissement,
            initial={"niveau": request.GET.get("niveau") or request.POST.get("niveau")},
        ),
        "enseignant": lambda data=None: FormulaireEnseignantRapide(data),
    }
    formulaire = formulaires[type_objet](
        request.POST if request.method == "POST" else None
    )
    if request.method == "GET":
        return render(
            request,
            "academique/partials/form_creation_rapide.html",
            {"form": formulaire, "type_objet": type_objet},
        )

    if not formulaire.is_valid():
        return render(
            request,
            "academique/partials/form_creation_rapide.html",
            {"form": formulaire, "type_objet": type_objet},
            status=400,
        )

    valeurs = formulaire.cleaned_data
    existe_deja = False
    if type_objet == "cycle":
        existe_deja = CycleEnseignement.objects.filter(
            ecole=request.etablissement,
            code=valeurs["code"],
        ).exists()
    elif type_objet == "matiere":
        existe_deja = Matiere.objects.filter(
            ecole=request.etablissement,
            code=valeurs["code"],
        ).exists()
    elif type_objet == "niveau":
        existe_deja = Niveau.objects.filter(
            ecole=request.etablissement,
            cycle=valeurs["cycle"],
            code=valeurs["code"],
        ).exists()
    elif type_objet == "classe":
        existe_deja = Classe.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=valeurs["annee_scolaire"],
            code=valeurs["code"],
        ).exists()
    elif type_objet == "section":
        existe_deja = Section.objects.filter(
            ecole=request.etablissement,
            niveau=valeurs["niveau"],
            code=valeurs["code"],
        ).exists()
    elif type_objet == "option":
        existe_deja = OptionPedagogique.objects.filter(
            ecole=request.etablissement,
            niveau=valeurs["niveau"],
            code=valeurs["code"],
        ).exists()
    elif type_objet == "annee":
        existe_deja = AnneeScolaire.objects.filter(
            ecole=request.etablissement,
            libelle=valeurs["libelle"],
        ).exists()
    if existe_deja:
        formulaire.add_error(None, "Un élément portant ces informations existe déjà.")
        return render(
            request,
            "academique/partials/form_creation_rapide.html",
            {"form": formulaire, "type_objet": type_objet},
            status=400,
        )

    with transaction.atomic():
        objet = formulaire.save(commit=False)
        objet.ecole = request.etablissement
        if type_objet == "annee":
            objet.statut = StatutAnneeScolaire.BROUILLON
            objet.est_courante = False
            objet.verrou_administratif = False
            objet.cree_par = request.user
        objet.save()

    if type_objet == "annee":
        label = objet.libelle
        parent_id = ""
    elif type_objet == "cycle":
        label = str(objet)
        parent_id = ""
    elif type_objet == "matiere":
        label = str(objet)
        parent_id = ""
    elif type_objet == "niveau":
        label = str(objet)
        parent_id = str(objet.pk)
    elif type_objet == "classe":
        label = f"{objet.code} — {objet.libelle}"
        parent_id = str(objet.annee_scolaire_id)
    elif type_objet in {"section", "option"}:
        label = str(objet)
        parent_id = str(objet.niveau_id)
    else:
        label = objet.nom_complet
        parent_id = ""

    return JsonResponse(
        {
            "id": str(objet.pk),
            "label": label,
            "type": type_objet,
            "parent_id": parent_id,
        }
    )
@login_required
@requiert_tenant
def detail_classe(request, pk):
    classe = get_object_or_404(
        Classe.objects.select_related(
            "niveau__cycle",
            "annee_scolaire",
            "section",
            "option",
            "enseignant_titulaire",
        ),
        pk=pk,
        ecole=request.etablissement,
    )
    matieres = list(
        MatiereClasse.objects.filter(classe=classe, ecole=request.etablissement)
        .select_related("matiere", "enseignant")
        .order_by("matiere__libelle")
    )
    nb_inscrits = classe.nb_inscrits()
    return render(
        request,
        "academique/detail_classe.html",
        {
            "classe": classe,
            "matieres": matieres,
            "nb_inscrits": nb_inscrits,
            "places_disponibles": (
                max(classe.capacite_max - nb_inscrits, 0)
                if classe.capacite_max is not None
                else None
            ),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_classe(request, pk):
    classe = _obtenir_classe_modifiable(request, pk)
    if request.method == "POST":
        form = forms.FormulaireClasse(request.POST, instance=classe, ecole=request.etablissement)
        if form.is_valid():
            form.save()
            messages.success(request, "Classe mise à jour.")
            return redirect("academique:detail_classe", pk=pk)
    else:
        form = forms.FormulaireClasse(instance=classe, ecole=request.etablissement)
    return render(
        request,
        "academique/form_classe.html",
        {
            "form": form,
            "classe": classe,
            "niveaux_disponibles": form.fields["niveau"].queryset.exists(),
            "peut_creer_annee": request.user.is_superuser
            or _possede_permission(request, "annee_scolaire.activer.etablissement"),
        },
    )


@login_required
@requiert_tenant
def matieres_classe(request, pk):
    classe = get_object_or_404(Classe, pk=pk, ecole=request.etablissement)
    from apps.academique.models import MatiereClasse
    q = request.GET.get("q", "").strip()
    matieres = MatiereClasse.objects.filter(classe=classe).select_related("matiere", "enseignant")
    if q:
        matieres = matieres.filter(
            Q(matiere__libelle__icontains=q)
            | Q(matiere__code__icontains=q)
            | Q(enseignant__nom__icontains=q)
            | Q(enseignant__prenom__icontains=q)
        )
    return render(request, "academique/matieres_classe.html", {
        "classe": classe, "matieres": matieres, "q": q,
    })



# views.py — à ajouter

@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.activer.etablissement")
def modifier_annee(request, pk):
    annee = get_object_or_404(
        AnneeScolaire,
        pk=pk,
        ecole=request.etablissement,
        statut=StatutAnneeScolaire.BROUILLON,
    )
    if request.method == "POST":
        form = forms.FormulaireAnneeScolaire(request.POST, instance=annee)
        if form.is_valid():
            form.save()
            messages.success(request, "Calendrier de l’année scolaire mis à jour.")
            return redirect("academique:detail_annee", pk=annee.pk)
    else:
        form = forms.FormulaireAnneeScolaire(instance=annee)
    return render(request, "academique/form_annee.html", {"form": form, "annee": annee})


@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.cloturer.etablissement")
@gerer_erreur_metier
@require_POST
def archiver_annee(request, pk):
    annee = get_object_or_404(
        AnneeScolaire, pk=pk, ecole=request.etablissement
    )
    ServiceAnneeScolaire(request.user).archiver(annee)
    messages.success(request, f"L’année scolaire {annee.libelle} est archivée.")
    return redirect("academique:liste_annees")


@login_required
@requiert_tenant
@requiert_permission("annee_scolaire.cloturer.etablissement")
@gerer_erreur_metier
def rouvrir_periode(request, pk):
    periode = get_object_or_404(PeriodeAcademique, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        service = ServicePeriodeAcademique(request.user)
        service.rouvrir(periode)
        messages.success(request, f"{periode.libelle} réouverte.")
    return redirect("academique:liste_periodes")


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def ajouter_matiere_classe(request, pk):
    from apps.academique.models import MatiereClasse
    classe = _obtenir_classe_modifiable(request, pk)
    if request.method == "POST":
        form = forms.FormulaireMatiereClasse(
            request.POST, ecole=request.etablissement, classe=classe
        )
        if form.is_valid():
            mc = form.save(commit=False)
            mc.ecole = request.etablissement
            mc.classe = classe
            mc.save()
            messages.success(request, f"Matière « {mc.matiere.libelle} » ajoutée.")
            return redirect("academique:matieres_classe", pk=pk)
        messages.error(request, "Corrigez les erreurs.")
    else:
        form = forms.FormulaireMatiereClasse(ecole=request.etablissement, classe=classe)
    return render(request, "academique/form_matiere_classe.html", {
        "form": form, "classe": classe
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def retirer_matiere_classe(request, pk, matiere_pk):
    from apps.academique.models import MatiereClasse
    classe = _obtenir_classe_modifiable(request, pk)
    mc = get_object_or_404(MatiereClasse, pk=matiere_pk, classe=classe, ecole=request.etablissement)
    if request.method == "POST":
        nom = mc.matiere.nom
        mc.delete()
        messages.success(request, f"Matière « {nom} » retirée de {classe.code}.")
    return redirect("academique:matieres_classe", pk=pk)


def _obtenir_classe_modifiable(request, pk):
    return get_object_or_404(
        Classe.objects.filter(
            annee_scolaire__statut__in=(
                StatutAnneeScolaire.BROUILLON,
                StatutAnneeScolaire.ACTIVE,
            ),
            annee_scolaire__verrou_administratif=False,
        ),
        pk=pk,
        ecole=request.etablissement,
    )