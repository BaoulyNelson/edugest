"""Formulaires académiques."""
from django import forms
from apps.academique.models import (
    AnneeScolaire,
    PeriodeAcademique,
    Classe,
    MatiereClasse,
    StatutAnneeScolaire,
)
from apps.parametrage.models import Niveau, Section, OptionPedagogique

W = lambda: {"class": "form-control"}

class FormulaireAnneeScolaire(forms.ModelForm):
    class Meta:
        model = AnneeScolaire
        fields = [
            "libelle", "date_debut", "date_fin", "type_decoupage",
            "verrou_administratif",
            "notes_internes",
        ]
        widgets = {
            "libelle": forms.TextInput(attrs={**W(), "placeholder": "2026-2027"}),
            "date_debut": forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "date_fin": forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "verrou_administratif": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes_internes": forms.Textarea(attrs={**W(), "rows": 2}),
        }

    def clean(self):
        cleaned = super().clean()
        debut = cleaned.get("date_debut")
        fin = cleaned.get("date_fin")
        if debut and fin and fin <= debut:
            raise forms.ValidationError(
                "La date de fin doit être postérieure à la date de début."
            )
        return cleaned


class FormulaireAnneeScolaireRapide(forms.ModelForm):
    class Meta:
        model = AnneeScolaire
        fields = ["libelle", "date_debut", "date_fin", "type_decoupage"]
        widgets = {
            "libelle": forms.TextInput(attrs={**W(), "placeholder": "2026-2027"}),
            "date_debut": forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "date_fin": forms.DateInput(
                format="%Y-%m-%d", attrs={**W(), "type": "date"}
            ),
            "type_decoupage": forms.Select(attrs={"class": "form-select"}),
        }

    def clean(self):
        cleaned = super().clean()
        debut = cleaned.get("date_debut")
        fin = cleaned.get("date_fin")
        if debut and fin and fin <= debut:
            raise forms.ValidationError(
                "La date de fin doit être postérieure à la date de début."
            )
        return cleaned



class FormulairePeriode(forms.ModelForm):
    class Meta:
        model = PeriodeAcademique
        fields = ['libelle', 'libelle_court', 'numero', 'type_periode', 'date_debut', 'date_fin', 'poids_calcul']
        widgets = {
            'libelle':       forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 1er Trimestre 2024-2025'}),
            'libelle_court': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: T1'}),
            'numero':        forms.NumberInput(attrs={'class': 'form-control'}),
            'type_periode':  forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'trimestre | semestre | annuel'}),
            'date_debut':    forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'date_fin':      forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'poids_calcul':  forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
        }


class SelectNiveauDependance(forms.Select):
    def create_option(self, name, value, label, selected, index, subindex=None, attrs=None):
        option = super().create_option(
            name, value, label, selected, index, subindex=subindex, attrs=attrs
        )
        instance = getattr(value, "instance", None)
        niveau_id = getattr(instance, "niveau_id", None)
        if niveau_id:
            option["attrs"]["data-niveau"] = str(niveau_id)
        return option


class FormulaireClasse(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            from apps.parametrage.models import Niveau, Section, OptionPedagogique
            from apps.enseignants.models import Enseignant
            self.fields["niveau"].queryset = Niveau.objects.filter(ecole=ecole, est_actif=True)
            self.fields["section"].queryset = Section.objects.filter(ecole=ecole, est_actif=True)
            self.fields["option"].queryset = OptionPedagogique.objects.filter(ecole=ecole, est_actif=True)
            self.fields["enseignant_titulaire"].queryset = Enseignant.objects.filter(ecole=ecole, statut="actif")
            niveau_id = (
                self.data.get("niveau")
                or self.initial.get("niveau")
                or getattr(self.instance, "niveau_id", None)
            )
            sections = Section.objects.filter(ecole=ecole, est_actif=True)
            options = OptionPedagogique.objects.filter(ecole=ecole, est_actif=True)
            if self.is_bound and niveau_id:
                sections = sections.filter(niveau_id=niveau_id)
                options = options.filter(niveau_id=niveau_id)
            elif self.is_bound:
                sections = Section.objects.none()
                options = OptionPedagogique.objects.none()
            self.fields["section"].queryset = sections
            self.fields["option"].queryset = options
            annees = AnneeScolaire.objects.filter(
                ecole=ecole,
                statut__in=(
                    StatutAnneeScolaire.ACTIVE,
                    StatutAnneeScolaire.BROUILLON,
                ),
            )
            if self.instance.pk and self.instance.annee_scolaire_id:
                annees = annees | AnneeScolaire.objects.filter(
                    ecole=ecole,
                    pk=self.instance.annee_scolaire_id,
                )
            self.fields["annee_scolaire"].queryset = annees

    class Meta:
        model = Classe
        fields = [
            "annee_scolaire", "niveau", "section", "option",
            "code", "libelle", "capacite_max", "salle",   # capacite_max était déclaré mais sans widget
            "enseignant_titulaire",
        ]
        widgets = {
            "code":    forms.TextInput(attrs={"class": "form-control"}),
            "libelle": forms.TextInput(attrs={"class": "form-control"}),
            "salle":   forms.TextInput(attrs={"class": "form-control"}),
            # ↓ manquant
            "capacite_max": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "annee_scolaire": forms.Select(attrs={"class": "form-select"}),
            "niveau":  forms.Select(attrs={"class": "form-select"}),
            "section": SelectNiveauDependance(attrs={"class": "form-select"}),
            "option":  SelectNiveauDependance(attrs={"class": "form-select"}),
            "enseignant_titulaire": forms.Select(attrs={"class": "form-select"}),
        }

    def clean(self):
        cleaned = super().clean()
        niveau = cleaned.get("niveau")
        for champ in ("section", "option"):
            valeur = cleaned.get(champ)
            if valeur and niveau and valeur.niveau_id != niveau.pk:
                self.add_error(champ, "Ce choix doit appartenir au niveau sélectionné.")
        return cleaned


class FormulaireSectionRapide(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["niveau"].queryset = Niveau.objects.filter(
                ecole=ecole,
                est_actif=True,
            )

    class Meta:
        model = Section
        fields = ["niveau", "code", "libelle"]
        widgets = {
            "niveau": forms.Select(attrs={"class": "form-select"}),
            "code": forms.TextInput(attrs={"class": "form-control"}),
            "libelle": forms.TextInput(attrs={"class": "form-control"}),
        }


class FormulaireOptionRapide(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["niveau"].queryset = Niveau.objects.filter(
                ecole=ecole,
                est_actif=True,
            )

    class Meta:
        model = OptionPedagogique
        fields = ["niveau", "code", "libelle"]
        widgets = {
            "niveau": forms.Select(attrs={"class": "form-select"}),
            "code": forms.TextInput(attrs={"class": "form-control"}),
            "libelle": forms.TextInput(attrs={"class": "form-control"}),
        }


class FormulaireClasseRapide(forms.ModelForm):
    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["annee_scolaire"].queryset = AnneeScolaire.objects.filter(
                ecole=ecole,
                statut=StatutAnneeScolaire.ACTIVE,
                verrou_administratif=False,
            )
            self.fields["niveau"].queryset = Niveau.objects.filter(
                ecole=ecole,
                est_actif=True,
            ).select_related("cycle")

    class Meta:
        model = Classe
        fields = ["annee_scolaire", "niveau", "code", "libelle"]
        widgets = {
            "annee_scolaire": forms.Select(attrs={"class": "form-select"}),
            "niveau": forms.Select(attrs={"class": "form-select"}),
            "code": forms.TextInput(attrs={"class": "form-control"}),
            "libelle": forms.TextInput(attrs={"class": "form-control"}),
        }


class FormulaireMatiereClasse(forms.ModelForm):
    """Assigner une matière + enseignant à une classe, avec coefficient optionnel."""

    def __init__(self, *args, ecole=None, classe=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            from apps.parametrage.models import Matiere
            from apps.enseignants.models import Enseignant
            self.fields["matiere"].queryset = Matiere.objects.filter(
                ecole=ecole, est_actif=True
            )
            self.fields["enseignant"].queryset = Enseignant.objects.filter(
                ecole=ecole, statut="actif"
            )
        if classe:
            # Exclure les matières déjà assignées à cette classe
            deja_assignees = MatiereClasse.objects.filter(classe=classe).values_list(
                "matiere_id", flat=True
            )
            self.fields["matiere"].queryset = self.fields["matiere"].queryset.exclude(
                pk__in=deja_assignees
            )

    class Meta:
        model = MatiereClasse
        fields = ["matiere", "enseignant", "coefficient_override"]
        widgets = {
            "matiere":              forms.Select(attrs={"class": "form-select"}),
            "enseignant":           forms.Select(attrs={"class": "form-select"}),
            "coefficient_override": forms.NumberInput(
                attrs={"class": "form-control", "step": "0.01", "min": "0.01", "placeholder": "Laisser vide = coefficient du niveau"}
            ),
        }

    def clean_coefficient_override(self):
        coeff = self.cleaned_data.get("coefficient_override")
        if coeff is not None and coeff <= 0:
            raise forms.ValidationError("Le coefficient doit être supérieur à 0.")
        return coeff