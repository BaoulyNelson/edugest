from django.contrib import admin
from apps.academique.models import AnneeScolaire, Classe, MatiereClasse, PeriodeAcademique
from apps.noyau.admin import AdminTenant


@admin.register(AnneeScolaire)
class AnneeScolaireAdmin(AdminTenant):
    list_display = ("libelle", "ecole", "date_debut", "date_fin", "statut")
    readonly_fields = tuple(field.name for field in AnneeScolaire._meta.fields)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(MatiereClasse)
class MatiereClasseAdmin(AdminTenant):
    list_display = ("ecole", "classe", "matiere", "enseignant", "coefficient_override")
    list_filter = ("ecole", "classe__annee_scolaire", "matiere")
    search_fields = (
        "ecole__nom",
        "ecole__slug",
        "classe__code",
        "classe__libelle",
        "matiere__code",
        "matiere__libelle",
        "enseignant__nom",
        "enseignant__prenom",
    )
    list_select_related = ("ecole", "classe", "matiere", "enseignant")


admin.site.register((PeriodeAcademique, Classe), AdminTenant)
