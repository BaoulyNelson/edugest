from datetime import date
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from apps.academique.models import (
    AnneeScolaire,
    Classe,
    MatiereClasse,
    PeriodeAcademique,
    StatutAnneeScolaire,
    StatutPeriode,
)
from apps.academique.services import obtenir_annee_scolaire_active
from apps.academique.forms import FormulaireClasse
from apps.etablissements.models import Etablissement
from apps.eleves.models import Eleve, Inscription, StatutInscription
from apps.enseignants.models import AffectationEnseignant, Enseignant
from apps.parametrage.models import (
    CycleEnseignement,
    Matiere,
    Niveau,
    OptionPedagogique,
    Section,
)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AdminMatiereClasseMultiEtablissementsTests(TestCase):
    def setUp(self):
        utilisateur = get_user_model().objects.create_superuser(
            email="admin-matieres@example.com",
            password="test-password",
            nom="Admin",
            prenom="Académique",
        )
        self.ecole_a = Etablissement.objects.create(
            slug="admin-matiere-ecole-a",
            nom="Établissement Matière A",
            ville="Port-au-Prince",
            cree_par=utilisateur,
        )
        self.ecole_b = Etablissement.objects.create(
            slug="admin-matiere-ecole-b",
            nom="Établissement Matière B",
            ville="Jacmel",
            cree_par=utilisateur,
        )
        for ecole, code in (
            (self.ecole_a, "MATH-A"),
            (self.ecole_b, "MATH-B"),
        ):
            annee = AnneeScolaire.objects.create(
                ecole=ecole,
                libelle="2026-2027",
                date_debut=date(2026, 9, 1),
                date_fin=date(2027, 6, 30),
            )
            PeriodeAcademique.objects.create(
                ecole=ecole,
                annee_scolaire=annee,
                numero=1,
                libelle=f"Premier trimestre {code}",
                type_periode="trimestriel",
                date_debut=date(2026, 9, 1),
                date_fin=date(2026, 12, 20),
                statut=StatutPeriode.OUVERTE,
            )
            cycle = CycleEnseignement.objects.create(
                ecole=ecole,
                code=f"CYCLE-{code}",
                libelle="Fondamental",
            )
            niveau = Niveau.objects.create(
                ecole=ecole,
                cycle=cycle,
                code=f"NIV-{code}",
                libelle="6e année",
            )
            classe = Classe.objects.create(
                ecole=ecole,
                annee_scolaire=annee,
                niveau=niveau,
                code=f"CL-{code}",
                libelle=f"Classe {code}",
            )
            matiere = Matiere.objects.create(
                ecole=ecole,
                code=code,
                libelle=f"Mathématiques {code}",
            )
            MatiereClasse.tous_objets.create(
                ecole=ecole,
                classe=classe,
                matiere=matiere,
            )
        self.client.force_login(utilisateur)
        self.url = reverse("admin:academique_matiereclasse_changelist")

    def test_superuser_voit_les_attributions_de_tous_les_etablissements(self):
        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Établissement Matière A")
        self.assertContains(response, "Établissement Matière B")
        self.assertContains(response, "MATH-A")
        self.assertContains(response, "MATH-B")

    def test_superuser_peut_filtrer_par_etablissement(self):
        response = self.client.get(
            self.url,
            {"ecole__id__exact": str(self.ecole_a.pk)},
        )

        self.assertEqual(response.status_code, 200)
        attributions = list(response.context["cl"].result_list)
        self.assertEqual(len(attributions), 1)
        self.assertEqual(attributions[0].ecole, self.ecole_a)

    def test_superuser_peut_rechercher_par_slug_etablissement(self):
        response = self.client.get(self.url, {"q": self.ecole_b.slug})

        self.assertEqual(response.status_code, 200)
        attributions = list(response.context["cl"].result_list)
        self.assertEqual(len(attributions), 1)
        self.assertEqual(attributions[0].ecole, self.ecole_b)

    def test_admin_periodes_affiche_et_filtre_les_etablissements(self):
        url = reverse("admin:academique_periodeacademique_changelist")
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Établissement Matière A")
        self.assertContains(response, "Établissement Matière B")

        response = self.client.get(
            url,
            {"ecole__id__exact": str(self.ecole_a.pk)},
        )
        periodes = list(response.context["cl"].result_list)
        self.assertEqual(len(periodes), 1)
        self.assertEqual(periodes[0].ecole, self.ecole_a)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AnneeScolaireHybrideTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="responsable-academique@example.com",
            password="test-password",
            nom="Responsable",
            prenom="École",
        )
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.ecole = Etablissement.objects.create(
            slug="ecole-annee-automatique",
            nom="École année automatique",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)

    def demander(self, route, *args):
        return self.client.get(
            reverse(route, args=args),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

    def test_premiere_visite_ne_valide_pas_une_annee_automatiquement(self):
        response = self.demander("academique:liste_classes")

        self.assertEqual(response.status_code, 200)
        self.assertFalse(AnneeScolaire.objects.filter(ecole=self.ecole).exists())

    def test_proposition_automatique_reste_en_brouillon_jusqu_a_validation(self):
        active = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)
        again = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)

        self.assertEqual(active.pk, again.pk)
        self.assertEqual(AnneeScolaire.objects.filter(ecole=self.ecole).count(), 1)
        self.assertEqual(active.statut, StatutAnneeScolaire.BROUILLON)

    def test_liste_classes_regroupe_le_titulaire_et_les_enseignants_affectes(self):
        annee = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        matiere = Matiere.objects.create(
            ecole=self.ecole,
            code="MAT",
            libelle="Mathématiques",
        )
        matiere_classe = MatiereClasse.objects.create(
            ecole=self.ecole,
            classe=classe,
            matiere=matiere,
        )
        enseignant = Enseignant.objects.create(
            ecole=self.ecole,
            nom="Augustin",
            prenom="Jean-Marc",
            sexe="M",
        )
        titulaire = Enseignant.objects.create(
            ecole=self.ecole,
            nom="Joseph",
            prenom="Marie",
            sexe="F",
        )
        classe.enseignant_titulaire = titulaire
        classe.save(update_fields=["enseignant_titulaire"])
        AffectationEnseignant.objects.create(
            ecole=self.ecole,
            enseignant=enseignant,
            matiere_classe=matiere_classe,
            date_debut=date(2026, 9, 1),
        )

        response = self.demander("academique:liste_classes")

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Équipe pédagogique")
        self.assertContains(response, "Titulaire")
        self.assertContains(response, "Jean-Marc Augustin")
        self.assertContains(response, "Marie Joseph")
        self.assertContains(response, "Mathématiques")
        self.assertNotContains(response, "Enseignants affectés")

    def test_liste_classes_filtre_par_recherche_niveau_et_statut(self):
        annee = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        classe_inactive = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-B",
            libelle="6e année fondamentale B",
            est_actif=False,
        )

        response = self.client.get(
            reverse("academique:liste_classes"),
            {"q": "6AF-A", "niveau": niveau.pk, "statut": "actif"},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, classe.code)
        self.assertNotContains(response, classe_inactive.code)
        self.assertEqual(response.context["total_classes"], 1)

    def test_exporte_uniquement_les_classes_selectionnees(self):
        annee = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        classe_selectionnee = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-B",
            libelle="6e année fondamentale B",
        )

        response = self.client.get(
            reverse("academique:liste_classes"),
            {"export": "csv", "ids": [classe_selectionnee.pk]},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        contenu = response.content.decode("utf-8-sig")
        self.assertEqual(response.status_code, 200)
        self.assertIn("6AF-A", contenu)
        self.assertNotIn("6AF-B", contenu)

    @patch("apps.academique.services.timezone.localdate", return_value=date(2026, 9, 1))
    def test_changement_de_date_ne_cloture_pas_l_annee_active(self, _):
        annee_actuelle = 2026
        ancienne_annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle=f"{annee_actuelle - 1}-{annee_actuelle}",
            date_debut=date(annee_actuelle - 1, 9, 1),
            date_fin=date(annee_actuelle, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
            est_courante=True,
            cree_par=self.utilisateur,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=ancienne_annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        eleve = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="AUTO-001",
            nom="Élève",
            prenom="Test",
            date_naissance=date(2012, 5, 3),
            sexe="F",
        )
        inscription = Inscription.tous_objets.create(
            ecole=self.ecole,
            annee_scolaire=ancienne_annee,
            classe=classe,
            eleve=eleve,
            date_inscription=date(annee_actuelle - 1, 9, 1),
            statut=StatutInscription.VALIDEE,
        )

        current = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)

        ancienne_annee.refresh_from_db()
        inscription.refresh_from_db()
        self.assertEqual(current.pk, ancienne_annee.pk)
        self.assertEqual(ancienne_annee.date_debut, date(annee_actuelle - 1, 9, 1))
        self.assertEqual(ancienne_annee.date_fin, date(annee_actuelle, 6, 30))
        self.assertEqual(ancienne_annee.statut, StatutAnneeScolaire.ACTIVE)
        self.assertIsNone(ancienne_annee.date_cloture_officielle)
        self.assertFalse(ancienne_annee.verrou_administratif)
        self.assertEqual(inscription.statut, StatutInscription.VALIDEE)

    @patch("apps.academique.views.timezone.localdate", return_value=date(2026, 10, 1))
    def test_creation_manuelle_affiche_le_formulaire_pre_rempli(self, _):
        response = self.client.get(
            reverse("academique:creer_annee"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="date_debut"')
        self.assertContains(response, 'name="date_fin"')
        self.assertContains(response, 'value="2026-09-01"')
        self.assertContains(response, 'value="2027-06-30"')
        self.assertFalse(AnneeScolaire.objects.filter(ecole=self.ecole).exists())

    def test_creation_enregistre_les_dates_personnalisees_en_brouillon(self):
        response = self.client.post(
            reverse("academique:creer_annee"),
            {
                "libelle": "2026-2027",
                "date_debut": "2026-10-01",
                "date_fin": "2027-07-15",
                "type_decoupage": "semestriel",
                "notes_internes": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        annee = AnneeScolaire.objects.get(ecole=self.ecole)

        self.assertEqual(response.status_code, 302)
        self.assertEqual(annee.date_debut, date(2026, 10, 1))
        self.assertEqual(annee.date_fin, date(2027, 7, 15))
        self.assertEqual(annee.statut, StatutAnneeScolaire.BROUILLON)

    def test_creation_refuse_un_libelle_sans_deux_annees_valides(self):
        for libelle in ("2026", "2026-2026", "2027-2026", "2026-2027 special"):
            with self.subTest(libelle=libelle):
                response = self.client.post(
                    reverse("academique:creer_annee"),
                    {
                        "libelle": libelle,
                        "date_debut": "2026-09-01",
                        "date_fin": "2027-06-30",
                        "type_decoupage": "trimestriel",
                        "notes_internes": "",
                    },
                    HTTP_X_TENANT_SLUG=self.ecole.slug,
                )

                self.assertEqual(response.status_code, 200)
                self.assertFalse(
                    AnneeScolaire.objects.filter(
                        ecole=self.ecole,
                        libelle=libelle,
                    ).exists()
                )
                self.assertContains(response, "AAAA-AAAA")

    def test_activation_requiert_une_classe_et_active_annee_configuree(self):
        annee = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        response = self.client.post(
            reverse("academique:activer_annee", args=[annee.pk]),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        annee.refresh_from_db()
        self.assertEqual(response.status_code, 302)
        self.assertEqual(annee.statut, StatutAnneeScolaire.ACTIVE)

    def test_liste_annees_cree_une_proposition_et_explique_le_calendrier(self):
        response = self.demander("academique:liste_annees")
        proposition = AnneeScolaire.objects.get(ecole=self.ecole)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, proposition.libelle)
        self.assertContains(response, "Vous pouvez modifier ses dates")
        self.assertEqual(proposition.statut, StatutAnneeScolaire.BROUILLON)
        self.assertContains(response, "Activer cette année")

    def test_selection_annee_est_conservee_dans_la_session(self):
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2024-2025",
            date_debut=date(2024, 9, 1),
            date_fin=date(2025, 6, 30),
            statut=StatutAnneeScolaire.CLOTUREE,
        )
        response = self.client.post(
            reverse("academique:selectionner_annee"),
            {"annee_scolaire": annee.pk},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
            HTTP_REFERER=reverse("academique:liste_annees"),
        )

        self.assertRedirects(response, reverse("academique:liste_annees"))
        self.assertEqual(
            self.client.session["annee_scolaire_selectionnee"], str(annee.pk)
        )

    def test_selection_refuse_une_annee_d_un_autre_etablissement(self):
        autre_ecole = Etablissement.objects.create(
            slug="autre-ecole-annee",
            nom="Autre école année",
            ville="Jacmel",
            cree_par=self.utilisateur,
        )
        annee_autre_ecole = AnneeScolaire.objects.create(
            ecole=autre_ecole,
            libelle="2024-2025",
            date_debut=date(2024, 9, 1),
            date_fin=date(2025, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        response = self.client.post(
            reverse("academique:selectionner_annee"),
            {"annee_scolaire": annee_autre_ecole.pk},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 302)
        self.assertNotIn("annee_scolaire_selectionnee", self.client.session)

    @patch("apps.academique.services.timezone.localdate", return_value=date(2026, 8, 31))
    def test_annee_precedente_reste_active_jusqu_au_31_aout(self, _):
        ancienne_annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2025-2026",
            date_debut=date(2025, 9, 1),
            date_fin=date(2026, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
            est_courante=True,
            cree_par=self.utilisateur,
        )

        active = obtenir_annee_scolaire_active(self.ecole, self.utilisateur)

        self.assertEqual(active.pk, ancienne_annee.pk)
        self.assertEqual(AnneeScolaire.objects.filter(ecole=self.ecole).count(), 1)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class CreationRapideReferentielTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="creation-rapide@example.com",
            password="test-password",
            nom="Admin",
            prenom="Académique",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-creation-rapide",
            nom="École création rapide",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.url = reverse("academique:creation_rapide_referentiel")

    def test_get_affiche_le_formulaire_modal_et_la_creation_de_cycle(self):
        response = self.client.get(
            self.url,
            {"type": "niveau"},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Créer un cycle sans perdre ces informations")
        self.assertContains(response, 'name="cycle"')

    def test_page_classe_affiche_les_actions_de_creation_rapide(self):
        response = self.client.get(
            reverse("academique:creer_classe"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        for type_objet in ("annee", "niveau", "section", "option", "enseignant"):
            self.assertContains(response, f'data-quick-create="{type_objet}"')
        self.assertContains(response, 'id="creationRapideModal"')

    def test_formulaire_matiere_classe_propose_la_creation_rapide_enseignant(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="LICENCE",
            libelle="Licence",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="L1",
            libelle="Licence 1",
        )
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="L1-A",
            libelle="Licence 1 A",
        )

        response = self.client.get(
            reverse("academique:ajouter_matiere_classe", kwargs={"pk": classe.pk}),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "data-quick-create-enseignant")
        self.assertContains(response, 'id="creationEnseignantRapideModal"')

    def test_cree_cycle_puis_niveau_dans_le_tenant_courant(self):
        cycle_response = self.client.post(
            self.url,
            {
                "type": "cycle",
                "code": "FOND",
                "libelle": "Fondamental",
                "ordre_affichage": "0",
                "couleur": "#1a3c6e",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(
            cycle_response.status_code,
            200,
            cycle_response.content.decode(),
        )
        cycle_id = cycle_response.json()["id"]
        niveau_response = self.client.post(
            self.url,
            {
                "type": "niveau",
                "cycle": cycle_id,
                "code": "6AF",
                "libelle": "6e année",
                "libelle_court": "6e AF",
                "duree_annees": "1",
                "ordre_affichage": "0",
                "est_actif": "on",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(niveau_response.status_code, 200)
        niveau = Niveau.objects.get(pk=niveau_response.json()["id"])
        self.assertEqual(niveau.ecole, self.ecole)
        self.assertEqual(str(niveau.cycle_id), cycle_response.json()["id"])

    def test_creation_rapide_refuse_un_cycle_d_un_autre_tenant(self):
        autre_ecole = Etablissement.objects.create(
            slug="autre-ecole-creation-rapide",
            nom="Autre école",
            ville="Jacmel",
            cree_par=self.utilisateur,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=autre_ecole,
            code="AUTRE",
            libelle="Autre cycle",
        )

        response = self.client.post(
            self.url,
            {
                "type": "niveau",
                "cycle": cycle.pk,
                "code": "N1",
                "libelle": "Niveau 1",
                "duree_annees": "1",
                "ordre_affichage": "0",
                "est_actif": "on",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 400)
        self.assertFalse(Niveau.objects.filter(ecole=self.ecole).exists())

    def test_formulaire_classe_refuse_une_section_d_un_autre_niveau(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau_a = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="N1",
            libelle="Niveau 1",
        )
        niveau_b = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="N2",
            libelle="Niveau 2",
        )
        section_b = Section.objects.create(
            ecole=self.ecole,
            niveau=niveau_b,
            code="A",
            libelle="Section A",
        )

        form = FormulaireClasse(
            data={"niveau": niveau_a.pk, "section": section_b.pk},
            ecole=self.ecole,
        )

        self.assertNotIn(section_b, form.fields["section"].queryset)
        self.assertFalse(form.is_valid())

    def test_cree_annee_section_option_et_enseignant_rapidement(self):
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="N1",
            libelle="Niveau 1",
        )
        creations = (
            (
                "annee",
                {
                    "libelle": "2099-2100",
                    "date_debut": "2099-09-01",
                    "date_fin": "2100-06-30",
                    "type_decoupage": "trimestriel",
                },
            ),
            (
                "section",
                {"niveau": niveau.pk, "code": "A", "libelle": "Section A"},
            ),
            (
                "option",
                {"niveau": niveau.pk, "code": "SCI", "libelle": "Sciences"},
            ),
            (
                "matiere",
                {
                    "code": "MAT",
                    "libelle": "Mathématiques",
                    "libelle_court": "Maths",
                    "type_matiere": "theorique",
                    "ordre_affichage": "0",
                    "couleur": "#3b82f6",
                    "est_actif": "on",
                },
            ),
            (
                "enseignant",
                {"nom": "Joseph", "prenom": "Marie", "sexe": "F"},
            ),
        )

        for type_objet, champs in creations:
            with self.subTest(type_objet=type_objet):
                response = self.client.post(
                    self.url,
                    {"type": type_objet, **champs},
                    HTTP_X_TENANT_SLUG=self.ecole.slug,
                )
                self.assertEqual(
                    response.status_code,
                    200,
                    response.content.decode(),
                )
                self.assertTrue(response.json()["id"])

        annee = AnneeScolaire.objects.get(ecole=self.ecole, libelle="2099-2100")
        self.assertEqual(annee.statut, StatutAnneeScolaire.BROUILLON)
        self.assertTrue(Section.objects.filter(ecole=self.ecole, niveau=niveau).exists())
        self.assertTrue(
            OptionPedagogique.objects.filter(ecole=self.ecole, niveau=niveau).exists()
        )
        self.assertTrue(Matiere.objects.filter(ecole=self.ecole, code="MAT").exists())
        self.assertTrue(
            Enseignant.objects.filter(
                ecole=self.ecole,
                nom="Joseph",
                prenom="Marie",
            ).exists()
        )

    def test_cree_une_classe_rapidement_pour_une_annee_active(self):
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="N1",
            libelle="Niveau 1",
        )

        response = self.client.post(
            self.url,
            {
                "type": "classe",
                "annee_scolaire": annee.pk,
                "niveau": niveau.pk,
                "code": "N1-A",
                "libelle": "Niveau 1 A",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200, response.content.decode())
        classe = Classe.objects.get(pk=response.json()["id"])
        self.assertEqual(classe.ecole, self.ecole)
        self.assertEqual(classe.annee_scolaire, annee)
        self.assertEqual(str(classe.niveau_id), str(niveau.pk))

    def test_creation_rapide_est_refusee_sans_permission(self):
        utilisateur = get_user_model().objects.create_user(
            email="sans-permission@example.com",
            password="test-password",
            nom="Utilisateur",
            prenom="Simple",
        )
        self.client.force_login(utilisateur)

        response = self.client.get(
            self.url,
            {"type": "cycle"},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 403)
