"""
apps/academique/services.py
============================
ServiceAnneeScolaire : transitions d'état avec gardes métier complètes.
ServicePeriodeAcademique : clôture et publication des périodes.
"""

from datetime import date

from django.db import transaction
from django.utils import timezone
from apps.academique.models import (
    AnneeScolaire, PeriodeAcademique,
    StatutAnneeScolaire, StatutPeriode,
    TRANSITIONS_ANNEE_SCOLAIRE, TRANSITIONS_PERIODE,
)
from apps.noyau.exceptions import (
    TransitionInterditError, RegleMetierError, OperationImpossibleError
)
from apps.securite.rbac import moteur_rbac


ANNEE_SESSION_KEY = "annee_scolaire_selectionnee"


def obtenir_annee_scolaire_selectionnee(request):
    """Retourne l'année de travail choisie dans cette session, ou le choix par défaut."""
    ecole = getattr(request, "etablissement", None)
    if ecole is None:
        return None

    annees = AnneeScolaire.objects.filter(ecole=ecole).order_by("-date_debut", "-pk")
    annee_id = request.session.get(ANNEE_SESSION_KEY)
    if annee_id:
        annee = annees.filter(pk=annee_id).first()
        if annee:
            return annee
        request.session.pop(ANNEE_SESSION_KEY, None)

    annee = annees.filter(
        statut=StatutAnneeScolaire.ACTIVE,
    ).first()
    if annee:
        return annee
    return annees.exclude(statut=StatutAnneeScolaire.ARCHIVEE).first()


def selectionner_annee_scolaire(request, annee_id):
    """Sélectionne uniquement une année appartenant à l'établissement courant."""
    annee = AnneeScolaire.objects.filter(
        ecole=request.etablissement,
        pk=annee_id,
    ).first()
    if annee is None:
        return None
    request.session[ANNEE_SESSION_KEY] = str(annee.pk)
    request.annee_scolaire_courante = annee
    return annee


def proposer_annee_scolaire(ecole, utilisateur=None):
    """Crée en brouillon une proposition préremplie selon le calendrier septembre-juin."""
    aujourd_hui = timezone.localdate()
    annee_debut = aujourd_hui.year if aujourd_hui.month >= 9 else aujourd_hui.year - 1
    annee_fin = annee_debut + 1
    libelle = f"{annee_debut}-{annee_fin}"
    annee, _ = AnneeScolaire.objects.get_or_create(
        ecole=ecole,
        libelle=libelle,
        defaults={
            "date_debut": date(annee_debut, 9, 1),
            "date_fin": date(annee_fin, 6, 30),
            "statut": StatutAnneeScolaire.BROUILLON,
            "cree_par": (
                utilisateur
                if getattr(utilisateur, "is_authenticated", False)
                else None
            ),
        },
    )
    return annee


@transaction.atomic
def obtenir_annee_scolaire_active(ecole, utilisateur=None) -> AnneeScolaire:
    """Retourne l'année active sans modifier ni clôturer automatiquement les années."""
    annee = AnneeScolaire.objects.filter(
        ecole=ecole,
        statut=StatutAnneeScolaire.ACTIVE,
    ).first()
    if annee is not None:
        return annee
    return proposer_annee_scolaire(ecole, utilisateur)


class ServiceAnneeScolaire:
    """Gère le cycle de vie d'une année scolaire."""

    def __init__(self, utilisateur):
        self.utilisateur = utilisateur
        self._audit = None  # Lazy init

    @property
    def audit(self):
        if self._audit is None:
            from apps.securite.rbac import ServiceAudit
            # Import depuis rbac.py où ServiceAudit est défini
            import importlib
            mod = importlib.import_module("apps.securite.rbac")
            self._audit = mod.ServiceAudit(self.utilisateur)
        return self._audit

    @transaction.atomic
    def activer(self, annee: AnneeScolaire) -> AnneeScolaire:
        """
        Brouillon → Active.
        Gardes : unicité de l'année active, classes existantes.
        """
        if not annee.peut_transitionner_vers(StatutAnneeScolaire.ACTIVE):
            raise TransitionInterditError(
                f"Transition impossible : {annee.statut} → active. "
                f"Transitions autorisées depuis '{annee.statut}' : "
                f"{TRANSITIONS_ANNEE_SCOLAIRE.get(annee.statut, [])}"
            )

        # Garde : une seule année active par école
        if AnneeScolaire.objects.filter(
            ecole=annee.ecole,
            statut=StatutAnneeScolaire.ACTIVE
        ).exists():
            raise RegleMetierError(
                "Une année scolaire est déjà active pour cet établissement. "
                "Clôturer l'année courante avant d'en activer une nouvelle."
            )

        # Garde : des classes doivent être configurées
        if not annee.classes.filter(est_actif=True).exists():
            raise OperationImpossibleError(
                "Impossible d'activer une année sans classes configurées. "
                "Créer au moins une classe active."
            )

        donnees_avant = {"statut": annee.statut}

        annee.statut = StatutAnneeScolaire.ACTIVE
        annee.est_courante = True
        annee.date_ouverture_officielle = timezone.now().date()
        annee.save(update_fields=["statut", "est_courante", "date_ouverture_officielle"])

        # Invalider le cache de l'année courante
        from django.core.cache import cache
        cache.delete(f"annee_courante:{annee.ecole_id}")

        return annee

    @transaction.atomic
    def cloturer(self, annee: AnneeScolaire) -> AnneeScolaire:
        """Active → Clôturée. Vérifie que tous les bulletins sont publiés."""
        if not annee.peut_transitionner_vers(StatutAnneeScolaire.CLOTUREE):
            raise TransitionInterditError(
                f"Transition impossible : {annee.statut} → cloturee."
            )

        # Garde : bulletins publiés pour toutes les périodes
        from apps.bulletins.models import Bulletin, StatutBulletin
        non_publies = Bulletin.objects.filter(
            inscription__annee_scolaire=annee,
        ).exclude(statut=StatutBulletin.PUBLIE).count()

        if non_publies > 0:
            raise RegleMetierError(
                f"{non_publies} bulletin(s) ne sont pas encore publiés. "
                "Publier tous les bulletins avant de clôturer l'année scolaire."
            )

        annee.statut = StatutAnneeScolaire.CLOTUREE
        annee.est_courante = False
        annee.verrou_administratif = True
        annee.date_cloture_officielle = timezone.now().date()
        annee.save(update_fields=[
            "statut", "est_courante", "verrou_administratif", "date_cloture_officielle"
        ])

        # Verrouiller toutes les inscriptions de l'année
        from apps.eleves.models import Inscription, StatutInscription
        Inscription.objects.filter(
            annee_scolaire=annee,
            statut=StatutInscription.VALIDEE,
        ).update(statut=StatutInscription.VERROUILEE)

        from django.core.cache import cache
        cache.delete(f"annee_courante:{annee.ecole_id}")

        return annee

    @transaction.atomic
    def archiver(self, annee: AnneeScolaire) -> AnneeScolaire:
        """Clôturée → Archivée. État terminal."""
        if not annee.peut_transitionner_vers(StatutAnneeScolaire.ARCHIVEE):
            raise TransitionInterditError(
                f"Transition impossible : {annee.statut} → archivee."
            )

        annee.statut = StatutAnneeScolaire.ARCHIVEE
        annee.save(update_fields=["statut"])
        return annee


class ServicePeriodeAcademique:
    """Gère la clôture et la publication des périodes."""

    def __init__(self, utilisateur):
        self.utilisateur = utilisateur

    @transaction.atomic
    def cloturer(self, periode: PeriodeAcademique) -> PeriodeAcademique:
        """Ouverte → Clôturée. Verrouille toutes les notes de la période."""
        if not periode.peut_transitionner_vers(StatutPeriode.CLOTUREE):
            raise TransitionInterditError(
                f"Impossible de clôturer une période en statut '{periode.statut}'."
            )

        if periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE:
            raise RegleMetierError(
                "Impossible de clôturer une période d'une année non active."
            )

        periode.statut = StatutPeriode.CLOTUREE
        periode.date_cloture = timezone.now()
        periode.cloture_par = self.utilisateur
        periode.save(update_fields=["statut", "date_cloture", "cloture_par"])

        # Verrouiller toutes les notes de cette période
        from apps.notes.models import Note
        nb_verrouillees = Note.objects.filter(periode=periode).update(
            est_verrouilee=True,
            date_verrouillage=timezone.now(),
        )

        return periode

    @transaction.atomic
    def publier(self, periode: PeriodeAcademique) -> PeriodeAcademique:
        """Clôturée → Publiée. Publie toutes les moyennes générales."""
        if not periode.peut_transitionner_vers(StatutPeriode.PUBLIEE):
            raise TransitionInterditError(
                f"Impossible de publier une période en statut '{periode.statut}'."
            )
        if periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE:
            raise RegleMetierError(
                "Impossible de publier une période d'une année non active."
            )

        # Vérifier que les classements sont calculés
        from apps.notes.models import MoyenneGenerale
        sans_rang = MoyenneGenerale.objects.filter(
            periode=periode,
            rang_classe__isnull=True,
        ).count()

        if sans_rang > 0:
            raise RegleMetierError(
                f"{sans_rang} moyenne(s) sans rang calculé. "
                "Calculer les classements avant de publier la période."
            )

        periode.statut = StatutPeriode.PUBLIEE
        periode.date_publication = timezone.now()
        periode.publiee_par = self.utilisateur
        periode.save(update_fields=["statut", "date_publication", "publiee_par"])

        return periode

    @transaction.atomic
    def rouvrir(self, periode: PeriodeAcademique, motif: str) -> PeriodeAcademique:
        """
        Clôturée → Ouverte.
        Opération exceptionnelle — doit être justifiée.
        NE PAS appliquer si statut=PUBLIEE (état terminal).
        """
        if not periode.peut_transitionner_vers(StatutPeriode.OUVERTE):
            raise TransitionInterditError(
                f"Impossible de rouvrir une période en statut '{periode.statut}'. "
                "Une période publiée ne peut jamais être rouverte."
            )

        if not motif.strip():
            raise RegleMetierError("Un motif est obligatoire pour réouvrir une période.")
        if periode.annee_scolaire.statut != StatutAnneeScolaire.ACTIVE:
            raise RegleMetierError(
                "Impossible de réouvrir une période d'une année non active."
            )

        periode.statut = StatutPeriode.OUVERTE
        periode.date_cloture = None
        periode.cloture_par = None
        periode.save(update_fields=["statut", "date_cloture", "cloture_par"])

        # Déverrouiller les notes pour permettre les corrections
        from apps.notes.models import Note
        Note.objects.filter(periode=periode, est_verrouilee=True).update(
            est_verrouilee=False,
            date_verrouillage=None,
        )

        return periode


"""
apps/eleves/services.py
========================
ServiceInscription : gestion complète du cycle de vie d'un élève.
"""


class ServiceInscription:
    """Gère les inscriptions, transferts, suspensions et abandons d'élèves."""

    def __init__(self, utilisateur):
        self.utilisateur = utilisateur

    @transaction.atomic
    def inscrire(
        self,
        eleve,
        annee,
        classe,
        type_inscription: str = "nouveau",
        frais_inscription=None,
        observations: str = "",
    ):
        """Inscrit un élève avec toutes les gardes métier."""
        from apps.eleves.models import Inscription, StatutInscription, StatutEleve

        # Garde 1 : l'élève doit être actif
        if eleve.statut not in [StatutEleve.ACTIF]:
            raise RegleMetierError(
                f"L'élève {eleve.nom_complet} a le statut '{eleve.statut}'. "
                "Seuls les élèves actifs peuvent être inscrits."
            )

        # Garde 2 : année active et non verrouillée
        if not annee.accepte_inscriptions:
            raise RegleMetierError(
                f"L'année scolaire {annee.libelle} n'accepte pas les inscriptions "
                f"(statut: {annee.statut}, verrou: {annee.verrou_administratif})."
            )

        # Garde 3 : pas de double inscription
        if Inscription.objects.filter(eleve=eleve, annee_scolaire=annee).exists():
            raise RegleMetierError(
                f"{eleve.nom_complet} est déjà inscrit pour {annee.libelle}."
            )

        # Garde 4 : classe non pleine
        if classe.est_pleine:
            raise RegleMetierError(
                f"La classe {classe.code} a atteint sa capacité maximale "
                f"({classe.capacite_max} élèves)."
            )

        inscription = Inscription.objects.create(
            ecole=annee.ecole,
            eleve=eleve,
            annee_scolaire=annee,
            classe=classe,
            type_inscription=type_inscription,
            statut=StatutInscription.EN_ATTENTE,
            date_inscription=timezone.now().date(),
            frais_inscription=frais_inscription,
            observations=observations,
        )

        # Mettre à jour la date de première inscription si nécessaire
        if not eleve.date_premiere_inscription:
            eleve.date_premiere_inscription = inscription.date_inscription
            eleve.save(update_fields=["date_premiere_inscription"])

        return inscription

    @transaction.atomic
    def valider(self, inscription) -> object:
        """Valide une inscription en attente."""
        from apps.eleves.models import StatutInscription
        if inscription.statut != StatutInscription.EN_ATTENTE:
            raise RegleMetierError(
                f"Seules les inscriptions en attente peuvent être validées "
                f"(statut actuel : {inscription.statut})."
            )

        inscription.statut = StatutInscription.VALIDEE
        inscription.date_validation = timezone.now().date()
        inscription.validee_par = self.utilisateur
        inscription.save(update_fields=["statut", "date_validation", "validee_par"])
        return inscription

    @transaction.atomic
    def changer_de_classe(self, inscription, nouvelle_classe) -> object:
        """Transfère un élève vers une autre classe de la même école/année."""
        from apps.eleves.models import StatutInscription

        if inscription.statut == StatutInscription.VERROUILEE:
            raise RegleMetierError(
                "Impossible de changer de classe : inscription verrouillée (année close)."
            )
        if nouvelle_classe.annee_scolaire != inscription.annee_scolaire:
            raise RegleMetierError(
                "Le changement de classe est uniquement possible au sein de la même année."
            )
        if nouvelle_classe.est_pleine:
            raise RegleMetierError(
                f"La classe {nouvelle_classe.code} est pleine."
            )

        ancienne_classe = inscription.classe
        inscription.classe = nouvelle_classe
        inscription.save(update_fields=["classe"])

        # Enregistrer le mouvement
        from apps.eleves.models import MouvementEleve, TypeMouvement
        MouvementEleve.objects.create(
            ecole=inscription.ecole,
            eleve=inscription.eleve,
            inscription=inscription,
            type_mouvement=TypeMouvement.TRANSFERT_ENTRANT,
            date_mouvement=timezone.now().date(),
            motif=f"Changement de classe : {ancienne_classe.code} → {nouvelle_classe.code}",
            enregistre_par=self.utilisateur,
        )
        return inscription

    @transaction.atomic
    def suspendre(self, inscription, motif: str) -> object:
        """Suspend un élève pour motif disciplinaire."""
        from apps.eleves.models import StatutEleve, MouvementEleve, TypeMouvement

        if not motif.strip():
            raise RegleMetierError("Un motif est obligatoire pour suspendre un élève.")

        inscription.eleve.statut = StatutEleve.SUSPENDU
        inscription.eleve.save(update_fields=["statut"])

        MouvementEleve.objects.create(
            ecole=inscription.ecole,
            eleve=inscription.eleve,
            inscription=inscription,
            type_mouvement=TypeMouvement.SUSPENSION,
            date_mouvement=timezone.now().date(),
            motif=motif,
            enregistre_par=self.utilisateur,
        )
        return inscription


"""
apps/badges/services.py
========================
ServiceBadge : génération de badges et cartes d'identité scolaires.
"""


class ServiceBadge:
    """Génère les badges élèves et enseignants."""

    def __init__(self, ecole):
        self.ecole = ecole

    def generer_badge_eleve(self, inscription) -> bytes:
        """Génère le badge PDF d'un élève."""
        from apps.badges.generateurs.badge_eleve import GenerateurBadgeEleve
        generateur = GenerateurBadgeEleve(ecole=self.ecole)
        buffer = generateur.generer(inscription)
        return buffer.read()

    def generer_badges_classe(self, classe) -> dict:
        """Génère les badges de tous les élèves d'une classe en ZIP."""
        import zipfile
        from io import BytesIO
        from apps.eleves.models import Inscription, StatutInscription

        inscrits = Inscription.objects.filter(
            classe=classe,
            statut=StatutInscription.VALIDEE,
        ).select_related("eleve")

        zip_buffer = BytesIO()
        generes = 0

        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            for inscription in inscrits:
                try:
                    pdf_bytes = self.generer_badge_eleve(inscription)
                    nom_fichier = (
                        f"badge_{inscription.eleve.matricule}_"
                        f"{inscription.eleve.nom}_{inscription.eleve.prenom}.pdf"
                    )
                    zf.writestr(nom_fichier, pdf_bytes)
                    generes += 1
                except Exception as exc:
                    import logging
                    logging.getLogger("apps.badges").error(
                        f"Erreur badge élève {inscription.eleve.matricule} : {exc}"
                    )

        zip_buffer.seek(0)
        return {
            "generes": generes,
            "zip_bytes": zip_buffer.read(),
        }