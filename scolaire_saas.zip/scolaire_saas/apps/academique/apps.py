from django.apps import AppConfig

class AcademiqueConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.academique"
    verbose_name = "Annees scolaires, periodes et classes"
