from django.contrib import messages
from django.shortcuts import render

def gerer_verrouillage(request, credentials, *args, **kwargs):
    messages.error(
        request,
        "Trop de tentatives de connexion. Réessayez plus tard."
    )
    from apps.comptes.forms import FormulaireConnexion

    return render(
        request,
        "comptes/connexion.html",
        {"form": FormulaireConnexion(request)},
        status=403,
    )