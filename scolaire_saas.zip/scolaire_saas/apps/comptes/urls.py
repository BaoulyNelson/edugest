from django.contrib.auth import views as auth_views
from django.urls import path, reverse_lazy
from apps.comptes import views
from apps.comptes.forms import FormulaireReinitialisationMotDePasse

app_name = "comptes"
urlpatterns = [
    path("connexion/", views.connexion, name="connexion"),
    path(
        "mot-de-passe-oublie/",
        auth_views.PasswordResetView.as_view(
            form_class=FormulaireReinitialisationMotDePasse,
            template_name="comptes/password_reset_form.html",
            email_template_name="comptes/password_reset_email.txt",
            subject_template_name="comptes/password_reset_subject.txt",
            success_url=reverse_lazy("comptes:password_reset_done"),
        ),
        name="password_reset",
    ),
    path(
        "mot-de-passe-envoye/",
        auth_views.PasswordResetDoneView.as_view(
            template_name="comptes/password_reset_done.html"
        ),
        name="password_reset_done",
    ),
    path(
        "reinitialiser/<uidb64>/<token>/",
        auth_views.PasswordResetConfirmView.as_view(
            template_name="comptes/password_reset_confirm.html",
            success_url=reverse_lazy("comptes:password_reset_complete"),
        ),
        name="password_reset_confirm",
    ),
    path(
        "mot-de-passe-reinitialise/",
        auth_views.PasswordResetCompleteView.as_view(
            template_name="comptes/password_reset_complete.html"
        ),
        name="password_reset_complete",
    ),
    path("deconnexion/", views.deconnexion, name="deconnexion"),
    path("profil/", views.profil, name="profil"),
    path(
        "changer-mot-de-passe/", views.changer_mot_de_passe, name="changer_mot_de_passe"
    ),
]
