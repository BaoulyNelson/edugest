"""
apps/comptes/backends.py
========================
Backend d'authentification multitenant.
Vérifie que l'utilisateur a bien un rôle actif dans l'établissement courant.
"""

from django.contrib.auth.backends import ModelBackend
from django.db import models
from apps.noyau.middleware import obtenir_tenant_courant


class BackendAuthMultitenant(ModelBackend):
    """
    Étend le backend standard Django avec une vérification tenant.
    Un utilisateur ne peut se connecter que s'il a un rôle actif
    dans l'établissement courant.

    Exception : les superutilisateurs Django (is_superuser=True)
    peuvent se connecter sans restriction tenant.
    """

    def authenticate(self, request, username=None, password=None, **kwargs):
        # username est l'email dans notre système
        email = username or kwargs.get("email")
        if not email or not password:
            return None

        from apps.comptes.models import Utilisateur
        try:
            utilisateur = Utilisateur.objects.get(email__iexact=email)
        except Utilisateur.DoesNotExist:
            # Timing attack mitigation : hasher quand même
            Utilisateur().set_password(password)
            return None

        if not utilisateur.check_password(password):
            return None

        if not utilisateur.est_actif:
            return None

        # Superutilisateur : accès universel (admin SaaS)
        if utilisateur.is_superuser:
            return utilisateur

        # Vérifier l'appartenance au tenant courant
        etablissement = obtenir_tenant_courant()
        if etablissement and not self._a_acces_tenant(utilisateur, etablissement):
            return None

        return utilisateur

    def _a_acces_tenant(self, utilisateur, etablissement) -> bool:
        """Vérifie qu'un rôle actif existe pour cet utilisateur dans cet établissement."""
        from apps.securite.models import UtilisateurRole
        from django.utils import timezone

        return UtilisateurRole.tous_objets.filter(
            utilisateur=utilisateur,
            ecole=etablissement,
            est_actif=True,
        ).filter(
            models.Q(expire_le__isnull=True) | models.Q(expire_le__gte=timezone.now().date())
        ).exists()

    def get_user(self, user_id):
        from apps.comptes.models import Utilisateur
        try:
            return Utilisateur.objects.get(pk=user_id)
        except Utilisateur.DoesNotExist:
            return None

