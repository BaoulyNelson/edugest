"""Formulaires d'authentification et de profil utilisateur."""
from django import forms
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.forms import (
    AuthenticationForm,
    PasswordChangeForm,
    PasswordResetForm,
)
from django.core.exceptions import ValidationError
from apps.comptes.models import Utilisateur


class FormulaireConnexion(AuthenticationForm):
    username = forms.EmailField(
        label="Adresse email",
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "votre@email.com", "autofocus": True}),
    )
    password = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={"class": "form-control", "placeholder": "••••••••"}),
    )


class FormulaireCreationCompte(forms.ModelForm):
    mot_de_passe = forms.CharField(label="Mot de passe", widget=forms.PasswordInput(attrs={"class": "form-control"}), min_length=8)
    confirmer_mot_de_passe = forms.CharField(label="Confirmer", widget=forms.PasswordInput(attrs={"class": "form-control"}))

    class Meta:
        model = Utilisateur
        fields = ["email", "nom", "prenom", "telephone"]
        widgets = {
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "nom": forms.TextInput(attrs={"class": "form-control"}),
            "prenom": forms.TextInput(attrs={"class": "form-control"}),
            "telephone": forms.TextInput(attrs={"class": "form-control"}),
        }

    def clean(self):
        cd = super().clean()
        if cd.get("mot_de_passe") != cd.get("confirmer_mot_de_passe"):
            self.add_error(
                "confirmer_mot_de_passe",
                "Les mots de passe ne correspondent pas.",
            )
        if cd.get("mot_de_passe"):
            user = Utilisateur(
                email=cd.get("email", ""),
                nom=cd.get("nom", ""),
                prenom=cd.get("prenom", ""),
            )
            try:
                validate_password(cd["mot_de_passe"], user=user)
            except ValidationError as error:
                self.add_error("mot_de_passe", error)
        return cd

    def save(self, commit=True):
        utilisateur = super().save(commit=False)
        utilisateur.set_password(self.cleaned_data["mot_de_passe"])
        if commit:
            utilisateur.save()
        return utilisateur


class ChampPhotoProfil(forms.ClearableFileInput):
    initial_text = ""
    input_text = ""
    clear_checkbox_label = "Retirer la photo"


class FormulaireProfil(forms.ModelForm):
    class Meta:
        model = Utilisateur
        fields = ["nom", "prenom", "telephone", "photo"]
        widgets = {
            **{
                field: forms.TextInput(attrs={"class": "form-control"})
                for field in ["nom", "prenom", "telephone"]
            },
            "photo": ChampPhotoProfil(
                attrs={"accept": "image/*", "class": "profile-photo-input"}
            ),
        }


class FormulairePreferences(forms.ModelForm):
    langue_preferee = forms.ChoiceField(
        label="Langue préférée",
        choices=(
            ("fr", "Français"),
            ("ht", "Kreyòl ayisyen"),
            ("en", "English"),
        ),
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    fuseau_horaire = forms.ChoiceField(
        label="Fuseau horaire",
        choices=(
            ("America/Port-au-Prince", "Haïti (America/Port-au-Prince)"),
            ("America/New_York", "États-Unis — Est (America/New_York)"),
            ("America/Toronto", "Canada — Est (America/Toronto)"),
            ("UTC", "Temps universel (UTC)"),
        ),
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    class Meta:
        model = Utilisateur
        fields = ["langue_preferee", "fuseau_horaire"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        langue_actuelle = self.instance.langue_preferee
        choix_langue = list(self.fields["langue_preferee"].choices)
        codes_connus = {code for code, _ in choix_langue}
        if langue_actuelle == "cr":
            choix_langue = [
                (("cr" if code == "ht" else code), label)
                for code, label in choix_langue
            ]
        elif langue_actuelle and langue_actuelle not in codes_connus:
            choix_langue.insert(-1, (langue_actuelle, f"Autre ({langue_actuelle})"))
        self.fields["langue_preferee"].choices = choix_langue
        fuseau_actuel = self.instance.fuseau_horaire
        fuseaux_connus = {
            code for code, _ in self.fields["fuseau_horaire"].choices
        }
        if fuseau_actuel and fuseau_actuel not in fuseaux_connus:
            self.fields["fuseau_horaire"].choices = [
                *self.fields["fuseau_horaire"].choices[:-1],
                (fuseau_actuel, f"Autre ({fuseau_actuel})"),
                self.fields["fuseau_horaire"].choices[-1],
            ]


class FormulaireConfirmationCompte(forms.Form):
    mot_de_passe = forms.CharField(
        label="Mot de passe actuel",
        strip=False,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control",
                "autocomplete": "current-password",
            }
        ),
    )
    confirmation = forms.CharField(
        label="Confirmation",
        widget=forms.TextInput(
            attrs={"class": "form-control", "autocomplete": "off"}
        ),
    )

    def __init__(self, utilisateur, confirmation_attendue, *args, **kwargs):
        self.utilisateur = utilisateur
        self.confirmation_attendue = confirmation_attendue
        super().__init__(*args, **kwargs)

    def clean_mot_de_passe(self):
        mot_de_passe = self.cleaned_data["mot_de_passe"]
        if not self.utilisateur.check_password(mot_de_passe):
            raise ValidationError("Le mot de passe saisi est incorrect.")
        return mot_de_passe

    def clean_confirmation(self):
        confirmation = self.cleaned_data["confirmation"]
        if confirmation != self.confirmation_attendue:
            raise ValidationError(
                f"Saisissez exactement « {self.confirmation_attendue} » pour confirmer."
            )
        return confirmation


class FormulaireSuppressionEcole(FormulaireConfirmationCompte):
    def __init__(self, utilisateur, ecole, *args, **kwargs):
        self.ecole = ecole
        super().__init__(utilisateur, ecole.slug, *args, **kwargs)
        self.fields["confirmation"].label = (
            f"Saisissez l'identifiant {ecole.slug} pour confirmer"
        )


from django.contrib.auth.forms import PasswordChangeForm

class FormulaireChangementMotDePasse(PasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        attrs = {"class": "form-control", "autocomplete": "current-password"}
        self.fields["old_password"].widget.attrs.update(attrs)
        attrs_new = {"class": "form-control", "autocomplete": "new-password"}
        self.fields["new_password1"].widget.attrs.update(attrs_new)
        self.fields["new_password2"].widget.attrs.update(attrs_new)


class FormulaireReinitialisationMotDePasse(PasswordResetForm):
    def get_users(self, email):
        utilisateurs_actifs = Utilisateur.objects.filter(
            email__iexact=email,
            est_actif=True,
        )
        return (
            utilisateur
            for utilisateur in utilisateurs_actifs
            if utilisateur.has_usable_password()
        )

    def save(self, *args, extra_email_context=None, **kwargs):
        from apps.etablissements.models import ConfigurationSite

        extra_email_context = dict(extra_email_context or {})
        extra_email_context["configuration_site"] = (
            ConfigurationSite.objects.filter(pk=1).first()
        )
        return super().save(
            *args,
            extra_email_context=extra_email_context,
            **kwargs,
        )