import os
import tempfile
from datetime import timedelta

from django.core import mail
from django.core.files.base import ContentFile
from django.contrib import admin
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from axes.models import AccessAttempt, AccessLog

from apps.comptes.forms import (
    FormulaireCreationCompte,
    FormulairePreferences,
)
from apps.comptes.models import Utilisateur
from apps.etablissements.models import Abonnement, Etablissement, PlanAbonnement
from apps.parametrage.models import CycleEnseignement, Niveau


@override_settings(
    EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class GestionMotDePasseTests(TestCase):
    def setUp(self):
        self.email = "responsable@example.com"
        self.user = Utilisateur.objects.create_user(
            email=self.email,
            password="AncienMotDePasse!246",
            nom="Responsable",
            prenom="École",
        )

    def test_password_reset_email_and_confirmation_change_password(self):
        response = self.client.post(
            reverse("comptes:password_reset"),
            {"email": self.email},
        )

        self.assertRedirects(
            response,
            reverse("comptes:password_reset_done"),
        )
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn(self.email, mail.outbox[0].to)

        reset_path = mail.outbox[0].body.split(
            "http://testserver", maxsplit=1
        )[1].splitlines()[0]
        confirm_response = self.client.get(reset_path, follow=True)
        self.assertEqual(confirm_response.status_code, 200)
        self.assertContains(confirm_response, "Choisir un nouveau mot de passe")
        self.assertContains(confirm_response, 'src="/static/images/logo.png"')
        confirm_path = confirm_response.request["PATH_INFO"]

        response = self.client.post(
            confirm_path,
            {
                "new_password1": "NouveauMotDePasse!975",
                "new_password2": "NouveauMotDePasse!975",
            },
        )

        self.assertRedirects(
            response,
            reverse("comptes:password_reset_complete"),
        )
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password("NouveauMotDePasse!975"))
        self.assertFalse(self.user.check_password("AncienMotDePasse!246"))

    def test_unknown_email_receives_same_confirmation_without_sending_email(self):
        response = self.client.post(
            reverse("comptes:password_reset"),
            {"email": "inconnu@example.com"},
        )

        self.assertRedirects(
            response,
            reverse("comptes:password_reset_done"),
        )
        self.assertEqual(len(mail.outbox), 0)

    def test_inactive_account_does_not_receive_reset_email(self):
        self.user.est_actif = False
        self.user.save(update_fields=["est_actif"])

        response = self.client.post(
            reverse("comptes:password_reset"),
            {"email": self.email},
        )

        self.assertRedirects(
            response,
            reverse("comptes:password_reset_done"),
        )
        self.assertEqual(len(mail.outbox), 0)

    def test_registration_applies_configured_password_validators(self):
        form = FormulaireCreationCompte(
            data={
                "email": "nouveau@example.com",
                "nom": "Utilisateur",
                "prenom": "Nouveau",
                "telephone": "",
                "mot_de_passe": "password123",
                "confirmer_mot_de_passe": "password123",
            }
        )

        self.assertFalse(form.is_valid())
        self.assertIn("mot_de_passe", form.errors)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ProfilTests(TestCase):
    def setUp(self):
        self.user = Utilisateur.objects.create_user(
            email="profil@example.com",
            password="AncienMotDePasse!246",
            nom="Nelson",
            prenom="Baouly",
            langue_preferee="cr",
        )
        self.client.force_login(self.user)

    def test_page_de_connexion_affiche_le_logo_officiel(self):
        self.client.logout()

        response = self.client.get(reverse("comptes:connexion"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'src="/static/images/logo.png"')

    def test_profil_affiche_les_onglets_et_le_formulaire(self):
        response = self.client.get(reverse("comptes:profil"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'data-profile-tab="ecoles"')
        self.assertContains(response, "Informations personnelles")

    def test_page_changement_mot_de_passe_affiche_le_formulaire_revu(self):
        response = self.client.get(reverse("comptes:changer_mot_de_passe"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "page-password-change")
        self.assertContains(response, "SÉCURITÉ DU COMPTE")
        self.assertContains(response, "Enregistrer le nouveau mot de passe")
        self.assertContains(response, 'href="/static/css/password_change.css?v=2"')

    def test_raccourci_admin_est_visible_uniquement_au_superuser(self):
        response = self.client.get(reverse("comptes:profil"))
        self.assertNotContains(response, 'class="profile-admin-button"')

        self.user.is_superuser = True
        self.user.save(update_fields=["is_superuser"])

        response = self.client.get(reverse("comptes:profil"))

        self.assertContains(response, 'class="profile-admin-button"')
        self.assertContains(response, 'href="/django-admin/"')

    def test_accueil_public_affiche_la_photo_du_compte_connecte(self):
        with tempfile.TemporaryDirectory() as media_root:
            with override_settings(MEDIA_ROOT=media_root):
                self.user.photo.save("photo-profil.png", ContentFile(b"photo"), save=True)

                response = self.client.get(reverse("saas:accueil"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'<img src="{self.user.photo.url}" alt="">')
        self.assertContains(
            response,
            'class="site-brand-logo" src="/static/images/logo.png" alt=""',
            count=2,
        )
        self.assertNotContains(response, 'class="bi bi-person"')

    def test_confirmation_deconnexion_affiche_annulation_et_confirmation(self):
        response = self.client.get(reverse("comptes:deconnexion"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Vous partez déjà")
        self.assertContains(response, reverse("comptes:profil"))
        self.assertContains(
            response,
            'class="site-brand-logo" src="/static/images/logo.png" alt=""',
        )
        self.assertContains(response, 'name="csrfmiddlewaretoken"')

    def test_confirmation_deconnexion_ferme_la_session_apres_post(self):
        response = self.client.post(reverse("comptes:deconnexion"))

        self.assertRedirects(response, reverse("comptes:connexion"))
        self.assertNotIn("_auth_user_id", self.client.session)


    def test_profil_met_a_jour_les_informations_personnelles(self):
        response = self.client.post(
            reverse("comptes:profil"),
            {
                "nom": "Nelson",
                "prenom": "Baouly",
                "telephone": "+509 0000-0000",
                "action": "profil",
            },
        )

        self.assertRedirects(
            response,
            f"{reverse('comptes:profil')}#tab-profil",
        )
        self.user.refresh_from_db()
        self.assertEqual(self.user.telephone, "+509 0000-0000")

    def test_preferences_met_a_jour_langue_et_fuseau_horaire(self):
        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "preferences",
                "langue_preferee": "fr",
                "fuseau_horaire": "UTC",
            },
        )

        self.assertRedirects(
            response,
            f"{reverse('comptes:profil')}#tab-preferences",
        )
        self.user.refresh_from_db()
        self.assertEqual(self.user.langue_preferee, "fr")
        self.assertEqual(self.user.fuseau_horaire, "UTC")

    def test_langue_existante_est_proposee_dans_le_formulaire_preferences(self):
        form = FormulairePreferences(instance=self.user)

        self.assertIn(("cr", "Kreyòl ayisyen"), form.fields["langue_preferee"].choices)
        self.assertEqual(
            sum(
                label == "Kreyòl ayisyen"
                for _, label in form.fields["langue_preferee"].choices
            ),
            1,
        )

    def test_fuseau_horaire_existant_est_conserve_dans_les_choix(self):
        self.user.fuseau_horaire = "America/Santo_Domingo"
        form = FormulairePreferences(instance=self.user)

        self.assertIn(
            ("America/Santo_Domingo", "Autre (America/Santo_Domingo)"),
            form.fields["fuseau_horaire"].choices,
        )

    def test_liste_ecoles_affiche_le_nombre_et_les_ecoles_du_compte(self):
        Etablissement.objects.create(
            slug="ecole-profil",
            nom="École du profil",
            ville="Port-au-Prince",
            cree_par=self.user,
        )

        response = self.client.get(reverse("comptes:profil"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["nombre_ecoles"], 1)
        self.assertContains(response, "École du profil")

    def test_profil_distingue_statut_ecole_et_abonnement_et_bloque_leur_acces(self):
        ecole = Etablissement.objects.create(
            slug="ecole-statut-profil",
            nom="École statut profil",
            ville="Port-au-Prince",
            cree_par=self.user,
        )
        plan = PlanAbonnement.objects.create(
            code="ESSAI-PROFIL",
            libelle="Essai",
            prix_mensuel_htg=0,
            prix_annuel_htg=0,
        )
        abonnement = Abonnement.objects.create(
            etablissement=ecole,
            plan=plan,
            date_debut=timezone.localdate(),
            en_periode_essai=True,
            date_fin_essai=timezone.localdate() + timedelta(days=5),
        )

        response = self.client.get(reverse("comptes:profil"))
        self.assertContains(response, "Établissement : actif")
        self.assertContains(response, "Abonnement : actif")
        self.assertContains(response, "Ouvrir")
        self.assertTrue(response.context["ecoles_compte"][0]["acces_autorise"])

        ecole.est_actif = False
        ecole.save(update_fields=["est_actif"])
        response = self.client.get(reverse("comptes:profil"))

        self.assertContains(response, "Établissement : inactif")
        self.assertContains(response, "Abonnement : actif")
        self.assertContains(response, "Établissement désactivé par l’administrateur.")
        self.assertNotContains(response, "Ouvrir")
        self.assertFalse(response.context["ecoles_compte"][0]["acces_autorise"])

        ecole.est_actif = True
        ecole.save(update_fields=["est_actif"])
        abonnement.est_actif = False
        abonnement.save(update_fields=["est_actif"])
        response = self.client.get(reverse("comptes:profil"))

        self.assertContains(response, "Établissement : actif")
        self.assertContains(response, "Abonnement : inactif")
        self.assertContains(response, "Abonnement inactif")
        self.assertFalse(response.context["ecoles_compte"][0]["acces_autorise"])

    def test_proprietaire_peut_supprimer_une_ecole_et_ses_donnees_protegees(self):
        ecole = Etablissement.objects.create(
            slug="ecole-supprimee",
            nom="École supprimée",
            ville="Jacmel",
            cree_par=self.user,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=ecole,
            cycle=cycle,
            code="1AF",
            libelle="1re année fondamentale",
        )

        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "supprimer_ecole",
                "ecole_id": str(ecole.pk),
                "mot_de_passe": "AncienMotDePasse!246",
                "confirmation": ecole.slug,
            },
        )

        self.assertRedirects(
            response,
            f"{reverse('comptes:profil')}#tab-ecoles",
        )
        self.assertFalse(Etablissement.objects.filter(pk=ecole.pk).exists())
        self.assertFalse(CycleEnseignement.tous_objets.filter(pk=cycle.pk).exists())
        self.assertFalse(Niveau.tous_objets.filter(pk=niveau.pk).exists())

    def test_suppression_ecole_refuse_une_confirmation_inexacte(self):
        ecole = Etablissement.objects.create(
            slug="ecole-confirmation",
            nom="École confirmation",
            ville="Jacmel",
            cree_par=self.user,
        )

        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "supprimer_ecole",
                "ecole_id": str(ecole.pk),
                "mot_de_passe": "AncienMotDePasse!246",
                "confirmation": "mauvais-slug",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(Etablissement.objects.filter(pk=ecole.pk).exists())
        self.assertContains(response, "Saisissez exactement")

    def test_suppression_ecole_nettoie_son_logo_apres_commit(self):
        ecole = Etablissement.objects.create(
            slug="ecole-avec-logo",
            nom="École avec logo",
            ville="Jacmel",
            cree_par=self.user,
        )

        with tempfile.TemporaryDirectory() as media_root:
            with override_settings(MEDIA_ROOT=media_root):
                ecole.logo.save("logo.png", ContentFile(b"logo"), save=True)
                chemin_logo = ecole.logo.path

                with self.captureOnCommitCallbacks(execute=True):
                    response = self.client.post(
                        reverse("comptes:profil"),
                        {
                            "action": "supprimer_ecole",
                            "ecole_id": str(ecole.pk),
                            "mot_de_passe": "AncienMotDePasse!246",
                            "confirmation": ecole.slug,
                        },
                    )

                self.assertRedirects(
                    response,
                    f"{reverse('comptes:profil')}#tab-ecoles",
                )
                self.assertFalse(os.path.exists(chemin_logo))

    def test_suppression_ecole_est_bloquee_par_une_donnee_dune_autre_ecole(self):
        ecole_cible = Etablissement.objects.create(
            slug="ecole-cible",
            nom="École cible",
            ville="Jacmel",
            cree_par=self.user,
        )
        autre_proprietaire = Utilisateur.objects.create_user(
            email="autre-ecole@example.com",
            nom="Propriétaire",
            prenom="Autre",
        )
        autre_ecole = Etablissement.objects.create(
            slug="autre-ecole",
            nom="Autre école",
            ville="Port-au-Prince",
            cree_par=autre_proprietaire,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=ecole_cible,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=autre_ecole,
            cycle=cycle,
            code="1AF",
            libelle="1re année fondamentale",
        )

        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "supprimer_ecole",
                "ecole_id": str(ecole_cible.pk),
                "mot_de_passe": "AncienMotDePasse!246",
                "confirmation": ecole_cible.slug,
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "données liées à un autre compte")
        self.assertTrue(Etablissement.objects.filter(pk=ecole_cible.pk).exists())
        self.assertTrue(Etablissement.objects.filter(pk=autre_ecole.pk).exists())
        self.assertTrue(CycleEnseignement.tous_objets.filter(pk=cycle.pk).exists())
        self.assertTrue(Niveau.tous_objets.filter(pk=niveau.pk).exists())

    def test_membre_ne_peut_pas_supprimer_une_ecole_dont_il_nest_pas_proprietaire(self):
        autre_proprietaire = Utilisateur.objects.create_user(
            email="autre-proprietaire@example.com",
            password="AutreMotDePasse!246",
            nom="Propriétaire",
            prenom="Autre",
        )
        ecole = Etablissement.objects.create(
            slug="ecole-autre-proprietaire",
            nom="École d'un autre propriétaire",
            ville="Jacmel",
            cree_par=autre_proprietaire,
        )

        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "supprimer_ecole",
                "ecole_id": str(ecole.pk),
                "mot_de_passe": "AncienMotDePasse!246",
                "confirmation": ecole.slug,
            },
        )

        self.assertEqual(response.status_code, 404)
        self.assertTrue(Etablissement.objects.filter(pk=ecole.pk).exists())

    def test_desactivation_compte_exige_mot_de_passe_et_confirmation(self):
        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "desactiver",
                "mot_de_passe": "AncienMotDePasse!246",
                "confirmation": "DESACTIVER",
            },
        )

        self.assertRedirects(response, reverse("comptes:connexion"))
        self.user.refresh_from_db()
        self.assertFalse(self.user.est_actif)

    def test_suppression_compte_supprime_les_ecoles_dont_il_est_proprietaire(self):
        ecole = Etablissement.objects.create(
            slug="ecole-a-supprimer",
            nom="École à supprimer",
            ville="Jacmel",
            cree_par=self.user,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=ecole,
            cycle=cycle,
            code="1AF",
            libelle="1re année fondamentale",
        )

        response = self.client.post(
            reverse("comptes:profil"),
            {
                "action": "supprimer",
                "mot_de_passe": "AncienMotDePasse!246",
                "confirmation": "SUPPRIMER",
            },
        )

        self.assertRedirects(response, reverse("comptes:connexion"))
        self.assertFalse(Etablissement.objects.filter(pk=ecole.pk).exists())
        self.assertFalse(CycleEnseignement.tous_objets.filter(pk=cycle.pk).exists())
        self.assertFalse(Niveau.tous_objets.filter(pk=niveau.pk).exists())
        self.assertFalse(Utilisateur.objects.filter(pk=self.user.pk).exists())


@override_settings(
    AXES_FAILURE_LIMIT=2,
    AXES_COOLOFF_TIME=timedelta(hours=1),
    AXES_LOCKOUT_PARAMETERS=[["username", "ip_address"]],
    AXES_RESET_ON_SUCCESS=True,
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class VerrouillageConnexionTests(TestCase):
    def test_un_compte_actif_peut_se_connecter(self):
        utilisateur = Utilisateur.objects.create_user(
            email="compte-actif@example.com",
            password="MotDePasseValide!2026",
            nom="Compte",
            prenom="Actif",
        )

        response = self.client.post(
            reverse("comptes:connexion"),
            {
                "username": utilisateur.email,
                "password": "MotDePasseValide!2026",
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            self.client.session["_auth_user_id"],
            str(utilisateur.pk),
        )

    def test_un_compte_desactive_ne_peut_pas_se_connecter(self):
        utilisateur = Utilisateur.objects.create_user(
            email="compte-desactive@example.com",
            password="MotDePasseValide!2026",
            nom="Compte",
            prenom="Désactivé",
            est_actif=False,
        )

        response = self.client.post(
            reverse("comptes:connexion"),
            {
                "username": utilisateur.email,
                "password": "MotDePasseValide!2026",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_limite_de_tentatives_affiche_le_message_sans_erreur_serveur(self):
        url_connexion = reverse("comptes:connexion")
        autre_utilisateur = Utilisateur.objects.create_user(
            email="autre-compte@example.com",
            password="MotDePasseValide!2026",
            nom="Autre",
            prenom="Compte",
        )
        donnees = {
            "username": "tentatives@example.com",
            "password": "mot-de-passe-incorrect",
        }

        premiere_tentative = self.client.post(url_connexion, donnees)
        self.assertEqual(premiere_tentative.status_code, 200)

        tentative_bloquee = self.client.post(url_connexion, donnees)
        self.assertEqual(tentative_bloquee.status_code, 403)
        self.assertContains(
            tentative_bloquee,
            "Trop de tentatives de connexion. Réessayez plus tard.",
            status_code=403,
        )

        connexion_autre_compte = self.client.post(
            url_connexion,
            {
                "username": autre_utilisateur.email,
                "password": "MotDePasseValide!2026",
            },
        )
        self.assertEqual(connexion_autre_compte.status_code, 302)
        self.assertEqual(
            self.client.session["_auth_user_id"],
            str(autre_utilisateur.pk),
        )


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class JournalAccesAdminTests(TestCase):
    def test_journal_axes_souvre_sans_decoupage_chronologique(self):
        administrateur = Utilisateur.objects.create_superuser(
            email="admin-axes@example.com",
            password="MotDePasseValide!2026",
            nom="Admin",
            prenom="Axes",
        )
        self.client.force_login(administrateur)

        response = self.client.get(reverse("admin:axes_accesslog_changelist"))

        self.assertEqual(response.status_code, 200)
        self.assertIsNone(admin.site._registry[AccessLog].date_hierarchy)

    def test_tentatives_axes_souvrent_sans_decoupage_chronologique(self):
        administrateur = Utilisateur.objects.create_superuser(
            email="admin-attempts@example.com",
            password="MotDePasseValide!2026",
            nom="Admin",
            prenom="Tentatives",
        )
        self.client.force_login(administrateur)

        response = self.client.get(reverse("admin:axes_accessattempt_changelist"))

        self.assertEqual(response.status_code, 200)
        self.assertIsNone(admin.site._registry[AccessAttempt].date_hierarchy)

    def test_action_debloque_uniquement_les_combinaisons_email_ip_selectionnees(self):
        administrateur = Utilisateur.objects.create_superuser(
            email="admin-reset-attempts@example.com",
            password="MotDePasseValide!2026",
            nom="Admin",
            prenom="Réinitialisation",
        )
        self.client.force_login(administrateur)
        tentative_selectionnee = AccessAttempt.objects.create(
            user_agent="Chrome",
            ip_address="192.0.2.10",
            username="bloque@example.com",
            http_accept="text/html",
            path_info="/comptes/connexion/",
            get_data="",
            post_data="",
            failures_since_start=5,
        )
        meme_combinaison = AccessAttempt.objects.create(
            user_agent="Firefox",
            ip_address="192.0.2.10",
            username="bloque@example.com",
            http_accept="text/html",
            path_info="/comptes/connexion/",
            get_data="",
            post_data="",
            failures_since_start=1,
        )
        autre_compte = AccessAttempt.objects.create(
            user_agent="Chrome",
            ip_address="192.0.2.10",
            username="autre@example.com",
            http_accept="text/html",
            path_info="/comptes/connexion/",
            get_data="",
            post_data="",
            failures_since_start=1,
        )
        autre_ip = AccessAttempt.objects.create(
            user_agent="Chrome",
            ip_address="192.0.2.11",
            username="bloque@example.com",
            http_accept="text/html",
            path_info="/comptes/connexion/",
            get_data="",
            post_data="",
            failures_since_start=1,
        )

        response = self.client.post(
            reverse("admin:axes_accessattempt_changelist"),
            {
                "action": "debloquer_comptes_selectionnes",
                "_selected_action": [str(tentative_selectionnee.pk)],
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertFalse(
            AccessAttempt.objects.filter(
                pk__in=[tentative_selectionnee.pk, meme_combinaison.pk]
            ).exists()
        )
        self.assertTrue(AccessAttempt.objects.filter(pk=autre_compte.pk).exists())
        self.assertTrue(AccessAttempt.objects.filter(pk=autre_ip.pk).exists())
        self.assertContains(
            self.client.get(reverse("admin:axes_accessattempt_changelist")),
            "tentative(s) réinitialisée(s)",
        )
