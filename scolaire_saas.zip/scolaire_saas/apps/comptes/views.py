"""Vues d'authentification."""
from django.contrib.auth import login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.db.models.deletion import ProtectedError
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib import messages
from django.urls import reverse
from django.utils import timezone
from apps.comptes.forms import (
    FormulaireConfirmationCompte,
    FormulaireConnexion,
    FormulairePreferences,
    FormulaireProfil,
    FormulaireSuppressionEcole,
)

from apps.comptes.forms import FormulaireChangementMotDePasse  # ← en haut du fichier

def connexion(request):
    """Page de connexion multitenant."""
    if request.user.is_authenticated:
        return redirect("tableau_bord:index")

    if request.method == "POST":
        form = FormulaireConnexion(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            user.enregistrer_connexion()

            # ── Résolution du tenant ──────────────────────────────────────
            # Écrire le slug en session s'il n'est pas déjà là
            if not request.session.get("tenant_slug"):
                slug = _resoudre_slug_depuis_user(user)
                if slug:
                    request.session["tenant_slug"] = slug
            # ─────────────────────────────────────────────────────────────

            next_url = request.GET.get("next", "")
            if next_url:
                return redirect(next_url)
            if request.session.get("tenant_slug"):
                return redirect("tableau_bord:index")
            return redirect("saas:tableau_bord")  # propriétaire sans école encore

        messages.error(request, "Email ou mot de passe incorrect.")
    else:
        form = FormulaireConnexion()
    return render(request, "comptes/connexion.html", {"form": form})


def _resoudre_slug_depuis_user(user) -> str | None:
    """
    Trouve le slug de l'école liée à cet utilisateur.
    Adapte selon la relation réelle dans ton modèle.
    """
    # Cas 1 : ForeignKey direct sur le User  (user.ecole ou user.etablissement)
    ecole = getattr(user, "ecole", None) or getattr(user, "etablissement", None)
    if ecole:
        return getattr(ecole, "slug", None)

    # Cas 2 : L'école a un champ proprietaire → user
    try:
        from apps.etablissements.models import Etablissement
        ecole = Etablissement.objects.filter(
            proprietaire=user, est_actif=True
        ).first()
        if ecole:
            return ecole.slug
    except Exception:
        pass

    return None

def deconnexion(request):
    if request.method == "POST":
        logout(request)
        return redirect("comptes:connexion")
    return render(request, "comptes/deconnexion_confirm.html")

@login_required
def profil(request):
    from apps.etablissements.models import Etablissement

    onglet_actif = request.GET.get("onglet", "profil")
    form_suppression_ecole = None
    form_profil = FormulaireProfil(instance=request.user)
    form_preferences = FormulairePreferences(instance=request.user)
    form_desactivation = FormulaireConfirmationCompte(
        request.user,
        "DESACTIVER",
    )
    form_suppression = FormulaireConfirmationCompte(
        request.user,
        "SUPPRIMER",
    )

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "profil":
            onglet_actif = "profil"
            form_profil = FormulaireProfil(
                request.POST,
                request.FILES,
                instance=request.user,
            )
            if form_profil.is_valid():
                form_profil.save()
                messages.success(request, "Profil mis à jour.")
                return redirect(f"{reverse('comptes:profil')}#tab-profil")
        elif action == "preferences":
            onglet_actif = "preferences"
            form_preferences = FormulairePreferences(
                request.POST,
                instance=request.user,
            )
            if form_preferences.is_valid():
                form_preferences.save()
                messages.success(request, "Préférences enregistrées.")
                return redirect(f"{reverse('comptes:profil')}#tab-preferences")
        elif action == "desactiver":
            onglet_actif = "compte"
            form_desactivation = FormulaireConfirmationCompte(
                request.user,
                "DESACTIVER",
                request.POST,
            )
            if form_desactivation.is_valid():
                utilisateur = request.user
                utilisateur.est_actif = False
                utilisateur.save(update_fields=["est_actif"])
                logout(request)
                messages.success(
                    request,
                    "Votre compte a été désactivé. Contactez un administrateur pour le réactiver.",
                )
                return redirect("comptes:connexion")
        elif action == "supprimer":
            onglet_actif = "compte"
            form_suppression = FormulaireConfirmationCompte(
                request.user,
                "SUPPRIMER",
                request.POST,
            )
            if form_suppression.is_valid():
                utilisateur = request.user
                if utilisateur.is_superuser:
                    form_suppression.add_error(
                        None,
                        "Un compte administrateur ne peut pas être supprimé depuis cette page.",
                    )
                else:
                    from apps.etablissements.services import (
                        SuppressionEtablissementBloquee,
                        supprimer_ecole_definitivement,
                    )

                    try:
                        with transaction.atomic():
                            for ecole in Etablissement.objects.filter(
                                cree_par=utilisateur
                            ):
                                supprimer_ecole_definitivement(ecole)
                            utilisateur.delete()
                    except (ProtectedError, SuppressionEtablissementBloquee):
                        form_suppression.add_error(
                            None,
                            "La suppression est bloquée par des données liées. "
                            "Contactez un administrateur pour finaliser leur transfert.",
                        )
                    else:
                        logout(request)
                        messages.success(
                            request,
                            "Votre compte et les écoles dont vous étiez propriétaire ont été supprimés.",
                        )
                        return redirect("comptes:connexion")
        elif action == "supprimer_ecole":
            onglet_actif = "ecoles"
            ecole = get_object_or_404(
                Etablissement,
                pk=request.POST.get("ecole_id"),
                cree_par=request.user,
            )
            form_suppression_ecole = FormulaireSuppressionEcole(
                request.user,
                ecole,
                request.POST,
            )
            if form_suppression_ecole.is_valid():
                from apps.etablissements.services import (
                    SuppressionEtablissementBloquee,
                    supprimer_ecole_definitivement,
                )

                try:
                    supprimer_ecole_definitivement(ecole)
                except SuppressionEtablissementBloquee:
                    form_suppression_ecole.add_error(
                        None,
                        "La suppression est bloquée car des données liées à un autre "
                        "compte ou établissement ont été détectées. Contactez un administrateur.",
                    )
                else:
                    messages.success(
                        request,
                        f"L'école « {ecole.nom} » et ses données ont été supprimées.",
                    )
                    return redirect(f"{reverse('comptes:profil')}#tab-ecoles")
    from apps.securite.models import UtilisateurRole

    roles_ecoles = UtilisateurRole.tous_objets.filter(
        utilisateur=request.user,
        est_actif=True,
    ).filter(
        Q(expire_le__isnull=True)
        | Q(expire_le__gte=timezone.localdate())
    ).select_related("role")
    ecoles_proprietaire = Etablissement.objects.filter(cree_par=request.user)
    ecoles = (
        Etablissement.objects.filter(
            Q(cree_par=request.user)
            | Q(pk__in=roles_ecoles.values("ecole_id"))
        )
        .select_related("abonnement_actif__plan")
        .distinct()
    )
    roles_par_ecole = {}
    for role_ecole in roles_ecoles:
        roles_par_ecole.setdefault(role_ecole.ecole_id, []).append(
            role_ecole.role.libelle
        )
    ecoles_compte = []
    for ecole in ecoles:
        abonnement = getattr(ecole, "abonnement_actif", None)
        essai_expire = (
            abonnement.expirer_essai_si_necessaire()
            if abonnement else False
        )
        if essai_expire:
            ecole.refresh_from_db(fields=["est_actif"])
        abonnement_actif = abonnement.est_actif if abonnement else False
        acces_autorise = ecole.est_actif and (
            abonnement is None or abonnement_actif
        )
        if essai_expire:
            motif_blocage = "La période d’essai est terminée."
        elif not ecole.est_actif:
            motif_blocage = "Établissement désactivé par l’administrateur."
        elif abonnement and not abonnement_actif:
            motif_blocage = "Abonnement inactif : contactez l’administrateur."
        else:
            motif_blocage = ""
        ecoles_compte.append({
            "ecole": ecole,
            "roles": roles_par_ecole.get(ecole.pk, []),
            "proprietaire": ecole.cree_par_id == request.user.pk,
            "plan": abonnement.plan.libelle if abonnement else "",
            "abonnement": abonnement,
            "abonnement_actif": abonnement_actif,
            "acces_autorise": acces_autorise,
            "motif_blocage": motif_blocage,
            "form_suppression": (
                form_suppression_ecole
                if form_suppression_ecole is not None
                and str(ecole.pk) == request.POST.get("ecole_id")
                else FormulaireSuppressionEcole(request.user, ecole)
            ) if ecole.cree_par_id == request.user.pk else None,
        })

    return render(
        request,
        "comptes/profil.html",
        {
            "form_profil": form_profil,
            "form_preferences": form_preferences,
            "form_desactivation": form_desactivation,
            "form_suppression": form_suppression,
            "onglet_actif": onglet_actif,
            "ecoles_compte": ecoles_compte,
            "nombre_ecoles": len(ecoles_compte),
            "nombre_ecoles_proprietaire": ecoles_proprietaire.count(),
        },
    )



@login_required
def changer_mot_de_passe(request):
    if request.method == "POST":
        form = FormulaireChangementMotDePasse(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, "Mot de passe modifié avec succès.")
            return redirect("comptes:profil")
    else:
        form = FormulaireChangementMotDePasse(request.user)
    return render(request, "comptes/changer_mot_de_passe.html", {"form": form})
