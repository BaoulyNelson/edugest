"""
apps/comptes/models.py
======================
Modèle Utilisateur personnalisé remplaçant django.contrib.auth.User.
Un utilisateur peut appartenir à plusieurs établissements avec des rôles différents.
"""

import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils import timezone
from apps.noyau.mixins import ContactUniqueMixin, HorodatageMixin, UUIDPrimaryKeyMixin


class GestionnaireUtilisateur(BaseUserManager):
    """Manager personnalisé : email comme identifiant principal (pas username)."""

    def create_user(self, email: str, password: str = None, **champs_extras):
        if not email:
            raise ValueError("L'adresse email est obligatoire.")
        email = self.normalize_email(email)
        utilisateur = self.model(email=email, **champs_extras)
        utilisateur.set_password(password)
        utilisateur.save(using=self._db)
        return utilisateur

    def create_superuser(self, email: str, password: str, **champs_extras):
        champs_extras.setdefault("is_staff", True)
        champs_extras.setdefault("is_superuser", True)
        champs_extras.setdefault("est_actif", True)
        return self.create_user(email, password, **champs_extras)


class Utilisateur(
    ContactUniqueMixin,
    UUIDPrimaryKeyMixin,
    AbstractBaseUser,
    PermissionsMixin,
    HorodatageMixin,
):
    """
    Utilisateur du système SaaS.
    L'email est l'identifiant de connexion — pas de username.
    L'appartenance à un établissement est gérée par UtilisateurRole (M2M via securite).

    Un utilisateur SaaS peut :
    - Posséder plusieurs établissements (directeur multi-écoles)
    - Avoir des rôles différents dans des écoles différentes
    - Être désactivé sans suppression (est_actif = False)
    """
    email = models.EmailField(
        unique=True,
        verbose_name="Adresse email",
        help_text="Identifiant de connexion unique.",
    )
    nom = models.CharField(max_length=100, verbose_name="Nom")
    prenom = models.CharField(max_length=100, verbose_name="Prénom")
    telephone = models.CharField(max_length=20, blank=True, verbose_name="Téléphone")
    photo = models.ImageField(
        upload_to="utilisateurs/photos/%Y/",
        null=True,
        blank=True,
        verbose_name="Photo de profil",
    )

    # Flags Django requis
    is_staff = models.BooleanField(
        default=False,
        verbose_name="Accès administration Django",
    )
    est_actif = models.BooleanField(
        default=True,
        db_index=True,
        verbose_name="Compte actif",
    )
    date_derniere_connexion = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Dernière connexion",
    )

    # Métadonnées SaaS
    est_proprietaire_saas = models.BooleanField(
        default=False,
        help_text="True si cet utilisateur a créé au moins un établissement SaaS.",
    )
    langue_preferee = models.CharField(max_length=5, default="fr")
    fuseau_horaire = models.CharField(max_length=50, default="America/Port-au-Prince")

    # Obligatoire pour AbstractBaseUser
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["nom", "prenom"]

    objects = GestionnaireUtilisateur()

    class Meta:
        verbose_name = "Utilisateur"
        verbose_name_plural = "Utilisateurs"
        ordering = ["nom", "prenom"]

    def __str__(self):
        return f"{self.prenom} {self.nom} <{self.email}>"

    @property
    def nom_complet(self) -> str:
        return f"{self.prenom} {self.nom}".strip()

    def enregistrer_connexion(self) -> None:
        """Met à jour la date de dernière connexion."""
        self.date_derniere_connexion = timezone.now()
        self.save(update_fields=["date_derniere_connexion"])

    def obtenir_etablissements(self):
        """Retourne tous les établissements où cet utilisateur a un rôle actif."""
        from apps.securite.models import UtilisateurRole
        return (
            UtilisateurRole.tous_objets
            .filter(utilisateur=self, est_actif=True)
            .select_related("ecole")
            .values_list("ecole", flat=True)
        )