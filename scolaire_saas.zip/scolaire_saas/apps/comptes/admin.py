from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib import messages
from axes.admin import AccessAttemptAdmin as AxesAccessAttemptAdmin
from axes.admin import AccessLogAdmin as AxesAccessLogAdmin
from axes.models import AccessAttempt, AccessLog
from axes.utils import reset as axes_reset
from apps.comptes.models import Utilisateur


admin.site.unregister(AccessAttempt)
admin.site.unregister(AccessLog)


@admin.register(AccessAttempt)
class AccessAttemptAdmin(AxesAccessAttemptAdmin):
    date_hierarchy = None
    actions = ["debloquer_comptes_selectionnes"]

    @admin.action(description="Débloquer les comptes sélectionnés (e-mail + IP)")
    def debloquer_comptes_selectionnes(self, request, queryset):
        combinaisons = set(
            queryset.values_list("username", "ip_address").distinct()
        )
        nombre_reinitialise = 0
        nombre_ignore = 0

        for username, ip_address in combinaisons:
            if not username or not ip_address:
                nombre_ignore += 1
                continue
            nombre_reinitialise += axes_reset(ip=ip_address, username=username)

        self.message_user(
            request,
            f"{nombre_reinitialise} tentative(s) réinitialisée(s) "
            "pour les combinaisons e-mail et adresse IP sélectionnées.",
            level=messages.SUCCESS,
        )
        if nombre_ignore:
            self.message_user(
                request,
                f"{nombre_ignore} combinaison(s) ignorée(s), car l’e-mail "
                "ou l’adresse IP était manquant(e).",
                level=messages.WARNING,
            )


@admin.register(AccessLog)
class AccessLogAdmin(AxesAccessLogAdmin):
    date_hierarchy = None


@admin.register(Utilisateur)
class UtilisateurAdmin(UserAdmin):
    list_display = ["email", "nom", "prenom", "est_actif", "is_staff", "cree_le"]
    list_filter = ["est_actif", "is_staff", "is_superuser"]
    search_fields = ["email", "nom", "prenom"]
    ordering = ["nom", "prenom"]
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Informations personnelles", {"fields": ("nom", "prenom", "telephone", "photo")}),
        ("Permissions", {"fields": ("est_actif", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Dates", {"fields": ("last_login", "cree_le", "modifie_le")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "nom", "prenom", "password1", "password2")}),
    )
    readonly_fields = ["cree_le", "modifie_le", "last_login"]
    USERNAME_FIELD = "email"
