"""Types de frais recommandés selon le profil de l’établissement."""

from decimal import Decimal
import unicodedata

from django.db import transaction
from apps.etablissements.models import TypeEtablissement
from apps.finances.models import FrequenceFrais, TypeFrais


FRAIS_COMMUNS = (
    {
        "code": "INSCR",
        "libelle": "Frais d’inscription",
        "frequence": FrequenceFrais.UNIQUE,
        "est_obligatoire": True,
        "ordre_affichage": 1,
    },
    {
        "code": "SCOLARITE",
        "libelle": "Frais de scolarité",
        "frequence": FrequenceFrais.MENSUEL,
        "est_obligatoire": True,
        "ordre_affichage": 2,
    },
)

FRAIS_PAR_TYPE = {
    TypeEtablissement.PRIMAIRE: (
        {
            "code": "CANTINE",
            "libelle": "Cantine",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 10,
        },
        {
            "code": "TRANSPORT",
            "libelle": "Transport scolaire",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 11,
        },
        {
            "code": "FOURNITURES",
            "libelle": "Fournitures scolaires",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 12,
        },
        {
            "code": "UNIFORME",
            "libelle": "Uniforme",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 13,
        },
    ),
    TypeEtablissement.SECONDAIRE: (
        {
            "code": "CANTINE",
            "libelle": "Cantine",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 10,
        },
        {
            "code": "TRANSPORT",
            "libelle": "Transport scolaire",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 11,
        },
        {
            "code": "EXAMEN",
            "libelle": "Frais d’examen",
            "frequence": FrequenceFrais.TRIMESTRIEL,
            "ordre_affichage": 12,
        },
        {
            "code": "UNIFORME",
            "libelle": "Uniforme",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 13,
        },
    ),
    TypeEtablissement.MIXTE: (
        {
            "code": "CANTINE",
            "libelle": "Cantine",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 10,
        },
        {
            "code": "TRANSPORT",
            "libelle": "Transport scolaire",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 11,
        },
        {
            "code": "FOURNITURES",
            "libelle": "Fournitures scolaires",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 12,
        },
        {
            "code": "UNIFORME",
            "libelle": "Uniforme",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 13,
        },
        {
            "code": "EXAMEN",
            "libelle": "Frais d’examen",
            "frequence": FrequenceFrais.TRIMESTRIEL,
            "ordre_affichage": 14,
        },
    ),
    TypeEtablissement.TECHNIQUE: (
        {
            "code": "ATELIER",
            "libelle": "Atelier et travaux pratiques",
            "frequence": FrequenceFrais.TRIMESTRIEL,
            "ordre_affichage": 10,
        },
        {
            "code": "MATERIEL",
            "libelle": "Matériel de formation",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 11,
        },
        {
            "code": "CERTIFICATION",
            "libelle": "Frais de certification",
            "frequence": FrequenceFrais.UNIQUE,
            "ordre_affichage": 12,
        },
        {
            "code": "TRANSPORT",
            "libelle": "Transport",
            "frequence": FrequenceFrais.MENSUEL,
            "ordre_affichage": 13,
        },
    ),
    TypeEtablissement.UNIVERSITE: (
        {
            "code": "SCOLARITE",
            "libelle": "Frais de scolarité",
            "frequence": FrequenceFrais.SEMESTRIEL,
            "est_obligatoire": True,
            "ordre_affichage": 2,
        },
        {
            "code": "LABORATOIRE",
            "libelle": "Frais de laboratoire",
            "frequence": FrequenceFrais.SEMESTRIEL,
            "ordre_affichage": 10,
        },
        {
            "code": "BIBLIOTHEQUE",
            "libelle": "Frais de bibliothèque",
            "frequence": FrequenceFrais.ANNUEL,
            "ordre_affichage": 11,
        },
        {
            "code": "CARTE",
            "libelle": "Carte étudiante",
            "frequence": FrequenceFrais.UNIQUE,
            "ordre_affichage": 12,
        },
        {
            "code": "MEMOIRE",
            "libelle": "Frais de mémoire ou de soutenance",
            "frequence": FrequenceFrais.UNIQUE,
            "ordre_affichage": 13,
        },
    ),
}


def _normaliser_libelle(valeur):
    sans_accents = unicodedata.normalize("NFKD", valeur)
    return "".join(
        caractere.casefold()
        for caractere in sans_accents
        if caractere.isalnum()
    )


@transaction.atomic
def preconfigurer_types_frais(ecole):
    """Ajoute les catégories recommandées sans écraser la configuration de l’école."""
    recommandations = {frais["code"]: frais for frais in FRAIS_COMMUNS}
    recommandations.update(
        {
            frais["code"]: frais
            for frais in FRAIS_PAR_TYPE.get(ecole.type_etablissement, ())
        }
    )
    ajoutes = 0
    types_existants = list(
        TypeFrais.tous_objets.filter(ecole=ecole).values("code", "libelle")
    )
    codes_existants = {type_frais["code"].casefold() for type_frais in types_existants}
    libelles_existants = {
        _normaliser_libelle(type_frais["libelle"]) for type_frais in types_existants
    }

    for recommandation in recommandations.values():
        code = recommandation["code"]
        libelle = recommandation["libelle"]
        if (
            code.casefold() in codes_existants
            or _normaliser_libelle(libelle) in libelles_existants
        ):
            continue

        valeurs = {
            "libelle": libelle,
            "frequence": recommandation["frequence"],
            "montant_defaut": Decimal("0.00"),
            "est_obligatoire": recommandation.get("est_obligatoire", False),
            "bloque_bulletin": False,
            "est_actif": True,
            "ordre_affichage": recommandation["ordre_affichage"],
            "description": "Modèle recommandé — définissez le montant selon les tarifs de l’établissement.",
        }
        _, cree = TypeFrais.tous_objets.get_or_create(
            ecole=ecole,
            code=code,
            defaults=valeurs,
        )
        ajoutes += int(cree)
        if cree:
            codes_existants.add(code.casefold())
            libelles_existants.add(_normaliser_libelle(libelle))

    return ajoutes
