"""
apps/finances/services.py
==========================
ServicePaiement : enregistrement, annulation, génération de reçus.
ServiceCaisse   : rapports journaliers, soldes, statistiques.
"""

from decimal import Decimal
from datetime import datetime, time, timedelta
from django.db import transaction
from django.utils import timezone
from apps.finances.models import (
    Paiement, FraisEleve, EcritureJournal,
    StatutPaiement, TypeEcritureJournal, ModePaiement
)
from apps.noyau.exceptions import RegleMetierError, DonneesInvalidesError
from apps.securite.rbac import ServiceAudit


def bornes_journee_locale(date_cible):
    debut = timezone.make_aware(datetime.combine(date_cible, time.min))
    lendemain = timezone.make_aware(
        datetime.combine(date_cible + timedelta(days=1), time.min)
    )
    return debut, lendemain


class ServicePaiement:
    """Point d'entrée unique pour tout paiement dans le système."""

    def __init__(self, utilisateur, ecole):
        self.utilisateur = utilisateur
        self.ecole = ecole
        self.audit = ServiceAudit(utilisateur)

    @transaction.atomic
    def enregistrer(
        self,
        frais_eleve: FraisEleve,
        montant: Decimal,
        mode_paiement: str = ModePaiement.ESPECES,
        reference_externe: str = "",
        observations: str = "",
        date_paiement=None,
    ) -> Paiement:
        """
        Enregistre un paiement avec toutes les gardes métier.
        Génère automatiquement le numéro de reçu.
        """
        # Garde 1 : montant positif
        if montant <= Decimal("0"):
            raise DonneesInvalidesError("Le montant doit être supérieur à zéro.")

        annee_scolaire = frais_eleve.inscription.annee_scolaire
        if not annee_scolaire.accepte_inscriptions:
            raise RegleMetierError(
                f"Impossible d’enregistrer un paiement pour l’année "
                f"{annee_scolaire.libelle} : elle n’est pas active."
            )

        # Garde 2 : ne pas sur-payer
        solde = frais_eleve.solde_restant()
        if montant > solde + Decimal("0.01"):  # tolérance d'arrondi
            raise RegleMetierError(
                f"Le montant ({montant}) dépasse le solde restant ({solde}). "
                "Paiement refusé pour éviter un trop-perçu."
            )

        # Garde 3 : frais non annulé
        if frais_eleve.inscription.statut == "annulee":
            raise RegleMetierError(
                "L'inscription associée est annulée. Paiement impossible."
            )

        numero_recu = self._generer_numero_recu()
        date_effective = date_paiement or timezone.now()

        # Déterminer le statut selon le solde couvert
        nouveau_solde = solde - montant
        if nouveau_solde <= Decimal("0.01"):
            statut = StatutPaiement.COMPLET
        else:
            statut = StatutPaiement.PARTIEL

        paiement = Paiement.objects.create(
            ecole=self.ecole,
            frais_eleve=frais_eleve,
            numero_recu=numero_recu,
            montant_paye=montant,
            mode_paiement=mode_paiement,
            reference_externe=reference_externe,
            statut=statut,
            date_paiement=date_effective,
            caissier=self.utilisateur,
            observations=observations,
        )

        # Écriture journal de caisse
        EcritureJournal.objects.create(
            ecole=self.ecole,
            paiement=paiement,
            type_ecriture=TypeEcritureJournal.ENCAISSEMENT,
            montant=montant,
            libelle=(
                f"Paiement {frais_eleve.type_frais.libelle} — "
                f"{frais_eleve.inscription.eleve.nom_complet}"
            ),
            annee_scolaire=frais_eleve.inscription.annee_scolaire,
            saisie_par=self.utilisateur,
            date_ecriture=date_effective,
        )

        self.audit.enregistrer(
            action="enregistrement_paiement",
            objet=paiement,
            donnees_apres={
                "recu": numero_recu,
                "montant": str(montant),
                "mode": mode_paiement,
                "eleve": frais_eleve.inscription.eleve.nom_complet,
            },
        )
        return paiement

    @transaction.atomic
    def annuler(self, paiement: Paiement, motif: str) -> Paiement:
        """
        Annule un paiement. Crée une écriture de journal inverse.
        INVARIANT : un paiement annulé ne peut être réannulé.
        """
        if paiement.est_annule:
            raise RegleMetierError(
                f"Le paiement #{paiement.numero_recu} est déjà annulé."
            )
        if not motif.strip():
            raise DonneesInvalidesError("Le motif d'annulation est obligatoire.")

        paiement.est_annule = True
        paiement.statut = StatutPaiement.ANNULE
        paiement.motif_annulation = motif
        paiement.annule_par = self.utilisateur
        paiement.date_annulation = timezone.now()
        paiement.save(update_fields=[
            "est_annule", "statut", "motif_annulation",
            "annule_par", "date_annulation"
        ])

        # Écriture inverse dans le journal
        EcritureJournal.objects.create(
            ecole=self.ecole,
            paiement=paiement,
            type_ecriture=TypeEcritureJournal.ANNULATION,
            montant=-paiement.montant_paye,
            libelle=f"ANNULATION reçu #{paiement.numero_recu} — {motif}",
            annee_scolaire=paiement.frais_eleve.inscription.annee_scolaire,
            saisie_par=self.utilisateur,
            date_ecriture=timezone.now(),
        )

        self.audit.enregistrer(
            action="annulation_paiement",
            objet=paiement,
            donnees_avant={"statut": "actif", "montant": str(paiement.montant_paye)},
            donnees_apres={"statut": "annule", "motif": motif},
        )
        return paiement


    def generer_recu_pdf(self, paiement: Paiement):
        """Génère un reçu PDF pour un paiement."""
        from apps.finances.generateurs.recu import GenerateurRecuPDF
        return GenerateurRecuPDF(ecole=self.ecole).generer(paiement)

    def _generer_numero_recu(self) -> str:
        """
        Génère un numéro de reçu unique par école.
        Format : REC-{annee}-{sequence_padded}
        Exemple : REC-2025-000142
        """
        from django.db.models import Max

        annee = timezone.now().year
        prefixe = f"REC-{annee}-"

        dernier = (
            Paiement.tous_objets
            .filter(ecole=self.ecole, numero_recu__startswith=prefixe)
            .aggregate(max_recu=Max("numero_recu"))["max_recu"]
        )

        if dernier:
            sequence_actuelle = int(dernier.split("-")[-1])
            suivante = sequence_actuelle + 1
        else:
            suivante = 1

        return f"{prefixe}{suivante:06d}"


class ServiceCaisse:
    """Rapports financiers et statistiques de caisse."""

    def __init__(self, ecole):
        self.ecole = ecole

    def rapport_journalier(self, date=None) -> dict:
        """Retourne le rapport de caisse d'une journée."""
        from django.db.models import Sum, Count

        date_cible = date or timezone.localdate()
        debut_journee, debut_lendemain = bornes_journee_locale(date_cible)

        encaissements = (
            Paiement.tous_objets
            .filter(
                ecole=self.ecole,
                date_paiement__gte=debut_journee,
                date_paiement__lt=debut_lendemain,
                est_annule=False,
            )
            .aggregate(
                total=Sum("montant_paye"),
                nombre=Count("id"),
            )
        )

        annulations = (
            Paiement.tous_objets
            .filter(
                ecole=self.ecole,
                date_annulation__gte=debut_journee,
                date_annulation__lt=debut_lendemain,
                est_annule=True,
            )
            .aggregate(total=Sum("montant_paye"))
        )

        par_mode = (
            Paiement.tous_objets
            .filter(
                ecole=self.ecole,
                date_paiement__gte=debut_journee,
                date_paiement__lt=debut_lendemain,
                est_annule=False,
            )
            .values("mode_paiement")
            .annotate(total=Sum("montant_paye"), nombre=Count("id"))
            .order_by("-total")
        )

        return {
            "date": date_cible,
            "total_encaisse": encaissements["total"] or Decimal("0"),
            "nombre_paiements": encaissements["nombre"] or 0,
            "total_annule": annulations["total"] or Decimal("0"),
            "net_caisse": (
                (encaissements["total"] or Decimal("0"))
                - (annulations["total"] or Decimal("0"))
            ),
            "par_mode_paiement": list(par_mode),
        }

    def soldes_par_classe(self, classe) -> list:
        """
        Retourne la liste des élèves d'une classe avec leur solde.
        Utile pour le suivi des paiements en retard.
        """
        from apps.eleves.models import Inscription, StatutInscription

        inscrits = (
            Inscription.objects
            .filter(classe=classe, statut=StatutInscription.VALIDEE)
            .select_related("eleve")
            .prefetch_related("frais__paiements")
        )

        resultats = []
        for inscription in inscrits:
            total_du = sum(f.montant_net for f in inscription.frais.all())
            total_paye = sum(
                p.montant_paye
                for f in inscription.frais.all()
                for p in f.paiements.filter(est_annule=False)
            )
            resultats.append({
                "eleve": inscription.eleve,
                "total_du": total_du,
                "total_paye": total_paye,
                "solde": total_du - total_paye,
                "est_solde": (total_du - total_paye) <= Decimal("0.01"),
            })

        return sorted(resultats, key=lambda x: x["solde"], reverse=True)