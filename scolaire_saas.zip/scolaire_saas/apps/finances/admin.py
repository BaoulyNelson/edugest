from django.contrib import admin
from apps.finances.models import EcritureJournal, FraisEleve, Paiement, Penalite, TypeFrais
from apps.noyau.admin import AdminTenant

admin.site.register(
    (TypeFrais, FraisEleve, Paiement, EcritureJournal, Penalite),
    AdminTenant,
)
