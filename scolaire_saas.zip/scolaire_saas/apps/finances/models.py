"""
apps/finances/models.py
========================
Gestion financière complète : frais, paiements, reçus, caisse, remises, pénalités.

INVARIANTS :
- Un Paiement enregistré ne peut être ni modifié ni supprimé — seulement annulé.
- Le solde d'un élève est toujours calculé dynamiquement (jamais stocké directement).
- Chaque annulation génère une entrée de journal opposée.
- numero_recu est unique par école — séquence générée par le service.
"""

from decimal import Decimal
from django.db import models
from django.core.validators import MinValueValidator
from apps.noyau.mixins import (
    UUIDPrimaryKeyMixin, TenantModelMixin, HorodatageMixin
)


# ─── Configuration des frais ─────────────────────────────────────────────────

class FrequenceFrais(models.TextChoices):
    UNIQUE = "unique", "Paiement unique"
    MENSUEL = "mensuel", "Mensuel"
    TRIMESTRIEL = "trimestriel", "Trimestriel"
    SEMESTRIEL = "semestriel", "Semestriel"
    ANNUEL = "annuel", "Annuel"


class TypeFrais(TenantModelMixin, HorodatageMixin):
    """
    Catégorie de frais définie par l'école.
    Exemples : Frais d'inscription, Écolage, Cantine, Transport, Livres.
    """
    code = models.CharField(max_length=30, verbose_name="Code")
    libelle = models.CharField(max_length=100, verbose_name="Libellé")
    description = models.TextField(blank=True)
    frequence = models.CharField(
        max_length=15,
        choices=FrequenceFrais.choices,
        default=FrequenceFrais.ANNUEL,
    )
    montant_defaut = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Montant par défaut",
    )
    est_obligatoire = models.BooleanField(
        default=True,
        help_text="False = frais optionnel, non bloquant pour les bulletins.",
    )
    bloque_bulletin = models.BooleanField(
        default=False,
        help_text="True = la génération du bulletin est bloquée si ce frais n'est pas soldé.",
    )
    est_actif = models.BooleanField(default=True, db_index=True)
    ordre_affichage = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Type de frais"
        verbose_name_plural = "Types de frais"
        unique_together = [("ecole", "code")]
        ordering = ["ordre_affichage", "libelle"]

    def __str__(self):
        return f"{self.libelle} ({self.code})"


# ─── Frais assignés à un élève ────────────────────────────────────────────────

class FraisEleve(UUIDPrimaryKeyMixin, TenantModelMixin, HorodatageMixin):
    """
    Frais spécifique assigné à une inscription.
    Peut différer du montant par défaut (remise personnelle, cas particulier).
    """
    inscription = models.ForeignKey(
        "eleves.Inscription",
        on_delete=models.PROTECT,
        related_name="frais",
    )
    type_frais = models.ForeignKey(
        TypeFrais,
        on_delete=models.PROTECT,
        related_name="frais_eleves",
    )
    montant_brut = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Montant brut",
    )
    remise_montant = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Remise (montant fixe)",
    )
    remise_pourcentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Remise (%)",
        validators=[MinValueValidator(Decimal("0")), ],
    )
    montant_net = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Montant net dû",
        help_text="Calculé automatiquement : brut - remise_fixe - (brut × remise_%).",
    )
    motif_remise = models.CharField(max_length=200, blank=True)
    assigne_par = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="frais_assignes",
    )

    class Meta:
        verbose_name = "Frais élève"
        verbose_name_plural = "Frais élèves"
        unique_together = [("ecole", "inscription", "type_frais")]

    def __str__(self):
        return f"{self.inscription.eleve.nom_complet} — {self.type_frais.libelle}"

    def calculer_montant_net(self) -> Decimal:
        """Calcule le montant net depuis les remises configurées."""
        remise_pct = (self.montant_brut * self.remise_pourcentage / Decimal("100"))
        net = self.montant_brut - self.remise_montant - remise_pct
        return max(net, Decimal("0.00"))

    def save(self, *args, **kwargs):
        # Recalcul automatique du net avant chaque sauvegarde
        self.montant_net = self.calculer_montant_net()
        super().save(*args, **kwargs)

    def solde_restant(self) -> Decimal:
        """Montant restant dû — calculé depuis les paiements."""
        total_verse = (
            self.paiements
            .filter(est_annule=False, statut__in=["partiel", "complet"])
            .aggregate(total=models.Sum("montant_paye"))["total"]
            or Decimal("0.00")
        )
        return max(self.montant_net - total_verse, Decimal("0.00"))

    @property
    def est_solde(self) -> bool:
        return self.solde_restant() <= Decimal("0.00")


# ─── Paiements ────────────────────────────────────────────────────────────────

class ModePaiement(models.TextChoices):
    ESPECES = "especes", "Espèces"
    VIREMENT = "virement", "Virement bancaire"
    CHEQUE = "cheque", "Chèque"
    MOBILE_MONEY = "mobile_money", "Mobile Money (MonCash, NatCash...)"
    CARTE = "carte", "Carte bancaire"
    AUTRE = "autre", "Autre"


class StatutPaiement(models.TextChoices):
    EN_ATTENTE = "en_attente", "En attente"
    PARTIEL = "partiel", "Partiel"
    COMPLET = "complet", "Complet"
    ANNULE = "annule", "Annulé"
    REMBOURSE = "rembourse", "Remboursé"


class Paiement(UUIDPrimaryKeyMixin, TenantModelMixin, HorodatageMixin):
    """
    Enregistrement immuable d'un versement.
    INVARIANT : une fois créé et non-annulé, aucun champ financier ne peut changer.
    Pour corriger une erreur : annuler + créer un nouveau paiement.
    Cela préserve la piste d'audit financière.
    """
    frais_eleve = models.ForeignKey(
        FraisEleve,
        on_delete=models.PROTECT,
        related_name="paiements",
    )
    numero_recu = models.CharField(
        max_length=30,
        verbose_name="Numéro de reçu",
        help_text="Généré automatiquement par le service. Unique par école.",
    )
    montant_paye = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Montant payé",
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    mode_paiement = models.CharField(
        max_length=15,
        choices=ModePaiement.choices,
        default=ModePaiement.ESPECES,
    )
    reference_externe = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Référence externe",
        help_text="Numéro de transaction mobile money, chèque, virement...",
    )
    statut = models.CharField(
        max_length=15,
        choices=StatutPaiement.choices,
        default=StatutPaiement.COMPLET,
        db_index=True,
    )
    date_paiement = models.DateTimeField(verbose_name="Date et heure du paiement")
    caissier = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="paiements_encaisses",
        verbose_name="Caissier",
    )
    observations = models.TextField(blank=True)

    # ── Annulation ────────────────────────────────────────────────────────────
    est_annule = models.BooleanField(default=False, db_index=True)
    motif_annulation = models.TextField(blank=True)
    annule_par = models.ForeignKey(
        "comptes.Utilisateur",
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="paiements_annules",
    )
    date_annulation = models.DateTimeField(null=True, blank=True)
    paiement_correction = models.ForeignKey(
        "self",
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="paiements_annules_lies",
        help_text="Nouveau paiement créé pour corriger celui-ci.",
    )

    class Meta:
        verbose_name = "Paiement"
        verbose_name_plural = "Paiements"
        unique_together = [("ecole", "numero_recu")]
        indexes = [
            models.Index(
                fields=["ecole", "frais_eleve", "est_annule"],
                name="idx_paiement_frais",
            ),
            models.Index(
                fields=["ecole", "caissier", "date_paiement"],
                name="idx_paiement_caissier",
            ),
        ]
        ordering = ["-date_paiement"]

    def __str__(self):
        return (
            f"Reçu #{self.numero_recu} — "
            f"{self.frais_eleve.inscription.eleve.nom_complet} — "
            f"{self.montant_paye} {self.ecole.devise_monetaire}"
        )


# ─── Journal de caisse ────────────────────────────────────────────────────────

class TypeEcritureJournal(models.TextChoices):
    ENCAISSEMENT = "encaissement", "Encaissement"
    ANNULATION = "annulation", "Annulation"
    REMBOURSEMENT = "remboursement", "Remboursement"
    AJUSTEMENT = "ajustement", "Ajustement manuel"


class EcritureJournal(TenantModelMixin, HorodatageMixin):
    """
    Journal de caisse — entrée immuable pour chaque mouvement financier.
    Double du Paiement mais oriente la comptabilité caisse.
    """
    paiement = models.ForeignKey(
        Paiement,
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="ecritures_journal",
    )
    type_ecriture = models.CharField(
        max_length=15,
        choices=TypeEcritureJournal.choices,
    )
    montant = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Montant (positif=entrée, négatif=sortie)",
    )
    libelle = models.CharField(max_length=200)
    annee_scolaire = models.ForeignKey(
        "academique.AnneeScolaire",
        on_delete=models.PROTECT,
        related_name="ecritures_journal",
    )
    saisie_par = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="ecritures_saisies",
    )
    date_ecriture = models.DateTimeField()

    class Meta:
        verbose_name = "Écriture de journal"
        verbose_name_plural = "Écritures de journal"
        ordering = ["-date_ecriture"]


# ─── Pénalités ───────────────────────────────────────────────────────────────

class Penalite(TenantModelMixin, HorodatageMixin):
    """Pénalité de retard de paiement applicable à un frais élève."""
    frais_eleve = models.ForeignKey(
        FraisEleve,
        on_delete=models.CASCADE,
        related_name="penalites",
    )
    montant = models.DecimalField(max_digits=8, decimal_places=2)
    motif = models.CharField(max_length=200)
    date_application = models.DateField()
    appliquee_par = models.ForeignKey(
        "comptes.Utilisateur",
        on_delete=models.PROTECT,
        related_name="+",
    )
    est_annulee = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Pénalité"
        verbose_name_plural = "Pénalités"