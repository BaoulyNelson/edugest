"""Génère un reçu PDF de paiement via ReportLab."""
from io import BytesIO
from reportlab.lib.pagesizes import A5
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas as pdf_canvas

class GenerateurRecuPDF:
    def __init__(self, ecole):
        self.ecole = ecole
        self.couleur = colors.HexColor(ecole.couleur_principale or "#1a3c6e")

    def generer(self, paiement) -> BytesIO:
        buf = BytesIO()
        larg, haut = A5
        c = pdf_canvas.Canvas(buf, pagesize=A5)
        # En-tête
        c.setFillColor(self.couleur)
        c.rect(0, haut - 30*mm, larg, 30*mm, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 14)
        c.drawCentredString(larg/2, haut - 14*mm, (self.ecole.nom_court or self.ecole.nom).upper())
        c.setFont("Helvetica", 9)
        c.drawCentredString(larg/2, haut - 22*mm, "REÇU DE PAIEMENT")
        # Corps
        c.setFillColor(colors.black)
        c.setFont("Helvetica-Bold", 11)
        c.drawString(15*mm, haut - 45*mm, f"Reçu N° : {paiement.numero_recu}")
        c.setFont("Helvetica", 10)
        frais = paiement.frais_eleve
        eleve = frais.inscription.eleve
        lignes = [
            ("Élève :", eleve.nom_complet),
            ("Matricule :", eleve.matricule),
            ("Classe :", frais.inscription.classe.code),
            ("Type de frais :", frais.type_frais.libelle),
            ("Montant payé :", f"{paiement.montant_paye} {self.ecole.devise_monetaire}"),
            ("Mode de paiement :", paiement.get_mode_paiement_display()),
            ("Date :", paiement.date_paiement.strftime("%d/%m/%Y à %H:%M")),
            ("Caissier :", paiement.caissier.nom_complet),
        ]
        y = haut - 58*mm
        for label, val in lignes:
            c.setFont("Helvetica-Bold", 9); c.drawString(15*mm, y, label)
            c.setFont("Helvetica", 9); c.drawString(65*mm, y, str(val))
            y -= 9*mm
        # Solde restant
        solde = frais.solde_restant()
        c.setFont("Helvetica-Bold", 10)
        c.setFillColor(colors.red if solde > 0 else colors.green)
        c.drawString(15*mm, y - 5*mm, f"Solde restant : {solde} {self.ecole.devise_monetaire}")
        # Pied
        c.setFillColor(self.couleur)
        c.rect(0, 0, larg, 18*mm, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.setFont("Helvetica", 7)
        c.drawCentredString(larg/2, 10*mm, f"{self.ecole.nom} — {self.ecole.ville}")
        c.drawCentredString(larg/2, 5*mm, "Ce reçu est votre preuve de paiement. Merci.")
        c.save()
        buf.seek(0)
        return buf
