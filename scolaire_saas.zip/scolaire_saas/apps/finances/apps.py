from django.apps import AppConfig

class FinancesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.finances"
    verbose_name = "Frais, paiements et gestion de caisse"
