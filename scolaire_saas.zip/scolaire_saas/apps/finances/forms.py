"""
apps/finances/forms.py
======================
Formulaires Django pour la gestion financière.
Tous les widgets utilisent les classes Bootstrap 5.

NOMS des formulaires alignés sur les vues existantes :
  - FormulaireTypeFrais        → creer_type_frais
  - FormulaireAssignerFrais    → assigner_frais
  - FormulairePaiement         → enregistrer_paiement
  - FormulaireAnnulationPaiement
  - FormulaireEcritureJournal
  - FormulairePenalite
"""

from decimal import Decimal
import datetime

from django import forms
from django.core.exceptions import ValidationError
from django.db.models import F, Q, Sum
from django.utils.translation import gettext_lazy as _

from .models import (
    TypeFrais,
    FrequenceFrais,
    FraisEleve,
    Paiement,
    EcritureJournal,
    Penalite,
    ModePaiement,
    TypeEcritureJournal,
)


# ─── Mixin Bootstrap ──────────────────────────────────────────────────────────

class BootstrapMixin:
    """
    Applique automatiquement les classes Bootstrap 5 à chaque widget.
    Intercepte aussi le kwarg `ecole` pour qu'il ne soit jamais transmis
    à BaseModelForm.__init__() — ce qui provoquait le TypeError.
    """

    CONTROL_WIDGETS = (
        forms.TextInput,
        forms.EmailInput,
        forms.NumberInput,
        forms.PasswordInput,
        forms.Textarea,
        forms.DateInput,
        forms.DateTimeInput,
        forms.TimeInput,
        forms.URLInput,
        forms.HiddenInput,
    )
    SELECT_WIDGETS  = (forms.Select, forms.SelectMultiple)
    CHECK_WIDGETS   = (forms.CheckboxInput,)

    def __init__(self, *args, **kwargs):
        # ← POP AVANT super() : Django ne connaît pas ces kwargs personnalisés
        self.ecole = kwargs.pop("ecole", None)
        super().__init__(*args, **kwargs)

        # Application des classes Bootstrap sur chaque widget
        for name, field in self.fields.items():
            w = field.widget
            if isinstance(w, self.CHECK_WIDGETS):
                w.attrs.setdefault("class", "form-check-input")
            elif isinstance(w, self.SELECT_WIDGETS):
                w.attrs["class"] = (w.attrs.get("class", "") + " form-select").strip()
            elif isinstance(w, self.CONTROL_WIDGETS):
                w.attrs["class"] = (w.attrs.get("class", "") + " form-control").strip()
            if isinstance(field, forms.DecimalField) and isinstance(w, forms.NumberInput):
                w.attrs.setdefault("placeholder", "0,00")
                if not self.is_bound:
                    if name in self.initial and self.initial[name] is not None:
                        if Decimal(str(self.initial[name])) == Decimal("0.00"):
                            self.initial[name] = None
                    elif field.initial is not None:
                        if Decimal(str(field.initial)) == Decimal("0.00"):
                            field.initial = None
            if self.ecole and field.label:
                field.label = str(field.label).replace(
                    "HTG", self.ecole.devise_monetaire
                )


# ─── FormulaireTypeFrais ──────────────────────────────────────────────────────

class FormulaireTypeFrais(BootstrapMixin, forms.ModelForm):
    """
    Création / modification d'une catégorie de frais.
    `ecole` est exclu : injecté par la vue avec t.ecole = request.etablissement.
    """

    class Meta:
        model  = TypeFrais
        fields = [
            "code", "libelle", "description", "frequence",
            "montant_defaut", "est_obligatoire", "bloque_bulletin",
            "est_actif", "ordre_affichage",
        ]
        widgets = {
            "code": forms.TextInput(attrs={
                "placeholder": "Ex. : INSCR, ECOL, CANT",
            }),
            "libelle": forms.TextInput(attrs={
                "placeholder": "Ex. : Frais d'inscription",
            }),
            "description": forms.Textarea(attrs={
                "rows": 3,
                "placeholder": "Description optionnelle…",
            }),
            "frequence":       forms.Select(),
            "montant_defaut":  forms.NumberInput(attrs={"min": "0", "step": "0.01"}),
            "ordre_affichage": forms.NumberInput(attrs={"min": "0"}),
        }
        labels = {
            "code":             _("Code"),
            "libelle":          _("Libellé"),
            "frequence":        _("Fréquence"),
            "montant_defaut":   _("Montant de référence (HTG)"),
            "est_obligatoire":  _("Frais obligatoire"),
            "bloque_bulletin":  _("Bloque la génération du bulletin"),
            "est_actif":        _("Actif"),
            "ordre_affichage":  _("Ordre d'affichage"),
        }
        help_texts = {
            "montant_defaut": _(
                "Valeur proposée lors d’une assignation. Ce n’est pas encore une dette ni un paiement."
            ),
        }

    def clean_code(self):
        code = self.cleaned_data.get("code", "").upper().strip()
        ecole = self.ecole or getattr(self.instance, "ecole", None)
        types_existants = TypeFrais.objects.filter(ecole=ecole, code__iexact=code)
        if self.instance.pk:
            types_existants = types_existants.exclude(pk=self.instance.pk)
        if ecole and types_existants.exists():
            raise ValidationError(_("Ce code de frais existe déjà dans cet établissement."))
        return code

    def clean_montant_defaut(self):
        montant = self.cleaned_data.get("montant_defaut", Decimal("0.00"))
        if montant is None:
            return Decimal("0.00")
        if montant < Decimal("0.00"):
            raise ValidationError(_("Le montant par défaut ne peut pas être négatif."))
        return montant

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["montant_defaut"].required = False


class FormulaireTypeFraisRapide(forms.Form):
    code = forms.CharField(
        max_length=30,
        label=_("Code"),
        widget=forms.TextInput(attrs={"placeholder": "Ex. : INSCR"}),
    )
    libelle = forms.CharField(
        max_length=100,
        label=_("Libellé"),
        widget=forms.TextInput(attrs={"placeholder": "Ex. : Frais d’inscription"}),
    )
    frequence = forms.ChoiceField(
        choices=FrequenceFrais.choices,
        label=_("Fréquence"),
    )
    montant_defaut = forms.DecimalField(
        required=False,
        min_value=Decimal("0.00"),
        max_digits=10,
        decimal_places=2,
        label=_("Montant de référence (HTG)"),
        widget=forms.NumberInput(
            attrs={"min": "0", "step": "0.01", "placeholder": "0,00"}
        ),
        help_text=_(
            "Valeur proposée lors d’une assignation. Ce n’est pas encore une dette ni un paiement."
        ),
    )

    def __init__(self, *args, ecole=None, **kwargs):
        self.ecole = ecole
        super().__init__(*args, **kwargs)
        if self.ecole:
            self.fields["montant_defaut"].label = _(
                "Montant de référence (%(devise)s)"
            ) % {"devise": self.ecole.devise_monetaire}

    def clean_code(self):
        code = self.cleaned_data["code"].upper().strip()
        if self.ecole and TypeFrais.objects.filter(ecole=self.ecole, code__iexact=code).exists():
            raise ValidationError(_("Ce code de frais existe déjà dans cet établissement."))
        return code


# ─── FormulaireAssignerFrais ──────────────────────────────────────────────────

class FormulaireAssignerFrais(BootstrapMixin, forms.ModelForm):
    """
    Assignation d'un frais à une inscription, avec remises optionnelles.
    `ecole` est intercepté par BootstrapMixin pour filtrer les querysets.
    `assigne_par` est exclu : injecté par la vue.
    `montant_net` est exclu : calculé par FraisEleve.save().
    """

    class Meta:
        model  = FraisEleve
        fields = [
            "inscription", "type_frais", "montant_brut",
            "remise_montant", "remise_pourcentage", "motif_remise",
        ]
        widgets = {
            "inscription":        forms.Select(),
            "type_frais":         forms.Select(),
            "montant_brut":       forms.NumberInput(attrs={"min": "0.01", "step": "0.01"}),
            "remise_montant":     forms.NumberInput(attrs={"min": "0", "step": "0.01"}),
            "remise_pourcentage": forms.NumberInput(attrs={"min": "0", "max": "100", "step": "0.01"}),
            "motif_remise":       forms.TextInput(attrs={"placeholder": "Ex. : Bourse, fratrie…"}),
        }
        labels = {
            "inscription":        _("Inscription / Élève"),
            "type_frais":         _("Type de frais"),
            "montant_brut":       _("Montant à facturer avant remise (HTG)"),
            "remise_montant":     _("Remise fixe (HTG)"),
            "remise_pourcentage": _("Remise (%)"),
            "motif_remise":       _("Motif de la remise"),
        }
        help_texts = {
            "type_frais": _(
                "Choisissez la catégorie du frais. Son montant de référence peut être ajusté ici."
            ),
            "montant_brut": _(
                "C’est le total dû avant remise. Le montant net dû est calculé après les remises."
            ),
            "remise_montant": _("Déduite du montant à facturer."),
            "remise_pourcentage": _("Pourcentage déduit du montant à facturer."),
        }

    def __init__(self, *args, **kwargs):
        # BootstrapMixin.__init__ a déjà fait kwargs.pop("ecole") → self.ecole
        annee_scolaire = kwargs.pop("annee_scolaire", None)
        super().__init__(*args, **kwargs)
        self.fields["remise_montant"].required = False
        self.fields["remise_pourcentage"].required = False

        # Filtrer les FK sur le tenant courant si ecole est disponible
        if self.ecole:
            inscriptions = self.fields["inscription"].queryset.filter(
                ecole=self.ecole
            )
            if annee_scolaire is not None:
                inscriptions = inscriptions.filter(annee_scolaire=annee_scolaire)
            else:
                inscriptions = inscriptions.none()
            self.fields["inscription"].queryset = inscriptions
            self.fields["type_frais"].queryset = (
                self.fields["type_frais"].queryset.filter(ecole=self.ecole, est_actif=True)
            )

    def clean(self):
        cleaned      = super().clean()
        brut         = cleaned.get("montant_brut", Decimal("0.00"))
        remise_fixe  = cleaned.get("remise_montant") or Decimal("0.00")
        remise_pct   = cleaned.get("remise_pourcentage") or Decimal("0.00")
        cleaned["remise_montant"] = remise_fixe
        cleaned["remise_pourcentage"] = remise_pct

        if brut is not None and brut <= Decimal("0.00"):
            self.add_error("montant_brut", _("Le montant brut doit être supérieur à zéro."))

        if remise_fixe and brut and remise_fixe > brut:
            self.add_error("remise_montant", _("La remise fixe ne peut pas dépasser le montant brut."))

        if remise_pct and not (Decimal("0") <= remise_pct <= Decimal("100")):
            self.add_error("remise_pourcentage", _("La remise doit être comprise entre 0 et 100."))

        return cleaned


# ─── FormulairePaiement ───────────────────────────────────────────────────────

class FormulairePaiement(BootstrapMixin, forms.Form):
    """
    Enregistrement d'un versement.
    Form simple (pas ModelForm) car le service ServicePaiement.enregistrer()
    gère la création du Paiement, la numérotation du reçu et l'écriture journal.

    Champs alignés sur ce que la vue extrait de form.cleaned_data :
      frais_eleve, montant, mode_paiement, reference_externe
    """

    frais_eleve = forms.ModelChoiceField(
        queryset=FraisEleve.objects.none(),
        label=_("Dette à régler"),
        widget=forms.Select(),
        help_text=_(
            "Seuls les frais assignés avec un solde restant sont proposés."
        ),
    )
    montant = forms.DecimalField(
        label=_("Montant payé maintenant (HTG)"),
        min_value=Decimal("0.01"),
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={"min": "0.01", "step": "0.01", "placeholder": "0,00"}
        ),
        help_text=_(
            "Saisissez le versement reçu aujourd’hui. Il peut être inférieur au solde restant; un paiement partiel est accepté."
        ),
    )
    mode_paiement = forms.ChoiceField(
        label=_("Mode de paiement"),
        choices=ModePaiement.choices,
        initial=ModePaiement.ESPECES,
        widget=forms.Select(),
    )
    reference_externe = forms.CharField(
        label=_("Référence externe"),
        required=False,
        max_length=100,
        widget=forms.TextInput(attrs={"placeholder": "N° transaction, chèque, virement…"}),
        help_text=_("Obligatoire pour virement, chèque, mobile money, carte."),
    )

    def __init__(self, *args, **kwargs):
        # BootstrapMixin.__init__ intercepte ecole → self.ecole
        annee_scolaire = kwargs.pop("annee_scolaire", None)
        super().__init__(*args, **kwargs)

        # Appliquer form-select / form-control (BootstrapMixin gère Form aussi)
        if self.ecole:
            frais = FraisEleve.objects.filter(ecole=self.ecole)
            if annee_scolaire is not None:
                frais = frais.filter(
                    inscription__annee_scolaire=annee_scolaire
                )
            else:
                frais = frais.none()
            frais_avec_solde = (
                frais.annotate(
                    total_verse=Sum(
                        "paiements__montant_paye",
                        filter=Q(
                            paiements__est_annule=False,
                            paiements__statut__in=["partiel", "complet"],
                        ),
                    )
                )
                .filter(
                    Q(total_verse__isnull=True, montant_net__gt=Decimal("0.00"))
                    | Q(total_verse__lt=F("montant_net"))
                )
                .select_related("inscription__eleve", "type_frais")
            )
            self.fields["frais_eleve"].queryset = frais_avec_solde

    def clean(self):
        cleaned = super().clean()
        mode    = cleaned.get("mode_paiement", "")
        ref     = (cleaned.get("reference_externe") or "").strip()

        modes_avec_ref = {
            ModePaiement.VIREMENT,
            ModePaiement.CHEQUE,
            ModePaiement.MOBILE_MONEY,
            ModePaiement.CARTE,
        }
        if mode in modes_avec_ref and not ref:
            self.add_error(
                "reference_externe",
                _("Une référence externe est requise pour ce mode de paiement."),
            )
        return cleaned


# ─── FormulaireAnnulationPaiement ─────────────────────────────────────────────

class FormulaireAnnulationPaiement(BootstrapMixin, forms.Form):
    """
    Confirmation d'annulation d'un paiement existant.
    L'annulation réelle est traitée par ServicePaiement.annuler().
    """

    motif_annulation = forms.CharField(
        label=_("Motif d'annulation"),
        min_length=10,
        max_length=500,
        widget=forms.Textarea(attrs={
            "rows": 4,
            "placeholder": "Décrivez la raison de l'annulation (minimum 10 caractères)…",
        }),
        help_text=_("Ce motif sera consigné dans le journal de caisse."),
    )
    confirmation = forms.BooleanField(
        label=_("Je confirme vouloir annuler ce paiement. Cette action est irréversible."),
        required=True,
        widget=forms.CheckboxInput(),
    )


# ─── FormulaireEcritureJournal ────────────────────────────────────────────────

class FormulaireEcritureJournal(BootstrapMixin, forms.ModelForm):
    """
    Ajustement manuel de caisse.
    `saisie_par` et `paiement` sont injectés par la vue.
    """

    class Meta:
        model  = EcritureJournal
        fields = ["type_ecriture", "montant", "libelle", "annee_scolaire", "date_ecriture"]
        widgets = {
            "type_ecriture":  forms.Select(),
            "montant":        forms.NumberInput(attrs={"step": "0.01", "placeholder": "Positif = entrée, négatif = sortie"}),
            "libelle":        forms.TextInput(attrs={"placeholder": "Ex. : Remboursement cantine — oct. 2024"}),
            "annee_scolaire": forms.Select(),
            "date_ecriture":  forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
        }
        labels = {
            "type_ecriture":  _("Type d'écriture"),
            "montant":        _("Montant (HTG)"),
            "libelle":        _("Libellé"),
            "annee_scolaire": _("Année scolaire"),
            "date_ecriture":  _("Date de l'écriture"),
        }

    def clean(self):
        cleaned       = super().clean()
        type_ecriture = cleaned.get("type_ecriture")
        montant       = cleaned.get("montant")

        if montant is None:
            return cleaned

        if type_ecriture == TypeEcritureJournal.ENCAISSEMENT and montant <= Decimal("0.00"):
            self.add_error("montant", _("Un encaissement doit avoir un montant positif."))
        if type_ecriture == TypeEcritureJournal.ANNULATION and montant >= Decimal("0.00"):
            self.add_error("montant", _("Une annulation doit avoir un montant négatif."))

        return cleaned


# ─── FormulairePenalite ───────────────────────────────────────────────────────

class FormulairePenalite(BootstrapMixin, forms.ModelForm):
    """
    Application d'une pénalité de retard à un frais élève.
    `appliquee_par` est injecté par la vue.
    """

    class Meta:
        model  = Penalite
        fields = ["frais_eleve", "montant", "motif", "date_application"]
        widgets = {
            "frais_eleve":      forms.Select(),
            "montant":          forms.NumberInput(attrs={"min": "0.01", "step": "0.01"}),
            "motif":            forms.TextInput(attrs={"placeholder": "Ex. : Retard de paiement — novembre 2024"}),
            "date_application": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
        }
        labels = {
            "frais_eleve":      _("Frais concerné"),
            "montant":          _("Montant de la pénalité (HTG)"),
            "motif":            _("Motif"),
            "date_application": _("Date d'application"),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.initial.get("date_application"):
            self.initial["date_application"] = datetime.date.today().strftime("%Y-%m-%d")
        if self.ecole:
            self.fields["frais_eleve"].queryset = (
                self.fields["frais_eleve"].queryset.filter(ecole=self.ecole)
            )

    def clean_montant(self):
        montant = self.cleaned_data.get("montant")
        if montant is not None and montant <= Decimal("0.00"):
            raise ValidationError(_("Le montant de la pénalité doit être positif."))
        return montant

    def clean_date_application(self):
        date = self.cleaned_data.get("date_application")
        if date and date > datetime.date.today():
            raise ValidationError(_("La date d'application ne peut pas être dans le futur."))
        return date
