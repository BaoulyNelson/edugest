from datetime import date, datetime, time
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from apps.academique.models import AnneeScolaire, Classe, StatutAnneeScolaire
from apps.eleves.models import Eleve, Inscription, StatutInscription
from apps.etablissements.models import Etablissement
from apps.finances.forms import (
    FormulaireAssignerFrais,
    FormulairePaiement,
    FormulaireTypeFrais,
    FormulaireTypeFraisRapide,
)
from apps.finances.models import (
    EcritureJournal,
    FraisEleve,
    TypeEcritureJournal,
    TypeFrais,
)
from apps.finances.preconfiguration import preconfigurer_types_frais
from apps.finances.services import ServicePaiement
from apps.noyau.exceptions import RegleMetierError
from apps.parametrage.models import CycleEnseignement, Niveau


class AnneeScolaireFinancesTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="finances-annee@example.com",
            password="testpass123",
            nom="Responsable",
            prenom="École",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-finances-annee",
            nom="École finances année",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        self.type_frais = TypeFrais.objects.create(
            ecole=self.ecole,
            code="ECOL",
            libelle="Écolage",
        )
        self.frais_par_annee = {}
        for libelle, debut, fin, statut, matricule in (
            (
                "2025-2026",
                date(2025, 9, 1),
                date(2026, 6, 30),
                StatutAnneeScolaire.ACTIVE,
                "FIN-ACT",
            ),
            (
                "2024-2025",
                date(2024, 9, 1),
                date(2025, 6, 30),
                StatutAnneeScolaire.CLOTUREE,
                "FIN-CLS",
            ),
        ):
            annee = AnneeScolaire.objects.create(
                ecole=self.ecole,
                libelle=libelle,
                date_debut=debut,
                date_fin=fin,
                statut=statut,
            )
            classe = Classe.objects.create(
                ecole=self.ecole,
                annee_scolaire=annee,
                niveau=niveau,
                code=f"CL-{matricule}",
                libelle=f"Classe {matricule}",
            )
            eleve = Eleve.tous_objets.create(
                ecole=self.ecole,
                matricule=matricule,
                nom="Élève",
                prenom=matricule,
                date_naissance=date(2012, 5, 3),
                sexe="F",
            )
            inscription = Inscription.tous_objets.create(
                ecole=self.ecole,
                annee_scolaire=annee,
                classe=classe,
                eleve=eleve,
                date_inscription=debut,
                statut=StatutInscription.VALIDEE,
            )
            self.frais_par_annee[statut] = FraisEleve.objects.create(
                ecole=self.ecole,
                inscription=inscription,
                type_frais=self.type_frais,
                montant_brut=Decimal("100.00"),
                assigne_par=self.utilisateur,
            )

    def test_formulaires_financiers_ne_proposent_que_l_annee_selectionnee(self):
        annee_active = AnneeScolaire.objects.get(
            ecole=self.ecole, statut=StatutAnneeScolaire.ACTIVE
        )
        frais_actifs = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]
        frais_clotures = self.frais_par_annee[StatutAnneeScolaire.CLOTUREE]

        formulaire_paiement = FormulairePaiement(
            ecole=self.ecole,
            annee_scolaire=annee_active,
        )
        formulaire_frais = FormulaireAssignerFrais(
            ecole=self.ecole,
            annee_scolaire=annee_active,
        )

        self.assertIn(frais_actifs, formulaire_paiement.fields["frais_eleve"].queryset)
        self.assertNotIn(
            frais_clotures, formulaire_paiement.fields["frais_eleve"].queryset
        )
        self.assertEqual(
            formulaire_frais.fields["inscription"].queryset.count(), 1
        )
        self.assertEqual(
            FormulairePaiement(ecole=self.ecole)
            .fields["frais_eleve"].queryset.count(),
            0,
        )

    def test_formulaire_paiement_exclut_les_dettes_entierement_payees(self):
        annee_active = AnneeScolaire.objects.get(
            ecole=self.ecole, statut=StatutAnneeScolaire.ACTIVE
        )
        frais = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]
        service = ServicePaiement(self.utilisateur, self.ecole)

        service.enregistrer(frais_eleve=frais, montant=Decimal("40.00"))
        formulaire = FormulairePaiement(
            ecole=self.ecole,
            annee_scolaire=annee_active,
        )
        self.assertIn(frais, formulaire.fields["frais_eleve"].queryset)

        service.enregistrer(frais_eleve=frais, montant=Decimal("60.00"))
        formulaire = FormulairePaiement(
            ecole=self.ecole,
            annee_scolaire=annee_active,
        )
        self.assertNotIn(frais, formulaire.fields["frais_eleve"].queryset)

    def test_champs_monetaires_zero_sont_vides_et_remises_vides_valent_zero(self):
        annee_active = AnneeScolaire.objects.get(
            ecole=self.ecole, statut=StatutAnneeScolaire.ACTIVE
        )
        formulaire_type = FormulaireTypeFrais(ecole=self.ecole)
        self.assertEqual(
            formulaire_type["montant_defaut"].field.widget.attrs["placeholder"],
            "0,00",
        )
        self.assertNotIn('value="0.00"', str(formulaire_type["montant_defaut"]))
        type_personnalise = TypeFrais(
            ecole=self.ecole,
            code="PERSO",
            libelle="Frais personnalisé",
            montant_defaut=Decimal("125.00"),
        )
        formulaire_modification = FormulaireTypeFrais(
            instance=type_personnalise,
            ecole=self.ecole,
        )
        self.assertIn('value="125.00"', str(formulaire_modification["montant_defaut"]))

        frais_actifs = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]
        formulaire = FormulaireAssignerFrais(
            data={
                "inscription": frais_actifs.inscription_id,
                "type_frais": self.type_frais.pk,
                "montant_brut": "100.00",
                "remise_montant": "",
                "remise_pourcentage": "",
                "motif_remise": "",
            },
            ecole=self.ecole,
            annee_scolaire=annee_active,
        )

        self.assertEqual(
            formulaire["remise_montant"].field.widget.attrs["placeholder"],
            "0,00",
        )
        self.assertNotIn('value="0.00"', str(formulaire["remise_montant"]))
        self.assertTrue(formulaire.is_valid(), formulaire.errors)
        self.assertEqual(formulaire.cleaned_data["remise_montant"], Decimal("0.00"))
        self.assertEqual(
            formulaire.cleaned_data["remise_pourcentage"], Decimal("0.00")
        )

    def test_service_refuse_un_paiement_sur_une_annee_cloturee(self):
        frais_clotures = self.frais_par_annee[StatutAnneeScolaire.CLOTUREE]

        with self.assertRaises(RegleMetierError):
            ServicePaiement(self.utilisateur, self.ecole).enregistrer(
                frais_eleve=frais_clotures,
                montant=Decimal("10.00"),
            )

    def test_types_frais_recommandes_sont_adaptes_et_idempotents(self):
        frais_inscription_existant = TypeFrais.tous_objets.create(
            ecole=self.ecole,
            code="INSCRIPTION",
            libelle="Frais d'inscription",
            montant_defaut=Decimal("10000.00"),
        )
        nombre_ajoutes = preconfigurer_types_frais(self.ecole)
        codes_attendus = {
            "INSCRIPTION",
            "SCOLARITE",
            "CANTINE",
            "TRANSPORT",
            "FOURNITURES",
            "UNIFORME",
            "EXAMEN",
        }
        types = TypeFrais.tous_objets.filter(ecole=self.ecole)

        self.assertEqual(nombre_ajoutes, len(codes_attendus) - 1)
        self.assertTrue(codes_attendus.issubset(set(types.values_list("code", flat=True))))
        self.assertFalse(types.filter(code="INSCR").exists())
        self.assertFalse(
            types.exclude(pk=frais_inscription_existant.pk)
            .exclude(montant_defaut=Decimal("0.00"))
            .exists()
        )
        self.assertEqual(frais_inscription_existant.montant_defaut, Decimal("10000.00"))

        type_scolarite = types.get(code="SCOLARITE")
        type_scolarite.montant_defaut = Decimal("1500.00")
        type_scolarite.save(update_fields=["montant_defaut"])
        self.assertEqual(preconfigurer_types_frais(self.ecole), 0)
        type_scolarite.refresh_from_db()

        self.assertEqual(type_scolarite.montant_defaut, Decimal("1500.00"))
        self.assertEqual(TypeFrais.tous_objets.filter(ecole=self.ecole).count(), 8)

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_paiement_depuis_soldes_ne_propose_que_les_dettes_de_l_eleve(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)
        frais = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]

        response = self.client.get(
            reverse("finances:enregistrer"),
            {"eleve_id": frais.inscription.eleve_id},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        formulaire = response.context["form"]
        self.assertEqual(
            list(formulaire.fields["frais_eleve"].queryset),
            [frais],
        )
        self.assertEqual(formulaire["frais_eleve"].value(), frais.pk)

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_soldes_affiche_toutes_les_classes_et_permet_de_filtrer(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)
        frais_actifs = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]
        classe_active = frais_actifs.inscription.classe
        nouvelle_classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=classe_active.annee_scolaire,
            niveau=classe_active.niveau,
            code="CL-ACT-2",
            libelle="Deuxième classe active",
        )
        eleve = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="FIN-ACT-2",
            nom="Deuxième",
            prenom="Élève",
            date_naissance=date(2012, 5, 3),
            sexe="F",
        )
        Inscription.tous_objets.create(
            ecole=self.ecole,
            annee_scolaire=classe_active.annee_scolaire,
            classe=nouvelle_classe,
            eleve=eleve,
            date_inscription=classe_active.annee_scolaire.date_debut,
            statut=StatutInscription.VALIDEE,
        )

        url = reverse("finances:soldes")
        response = self.client.get(
            url,
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context["soldes"]), 2)
        self.assertContains(response, frais_actifs.inscription.eleve.nom_complet)
        self.assertContains(response, eleve.nom_complet)

        response = self.client.get(
            url,
            {"classe_id": nouvelle_classe.pk},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context["soldes"]), 1)
        self.assertEqual(response.context["soldes"][0]["eleve"], eleve)

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_frais_eleves_affiche_les_frais_les_plus_recents_en_premier(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)
        frais_existant = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]
        eleve_recent = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="FIN-RECENT",
            nom="Aardvark",
            prenom="Nouvel élève",
            date_naissance=date(2012, 5, 3),
            sexe="F",
        )
        inscription = Inscription.tous_objets.create(
            ecole=self.ecole,
            annee_scolaire=frais_existant.inscription.annee_scolaire,
            classe=frais_existant.inscription.classe,
            eleve=eleve_recent,
            date_inscription=frais_existant.inscription.date_inscription,
            statut=StatutInscription.VALIDEE,
        )
        frais_recent = FraisEleve.objects.create(
            ecole=self.ecole,
            inscription=inscription,
            type_frais=self.type_frais,
            montant_brut=Decimal("100.00"),
            assigne_par=self.utilisateur,
        )

        response = self.client.get(
            reverse("finances:frais_eleves"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["frais"][0].pk, frais_recent.pk)
        self.assertEqual(response.context["frais"][1].pk, frais_existant.pk)

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_tableau_de_bord_affiche_les_dettes_de_l_annee_selectionnee(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)

        response = self.client.get(
            reverse("finances:tableau_bord"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["montant_a_recouvrer"], Decimal("100.00"))
        self.assertEqual(response.context["nombre_dettes"], 1)

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_tableau_de_bord_inclut_les_paiements_du_jour_et_du_mois(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)
        self.ecole.devise_monetaire = "USD"
        self.ecole.save(update_fields=["devise_monetaire"])
        ServicePaiement(self.utilisateur, self.ecole).enregistrer(
            frais_eleve=self.frais_par_annee[StatutAnneeScolaire.ACTIVE],
            montant=Decimal("25.00"),
            mode_paiement="especes",
        )

        response = self.client.get(
            reverse("finances:tableau_bord"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["rapport"]["total_encaisse"], Decimal("25.00"))
        self.assertEqual(response.context["rapport"]["nombre_paiements"], 1)
        self.assertEqual(response.context["rapport"]["total_mois"], Decimal("25.00"))
        self.assertEqual(response.context["rapport"]["nombre_paiements_mois"], 1)
        self.assertEqual(
            response.context["rapport"]["par_mode_paiement"][0]["mode_paiement"],
            "especes",
        )
        self.assertEqual(response.context["paiements_recents"].count(), 1)
        self.assertContains(response, "25.00 USD")
        self.assertNotContains(response, "25.00 HTG")
        self.assertIn(
            "USD",
            FormulaireAssignerFrais(ecole=self.ecole).fields["montant_brut"].label,
        )
        self.assertIn(
            "USD", FormulairePaiement(ecole=self.ecole).fields["montant"].label
        )
        self.assertIn(
            "USD",
            FormulaireTypeFraisRapide(ecole=self.ecole)
            .fields["montant_defaut"].label,
        )

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_enregistrement_affiche_confirmation_et_non_un_telechargement_pdf(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)
        frais = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]

        response = self.client.post(
            reverse("finances:enregistrer"),
            {
                "frais_eleve": str(frais.pk),
                "montant": "25.00",
                "mode_paiement": "especes",
                "reference_externe": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        paiement = frais.paiements.get()
        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            response.url,
            reverse("finances:confirmation_paiement", args=[paiement.pk]),
        )

        confirmation = self.client.get(
            response.url,
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(confirmation.status_code, 200)
        self.assertContains(confirmation, "Paiement enregistré")
        self.assertContains(confirmation, paiement.numero_recu)
        self.assertContains(confirmation, "25.00 HTG")
        self.assertContains(confirmation, "Télécharger le reçu PDF")

    @override_settings(
        STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
        STORAGES={
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {
                "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
            },
        },
    )
    def test_journal_filtre_la_periode_et_calcule_les_soldes(self):
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.client.force_login(self.utilisateur)
        frais = self.frais_par_annee[StatutAnneeScolaire.ACTIVE]
        annee = frais.inscription.annee_scolaire

        def creer_ecriture(jour, montant, type_ecriture):
            return EcritureJournal.tous_objets.create(
                ecole=self.ecole,
                type_ecriture=type_ecriture,
                montant=Decimal(montant),
                libelle=f"Mouvement {jour}",
                annee_scolaire=annee,
                saisie_par=self.utilisateur,
                date_ecriture=timezone.make_aware(
                    datetime.combine(jour, time.min)
                ),
            )

        ecriture_ouverture = creer_ecriture(
            date(2025, 9, 10), "200.00", TypeEcritureJournal.ENCAISSEMENT
        )
        creer_ecriture(date(2025, 10, 10), "-20.00", TypeEcritureJournal.ANNULATION)
        creer_ecriture(date(2025, 10, 11), "30.00", TypeEcritureJournal.ENCAISSEMENT)
        self.assertEqual(
            EcritureJournal.tous_objets.filter(
                pk=ecriture_ouverture.pk,
                annee_scolaire=annee,
                date_ecriture__lt=timezone.make_aware(
                    datetime.combine(date(2025, 10, 10), time.min)
                ),
            ).count(),
            1,
        )

        response = self.client.get(
            reverse("finances:caisse"),
            {"date_debut": "2025-10-10", "date_fin": "2025-10-11"},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["solde_ouverture"], Decimal("200.00"))
        self.assertEqual(response.context["total_entrees"], Decimal("30.00"))
        self.assertEqual(response.context["total_sorties"], Decimal("20.00"))
        self.assertEqual(response.context["net_periode"], Decimal("10.00"))
        self.assertEqual(response.context["solde_cloture"], Decimal("210.00"))
        self.assertEqual(response.context["nombre_ecritures"], 2)
        self.assertContains(response, "Annulation")
        self.assertNotContains(response, "Mouvement 2025-09-10")


class CreationRapideTypeFraisTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="type-frais-rapide@example.com",
            password="test-password",
            nom="Admin",
            prenom="Finances",
        )
        self.utilisateur.is_superuser = True
        self.utilisateur.save(update_fields=["is_superuser"])
        self.ecole = Etablissement.objects.create(
            slug="ecole-type-frais-rapide",
            nom="École types rapides",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)

    def test_cree_un_type_frais_rapidement_et_le_retourne(self):
        response = self.client.post(
            reverse("finances:creer_type_frais_rapide"),
            {
                "code": "inscr",
                "libelle": "Frais d’inscription",
                "frequence": "unique",
                "montant_defaut": "1250.00",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 201)
        type_frais = TypeFrais.objects.get(ecole=self.ecole, code="INSCR")
        self.assertEqual(response.json()["id"], str(type_frais.pk))
        self.assertEqual(response.json()["montant_defaut"], "1250.00")
        self.assertTrue(type_frais.est_actif)

    def test_refuse_un_code_deja_utilise(self):
        TypeFrais.objects.create(
            ecole=self.ecole,
            code="INSCR",
            libelle="Frais d’inscription",
        )

        response = self.client.post(
            reverse("finances:creer_type_frais_rapide"),
            {
                "code": "inscr",
                "libelle": "Autre frais",
                "frequence": "unique",
                "montant_defaut": "100.00",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn("code", response.json()["erreurs"])

    def test_ajoute_les_types_recommandes_a_un_etablissement_existant(self):
        url = reverse("finances:ajouter_types_frais_recommandes")

        response = self.client.post(url, HTTP_X_TENANT_SLUG=self.ecole.slug)

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse("finances:types_frais"))
        self.assertTrue(
            TypeFrais.objects.filter(ecole=self.ecole, code="SCOLARITE").exists()
        )
        self.assertTrue(
            TypeFrais.objects.filter(ecole=self.ecole, code="CANTINE").exists()
        )

        self.client.post(url, HTTP_X_TENANT_SLUG=self.ecole.slug)
        self.assertEqual(TypeFrais.objects.filter(ecole=self.ecole).count(), 7)

    def test_modifie_le_montant_de_reference_d_un_type_de_frais(self):
        type_frais = TypeFrais.objects.create(
            ecole=self.ecole,
            code="SCOLARITE",
            libelle="Frais de scolarité",
        )

        response = self.client.post(
            reverse("finances:modifier_type_frais", args=[type_frais.pk]),
            {
                "code": "SCOLARITE",
                "libelle": "Frais de scolarité",
                "description": "Tarif semestriel",
                "frequence": "semestriel",
                "montant_defaut": "2500.00",
                "est_obligatoire": "on",
                "bloque_bulletin": "",
                "est_actif": "on",
                "ordre_affichage": "2",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 302)
        type_frais.refresh_from_db()
        self.assertEqual(type_frais.montant_defaut, Decimal("2500.00"))
        self.assertEqual(type_frais.frequence, "semestriel")


class CreationRapideFraisEleveTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="creation-frais-eleve@example.com",
            password="test-password",
            nom="Admin",
            prenom="Finances",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-creation-frais-eleve",
            nom="École création frais",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=CycleEnseignement.objects.create(
                ecole=self.ecole,
                code="FOND",
                libelle="Fondamental",
            ),
            code="N1",
            libelle="Niveau 1",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="N1-A",
            libelle="Niveau 1 A",
        )
        eleve = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="FE-001",
            nom="Joseph",
            prenom="Marie",
            date_naissance=date(2012, 5, 3),
            sexe="F",
        )
        self.inscription = Inscription.tous_objets.create(
            ecole=self.ecole,
            eleve=eleve,
            annee_scolaire=annee,
            classe=classe,
            date_inscription=date(2026, 9, 1),
        )
        self.type_frais = TypeFrais.objects.create(
            ecole=self.ecole,
            code="SCOL",
            libelle="Scolarité",
            montant_defaut=Decimal("2500.00"),
        )
        self.url = reverse("finances:creation_rapide_frais_eleve")

    def test_get_affiche_le_formulaire_et_post_cree_une_dette(self):
        get_response = self.client.get(
            self.url,
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )
        self.assertEqual(get_response.status_code, 200)
        self.assertContains(get_response, 'data-nested-create="inscription"')

        response = self.client.post(
            self.url,
            {
                "inscription": self.inscription.pk,
                "type_frais": self.type_frais.pk,
                "montant_brut": "2500.00",
                "remise_montant": "",
                "remise_pourcentage": "",
                "motif_remise": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 201, response.content.decode())
        frais = FraisEleve.objects.get(pk=response.json()["id"])
        self.assertEqual(frais.ecole, self.ecole)
        self.assertEqual(frais.montant_net, Decimal("2500.00"))
        self.assertEqual(response.json()["solde"], "2500.00")
