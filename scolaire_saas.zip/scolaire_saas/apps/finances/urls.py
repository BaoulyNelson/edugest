from django.urls import path
from apps.finances import views

app_name = "finances"
urlpatterns = [
    path("", views.tableau_bord_finances, name="tableau_bord"),
    path("frais/", views.liste_types_frais, name="types_frais"),
    path("frais/ajouter-recommandes/", views.ajouter_types_frais_recommandes, name="ajouter_types_frais_recommandes"),
    path("frais/creer/", views.creer_type_frais, name="creer_type_frais"),
    path("frais/<int:pk>/modifier/", views.modifier_type_frais, name="modifier_type_frais"),
    path("frais/creer/rapide/", views.creer_type_frais_rapide, name="creer_type_frais_rapide"),
    path("frais-eleves/creation-rapide/", views.creation_rapide_frais_eleve, name="creation_rapide_frais_eleve"),
    path("frais-eleves/", views.liste_frais_eleves, name="frais_eleves"),
    path("frais-eleves/importer/", views.importer_frais_eleves, name="importer_frais_eleves"),
    path("frais-eleves/assigner/", views.assigner_frais, name="assigner_frais"),
    path("paiements/", views.liste_paiements, name="paiements"),
    path("paiements/importer/", views.importer_paiements, name="importer_paiements"),
    path("paiements/enregistrer/", views.enregistrer_paiement, name="enregistrer"),
    path("paiements/<uuid:pk>/confirmation/", views.confirmation_paiement, name="confirmation_paiement"),
    path("paiements/<uuid:pk>/annuler/", views.annuler_paiement, name="annuler"),
    path("paiements/<uuid:pk>/recu/", views.telecharger_recu, name="recu"),
    path("caisse/", views.journal_caisse, name="caisse"),
    path("soldes/", views.soldes_eleves, name="soldes"),
    path("rapport-journalier/", views.rapport_journalier, name="rapport_journalier"),
]
