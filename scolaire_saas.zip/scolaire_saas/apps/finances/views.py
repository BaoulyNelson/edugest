"""Vues de gestion financière."""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import FileResponse, JsonResponse
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import F, Q, Sum, Value
from django.db.models.functions import Coalesce
from django.views.decorators.http import require_http_methods, require_POST
from decimal import Decimal, InvalidOperation
from apps.noyau.decorateurs import (
    requiert_tenant,
    requiert_permission,
    gerer_erreur_metier,
)
from apps.finances.models import (
    TypeFrais, FraisEleve, Paiement, FrequenceFrais, StatutPaiement,
)
from apps.finances.services import (
    ServicePaiement,
    ServiceCaisse,
    bornes_journee_locale,
)


def _peut_creer_inscription(request):
    return _possede_permission_finances(request, "eleves.inscrire.toutes_classes")


def _possede_permission_finances(request, code_permission):
    from apps.securite.rbac import moteur_rbac

    return moteur_rbac.possede_permission(
        utilisateur=request.user,
        ecole=request.etablissement,
        code_permission=code_permission,
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def tableau_bord_finances(request):
    from django.utils import timezone
    from django.db.models import Q, Sum
    from apps.finances.models import ModePaiement

    service_caisse = ServiceCaisse(request.etablissement)
    rapport = service_caisse.rapport_journalier()
    aujourd_hui = timezone.localdate()
    debut_mois = aujourd_hui.replace(day=1)
    debut_mois_local, _ = bornes_journee_locale(debut_mois)
    _, debut_demain = bornes_journee_locale(aujourd_hui)
    paiements_mois = Paiement.tous_objets.filter(
        ecole=request.etablissement,
        date_paiement__gte=debut_mois_local,
        date_paiement__lt=debut_demain,
        est_annule=False,
    )
    rapport["total_mois"] = (
        paiements_mois.aggregate(total=Sum("montant_paye"))["total"]
        or Decimal("0.00")
    )
    rapport["nombre_paiements_mois"] = paiements_mois.count()

    total_modes = sum(
        (mode["total"] for mode in rapport["par_mode_paiement"]),
        Decimal("0.00"),
    )
    libelles_modes = dict(ModePaiement.choices)
    for mode in rapport["par_mode_paiement"]:
        mode["libelle"] = libelles_modes.get(
            mode["mode_paiement"], mode["mode_paiement"]
        )
        mode["part"] = (
            round(mode["total"] * 100 / total_modes) if total_modes else 0
        )

    annee = request.annee_scolaire_courante
    frais_annee = FraisEleve.tous_objets.none()
    if annee:
        frais_annee = FraisEleve.tous_objets.filter(
            ecole=request.etablissement,
            inscription__annee_scolaire=annee,
        ).annotate(
            total_verse=Sum(
                "paiements__montant_paye",
                filter=Q(
                    paiements__est_annule=False,
                    paiements__statut__in=["partiel", "complet"],
                ),
            )
        )

    montant_a_recouvrer = Decimal("0.00")
    nombre_dettes = 0
    for frais in frais_annee:
        solde = max(frais.montant_net - (frais.total_verse or Decimal("0.00")), Decimal("0.00"))
        if solde > Decimal("0.01"):
            montant_a_recouvrer += solde
            nombre_dettes += 1

    debut_journee, debut_lendemain = bornes_journee_locale(rapport["date"])
    paiements_recents = (
        Paiement.tous_objets.filter(
            ecole=request.etablissement,
            date_paiement__gte=debut_journee,
            date_paiement__lt=debut_lendemain,
            est_annule=False,
        )
        .select_related(
            "frais_eleve__inscription__eleve",
            "frais_eleve__type_frais",
        )
        .order_by("-date_paiement")[:6]
    )
    return render(
        request,
        "finances/tableau_bord.html",
        {
            "rapport": rapport,
            "annee": annee,
            "montant_a_recouvrer": montant_a_recouvrer,
            "nombre_dettes": nombre_dettes,
            "paiements_recents": paiements_recents,
        },
    )


@login_required
@requiert_tenant
def liste_types_frais(request):
    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    types = TypeFrais.objects.filter(ecole=request.etablissement)
    if q:
        types = types.filter(Q(code__icontains=q) | Q(libelle__icontains=q))
    if statut in {"actif", "inactif"}:
        types = types.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    types = types.order_by("ordre_affichage", "libelle")
    return render(request, "finances/types_frais.html", {
        "types": types, "q": q, "filtre_statut": statut,
    })


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
@require_POST
def ajouter_types_frais_recommandes(request):
    from apps.finances.preconfiguration import preconfigurer_types_frais

    ajoutes = preconfigurer_types_frais(request.etablissement)
    if ajoutes:
        messages.success(
            request,
            f"{ajoutes} type(s) de frais recommandé(s) ajouté(s). "
            "Vérifiez les montants de référence avant toute assignation.",
        )
    else:
        messages.info(request, "Tous les types de frais recommandés sont déjà présents.")
    return redirect("finances:types_frais")


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_type_frais(request):
    from apps.finances import forms

    if request.method == "POST":
        form = forms.FormulaireTypeFrais(request.POST, ecole=request.etablissement)
        if form.is_valid():
            t = form.save(commit=False)
            t.ecole = request.etablissement
            t.save()
            messages.success(request, f"Type de frais {t.libelle} créé.")
            return redirect("finances:types_frais")
    else:
        form = forms.FormulaireTypeFrais(ecole=request.etablissement)
    return render(request, "finances/form_type_frais.html", {"form": form})


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def modifier_type_frais(request, pk):
    from apps.finances import forms

    type_frais = get_object_or_404(
        TypeFrais.tous_objets,
        pk=pk,
        ecole=request.etablissement,
    )
    if request.method == "POST":
        form = forms.FormulaireTypeFrais(
            request.POST,
            instance=type_frais,
            ecole=request.etablissement,
        )
        if form.is_valid():
            form.save()
            messages.success(request, f"Type de frais « {type_frais.libelle} » mis à jour.")
            return redirect("finances:types_frais")
    else:
        form = forms.FormulaireTypeFrais(
            instance=type_frais,
            ecole=request.etablissement,
        )
    return render(
        request,
        "finances/form_type_frais.html",
        {"form": form, "type_frais": type_frais},
    )


@login_required
@requiert_tenant
@requiert_permission("parametrage.modifier.etablissement")
def creer_type_frais_rapide(request):
    from apps.finances import forms

    if request.method == "GET":
        form = forms.FormulaireTypeFraisRapide(ecole=request.etablissement)
        return render(
            request,
            "finances/partials/form_type_frais_rapide.html",
            {"form": form},
        )
    if request.method != "POST":
        return JsonResponse({"erreur": "Méthode non autorisée."}, status=405)

    form = forms.FormulaireTypeFraisRapide(
        request.POST,
        ecole=request.etablissement,
    )
    if not form.is_valid():
        return JsonResponse(
            {"erreurs": form.errors.get_json_data()},
            status=400,
        )

    try:
        with transaction.atomic():
            type_frais = TypeFrais.objects.create(
                ecole=request.etablissement,
                code=form.cleaned_data["code"],
                libelle=form.cleaned_data["libelle"],
                frequence=form.cleaned_data["frequence"],
                montant_defaut=form.cleaned_data["montant_defaut"] or Decimal("0.00"),
            )
    except IntegrityError:
        return JsonResponse(
            {"erreur": "Ce code de frais existe déjà dans cet établissement."},
            status=409,
        )
    return JsonResponse(
        {
            "id": str(type_frais.pk),
            "type": "type_frais",
            "code": type_frais.code,
            "libelle": type_frais.libelle,
            "montant_defaut": str(type_frais.montant_defaut),
        },
        status=201,
    )


@login_required
@requiert_tenant
@requiert_permission("finances.encaisser.toutes_classes")
@require_http_methods(["GET", "POST"])
def creation_rapide_frais_eleve(request):
    from apps.academique.models import StatutAnneeScolaire
    from apps.finances import forms

    annee = request.annee_scolaire_courante
    if not annee or annee.statut != StatutAnneeScolaire.ACTIVE:
        return JsonResponse(
            {"erreur": "Sélectionnez l’année scolaire active avant de créer un frais."},
            status=409,
        )

    form = forms.FormulaireAssignerFrais(
        request.POST if request.method == "POST" else None,
        ecole=request.etablissement,
        annee_scolaire=annee,
    )
    contexte = {
        "form": form,
        "peut_creer_inscription": _peut_creer_inscription(request),
        "peut_creer_type_frais": _possede_permission_finances(
            request, "parametrage.modifier.etablissement"
        ),
    }
    if request.method == "GET":
        return render(
            request,
            "finances/partials/form_assigner_frais_rapide.html",
            contexte,
        )
    if not form.is_valid():
        return render(
            request,
            "finances/partials/form_assigner_frais_rapide.html",
            contexte,
            status=400,
        )

    try:
        with transaction.atomic():
            frais = form.save(commit=False)
            frais.ecole = request.etablissement
            frais.assigne_par = request.user
            frais.save()
    except IntegrityError:
        form.add_error(
            None,
            "Ce type de frais est déjà assigné à cette inscription.",
        )
        return render(
            request,
            "finances/partials/form_assigner_frais_rapide.html",
            contexte,
            status=409,
        )

    return JsonResponse(
        {
            "id": str(frais.pk),
            "label": str(frais),
            "type": "frais_eleve",
            "eleve": frais.inscription.eleve.nom_complet,
            "type_frais": frais.type_frais.libelle,
            "annee": frais.inscription.annee_scolaire.libelle,
            "net": f"{frais.montant_net:.2f}",
            "verse": "0.00",
            "solde": f"{frais.montant_net:.2f}",
        },
        status=201,
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def liste_frais_eleves(request):
    from apps.academique.models import Classe

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    type_id = request.GET.get("type", "")
    classe_id = request.GET.get("classe", "")
    statut = request.GET.get("statut", "")
    classes = (
        Classe.objects.filter(ecole=request.etablissement, annee_scolaire=annee)
        .order_by("code")
        if annee else Classe.objects.none()
    )
    types = TypeFrais.objects.filter(ecole=request.etablissement).order_by("libelle")
    frais = (
        FraisEleve.objects.filter(
            ecole=request.etablissement,
            inscription__annee_scolaire=annee,
        )
        .select_related("inscription__eleve", "type_frais")
        .annotate(
            montant_paye=Coalesce(
                Sum(
                    "paiements__montant_paye",
                    filter=Q(
                        paiements__est_annule=False,
                        paiements__statut__in=(
                            StatutPaiement.PARTIEL,
                            StatutPaiement.COMPLET,
                        ),
                    ),
                ),
                Value(Decimal("0.00")),
            )
        )
        .annotate(solde=F("montant_net") - F("montant_paye"))
        .order_by("-cree_le", "-pk")
    ) if annee else FraisEleve.objects.none()
    if q:
        frais = frais.filter(
            Q(inscription__eleve__nom__icontains=q)
            | Q(inscription__eleve__prenom__icontains=q)
            | Q(inscription__eleve__matricule__icontains=q)
            | Q(type_frais__libelle__icontains=q)
            | Q(type_frais__code__icontains=q)
            | Q(inscription__classe__code__icontains=q)
        )
    if type_id:
        try:
            type_pk = TypeFrais._meta.pk.to_python(type_id)
        except (TypeError, ValueError, ValidationError):
            type_pk = None
        if type_pk is not None and types.filter(pk=type_pk).exists():
            frais = frais.filter(type_frais_id=type_pk)
        else:
            type_id = ""
    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError, ValidationError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            frais = frais.filter(inscription__classe_id=classe_pk)
        else:
            classe_id = ""
    if statut == "du":
        frais = frais.filter(solde__gt=Decimal("0.01"))
    elif statut == "solde":
        frais = frais.filter(solde__lte=Decimal("0.01"))
    else:
        statut = ""
    return render(
        request,
        "finances/frais_eleves.html",
        {
            "frais": frais,
            "annee": annee,
            "q": q,
            "types": types,
            "classes": classes,
            "filtre_type": type_id,
            "filtre_classe": classe_id,
            "filtre_statut": statut,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.encaisser.toutes_classes")
def importer_frais_eleves(request):
    """Importe les frais d'élèves en calculant leur montant net au modèle."""
    from apps.eleves.models import Inscription
    from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
    from apps.noyau.csv_utils import lire_csv
    from apps.noyau.exceptions import ErreurMetierBase

    annee = request.annee_scolaire_courante
    if annee and annee.statut != StatutAnneeScolaire.ACTIVE:
        annee = None
    resultat = None
    if request.method == "POST":
        fichier = request.FILES.get("fichier_csv")
        if not fichier:
            messages.error(request, "Sélectionnez un fichier CSV.")
        elif not annee:
            messages.error(request, "Aucune année scolaire active.")
        else:
            try:
                lecteur = lire_csv(
                    fichier,
                    {
                        "matricule", "type_frais_code", "montant_brut",
                        "remise_montant", "remise_pourcentage", "motif_remise",
                    },
                )
                crees, erreurs = 0, []
                for numero, ligne in enumerate(lecteur, start=2):
                    try:
                        with transaction.atomic():
                            inscription = Inscription.objects.get(
                                ecole=request.etablissement,
                                annee_scolaire=annee,
                                eleve__matricule=(ligne.get("matricule") or "").strip(),
                            )
                            type_frais = TypeFrais.objects.get(
                                ecole=request.etablissement,
                                code=(ligne.get("type_frais_code") or "").strip(),
                                est_actif=True,
                            )
                            if FraisEleve.objects.filter(
                                ecole=request.etablissement,
                                inscription=inscription,
                                type_frais=type_frais,
                            ).exists():
                                raise ValueError(
                                    "Un frais de ce type est déjà assigné à cette inscription."
                                )
                            montant_brut = Decimal(
                                (ligne.get("montant_brut") or "").strip().replace(",", ".")
                            )
                            remise_montant = Decimal(
                                (ligne.get("remise_montant") or "0").strip().replace(",", ".")
                            )
                            remise_pourcentage = Decimal(
                                (ligne.get("remise_pourcentage") or "0").strip().replace(",", ".")
                            )
                            frais = FraisEleve(
                                ecole=request.etablissement,
                                inscription=inscription,
                                type_frais=type_frais,
                                montant_brut=montant_brut,
                                remise_montant=remise_montant,
                                remise_pourcentage=remise_pourcentage,
                                motif_remise=(ligne.get("motif_remise") or "").strip(),
                                assigne_par=request.user,
                            )
                            frais.full_clean()
                            frais.save()
                        crees += 1
                    except (
                        Inscription.DoesNotExist,
                        Inscription.MultipleObjectsReturned,
                        TypeFrais.DoesNotExist,
                        TypeFrais.MultipleObjectsReturned,
                        ErreurMetierBase,
                        ValidationError,
                        InvalidOperation,
                        ValueError,
                        IntegrityError,
                    ) as erreur:
                        erreurs.append(f"Ligne {numero} : {erreur}")
                resultat = {"crees": crees, "erreurs": erreurs}
            except ValueError as erreur:
                messages.error(request, f"Import impossible : {erreur}")

    return render(
        request,
        "noyau/importer_metier.html",
        {
            "titre": "Importer des frais par élève",
            "description": "Les frais sont rattachés aux inscriptions de l’année active. Le montant net est recalculé automatiquement. Les doublons sont refusés.",
            "entetes": "matricule;type_frais_code;montant_brut;remise_montant;remise_pourcentage;motif_remise",
            "retour_url": "finances:frais_eleves",
            "resultat": resultat,
            "nombre": resultat["crees"] if resultat else 0,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.encaisser.toutes_classes")
def assigner_frais(request):
    from apps.finances import forms
    from apps.academique.models import StatutAnneeScolaire

    annee = request.annee_scolaire_courante
    if not annee or annee.statut != StatutAnneeScolaire.ACTIVE:
        annee = None
        messages.warning(
            request, "Sélectionnez l’année scolaire active pour assigner des frais."
        )

    if request.method == "POST":
        form = forms.FormulaireAssignerFrais(
            request.POST,
            ecole=request.etablissement,
            annee_scolaire=annee,
        )
        if form.is_valid():
            frais = form.save(commit=False)
            frais.ecole = request.etablissement
            frais.assigne_par = request.user
            frais.save()
            messages.success(request, "Frais assigné.")
            return redirect("finances:frais_eleves")
    else:
        from apps.eleves.models import Inscription

        initial = {}
        inscription_id = request.GET.get("inscription")
        if inscription_id:
            inscription = get_object_or_404(
                Inscription.objects.filter(
                    ecole=request.etablissement,
                    annee_scolaire=annee,
                ),
                pk=inscription_id,
            )
            initial["inscription"] = inscription.pk
        form = forms.FormulaireAssignerFrais(
            ecole=request.etablissement,
            annee_scolaire=annee,
            initial=initial,
        )
    from apps.securite.rbac import moteur_rbac

    types_frais_data = {
        str(type_frais.pk): {
            "montant_defaut": str(type_frais.montant_defaut),
        }
        for type_frais in form.fields["type_frais"].queryset
    }
    return render(
        request,
        "finances/form_assigner_frais.html",
        {
            "form": form,
            "annee": annee,
            "types_frais_data": types_frais_data,
            "frequence_frais_choices": FrequenceFrais.choices,
            "peut_creer_inscription": _peut_creer_inscription(request),
            "peut_creer_type_frais": moteur_rbac.possede_permission(
                utilisateur=request.user,
                ecole=request.etablissement,
                code_permission="parametrage.modifier.etablissement",
            ),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def liste_paiements(request):
    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    mode = request.GET.get("mode", "")
    statut = request.GET.get("statut", "")
    paiements = (
        Paiement.objects.filter(ecole=request.etablissement, est_annule=False)
        .filter(frais_eleve__inscription__annee_scolaire=annee)
        .select_related(
            "frais_eleve__inscription__eleve",
            "frais_eleve__type_frais",
            "caissier",
        )
        .order_by("-date_paiement")
    ) if annee else Paiement.objects.none()
    if q:
        paiements = paiements.filter(
            Q(numero_recu__icontains=q)
            | Q(frais_eleve__inscription__eleve__nom__icontains=q)
            | Q(frais_eleve__inscription__eleve__prenom__icontains=q)
            | Q(frais_eleve__inscription__eleve__matricule__icontains=q)
            | Q(frais_eleve__type_frais__libelle__icontains=q)
            | Q(caissier__nom__icontains=q)
            | Q(caissier__prenom__icontains=q)
        )
    if mode in dict(Paiement._meta.get_field("mode_paiement").choices):
        paiements = paiements.filter(mode_paiement=mode)
    else:
        mode = ""
    if statut in {StatutPaiement.PARTIEL, StatutPaiement.COMPLET}:
        paiements = paiements.filter(statut=statut)
    else:
        statut = ""
    paginator = Paginator(paiements, 25)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "finances/paiements.html",
        {
            "paiements": page_obj.object_list,
            "page_obj": page_obj,
            "annee": annee,
            "q": q,
            "filtre_mode": mode,
            "filtre_statut": statut,
            "mode_choices": Paiement._meta.get_field("mode_paiement").choices,
            "statut_choices": (
                (StatutPaiement.PARTIEL, "Partiel"),
                (StatutPaiement.COMPLET, "Complet"),
            ),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.encaisser.toutes_classes")
def importer_paiements(request):
    """Importe les paiements via le service qui crée reçus, journal et audit."""
    from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
    from apps.noyau.csv_utils import lire_csv
    from apps.noyau.exceptions import ErreurMetierBase

    annee = request.annee_scolaire_courante
    if annee and annee.statut != StatutAnneeScolaire.ACTIVE:
        annee = None
    resultat = None
    if request.method == "POST":
        fichier = request.FILES.get("fichier_csv")
        if not fichier:
            messages.error(request, "Sélectionnez un fichier CSV.")
        elif not annee:
            messages.error(request, "Aucune année scolaire active.")
        else:
            try:
                lecteur = lire_csv(
                    fichier,
                    {
                        "matricule", "type_frais_code", "montant_paye",
                        "mode_paiement", "reference_externe", "observations",
                    },
                )
                crees, erreurs = 0, []
                for numero, ligne in enumerate(lecteur, start=2):
                    try:
                        with transaction.atomic():
                            frais = FraisEleve.objects.get(
                                ecole=request.etablissement,
                                inscription__annee_scolaire=annee,
                                inscription__eleve__matricule=(
                                    ligne.get("matricule") or ""
                                ).strip(),
                                type_frais__code=(
                                    ligne.get("type_frais_code") or ""
                                ).strip(),
                            )
                            montant = Decimal(
                                (ligne.get("montant_paye") or "")
                                .strip()
                                .replace(",", ".")
                            )
                            mode = (ligne.get("mode_paiement") or "").strip() or "especes"
                            Paiement._meta.get_field("mode_paiement").clean(mode, None)
                            ServicePaiement(request.user, request.etablissement).enregistrer(
                                frais_eleve=frais,
                                montant=montant,
                                mode_paiement=mode,
                                reference_externe=(
                                    ligne.get("reference_externe") or ""
                                ).strip(),
                                observations=(ligne.get("observations") or "").strip(),
                            )
                        crees += 1
                    except (
                        FraisEleve.DoesNotExist,
                        FraisEleve.MultipleObjectsReturned,
                        ErreurMetierBase,
                        ValidationError,
                        InvalidOperation,
                        ValueError,
                        IntegrityError,
                    ) as erreur:
                        erreurs.append(f"Ligne {numero} : {erreur}")
                resultat = {"crees": crees, "erreurs": erreurs}
            except ValueError as erreur:
                messages.error(request, f"Import impossible : {erreur}")

    return render(
        request,
        "noyau/importer_metier.html",
        {
            "titre": "Importer des paiements",
            "description": "Chaque ligne doit désigner un frais assigné de l’année active. Le service vérifie le solde et génère un reçu, une écriture de caisse et une trace d’audit.",
            "entetes": "matricule;type_frais_code;montant_paye;mode_paiement;reference_externe;observations",
            "retour_url": "finances:paiements",
            "resultat": resultat,
            "nombre": resultat["crees"] if resultat else 0,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.encaisser.toutes_classes")
@gerer_erreur_metier
def enregistrer_paiement(request):
    from apps.finances import forms
    from apps.academique.models import StatutAnneeScolaire
    from decimal import Decimal
    from django.db.models import Q, Sum

    annee = request.annee_scolaire_courante
    if not annee or annee.statut != StatutAnneeScolaire.ACTIVE:
        annee = None
        messages.warning(
            request, "Sélectionnez l’année scolaire active pour enregistrer un paiement."
        )

    if request.method == "POST":
        form = forms.FormulairePaiement(
            request.POST,
            ecole=request.etablissement,
            annee_scolaire=annee,
        )
        if form.is_valid():
            service = ServicePaiement(request.user, request.etablissement)
            paiement = service.enregistrer(
                frais_eleve=form.cleaned_data["frais_eleve"],
                montant=form.cleaned_data["montant"],
                mode_paiement=form.cleaned_data["mode_paiement"],
                reference_externe=form.cleaned_data.get("reference_externe", ""),
            )
            messages.success(
                request, f"Paiement enregistré — Reçu #{paiement.numero_recu}"
            )
            return redirect("finances:confirmation_paiement", pk=paiement.pk)
    else:
        frais_id = request.GET.get("frais_id")
        form = forms.FormulairePaiement(
            ecole=request.etablissement,
            annee_scolaire=annee,
            initial={"frais_eleve": frais_id},
        )
    eleve_id = request.GET.get("eleve_id")
    if eleve_id:
        frais_eleve_field = form.fields["frais_eleve"]
        frais_eleve_field.queryset = frais_eleve_field.queryset.filter(
            inscription__eleve_id=eleve_id
        )
        if request.method == "GET" and not request.GET.get("frais_id"):
            frais_unique = frais_eleve_field.queryset.first()
            if frais_unique and frais_eleve_field.queryset.count() == 1:
                form.initial["frais_eleve"] = frais_unique.pk
    frais_selectionne_id = form["frais_eleve"].value()
    soldes_frais = {}
    for frais in form.fields["frais_eleve"].queryset.annotate(
        montant_verse=Sum(
            "paiements__montant_paye",
            filter=Q(
                paiements__est_annule=False,
                paiements__statut__in=["partiel", "complet"],
            ),
        )
    ):
        verse = frais.montant_verse or Decimal("0.00")
        solde = max(frais.montant_net - verse, Decimal("0.00"))
        soldes_frais[str(frais.pk)] = {
            "eleve": frais.inscription.eleve.nom_complet,
            "type": frais.type_frais.libelle,
            "annee": frais.inscription.annee_scolaire.libelle,
            "net": str(frais.montant_net),
            "verse": str(verse),
            "solde": str(solde),
        }
    return render(
        request,
        "finances/form_paiement.html",
        {
            "form": form,
            "annee": annee,
            "soldes_frais": soldes_frais,
            "frais_selectionne_id": str(frais_selectionne_id or ""),
            "peut_creer_inscription": _peut_creer_inscription(request),
            "peut_creer_type_frais": _possede_permission_finances(
                request, "parametrage.modifier.etablissement"
            ),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def confirmation_paiement(request, pk):
    paiement = get_object_or_404(
        Paiement.tous_objets.select_related(
            "frais_eleve__inscription__eleve",
            "frais_eleve__inscription__classe",
            "frais_eleve__inscription__annee_scolaire",
            "frais_eleve__type_frais",
            "caissier",
        ),
        pk=pk,
        ecole=request.etablissement,
    )
    return render(
        request,
        "finances/confirmation_paiement.html",
        {
            "paiement": paiement,
            "solde_restant": paiement.frais_eleve.solde_restant(),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.annuler.toutes_classes")
@gerer_erreur_metier
def annuler_paiement(request, pk):
    paiement = get_object_or_404(Paiement, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        motif = request.POST.get("motif", "")
        service = ServicePaiement(request.user, request.etablissement)
        service.annuler(paiement, motif)
        messages.warning(request, f"Paiement #{paiement.numero_recu} annulé.")
    return redirect("finances:paiements")


@login_required
@requiert_tenant
def telecharger_recu(request, pk):
    paiement = get_object_or_404(Paiement, pk=pk, ecole=request.etablissement)
    service = ServicePaiement(request.user, request.etablissement)
    buffer = service.generer_recu_pdf(paiement)
    return FileResponse(
        buffer,
        content_type="application/pdf",
        as_attachment=True,
        filename=f"recu_{paiement.numero_recu}.pdf",
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def journal_caisse(request):
    from datetime import date, datetime, time, timedelta
    from django.core.paginator import Paginator
    from django.db.models import Count, Q, Sum
    from django.utils import timezone
    from apps.finances.models import EcritureJournal, TypeEcritureJournal

    annee = request.annee_scolaire_courante
    aujourd_hui = timezone.localdate()
    if annee:
        date_fin_defaut = min(aujourd_hui, annee.date_fin)
        if date_fin_defaut < annee.date_debut:
            date_fin_defaut = annee.date_debut
        date_debut_defaut = max(
            date_fin_defaut.replace(day=1),
            annee.date_debut,
        )
        date_debut_defaut = min(date_debut_defaut, date_fin_defaut)
    else:
        date_debut_defaut = aujourd_hui.replace(day=1)
        date_fin_defaut = aujourd_hui

    try:
        date_debut = date.fromisoformat(
            request.GET.get("date_debut", date_debut_defaut.isoformat())
        )
        date_fin = date.fromisoformat(
            request.GET.get("date_fin", date_fin_defaut.isoformat())
        )
        if date_debut > date_fin:
            raise ValueError("La date de début dépasse la date de fin.")
        if annee and (
            date_debut < annee.date_debut or date_fin > annee.date_fin
        ):
            raise ValueError("La période doit rester dans l’année scolaire sélectionnée.")
    except ValueError as erreur:
        messages.error(request, f"Période invalide : {erreur}")
        date_debut = date_debut_defaut
        date_fin = date_fin_defaut

    ecritures_annee = (
        EcritureJournal.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=annee,
        )
        if annee
        else EcritureJournal.objects.none()
    )
    debut_periode = timezone.make_aware(datetime.combine(date_debut, time.min))
    fin_periode_exclusive = timezone.make_aware(
        datetime.combine(date_fin + timedelta(days=1), time.min)
    )
    ecritures_periode = ecritures_annee.filter(
        date_ecriture__gte=debut_periode,
        date_ecriture__lt=fin_periode_exclusive,
    )
    avant_periode = ecritures_annee.filter(
        date_ecriture__lt=debut_periode,
    ).aggregate(total=Sum("montant"))["total"] or Decimal("0.00")
    resume_periode = ecritures_periode.aggregate(
        entrees=Sum("montant", filter=Q(montant__gt=0)),
        sorties=Sum("montant", filter=Q(montant__lt=0)),
        nombre=Count("pk"),
    )
    total_entrees = resume_periode["entrees"] or Decimal("0.00")
    total_sorties = abs(resume_periode["sorties"] or Decimal("0.00"))
    net_periode = total_entrees - total_sorties
    recapitulatif_types = (
        ecritures_periode.values("type_ecriture")
        .annotate(nombre=Count("pk"), total=Sum("montant"))
        .order_by("type_ecriture")
    )
    libelles_types = dict(TypeEcritureJournal.choices)
    recapitulatif_types = [
        {
            **ligne,
            "libelle": libelles_types.get(ligne["type_ecriture"], ligne["type_ecriture"]),
        }
        for ligne in recapitulatif_types
    ]

    ecritures = ecritures_periode.select_related(
        "saisie_par",
        "paiement__caissier",
        "paiement__frais_eleve__inscription__eleve",
        "paiement__frais_eleve__type_frais",
    ).order_by("-date_ecriture", "-pk")
    q = request.GET.get("q", "").strip()
    type_ecriture = request.GET.get("type_ecriture", "")
    if q:
        ecritures = ecritures.filter(
            Q(libelle__icontains=q)
            | Q(paiement__numero_recu__icontains=q)
            | Q(paiement__frais_eleve__inscription__eleve__nom__icontains=q)
            | Q(paiement__frais_eleve__inscription__eleve__prenom__icontains=q)
            | Q(paiement__frais_eleve__inscription__eleve__matricule__icontains=q)
            | Q(saisie_par__nom__icontains=q)
            | Q(saisie_par__prenom__icontains=q)
        )
    if type_ecriture in dict(TypeEcritureJournal.choices):
        ecritures = ecritures.filter(type_ecriture=type_ecriture)
    else:
        type_ecriture = ""
    page_ecritures = Paginator(ecritures, 50).get_page(request.GET.get("page"))
    query_sans_page = request.GET.copy()
    query_sans_page.pop("page", None)
    return render(
        request,
        "finances/caisse.html",
        {
            "ecritures": page_ecritures,
            "annee": annee,
            "date_debut": date_debut,
            "date_fin": date_fin,
            "solde_ouverture": avant_periode,
            "total_entrees": total_entrees,
            "total_sorties": total_sorties,
            "net_periode": net_periode,
            "solde_cloture": avant_periode + net_periode,
            "nombre_ecritures": resume_periode["nombre"] or 0,
            "recapitulatif_types": recapitulatif_types,
            "query_sans_page": query_sans_page,
            "q": q,
            "filtre_type_ecriture": type_ecriture,
            "type_ecriture_choices": TypeEcritureJournal.choices,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def soldes_eleves(request):
    from apps.academique.models import Classe

    annee = request.annee_scolaire_courante
    classe_id = request.GET.get("classe_id")
    q = request.GET.get("q", "").strip()
    statut = request.GET.get("statut", "")
    soldes = []
    classes = Classe.objects.filter(
        ecole=request.etablissement, annee_scolaire=annee
    ).order_by("code") if annee else Classe.objects.none()
    classes_a_afficher = (
        [get_object_or_404(classes, pk=classe_id)]
        if classe_id and annee
        else classes
    )
    service_caisse = ServiceCaisse(request.etablissement)
    for classe in classes_a_afficher:
        for ligne in service_caisse.soldes_par_classe(classe):
            ligne["classe"] = classe
            soldes.append(ligne)
    if q:
        terme = q.casefold()
        soldes = [
            ligne for ligne in soldes
            if terme in ligne["eleve"].nom_complet.casefold()
            or terme in ligne["eleve"].matricule.casefold()
        ]
    if statut == "du":
        soldes = [ligne for ligne in soldes if not ligne["est_solde"]]
    elif statut == "solde":
        soldes = [ligne for ligne in soldes if ligne["est_solde"]]
    else:
        statut = ""
    soldes.sort(key=lambda ligne: ligne["solde"], reverse=True)
    return render(
        request,
        "finances/soldes.html",
        {
            "soldes": soldes,
            "classes": classes,
            "annee": annee,
            "q": q,
            "filtre_statut": statut,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("finances.consulter.toutes_classes")
def rapport_journalier(request):
    from django.utils import timezone

    date_str = request.GET.get("date")
    date_cible = None
    if date_str:
        from datetime import date

        try:
            date_cible = date.fromisoformat(date_str)
        except ValueError:
            pass
    service_caisse = ServiceCaisse(request.etablissement)
    rapport = service_caisse.rapport_journalier(date=date_cible)
    return render(request, "finances/rapport_journalier.html", {"rapport": rapport})
