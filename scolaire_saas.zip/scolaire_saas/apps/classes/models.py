"""apps/classes/models.py — proxy vers academique."""
# Les classes sont gérées dans apps.academique.models (Classe, MatiereClasse).
# Ce module est un alias pour compatibilité d'imports.
from apps.academique.models import Classe, MatiereClasse
__all__ = ["Classe", "MatiereClasse"]
