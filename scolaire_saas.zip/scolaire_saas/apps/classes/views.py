"""Vues des classes (raccourcis vers les vues académique)."""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from apps.noyau.decorateurs import requiert_tenant
from apps.academique.models import Classe
from apps.parametrage.models import Niveau


@login_required
@requiert_tenant
def liste_classes(request):
    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    niveau_id = request.GET.get("niveau", "")
    niveaux = Niveau.objects.filter(
        ecole=request.etablissement,
        classes__annee_scolaire=annee,
    ).distinct().order_by("cycle__ordre_affichage", "ordre_affichage") if annee else Niveau.objects.none()
    classes = Classe.objects.filter(
        ecole=request.etablissement, annee_scolaire=annee
    ).select_related("niveau", "enseignant_titulaire") if annee else Classe.objects.none()
    if q:
        classes = classes.filter(
            Q(code__icontains=q)
            | Q(libelle__icontains=q)
            | Q(niveau__libelle__icontains=q)
            | Q(enseignant_titulaire__nom__icontains=q)
            | Q(enseignant_titulaire__prenom__icontains=q)
        )
    if niveau_id:
        try:
            niveau_pk = int(niveau_id)
        except (TypeError, ValueError):
            niveau_pk = None
        if niveau_pk is not None and niveaux.filter(pk=niveau_pk).exists():
            classes = classes.filter(niveau_id=niveau_pk)
        else:
            niveau_id = ""
    statut = request.GET.get("statut", "")
    if statut in {"actif", "inactif"}:
        classes = classes.filter(est_actif=(statut == "actif"))
    else:
        statut = ""
    return render(request, "classes/liste.html", {
        "classes": classes,
        "annee": annee,
        "q": q,
        "niveaux": niveaux,
        "filtre_niveau": niveau_id,
        "filtre_statut": statut,
    })


@login_required
@requiert_tenant
def detail_classe(request, pk):
    classe = get_object_or_404(Classe, pk=pk, ecole=request.etablissement)
    return render(request, "classes/detail.html", {"classe": classe})


@login_required
@requiert_tenant
def effectif_classe(request, pk):
    classe = get_object_or_404(Classe, pk=pk, ecole=request.etablissement)
    from apps.eleves.models import Inscription, StatutInscription
    q = request.GET.get("q", "").strip()
    inscrits = Inscription.objects.filter(
        ecole=request.etablissement,
        classe=classe,
        statut=StatutInscription.VALIDEE,
    ).select_related("eleve")
    nombre_total = inscrits.count()
    if q:
        inscrits = inscrits.filter(
            Q(eleve__nom__icontains=q)
            | Q(eleve__prenom__icontains=q)
            | Q(eleve__matricule__icontains=q)
        )
    return render(request, "classes/effectif.html", {
        "classe": classe, "inscrits": inscrits, "q": q,
        "nombre_total": nombre_total,
    })


@login_required
@requiert_tenant
def notes_classe(request, pk):
    classe = get_object_or_404(Classe, pk=pk, ecole=request.etablissement)
    return redirect("notes:saisie")


@login_required
@requiert_tenant
def bulletins_classe(request, pk):
    classe = get_object_or_404(Classe, pk=pk, ecole=request.etablissement)
    return redirect("bulletins:liste")


@login_required
@requiert_tenant
def badges_classe(request, pk):
    return redirect("badges:badges_classe", classe_id=pk)
