from django.urls import path
from apps.classes import views
app_name = "classes"
urlpatterns = [
    path("", views.liste_classes, name="liste"),
    path("<int:pk>/", views.detail_classe, name="detail"),
    path("<int:pk>/effectif/", views.effectif_classe, name="effectif"),
    path("<int:pk>/notes/", views.notes_classe, name="notes"),
    path("<int:pk>/bulletins/", views.bulletins_classe, name="bulletins"),
    path("<int:pk>/badges/", views.badges_classe, name="badges"),
]
