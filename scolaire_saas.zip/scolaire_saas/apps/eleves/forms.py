"""Formulaires de gestion des élèves."""
from django import forms
from django.utils import timezone
from apps.academique.models import AnneeScolaire, Classe
from apps.eleves.models import (
    Eleve,
    Inscription,
    MouvementEleve,
    DossierDisciplinaire,
    TypeInscription,
)

FC = {"class": "form-control"}
FS = {"class": "form-select"}


class SelectClasseAnnee(forms.Select):
    def create_option(self, name, value, label, selected, index, subindex=None, attrs=None):
        option = super().create_option(
            name, value, label, selected, index, subindex=subindex, attrs=attrs
        )
        classe = getattr(value, "instance", None)
        annee_id = getattr(classe, "annee_scolaire_id", None)
        if annee_id:
            option["attrs"]["data-annee"] = str(annee_id)
        return option


class FormulaireEleve(forms.ModelForm):
    """
    Formulaire de création/modification d'un élève.
    Le matricule est exclu — généré automatiquement dans Eleve.save().
    """
    class Meta:
        model  = Eleve
        fields = [
            "nom", "prenom", "date_naissance", "lieu_naissance",
            "departement_naissance", "sexe", "nationalite",
            "photo", "adresse",
            "nom_pere", "telephone_parent1",
            "groupe_sanguin",
        ]
        widgets = {
            "date_naissance": forms.DateInput(
                format="%Y-%m-%d",
                attrs={**FC, "type": "date"},
            ),
            "adresse":        forms.Textarea(attrs={**FC, "rows": 2}),
            "sexe":           forms.Select(attrs=FS),
            "photo":          forms.FileInput(attrs=FC),
            **{f: forms.TextInput(attrs=FC) for f in [
                "nom", "prenom", "lieu_naissance", "departement_naissance",
                "nationalite", "nom_pere", 
                "telephone_parent1", "groupe_sanguin",
            ]},
        }


class FormulaireEleveRapide(forms.ModelForm):
    class Meta:
        model = Eleve
        fields = ["nom", "prenom", "date_naissance", "sexe"]
        widgets = {
            "nom": forms.TextInput(attrs=FC),
            "prenom": forms.TextInput(attrs=FC),
            "date_naissance": forms.DateInput(
                format="%Y-%m-%d",
                attrs={**FC, "type": "date"},
            ),
            "sexe": forms.Select(attrs=FS),
        }


class FormulaireInscription(forms.ModelForm):
    """
    Formulaire d'inscription d'un élève dans une classe.
    numero_ordre exclu — généré automatiquement dans Inscription.save().
    Les querysets sont filtrés par école (tenant).
    """
    def __init__(
        self,
        *args,
        ecole=None,
        annee_scolaire=None,
        date_inscription=None,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["frais_inscription"].label = (
                "Montant indicatif d’inscription "
                f"({ecole.devise_monetaire})"
            )
        date_inscription = date_inscription or timezone.localdate()
        self.initial["date_inscription"] = date_inscription
        self.fields["date_inscription"].initial = date_inscription
        self.fields["date_inscription"].disabled = True
        self.fields["date_inscription"].help_text = (
            "Renseignée automatiquement à la date du jour."
        )

        if ecole:
            from apps.academique.models import AnneeScolaire, StatutAnneeScolaire, Classe
            annees = AnneeScolaire.objects.filter(
                ecole=ecole, statut=StatutAnneeScolaire.ACTIVE
            )
            self.fields["annee_scolaire"].queryset = annees

            annee_id = self.data.get("annee_scolaire") if self.is_bound else None
            if annee_id:
                annee_scolaire = annees.filter(pk=annee_id).first()
            elif annee_scolaire:
                annee_scolaire = annees.filter(pk=annee_scolaire.pk).first()
            if not annee_scolaire:
                annee_scolaire = annees.first()
            if annee_scolaire:
                self.initial.setdefault("annee_scolaire", annee_scolaire.pk)

            eleves_deja_inscrits = Inscription.objects.filter(
                ecole=ecole,
                annee_scolaire=annee_scolaire,
            ).values("eleve_id") if annee_scolaire else Inscription.objects.none()
            self.fields["eleve"].queryset = (
                Eleve.objects.filter(
                    ecole=ecole,
                    statut="actif",
                    supprime_le__isnull=True,
                )
                .exclude(pk__in=eleves_deja_inscrits)
                .order_by("nom", "prenom")
            )
            classes = Classe.objects.filter(ecole=ecole, est_actif=True)
            if annee_scolaire:
                classes = classes.filter(annee_scolaire=annee_scolaire)
            else:
                classes = classes.none()
            self.fields["classe"].queryset = classes.order_by("code")
            self.fields["classe"].widget = SelectClasseAnnee(attrs=FS)
        # Appliquer les classes CSS sur tous les widgets
        for field in self.fields.values():
            css = FS if isinstance(field.widget, forms.Select) else FC
            field.widget.attrs.setdefault("class", css["class"])

    class Meta:
        model  = Inscription
        fields = [
            "eleve", "annee_scolaire", "classe",
            "type_inscription", "date_inscription",
            "frais_inscription", "observations",
        ]
        widgets = {
            "date_inscription": forms.DateInput(
                format="%Y-%m-%d",
                attrs={**FC, "type": "date"},
            ),
            "frais_inscription": forms.NumberInput(
                attrs={**FC, "step": "0.01", "placeholder": "0,00"}
            ),
            "observations":     forms.Textarea(attrs={**FC, "rows": 2}),
        }
        labels = {
            "frais_inscription": "Montant indicatif d’inscription (HTG)",
        }
        help_texts = {
            "frais_inscription": (
                "Information conservée sur l’inscription; elle ne crée pas une dette "
                "financière et ne peut pas être encaissée. Pour suivre un montant dû, "
                "assignez un frais dans l’onglet Frais & Paiements."
            ),
        }


class FormulaireInscriptionGroupe(forms.Form):
    annee_scolaire = forms.ModelChoiceField(
        queryset=AnneeScolaire.objects.none(),
        label="Année scolaire",
        widget=forms.Select(attrs=FS),
    )
    classe = forms.ModelChoiceField(
        queryset=Classe.objects.none(),
        label="Classe",
        widget=forms.Select(attrs=FS),
    )
    type_inscription = forms.ChoiceField(
        choices=TypeInscription.choices,
        label="Type d’inscription",
        widget=forms.Select(attrs=FS),
    )
    eleves = forms.ModelMultipleChoiceField(
        queryset=Eleve.objects.none(),
        label="Élèves à inscrire",
        widget=forms.CheckboxSelectMultiple,
        error_messages={"required": "Sélectionnez au moins un élève."},
    )
    frais_inscription = forms.DecimalField(
        required=False,
        min_value=0,
        label="Montant indicatif d’inscription par élève (HTG)",
        widget=forms.NumberInput(
            attrs={**FC, "step": "0.01", "min": "0", "placeholder": "0,00"}
        ),
        help_text=(
            "Valeur informative seulement; elle ne crée pas de dette à encaisser. "
            "Les frais à suivre se créent dans Finances."
        ),
    )
    observations = forms.CharField(
        required=False,
        label="Observations communes",
        widget=forms.Textarea(attrs={**FC, "rows": 2}),
    )

    def __init__(self, *args, ecole=None, **kwargs):
        super().__init__(*args, **kwargs)
        if ecole:
            self.fields["frais_inscription"].label = (
                "Montant indicatif d’inscription par élève "
                f"({ecole.devise_monetaire})"
            )
        from apps.academique.models import AnneeScolaire, Classe, StatutAnneeScolaire

        annees = AnneeScolaire.objects.filter(
            ecole=ecole,
            statut=StatutAnneeScolaire.ACTIVE,
        )
        self.fields["annee_scolaire"].queryset = annees
        annee_id = self.data.get("annee_scolaire") if self.is_bound else None
        if annee_id:
            annee = annees.filter(pk=annee_id).first()
        else:
            annee = annees.first()
            if annee:
                self.initial.setdefault("annee_scolaire", annee.pk)

        classes = Classe.objects.filter(ecole=ecole, est_actif=True)
        if annee:
            classes = classes.filter(annee_scolaire=annee)
        else:
            classes = classes.none()
        self.fields["classe"].queryset = classes.order_by("code")

        if annee:
            eleves_deja_inscrits = Inscription.objects.filter(
                ecole=ecole,
                annee_scolaire=annee,
            ).values("eleve_id")
            self.fields["eleves"].queryset = (
                Eleve.objects.filter(
                    ecole=ecole,
                    statut="actif",
                    supprime_le__isnull=True,
                )
                .exclude(pk__in=eleves_deja_inscrits)
                .order_by("nom", "prenom")
            )

    def clean(self):
        cleaned_data = super().clean()
        annee = cleaned_data.get("annee_scolaire")
        classe = cleaned_data.get("classe")
        eleves = cleaned_data.get("eleves")
        if annee and classe and classe.annee_scolaire_id != annee.pk:
            self.add_error("classe", "Choisissez une classe de l’année sélectionnée.")
        if annee and not annee.accepte_inscriptions:
            self.add_error("annee_scolaire", "Cette année n’accepte pas les inscriptions.")
        if classe and eleves and classe.capacite_max is not None:
            places_restantes = max(classe.capacite_max - classe.nb_inscrits(), 0)
            if eleves.count() > places_restantes:
                self.add_error(
                    "eleves",
                    f"Cette classe ne dispose que de {places_restantes} place(s) restante(s).",
                )
        return cleaned_data


class FormulaireMouvement(forms.ModelForm):
    """Enregistrement d'un mouvement (transfert, abandon, suspension...)."""
    class Meta:
        model  = MouvementEleve
        fields = [
            "type_mouvement", "date_mouvement", "motif",
            "etablissement_destination", "etablissement_origine",
            "document_joint",
        ]
        widgets = {
            "type_mouvement":            forms.Select(attrs=FS),
            "date_mouvement":            forms.DateInput(attrs={**FC, "type": "date"}),
            "motif":                     forms.Textarea(attrs={**FC, "rows": 3}),
            "etablissement_destination": forms.TextInput(attrs=FC),
            "etablissement_origine":     forms.TextInput(attrs=FC),
            "document_joint":            forms.FileInput(attrs=FC),
        }


class FormulaireDiscipline(forms.ModelForm):
    """Enregistrement d'un incident disciplinaire."""
    class Meta:
        model  = DossierDisciplinaire
        fields = [
            "type_discipline", "date_incident", "description",
            "sanction_appliquee", "est_leve", "date_levee",
        ]
        widgets = {
            "type_discipline":    forms.Select(attrs=FS),
            "date_incident":      forms.DateInput(attrs={**FC, "type": "date"}),
            "date_levee":         forms.DateInput(attrs={**FC, "type": "date"}),
            "description":        forms.Textarea(attrs={**FC, "rows": 3}),
            "sanction_appliquee": forms.Textarea(attrs={**FC, "rows": 2}),
            "est_leve":           forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }