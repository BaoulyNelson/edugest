"""apps/eleves/services.py — ServiceInscription."""
from django.db import transaction
from django.utils import timezone
from apps.noyau.exceptions import RegleMetierError, DonneesInvalidesError
from apps.securite.rbac import ServiceAudit

class ServiceInscription:
    def __init__(self, utilisateur):
        self.utilisateur = utilisateur
        self.audit = ServiceAudit(utilisateur)

    @transaction.atomic
    def inscrire(self, eleve, annee, classe, type_inscription="nouveau", frais_inscription=None, observations=""):
        from apps.eleves.models import Inscription, StatutInscription, StatutEleve
        if eleve.statut not in [StatutEleve.ACTIF]:
            raise RegleMetierError(f"Élève {eleve.nom_complet} non actif (statut: {eleve.statut}).")
        if not annee.accepte_inscriptions:
            raise RegleMetierError(f"L'année {annee.libelle} n'accepte pas les inscriptions.")
        if Inscription.objects.filter(eleve=eleve, annee_scolaire=annee).exists():
            raise RegleMetierError(f"{eleve.nom_complet} déjà inscrit pour {annee.libelle}.")
        if classe.est_pleine:
            raise RegleMetierError(f"Classe {classe.code} pleine ({classe.capacite_max} max).")
        inscription = Inscription.objects.create(
            ecole=annee.ecole, eleve=eleve, annee_scolaire=annee, classe=classe,
            type_inscription=type_inscription, statut=StatutInscription.EN_ATTENTE,
            date_inscription=timezone.localdate(), frais_inscription=frais_inscription, observations=observations,
        )
        if not eleve.date_premiere_inscription:
            eleve.date_premiere_inscription = inscription.date_inscription
            eleve.save(update_fields=["date_premiere_inscription"])
        self.audit.enregistrer("inscription_eleve", inscription, donnees_apres={"eleve": str(eleve), "classe": str(classe)})
        return inscription

    @transaction.atomic
    def valider(self, inscription):
        from apps.eleves.models import StatutInscription
        if inscription.statut != StatutInscription.EN_ATTENTE:
            raise RegleMetierError(f"Seules les inscriptions en attente peuvent être validées.")
        if not inscription.annee_scolaire.accepte_inscriptions:
            raise RegleMetierError(
                "Impossible de valider une inscription pour une année scolaire inactive."
            )
        inscription.statut = StatutInscription.VALIDEE
        inscription.date_validation = timezone.now().date()
        inscription.validee_par = self.utilisateur
        inscription.save(update_fields=["statut", "date_validation", "validee_par"])
        return inscription

    @transaction.atomic
    def changer_de_classe(self, inscription, nouvelle_classe):
        from apps.eleves.models import StatutInscription, MouvementEleve, TypeMouvement
        if inscription.statut == StatutInscription.VERROUILEE:
            raise RegleMetierError("Inscription verrouillée (année close).")
        if not inscription.annee_scolaire.accepte_inscriptions:
            raise RegleMetierError(
                "Impossible de changer la classe pour une année scolaire inactive."
            )
        if nouvelle_classe.annee_scolaire != inscription.annee_scolaire:
            raise RegleMetierError("Changement uniquement au sein de la même année.")
        if nouvelle_classe.est_pleine:
            raise RegleMetierError(f"Classe {nouvelle_classe.code} pleine.")
        ancienne = inscription.classe
        inscription.classe = nouvelle_classe
        inscription.save(update_fields=["classe"])
        MouvementEleve.objects.create(
            ecole=inscription.ecole, eleve=inscription.eleve, inscription=inscription,
            type_mouvement=TypeMouvement.TRANSFERT_ENTRANT, date_mouvement=timezone.now().date(),
            motif=f"Changement : {ancienne.code} → {nouvelle_classe.code}", enregistre_par=self.utilisateur,
        )
        return inscription

    @transaction.atomic
    def suspendre(self, inscription, motif):
        from apps.eleves.models import StatutEleve, MouvementEleve, TypeMouvement
        if not motif.strip():
            raise DonneesInvalidesError("Motif obligatoire.")
        inscription.eleve.statut = StatutEleve.SUSPENDU
        inscription.eleve.save(update_fields=["statut"])
        MouvementEleve.objects.create(
            ecole=inscription.ecole, eleve=inscription.eleve, inscription=inscription,
            type_mouvement=TypeMouvement.SUSPENSION, date_mouvement=timezone.now().date(),
            motif=motif, enregistre_par=self.utilisateur,
        )
        return inscription
