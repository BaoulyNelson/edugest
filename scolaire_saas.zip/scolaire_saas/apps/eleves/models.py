"""
apps/eleves/models.py
=====================
Gestion complète du cycle de vie d'un élève :
inscription → réinscription → transfert → abandon → archive.
Historique complet immuable à chaque étape.
"""

import uuid
import datetime
from django.db import models
from django.db.models import Max
from django.core.validators import RegexValidator
from apps.noyau.mixins import (
    ContactUniqueMixin, UUIDPrimaryKeyMixin, TenantModelMixin,
    HorodatageMixin, SuppressionDouce
)

# ─── Élève ───────────────────────────────────────────────────────────────────

class Sexe(models.TextChoices):
    MASCULIN = "M", "Masculin"
    FEMININ  = "F", "Féminin"


class StatutEleve(models.TextChoices):
    ACTIF     = "actif",     "Actif"
    SUSPENDU  = "suspendu",  "Suspendu"
    TRANSFERE = "transfere", "Transféré"
    ABANDONNE = "abandonne", "Abandon"
    DIPLOME   = "diplome",   "Diplômé"
    ARCHIVE   = "archive",   "Archivé"


class Eleve(
    ContactUniqueMixin,
    UUIDPrimaryKeyMixin,
    TenantModelMixin,
    HorodatageMixin,
    SuppressionDouce,
):
    """
    Entité principale représentant un élève dans l'école.
    INVARIANT : matricule unique par école — généré automatiquement si absent.
    INVARIANT : soft delete uniquement — jamais supprimé physiquement.
    """
    matricule = models.CharField(
        max_length=30,
        verbose_name="Matricule",
        help_text="Généré automatiquement si laissé vide.",
        blank=True,  # ← permet la génération auto
    )
    nom              = models.CharField(max_length=80, verbose_name="Nom de famille")
    prenom           = models.CharField(max_length=80, verbose_name="Prénom(s)")
    date_naissance   = models.DateField(verbose_name="Date de naissance")
    lieu_naissance   = models.CharField(max_length=100, blank=True)
    departement_naissance = models.CharField(max_length=50, blank=True)
    pays_naissance   = models.CharField(max_length=3, default="HTI")
    sexe             = models.CharField(max_length=1, choices=Sexe.choices)
    nationalite      = models.CharField(max_length=50, default="Haïtienne")
    photo            = models.ImageField(upload_to="eleves/photos/%Y/", null=True, blank=True)
    adresse          = models.TextField(blank=True, verbose_name="Adresse domicile")
    nom_pere         = models.CharField(max_length=100, blank=True)
    telephone_parent1 = models.CharField(
        max_length=20, blank=True,
        validators=[RegexValidator(
            r'^\+?1?\d{9,15}$',
            message="Format : '+509XXXXXXXX'. Jusqu'à 15 chiffres."
        )]
    )
    groupe_sanguin   = models.CharField(max_length=5, blank=True)
    statut           = models.CharField(
        max_length=15, choices=StatutEleve.choices,
        default=StatutEleve.ACTIF, db_index=True,
    )
    date_premiere_inscription = models.DateField(null=True, blank=True)

    class Meta:
        verbose_name        = "Élève"
        verbose_name_plural = "Élèves"
        unique_together     = [("ecole", "matricule")]
        indexes = [
            models.Index(fields=["ecole", "statut"], name="idx_eleve_statut"),
            models.Index(fields=["ecole", "nom", "prenom"], name="idx_eleve_nom"),
        ]
        ordering = ["nom", "prenom"]

    def __str__(self):
        return f"{self.nom} {self.prenom} [{self.matricule}]"

    @property
    def nom_complet(self) -> str:
        return f"{self.prenom} {self.nom}"



    def save(self, *args, **kwargs):
        if not self.matricule:
            from apps.noyau.utilitaires import generer_matricule_eleve
            self.matricule = generer_matricule_eleve(
                self.ecole,
                self.date_premiere_inscription,
            )
        super().save(*args, **kwargs)

    def obtenir_inscription_courante(self):
        """Retourne l'inscription de l'année active, ou None."""
        return (
            self.inscriptions
            .select_related("annee_scolaire", "classe")
            .filter(
                annee_scolaire__statut="active",
                statut=StatutInscription.VALIDEE,
            )
            .first()
        )


# ─── Inscription ─────────────────────────────────────────────────────────────

class TypeInscription(models.TextChoices):
    NOUVEAU           = "nouveau",           "Nouvel élève"
    REINSCRIPTION     = "reinscription",     "Réinscription"
    TRANSFERT_ENTRANT = "transfert_entrant", "Transfert entrant"
    DOUBLEMENT        = "doublement",        "Doublement de classe"


class StatutInscription(models.TextChoices):
    EN_ATTENTE  = "en_attente",  "En attente de validation"
    VALIDEE     = "validee",     "Validée"
    ANNULEE     = "annulee",     "Annulée"
    VERROUILEE  = "verrouilee",  "Verrouillée (année close)"


class Inscription(UUIDPrimaryKeyMixin, TenantModelMixin, HorodatageMixin):
    """
    Liaison élève ↔ classe ↔ année scolaire.
    INVARIANT : un élève ne peut avoir qu'une inscription VALIDEE par année scolaire.
    INVARIANT : une fois verrouillée (année close), aucune modification possible.
    Le numéro d'ordre est généré automatiquement par classe.
    """
    eleve = models.ForeignKey(
        Eleve, on_delete=models.PROTECT, related_name="inscriptions",
    )
    annee_scolaire = models.ForeignKey(
        "academique.AnneeScolaire", on_delete=models.PROTECT,
        related_name="inscriptions",
    )
    classe = models.ForeignKey(
        "academique.Classe", on_delete=models.PROTECT,
        related_name="inscriptions",
    )
    type_inscription = models.CharField(
        max_length=20, choices=TypeInscription.choices,
        default=TypeInscription.NOUVEAU,
    )
    statut = models.CharField(
        max_length=15, choices=StatutInscription.choices,
        default=StatutInscription.EN_ATTENTE, db_index=True,
    )
    date_inscription = models.DateField()
    date_validation  = models.DateField(null=True, blank=True)
    validee_par = models.ForeignKey(
        "comptes.Utilisateur", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="inscriptions_validees",
    )
    numero_ordre = models.PositiveSmallIntegerField(
        null=True, blank=True,
        verbose_name="Numéro d'ordre",
        help_text="Généré automatiquement selon l'ordre d'inscription dans la classe.",
    )
    frais_inscription = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
    )
    observations = models.TextField(blank=True)

    class Meta:
        verbose_name        = "Inscription"
        verbose_name_plural = "Inscriptions"
        unique_together     = [("ecole", "eleve", "annee_scolaire")]
        indexes = [
            models.Index(fields=["ecole", "annee_scolaire", "classe"], name="idx_inscription_classe"),
            models.Index(fields=["ecole", "statut"],                   name="idx_inscription_statut"),
        ]
        constraints = [
            # Numéro d'ordre unique par classe (pas globalement)
            models.UniqueConstraint(
                fields=['ecole', 'classe', 'annee_scolaire', 'numero_ordre'],
                name='unique_numero_ordre_par_classe',
                condition=models.Q(numero_ordre__isnull=False),
            )
        ]

    def __str__(self):
        return f"{self.eleve} → {self.classe} ({self.annee_scolaire.libelle})"

    def save(self, *args, **kwargs):
        # Génération automatique du numéro d'ordre si absent
        if not self.numero_ordre and self.classe_id:
            self.numero_ordre = self._prochain_numero_ordre()
        super().save(*args, **kwargs)

    def _prochain_numero_ordre(self) -> int:
        """
        Retourne le prochain numéro d'ordre disponible dans cette classe.
        Thread-safe par select_for_update si besoin.
        """
        dernier = Inscription.objects.filter(
            ecole=self.ecole,
            classe=self.classe,
            annee_scolaire=self.annee_scolaire,
        ).aggregate(Max('numero_ordre'))['numero_ordre__max']
        return (dernier or 0) + 1


# ─── Historique & mouvements ─────────────────────────────────────────────────

class TypeMouvement(models.TextChoices):
    TRANSFERT_SORTANT = "transfert_sortant", "Transfert sortant"
    TRANSFERT_ENTRANT = "transfert_entrant", "Transfert entrant"
    ABANDON           = "abandon",           "Abandon"
    SUSPENSION        = "suspension",        "Suspension"
    RETOUR            = "retour",            "Retour après suspension"
    RENVOI            = "renvoi",            "Renvoi définitif"


class MouvementEleve(TenantModelMixin, HorodatageMixin):
    """
    Journal immuable des mouvements d'un élève.
    Tout changement de statut majeur est enregistré ici.
    """
    eleve = models.ForeignKey(
        Eleve, on_delete=models.PROTECT, related_name="mouvements",
    )
    inscription = models.ForeignKey(
        Inscription, on_delete=models.PROTECT, related_name="mouvements",
    )
    type_mouvement            = models.CharField(max_length=20, choices=TypeMouvement.choices)
    date_mouvement            = models.DateField()
    motif                     = models.TextField(verbose_name="Motif / Justification")
    etablissement_destination = models.CharField(max_length=200, blank=True)
    etablissement_origine     = models.CharField(max_length=200, blank=True)
    enregistre_par = models.ForeignKey(
        "comptes.Utilisateur", on_delete=models.PROTECT,
        related_name="mouvements_enregistres",
    )
    document_joint = models.FileField(
        upload_to="eleves/mouvements/%Y/", null=True, blank=True,
    )

    class Meta:
        verbose_name        = "Mouvement d'élève"
        verbose_name_plural = "Mouvements d'élèves"
        ordering            = ["-date_mouvement"]


class DossierDisciplinaire(TenantModelMixin, HorodatageMixin):
    """
    Enregistrement disciplinaire associé à un élève.
    Peut apparaître dans le bulletin selon la config TypeDiscipline.
    """
    eleve = models.ForeignKey(
        Eleve, on_delete=models.PROTECT, related_name="dossiers_discipline",
    )
    inscription = models.ForeignKey(
        Inscription, on_delete=models.PROTECT, related_name="dossiers_discipline",
    )
    type_discipline = models.ForeignKey(
        "parametrage.TypeDiscipline", on_delete=models.PROTECT,
    )
    date_incident        = models.DateField()
    description          = models.TextField()
    sanction_appliquee   = models.TextField(blank=True)
    enregistre_par = models.ForeignKey(
        "comptes.Utilisateur", on_delete=models.PROTECT, related_name="+",
    )
    est_leve   = models.BooleanField(default=False)
    date_levee = models.DateField(null=True, blank=True)

    class Meta:
        verbose_name = "Dossier disciplinaire"
        ordering     = ["-date_incident"]