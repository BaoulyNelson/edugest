from django.urls import path
from apps.eleves import views
app_name = "eleves"
urlpatterns = [
    path("", views.liste_eleves, name="liste"),
    path("creer/", views.creer_eleve, name="creer"),
    path("<uuid:pk>/", views.detail_eleve, name="detail"),
    path("<uuid:pk>/modifier/", views.modifier_eleve, name="modifier"),
    path("inscrire/", views.inscrire_eleve, name="inscrire"),
    path("creation-rapide/eleve/", views.creation_rapide_eleve, name="creation_rapide_eleve"),
    path("creation-rapide/inscription/", views.creation_rapide_inscription, name="creation_rapide_inscription"),
    path("inscrire/groupe/", views.inscrire_groupe, name="inscrire_groupe"),
    path("inscriptions/", views.liste_inscriptions, name="inscriptions"),
    path("inscriptions/valider-selection/", views.valider_inscriptions_selection, name="valider_inscriptions_selection"),
    path("inscriptions/importer/", views.importer_inscriptions, name="importer_inscriptions"),
    path("inscriptions/<uuid:pk>/valider/", views.valider_inscription, name="valider_inscription"),
    path("inscriptions/<uuid:pk>/changer-classe/", views.changer_classe, name="changer_classe"),
    path("<uuid:pk>/suspendre/", views.suspendre_eleve, name="suspendre"),
    path("<uuid:pk>/historique/", views.historique_eleve, name="historique"),
    path("importer/", views.importer_eleves, name="importer"),
]
