from datetime import date
from decimal import Decimal
from pathlib import Path

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from apps.academique.models import AnneeScolaire, Classe, StatutAnneeScolaire
from apps.eleves.forms import FormulaireInscription, FormulaireInscriptionGroupe
from apps.eleves.models import Eleve, Inscription, StatutInscription
from apps.etablissements.models import Etablissement
from apps.finances.models import FraisEleve, TypeFrais
from apps.noyau.models import ContactUnique
from apps.parametrage.models import CycleEnseignement, Niveau
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole
from apps.enseignants.models import Enseignant


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ListeElevesTests(TestCase):
    def setUp(self):
        utilisateur = get_user_model().objects.create_user(
            email="responsable-eleves@example.com",
            password="MotDePasse!246",
            nom="Responsable",
            prenom="École",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-liste-eleves",
            nom="École liste élèves",
            ville="Port-au-Prince",
            cree_par=utilisateur,
        )
        self.client.force_login(utilisateur)
        permission = PermissionGranulaire.objects.create(
            code="eleves.inscrire.toutes_classes",
            description="Gérer les dossiers élèves pour le test.",
            module="eleves",
            action="inscrire",
            portee="toutes_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="responsable-eleves-test",
            libelle="Responsable élèves",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=role,
        )
        for numero in range(1, 12):
            Eleve.tous_objets.create(
                ecole=self.ecole,
                matricule=f"EL-{numero:03}",
                nom=f"Nom{numero:02}",
                prenom=f"Prenom{numero:02}",
                date_naissance=date(2012, 5, 3),
                sexe="F" if numero % 2 else "M",
                nom_pere=f"Parent{numero:02}",
            )

    def demander_liste(self, **params):
        return self.client.get(
            reverse("eleves:liste"),
            params,
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

    def creer_annee_et_classe(self):
        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        return annee, classe

    def test_formulaire_inscription_preselectionne_annee_et_date_automatiques(self):
        annee, classe = self.creer_annee_et_classe()
        form = FormulaireInscription(ecole=self.ecole, annee_scolaire=annee)

        self.assertEqual(str(form["annee_scolaire"].value()), str(annee.pk))
        self.assertEqual(
            form.fields["date_inscription"].initial,
            timezone.localdate(),
        )
        self.assertTrue(form.fields["date_inscription"].disabled)
        self.assertIn(classe, form.fields["classe"].queryset)

    def test_formulaire_ne_propose_pas_un_eleve_deja_inscrit_y_compris_en_attente(self):
        annee, classe = self.creer_annee_et_classe()
        eleve = Eleve.tous_objets.get(ecole=self.ecole, matricule="EL-001")
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=eleve,
            annee_scolaire=annee,
            classe=classe,
            date_inscription=date(2026, 10, 1),
            statut=StatutInscription.EN_ATTENTE,
        )

        form = FormulaireInscription(ecole=self.ecole, annee_scolaire=annee)

        self.assertFalse(form.fields["eleve"].queryset.filter(pk=eleve.pk).exists())

    def test_liste_eleve_identifie_une_inscription_en_attente(self):
        annee, classe = self.creer_annee_et_classe()
        eleve = Eleve.tous_objets.get(ecole=self.ecole, matricule="EL-001")
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=eleve,
            annee_scolaire=annee,
            classe=classe,
            date_inscription=date(2026, 10, 1),
            statut=StatutInscription.EN_ATTENTE,
        )

        response = self.demander_liste()

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "En attente de validation")
        self.assertNotContains(
            response,
            f'href="{reverse("eleves:inscrire")}?eleve={eleve.pk}"',
        )

    def test_liste_recherche_et_pagine_les_eleves(self):
        response = self.demander_liste(q="Nom02")

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "EL-002")
        self.assertNotContains(response, "EL-001")
        self.assertContains(response, "Exporter CSV")
        self.assertContains(response, "Naissance")
        self.assertContains(response, "Père / contact")
        self.assertNotContains(response, "Filtrer</button>")
        self.assertNotContains(response, "Présence")

        response = self.demander_liste(per_page="10")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context["eleves"]), 10)
        self.assertEqual(response.context["total_eleves"], 11)

        response = self.demander_liste(per_page="10", page="2")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context["eleves"]), 1)
        self.assertContains(response, "EL-011")

    def test_export_csv_peut_limiter_a_la_selection(self):
        eleve = Eleve.tous_objets.get(ecole=self.ecole, matricule="EL-003")

        response = self.demander_liste(export="csv", ids=str(eleve.pk))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "text/csv; charset=utf-8")
        contenu = response.content.decode("utf-8-sig")
        self.assertIn("EL-003", contenu)
        self.assertNotIn("EL-002", contenu)
        self.assertIn("date_naissance", contenu)
        self.assertIn("telephone_parent1", contenu)
        self.assertNotIn("Présence", contenu)

    def test_export_csv_refuse_un_identifiant_invalide(self):
        response = self.demander_liste(export="csv", ids="pas-un-uuid")

        self.assertEqual(response.status_code, 400)

    def test_parent_sans_permission_de_consultation_ne_voit_pas_les_eleves(self):
        parent = get_user_model().objects.create_user(
            email="parent-sans-permission@example.com",
            nom="Parent",
            prenom="Test",
        )
        role_parent = Role.objects.create(
            ecole=self.ecole,
            code="parent-test",
            libelle="Parent",
        )
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=parent,
            role=role_parent,
        )
        self.client.force_login(parent)

        eleve = Eleve.tous_objets.get(ecole=self.ecole, matricule="EL-001")
        urls = (
            reverse("eleves:liste"),
            reverse("eleves:inscriptions"),
            reverse("eleves:detail", kwargs={"pk": eleve.pk}),
            reverse("eleves:historique", kwargs={"pk": eleve.pk}),
        )

        for url in urls:
            with self.subTest(url=url):
                response = self.client.get(url, HTTP_X_TENANT_SLUG=self.ecole.slug)

                self.assertEqual(response.status_code, 403)

    def test_role_consultation_seule_ne_voit_pas_les_actions_de_gestion(self):
        surveillant = get_user_model().objects.create_user(
            email="surveillant-consultation@example.com",
            nom="Surveillant",
            prenom="Test",
        )
        permission = PermissionGranulaire.objects.create(
            code="eleves.consulter.toutes_classes",
            description="Consulter tous les élèves pour le test.",
            module="eleves",
            action="consulter",
            portee="toutes_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="surveillant-test",
            libelle="Surveillant",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=surveillant,
            role=role,
        )
        self.client.force_login(surveillant)

        response = self.demander_liste()

        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, "Ajouter un élève")
        self.assertNotContains(response, "Importer CSV")
        self.assertNotContains(response, ">Inscrire</a>")

        response = self.client.get(
            reverse("eleves:inscriptions"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, "Inscrire un groupe")
        self.assertNotContains(response, "Valider la sélection")

    def test_enseignant_ne_voit_que_les_eleves_de_ses_classes_affectees(self):
        utilisateur = get_user_model().objects.create_user(
            email="enseignant-classes-propres@example.com",
            nom="Enseignant",
            prenom="Test",
        )
        permission = PermissionGranulaire.objects.create(
            code="eleves.consulter.propres_classes",
            description="Consulter les élèves de ses classes.",
            module="eleves",
            action="consulter",
            portee="propres_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="enseignant-classes-test",
            libelle="Enseignant",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=utilisateur,
            role=role,
        )
        annee, classe_affectee = self.creer_annee_et_classe()
        classe_autre = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=classe_affectee.niveau,
            code="6AF-B",
            libelle="6e année fondamentale B",
        )
        enseignant = Enseignant.objects.create(
            ecole=self.ecole,
            utilisateur=utilisateur,
            nom="Enseignant",
            prenom="Test",
            sexe="M",
        )
        classe_affectee.enseignant_titulaire = enseignant
        classe_affectee.save()
        eleve_affecte = Eleve.tous_objets.get(ecole=self.ecole, matricule="EL-001")
        autre_eleve = Eleve.tous_objets.get(ecole=self.ecole, matricule="EL-002")
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=eleve_affecte,
            annee_scolaire=annee,
            classe=classe_affectee,
            date_inscription=date(2026, 10, 1),
            statut=StatutInscription.VALIDEE,
        )
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=autre_eleve,
            annee_scolaire=annee,
            classe=classe_autre,
            date_inscription=date(2026, 10, 1),
            statut=StatutInscription.VALIDEE,
        )
        self.client.force_login(utilisateur)

        response = self.demander_liste()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["total_eleves"], 1)
        self.assertEqual(response.context["eleves"][0].pk, eleve_affecte.pk)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class InscriptionIndividuelleTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="admin-inscription-individuelle@example.com",
            password="test-password",
            nom="Admin",
            prenom="Inscription",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-inscription-individuelle",
            nom="École inscription individuelle",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        self.classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
        )
        self.eleve = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="INS-001",
            nom="Jean",
            prenom="Marie",
            date_naissance=date(2012, 5, 3),
            sexe="F",
        )

    def test_formulaire_modification_affiche_date_de_naissance_existante(self):
        response = self.client.get(
            reverse("eleves:modifier", kwargs={"pk": self.eleve.pk}),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["form"]["date_naissance"].value(),
            date(2012, 5, 3),
        )
        self.assertContains(response, 'name="date_naissance"')
        self.assertContains(response, 'value="2012-05-03"')

    def test_formulaire_affiche_date_automatique_et_annee_active(self):
        response = self.client.get(
            reverse("eleves:inscrire"),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, timezone.localdate().isoformat())
        self.assertContains(response, 'name="date_inscription"')
        self.assertContains(response, "disabled")
        self.assertContains(
            response,
            f'<option value="{self.annee.pk}" selected>',
            html=False,
        )
        self.assertContains(response, 'data-quick-create="eleve"')
        self.assertContains(response, 'data-quick-create="classe"')
        self.assertContains(response, 'id="enrollmentQuickModal"', count=1)

    def test_creation_rapide_cree_un_eleve_dans_le_tenant_et_le_retourne(self):
        response = self.client.post(
            reverse("eleves:creation_rapide_eleve"),
            {
                "nom": "Joseph",
                "prenom": "Marie",
                "date_naissance": "2012-05-03",
                "sexe": "F",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 201)
        eleve = Eleve.objects.get(pk=response.json()["id"])
        self.assertEqual(eleve.ecole, self.ecole)
        self.assertEqual(eleve.nom_complet, "Marie Joseph")
        self.assertIn(eleve.matricule, response.json()["label"])

    def test_creation_rapide_inscription_retourne_une_inscription_en_attente(self):
        response = self.client.post(
            reverse("eleves:creation_rapide_inscription"),
            {
                "eleve": self.eleve.pk,
                "annee_scolaire": self.annee.pk,
                "classe": self.classe.pk,
                "type_inscription": "nouveau",
                "frais_inscription": "",
                "observations": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 201, response.content.decode())
        inscription = Inscription.objects.get(pk=response.json()["id"])
        self.assertEqual(inscription.statut, StatutInscription.EN_ATTENTE)
        self.assertEqual(inscription.ecole, self.ecole)

    def test_inscription_creee_en_attente_puis_visible_comme_telle(self):
        response = self.client.post(
            reverse("eleves:inscrire"),
            {
                "eleve": self.eleve.pk,
                "annee_scolaire": self.annee.pk,
                "classe": self.classe.pk,
                "type_inscription": "nouveau",
                "date_inscription": "2000-01-01",
                "frais_inscription": "1250.00",
                "observations": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
            follow=True,
        )

        inscription = Inscription.objects.get(eleve=self.eleve)
        self.assertRedirects(
            response,
            reverse("eleves:inscriptions"),
            target_status_code=200,
        )
        self.assertEqual(inscription.statut, StatutInscription.EN_ATTENTE)
        self.assertEqual(inscription.date_inscription, timezone.localdate())
        self.assertEqual(inscription.frais_inscription, Decimal("1250.00"))
        self.assertContains(response, "mise en attente")
        self.assertContains(response, "En attente de validation")

    def test_detail_affiche_le_frais_inscription_et_le_lien_aux_inscriptions(self):
        inscription = Inscription.objects.create(
            ecole=self.ecole,
            eleve=self.eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
            frais_inscription=Decimal("1250.00"),
        )

        response = self.client.get(
            reverse("eleves:detail", kwargs={"pk": self.eleve.pk}),
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.context["inscriptions"][0].frais_inscription,
            Decimal("1250.00"),
        )
        self.assertContains(response, "Frais d’inscription")
        self.assertContains(response, "Montant enregistré")
        self.assertContains(response, reverse("eleves:inscriptions"))
        self.assertContains(
            response,
            f'{reverse("finances:assigner_frais")}?inscription={inscription.pk}',
        )

    def test_assigner_frais_preselectionne_inscription_deja_choisie(self):
        inscription = Inscription.objects.create(
            ecole=self.ecole,
            eleve=self.eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
        )

        response = self.client.get(
            f'{reverse("finances:assigner_frais")}?inscription={inscription.pk}',
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            str(response.context["form"]["inscription"].value()),
            str(inscription.pk),
        )

    def test_paiement_affiche_total_deja_verse_et_solde_du_frais_selectionne(self):
        inscription = Inscription.objects.create(
            ecole=self.ecole,
            eleve=self.eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
        )
        type_frais = TypeFrais.objects.create(
            ecole=self.ecole,
            code="SCOL",
            libelle="Frais scolaires",
        )
        frais = FraisEleve.objects.create(
            ecole=self.ecole,
            inscription=inscription,
            type_frais=type_frais,
            montant_brut=Decimal("1000.00"),
            assigne_par=self.utilisateur,
        )

        response = self.client.get(
            f'{reverse("finances:enregistrer")}?frais_id={frais.pk}',
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["soldes_frais"][str(frais.pk)]["net"], "1000.00")
        self.assertEqual(response.context["soldes_frais"][str(frais.pk)]["verse"], "0.00")
        self.assertEqual(response.context["soldes_frais"][str(frais.pk)]["solde"], "1000.00")
        self.assertContains(response, "Montant payé maintenant")
        self.assertContains(response, "Total dû")

    def test_liste_inscriptions_filtre_et_recherche(self):
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=self.eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
            statut=StatutInscription.EN_ATTENTE,
        )
        autre_eleve = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="INS-002",
            nom="Autre",
            prenom="Élève",
            date_naissance=date(2013, 4, 2),
            sexe="M",
        )
        Inscription.objects.create(
            ecole=self.ecole,
            eleve=autre_eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
            statut=StatutInscription.VALIDEE,
        )

        response = self.client.get(
            reverse("eleves:inscriptions"),
            {
                "q": "Jean",
                "classe": self.classe.pk,
                "statut": StatutInscription.EN_ATTENTE,
                "type": "nouveau",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["total_inscriptions"], 1)
        self.assertContains(response, "INS-001")
        self.assertContains(response, "Féminin")
        self.assertNotContains(response, "INS-002")
        self.assertNotContains(response, ">Filtrer</button>", html=False)

    def test_validation_en_masse_ne_valide_que_les_inscriptions_selectionnees(self):
        inscription_a = Inscription.objects.create(
            ecole=self.ecole,
            eleve=self.eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
            statut=StatutInscription.EN_ATTENTE,
        )
        autre_eleve = Eleve.tous_objets.create(
            ecole=self.ecole,
            matricule="INS-003",
            nom="Autre",
            prenom="Élève",
            date_naissance=date(2013, 4, 2),
            sexe="M",
        )
        inscription_b = Inscription.objects.create(
            ecole=self.ecole,
            eleve=autre_eleve,
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=timezone.localdate(),
            statut=StatutInscription.EN_ATTENTE,
        )
        response = self.client.post(
            reverse("eleves:valider_inscriptions_selection"),
            {"inscriptions": [str(inscription_a.pk), str(inscription_b.pk)]},
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertRedirects(response, reverse("eleves:inscriptions"))
        inscription_a.refresh_from_db()
        inscription_b.refresh_from_db()
        self.assertEqual(inscription_a.statut, StatutInscription.VALIDEE)
        self.assertEqual(inscription_b.statut, StatutInscription.VALIDEE)


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AdminElevesMultiEtablissementsTests(TestCase):
    def setUp(self):
        utilisateur = get_user_model().objects.create_superuser(
            email="admin-eleves@example.com",
            password="test-password",
            nom="Admin",
            prenom="Élèves",
        )
        self.ecole_a = Etablissement.objects.create(
            slug="admin-eleves-a",
            nom="Établissement A",
            ville="Port-au-Prince",
            cree_par=utilisateur,
        )
        self.ecole_b = Etablissement.objects.create(
            slug="admin-eleves-b",
            nom="Établissement B",
            ville="Jacmel",
            cree_par=utilisateur,
        )
        for ecole, matricule in (
            (self.ecole_a, "ADMIN-A-001"),
            (self.ecole_b, "ADMIN-B-001"),
        ):
            Eleve.tous_objets.create(
                ecole=ecole,
                matricule=matricule,
                nom="Élève",
                prenom=matricule,
                date_naissance=date(2012, 5, 3),
                sexe="F",
            )
        self.client.force_login(utilisateur)
        self.url = reverse("admin:eleves_eleve_changelist")

    def test_superuser_voit_les_eleves_de_tous_les_etablissements(self):
        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "ADMIN-A-001")
        self.assertContains(response, "ADMIN-B-001")
        self.assertContains(response, "Établissement A")
        self.assertContains(response, "Établissement B")

    def test_superuser_peut_filtrer_par_etablissement(self):
        response = self.client.get(
            self.url,
            {"ecole__id__exact": str(self.ecole_a.pk)},
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "ADMIN-A-001")
        self.assertNotContains(response, "ADMIN-B-001")

    def test_superuser_peut_rechercher_par_slug_etablissement(self):
        response = self.client.get(self.url, {"q": self.ecole_b.slug})

        self.assertEqual(response.status_code, 200)
        eleves_affiches = list(response.context["cl"].result_list)
        self.assertEqual(len(eleves_affiches), 1)
        self.assertEqual(eleves_affiches[0].matricule, "ADMIN-B-001")


class UniciteContactTenantTests(TestCase):
    def setUp(self):
        utilisateur = get_user_model().objects.create_user(
            email="contacts-tenants@example.com",
            password="test-password-123",
            nom="Responsable",
            prenom="Test",
        )
        self.ecole_a = Etablissement.objects.create(
            slug="contacts-ecole-a",
            nom="École A",
            ville="Port-au-Prince",
            cree_par=utilisateur,
        )
        self.ecole_b = Etablissement.objects.create(
            slug="contacts-ecole-b",
            nom="École B",
            ville="Jacmel",
            cree_par=utilisateur,
        )

    def creer_eleve(self, ecole, matricule, nom, telephone):
        return Eleve.tous_objets.create(
            ecole=ecole,
            matricule=matricule,
            nom=nom,
            prenom="Jean",
            date_naissance=date(2012, 5, 3),
            sexe="M",
            telephone_parent1=telephone,
        )

    def test_meme_telephone_parent_est_autorise_dans_deux_tenants(self):
        self.creer_eleve(self.ecole_a, "A-001", "Élève A", "+50937000000")
        self.creer_eleve(self.ecole_b, "B-001", "Élève B", "+50937000000")

        self.assertEqual(
            ContactUnique.objects.filter(
                type_contact=ContactUnique.TYPE_TELEPHONE,
            ).count(),
            2,
        )

    def test_meme_telephone_parent_reste_interdit_dans_le_meme_tenant(self):
        self.creer_eleve(self.ecole_a, "A-001", "Élève A", "+50937000000")

        with self.assertRaises(ValidationError):
            self.creer_eleve(self.ecole_a, "A-002", "Élève B", "+50937000000")


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class ImportElevesTenantTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_superuser(
            email="import-tenants@example.com",
            password="test-password-123",
            nom="Responsable",
            prenom="Import",
        )
        self.ecole_a = Etablissement.objects.create(
            slug="import-ecole-a",
            nom="École import A",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.ecole_b = Etablissement.objects.create(
            slug="import-ecole-b",
            nom="École import B",
            ville="Jacmel",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)

    def importer_dans(self, ecole):
        chemin = Path(__file__).resolve().parents[2] / "data" / "eleves.csv"
        return self.client.post(
            reverse("eleves:importer"),
            {
                "fichier_csv": SimpleUploadedFile(
                    chemin.name,
                    chemin.read_bytes(),
                    content_type="text/csv",
                )
            },
            HTTP_X_TENANT_SLUG=ecole.slug,
            follow=True,
        )

    def test_meme_csv_est_importable_dans_deux_tenants(self):
        reponse_a = self.importer_dans(self.ecole_a)
        reponse_b = self.importer_dans(self.ecole_b)

        self.assertEqual(reponse_a.status_code, 200)
        self.assertEqual(reponse_b.status_code, 200)
        self.assertEqual(Eleve.tous_objets.filter(ecole=self.ecole_a).count(), 35)
        self.assertEqual(Eleve.tous_objets.filter(ecole=self.ecole_b).count(), 35)
        self.assertEqual(
            Eleve.tous_objets.filter(ecole=self.ecole_a)
            .exclude(telephone_parent1="")
            .count(),
            35,
        )
        self.assertEqual(
            ContactUnique.objects.filter(
                type_contact=ContactUnique.TYPE_TELEPHONE,
            ).count(),
            70,
        )
        self.assertContains(reponse_b, "35 élève(s) importé(s)")
        self.assertContains(reponse_b, "0 erreur(s)")
        self.assertNotContains(reponse_b, "Colonnes non reconnues")


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class InscriptionGroupeTests(TestCase):
    def setUp(self):
        utilisateur = get_user_model().objects.create_user(
            email="responsable-inscriptions@example.com",
            password="test-password",
            nom="Responsable",
            prenom="École",
        )
        utilisateur.is_superuser = True
        utilisateur.save(update_fields=["is_superuser"])
        self.ecole = Etablissement.objects.create(
            slug="ecole-inscription-groupe",
            nom="École inscription groupe",
            ville="Port-au-Prince",
            cree_par=utilisateur,
        )
        self.client.force_login(utilisateur)
        self.annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle=str(timezone.localdate().year),
            date_debut=date(timezone.localdate().year, 1, 1),
            date_fin=date(timezone.localdate().year, 12, 31),
            statut=StatutAnneeScolaire.ACTIVE,
            cree_par=utilisateur,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="FOND",
            libelle="Fondamental",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="6AF",
            libelle="6e année fondamentale",
        )
        self.classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=self.annee,
            niveau=niveau,
            code="6AF-A",
            libelle="6e année fondamentale A",
            capacite_max=10,
        )
        self.eleves = [
            Eleve.tous_objets.create(
                ecole=self.ecole,
                matricule=f"MASS-{numero}",
                nom=f"Nom{numero}",
                prenom=f"Prenom{numero}",
                date_naissance=date(2012, 5, 3),
                sexe="F",
            )
            for numero in range(1, 4)
        ]

    def test_formulaire_annee_ne_propose_plus_les_dates_officielles(self):
        from apps.academique.forms import FormulaireAnneeScolaire

        self.assertNotIn("date_ouverture_officielle", FormulaireAnneeScolaire.base_fields)
        self.assertNotIn("date_cloture_officielle", FormulaireAnneeScolaire.base_fields)

    def test_inscription_en_masse_cree_une_inscription_par_eleve_selectionne(self):
        response = self.client.post(
            reverse("eleves:inscrire_groupe"),
            {
                "annee_scolaire": self.annee.pk,
                "classe": self.classe.pk,
                "type_inscription": "nouveau",
                "eleves": [str(eleve.pk) for eleve in self.eleves],
                "frais_inscription": "",
                "observations": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            Inscription.tous_objets.filter(
                ecole=self.ecole,
                annee_scolaire=self.annee,
                classe=self.classe,
            ).count(),
            3,
        )
        self.assertContains(response, "3 inscription(s) créée(s)")

    def test_formulaire_groupe_exclut_les_eleves_deja_inscrits(self):
        Inscription.tous_objets.create(
            ecole=self.ecole,
            eleve=self.eleves[0],
            annee_scolaire=self.annee,
            classe=self.classe,
            date_inscription=date(2026, 9, 1),
        )

        form = FormulaireInscriptionGroupe(ecole=self.ecole)

        self.assertNotIn(self.eleves[0], form.fields["eleves"].queryset)

    def test_inscription_en_masse_refuse_un_groupe_plus_grand_que_la_capacite(self):
        self.classe.capacite_max = 2
        self.classe.save(update_fields=["capacite_max"])

        response = self.client.post(
            reverse("eleves:inscrire_groupe"),
            {
                "annee_scolaire": self.annee.pk,
                "classe": self.classe.pk,
                "type_inscription": "nouveau",
                "eleves": [str(eleve.pk) for eleve in self.eleves],
                "frais_inscription": "",
                "observations": "",
            },
            HTTP_X_TENANT_SLUG=self.ecole.slug,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "ne dispose que de 2 place(s) restante(s)")
        self.assertFalse(
            Inscription.tous_objets.filter(
                ecole=self.ecole,
                annee_scolaire=self.annee,
            ).exists()
        )
