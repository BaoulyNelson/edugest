"""Vues de gestion des élèves."""
import csv
from uuid import UUID
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db.models import Prefetch, Q
from django.db import IntegrityError, transaction
from django.http import HttpResponse, HttpResponseBadRequest, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from apps.noyau.decorateurs import (
    requiert_tenant,
    requiert_permission,
    requiert_une_permission,
    gerer_erreur_metier,
)
from apps.academique.models import AnneeScolaire, Classe, MatiereClasse, StatutAnneeScolaire
from apps.eleves.models import (
    Eleve,
    Inscription,
    Sexe,
    StatutEleve,
    StatutInscription,
    TypeMouvement,
)
from apps.eleves.services import ServiceInscription
from apps.eleves import forms
from apps.noyau.exceptions import ErreurMetierBase


PERMISSIONS_CONSULTER_ELEVES = (
    "eleves.inscrire.toutes_classes",
    "eleves.consulter.toutes_classes",
    "eleves.consulter.propres_classes",
    "finances.consulter.toutes_classes",
)


def _classes_enseignant(request):
    classes_matiere = MatiereClasse.objects.filter(
        ecole=request.etablissement,
    ).filter(
        Q(enseignant__utilisateur=request.user)
        | Q(affectations_enseignants__enseignant__utilisateur=request.user)
    ).values("classe_id")
    return Classe.objects.filter(ecole=request.etablissement).filter(
        Q(enseignant_titulaire__utilisateur=request.user)
        | Q(pk__in=classes_matiere)
    ).distinct()


def _permissions_eleves(request):
    from apps.securite.rbac import moteur_rbac

    return moteur_rbac.obtenir_toutes_permissions(request.user, request.etablissement)


def _doit_limiter_aux_classes_propres(request, permissions):
    return (
        not request.user.is_superuser
        and "eleves.consulter.propres_classes" in permissions
        and not any(
            permission in permissions
            for permission in (
                "eleves.inscrire.toutes_classes",
                "eleves.consulter.toutes_classes",
                "finances.consulter.toutes_classes",
            )
        )
    )


@login_required
@requiert_tenant
@requiert_une_permission(*PERMISSIONS_CONSULTER_ELEVES)
def liste_eleves(request):
    q = request.GET.get("q", "").strip()
    sexe = request.GET.get("sexe", "")
    statut = request.GET.get("statut", "")
    classe_id = request.GET.get("classe", "")
    per_page = request.GET.get("per_page", "10")
    if per_page not in {"10", "20", "50"}:
        per_page = "10"

    annee_courante = request.annee_scolaire_courante
    classes = (
        Classe.objects.filter(annee_scolaire=annee_courante, est_actif=True)
        .order_by("code")
        if annee_courante
        else Classe.objects.none()
    )
    if annee_courante:
        inscriptions_courantes = Inscription.objects.filter(
            annee_scolaire=annee_courante,
        ).select_related("classe")
    else:
        inscriptions_courantes = Inscription.objects.none()

    eleves = (
        Eleve.objects.filter(supprime_le__isnull=True)
        .prefetch_related(
            Prefetch(
                "inscriptions",
                queryset=inscriptions_courantes,
                to_attr="inscriptions_courantes",
            )
        )
        .order_by("nom", "prenom")
    )
    permissions = _permissions_eleves(request)
    peut_gerer_eleves = (
        request.user.is_superuser or "eleves.inscrire.toutes_classes" in permissions
    )
    peut_suspendre_eleves = (
        request.user.is_superuser or "eleves.suspendre.toutes_classes" in permissions
    )
    if _doit_limiter_aux_classes_propres(request, permissions):
        classes_enseignant = _classes_enseignant(request)
        classes = classes.filter(pk__in=classes_enseignant)
        eleves = eleves.filter(inscriptions__classe__in=classes_enseignant)
    if q:
        eleves = eleves.filter(
            Q(nom__icontains=q)
            | Q(prenom__icontains=q)
            | Q(matricule__icontains=q)
            | Q(nom_pere__icontains=q)
            | Q(telephone_parent1__icontains=q)
        )
    if sexe in dict(Sexe.choices):
        eleves = eleves.filter(sexe=sexe)
    if statut in dict(StatutEleve.choices):
        eleves = eleves.filter(statut=statut)
    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError, ValidationError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            eleves = eleves.filter(
                inscriptions__annee_scolaire=annee_courante,
                inscriptions__statut=StatutInscription.VALIDEE,
                inscriptions__classe_id=classe_pk,
            )

    ids = request.GET.getlist("ids")
    if request.GET.get("export") == "csv":
        if ids:
            try:
                ids = [UUID(eleve_id) for eleve_id in ids]
            except (AttributeError, TypeError, ValueError):
                return HttpResponseBadRequest("Identifiant d’élève invalide.")
            eleves = eleves.filter(pk__in=ids)
        response = HttpResponse(content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = 'attachment; filename="eleves.csv"'
        response.write("\ufeff")
        writer = csv.writer(response, delimiter=";")
        writer.writerow(
            [
                "Matricule",
                "Nom",
                "Prénom",
                "date_naissance",
                "lieu_naissance",
                "departement_naissance",
                "pays_naissance",
                "sexe",
                "nationalite",
                "adresse",
                "nom_pere",
                "telephone_parent1",
                "groupe_sanguin",
                "Statut",
            ]
        )

        def proteger_formule(valeur):
            valeur = str(valeur or "")
            if valeur.lstrip().startswith(("=", "+", "-", "@")):
                return "'" + valeur
            return valeur

        for eleve in eleves.distinct():
            writer.writerow(
                [
                    proteger_formule(eleve.matricule),
                    proteger_formule(eleve.nom),
                    proteger_formule(eleve.prenom),
                    eleve.date_naissance.isoformat(),
                    proteger_formule(eleve.lieu_naissance),
                    proteger_formule(eleve.departement_naissance),
                    proteger_formule(eleve.pays_naissance),
                    eleve.sexe,
                    proteger_formule(eleve.nationalite),
                    proteger_formule(eleve.adresse),
                    proteger_formule(eleve.nom_pere),
                    proteger_formule(eleve.telephone_parent1),
                    proteger_formule(eleve.groupe_sanguin),
                    eleve.statut,
                ]
            )
        return response

    paginator = Paginator(eleves.distinct(), int(per_page))
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "eleves/liste.html",
        {
            "eleves": page_obj.object_list,
            "page_obj": page_obj,
            "q": q,
            "classes": classes,
            "filtre_classe": classe_id,
            "annee_consultee": annee_courante is not None,
            "filtre_sexe": sexe,
            "filtre_statut": statut,
            "sexe_choices": Sexe.choices,
            "statut_choices": StatutEleve.choices,
            "per_page": per_page,
            "total_eleves": paginator.count,
            "peut_gerer_eleves": peut_gerer_eleves,
            "peut_suspendre_eleves": peut_suspendre_eleves,
        },
    )


@login_required
@requiert_tenant
@requiert_une_permission(*PERMISSIONS_CONSULTER_ELEVES)
def detail_eleve(request, pk):
    eleves = Eleve.objects.filter(
        pk=pk,
        ecole=request.etablissement,
        supprime_le__isnull=True,
    )
    permissions = _permissions_eleves(request)
    if _doit_limiter_aux_classes_propres(request, permissions):
        eleves = eleves.filter(inscriptions__classe__in=_classes_enseignant(request))
    eleve = get_object_or_404(eleves.distinct())
    inscriptions = eleve.inscriptions.select_related(
        "annee_scolaire", "classe"
    ).prefetch_related("frais__type_frais").order_by("-annee_scolaire__date_debut")
    if _doit_limiter_aux_classes_propres(request, permissions):
        inscriptions = inscriptions.filter(classe__in=_classes_enseignant(request))
    annee_courante = request.annee_scolaire_courante
    inscription_courante = (
        inscriptions.filter(annee_scolaire=annee_courante).first()
        if annee_courante
        else None
    )
    frais_courant = (
        inscription_courante.frais.first() if inscription_courante else None
    )
    a_frais_financiers = any(
        inscription.frais_inscription is not None or bool(inscription.frais.all())
        for inscription in inscriptions
    )
    return render(
        request,
        "eleves/detail.html",
        {
            "eleve": eleve,
            "inscriptions": inscriptions,
            "inscription_courante": inscription_courante,
            "frais_courant": frais_courant,
            "a_frais_financiers": a_frais_financiers,
            "peut_gerer_eleves": (
                request.user.is_superuser
                or "eleves.inscrire.toutes_classes" in permissions
            ),
            "peut_suspendre_eleves": (
                request.user.is_superuser
                or "eleves.suspendre.toutes_classes" in permissions
            ),
            "peut_generer_badges": (
                request.user.is_superuser
                or "badges.generer.toutes_classes" in permissions
            ),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
def creer_eleve(request):
    if request.method == "POST":
        form = forms.FormulaireEleve(request.POST, request.FILES)
        if form.is_valid():
            eleve = form.save(commit=False)
            eleve.ecole = request.etablissement
            if not eleve.matricule:
                eleve.matricule = _generer_matricule(request.etablissement)
            eleve.save()
            messages.success(request, f"Élève {eleve.nom_complet} créé.")
            return redirect("eleves:inscrire")
    else:
        form = forms.FormulaireEleve()
    return render(request, "eleves/form_eleve.html", {"form": form})


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
def modifier_eleve(request, pk):
    eleve = get_object_or_404(Eleve, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        form = forms.FormulaireEleve(request.POST, request.FILES, instance=eleve)
        if form.is_valid():
            form.save()
            messages.success(request, "Dossier élève mis à jour.")
            return redirect("eleves:detail", pk=pk)
    else:
        form = forms.FormulaireEleve(instance=eleve)
    return render(request, "eleves/form_eleve.html", {"form": form, "eleve": eleve})


@login_required
@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@gerer_erreur_metier
def inscrire_eleve(request):
    if request.method == "POST":
        form = forms.FormulaireInscription(
            request.POST,
            ecole=request.etablissement,
            annee_scolaire=request.annee_scolaire_courante,
        )
        if form.is_valid():
            service = ServiceInscription(request.user)
            service.inscrire(
                eleve=form.cleaned_data["eleve"],
                annee=form.cleaned_data["annee_scolaire"],
                classe=form.cleaned_data["classe"],
                type_inscription=form.cleaned_data["type_inscription"],
                frais_inscription=form.cleaned_data["frais_inscription"],
                observations=form.cleaned_data["observations"],
            )
            messages.success(
                request,
                "Demande d’inscription créée et mise en attente. "
                "Vérifiez-la puis validez-la dans la liste des inscriptions.",
            )
            return redirect("eleves:inscriptions")
    else:
        eleve_pk = request.GET.get("eleve")
        form = forms.FormulaireInscription(
            ecole=request.etablissement,
            annee_scolaire=request.annee_scolaire_courante,
            initial={"eleve": eleve_pk} if eleve_pk else {},
        )

    eleves_recents = form.fields["eleve"].queryset.order_by("-cree_le")[:10]
    return render(
        request,
        "eleves/inscrire.html",
        {
            "form": form,
            "eleves_recents": eleves_recents,
            "annee_active": form.fields["annee_scolaire"].queryset.exists(),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@require_http_methods(["GET", "POST"])
def creation_rapide_eleve(request):
    form = forms.FormulaireEleveRapide(
        request.POST if request.method == "POST" else None
    )
    if request.method == "GET":
        return render(
            request,
            "eleves/partials/form_eleve_rapide.html",
            {"form": form},
        )
    if not form.is_valid():
        return render(
            request,
            "eleves/partials/form_eleve_rapide.html",
            {"form": form},
            status=400,
        )
    eleve = form.save(commit=False)
    eleve.ecole = request.etablissement
    eleve.save()
    return JsonResponse(
        {
            "id": str(eleve.pk),
            "label": f"{eleve.nom_complet} [{eleve.matricule}]",
            "type": "eleve",
        },
        status=201,
    )


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@require_http_methods(["GET", "POST"])
def creation_rapide_inscription(request):
    annee = request.annee_scolaire_courante
    form = forms.FormulaireInscription(
        request.POST if request.method == "POST" else None,
        ecole=request.etablissement,
        annee_scolaire=annee,
    )
    if request.method == "GET":
        return render(
            request,
            "eleves/partials/form_inscription_rapide.html",
            {"form": form},
        )
    if not form.is_valid():
        return render(
            request,
            "eleves/partials/form_inscription_rapide.html",
            {"form": form},
            status=400,
        )
    try:
        inscription = ServiceInscription(request.user).inscrire(
            eleve=form.cleaned_data["eleve"],
            annee=form.cleaned_data["annee_scolaire"],
            classe=form.cleaned_data["classe"],
            type_inscription=form.cleaned_data["type_inscription"],
            frais_inscription=form.cleaned_data["frais_inscription"],
            observations=form.cleaned_data["observations"],
        )
    except ErreurMetierBase as erreur:
        form.add_error(None, str(erreur))
        return render(
            request,
            "eleves/partials/form_inscription_rapide.html",
            {"form": form},
            status=400,
        )
    return JsonResponse(
        {
            "id": str(inscription.pk),
            "label": (
                f"{inscription.eleve.nom_complet} — {inscription.classe.code} "
                f"({inscription.annee_scolaire.libelle})"
            ),
            "type": "inscription",
        },
        status=201,
    )


@login_required
@requiert_tenant
@requiert_une_permission(*PERMISSIONS_CONSULTER_ELEVES)
def liste_inscriptions(request):
    from django.core.paginator import Paginator

    annee = request.annee_scolaire_courante
    q = request.GET.get("q", "").strip()
    classe_id = request.GET.get("classe", "")
    statut = request.GET.get("statut", "")
    type_inscription = request.GET.get("type", "")
    per_page = request.GET.get("per_page", "20")
    if per_page not in {"10", "20", "50"}:
        per_page = "20"

    classes = (
        Classe.objects.filter(ecole=request.etablissement, annee_scolaire=annee)
        .order_by("code")
        if annee
        else Classe.objects.none()
    )
    inscriptions = (
        Inscription.objects.filter(ecole=request.etablissement, annee_scolaire=annee)
        .select_related("eleve", "classe")
        .order_by("classe__code", "eleve__nom", "eleve__prenom")
        if annee
        else Inscription.objects.none()
    )
    permissions = _permissions_eleves(request)
    if _doit_limiter_aux_classes_propres(request, permissions):
        classes = classes.filter(pk__in=_classes_enseignant(request))
        inscriptions = inscriptions.filter(classe__in=classes)
    if q:
        inscriptions = inscriptions.filter(
            Q(eleve__nom__icontains=q)
            | Q(eleve__prenom__icontains=q)
            | Q(eleve__matricule__icontains=q)
        )
    if classe_id:
        try:
            classe_pk = Classe._meta.pk.to_python(classe_id)
        except (TypeError, ValueError, ValidationError):
            classe_pk = None
        if classe_pk is not None and classes.filter(pk=classe_pk).exists():
            inscriptions = inscriptions.filter(classe_id=classe_pk)
        else:
            inscriptions = inscriptions.none()
    if statut in dict(StatutInscription.choices):
        inscriptions = inscriptions.filter(statut=statut)
    if type_inscription in dict(Inscription._meta.get_field("type_inscription").choices):
        inscriptions = inscriptions.filter(type_inscription=type_inscription)

    paginator = Paginator(inscriptions, int(per_page))
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "eleves/inscriptions.html",
        {
            "inscriptions": page_obj.object_list,
            "page_obj": page_obj,
            "annee": annee,
            "classes": classes,
            "q": q,
            "filtre_classe": classe_id,
            "filtre_statut": statut,
            "filtre_type": type_inscription,
            "per_page": per_page,
            "statut_choices": StatutInscription.choices,
            "type_choices": Inscription._meta.get_field("type_inscription").choices,
            "total_inscriptions": paginator.count,
            "peut_gerer_eleves": (
                request.user.is_superuser
                or "eleves.inscrire.toutes_classes" in permissions
            ),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@gerer_erreur_metier
def valider_inscriptions_selection(request):
    if request.method != "POST":
        return redirect("eleves:inscriptions")

    identifiants = request.POST.getlist("inscriptions")
    if not identifiants:
        messages.warning(request, "Sélectionnez au moins une inscription à valider.")
    else:
        inscriptions = Inscription.objects.filter(
            ecole=request.etablissement,
            annee_scolaire=request.annee_scolaire_courante,
            statut=StatutInscription.EN_ATTENTE,
            pk__in=identifiants,
        ).select_related("eleve")
        service = ServiceInscription(request.user)
        validees = 0
        with transaction.atomic():
            for inscription in inscriptions:
                service.valider(inscription)
                validees += 1
        if validees:
            messages.success(
                request,
                f"{validees} inscription(s) sélectionnée(s) validée(s).",
            )
        else:
            messages.warning(
                request,
                "Aucune inscription en attente correspondante n’a été trouvée pour l’année sélectionnée.",
            )

    from django.utils.http import url_has_allowed_host_and_scheme

    retour = request.POST.get("next", "")
    if url_has_allowed_host_and_scheme(retour, allowed_hosts={request.get_host()}):
        return redirect(retour)
    return redirect("eleves:inscriptions")


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
def importer_inscriptions(request):
    """Importe des demandes d'inscription en passant par ServiceInscription."""
    from decimal import Decimal, InvalidOperation
    from apps.academique.models import AnneeScolaire, StatutAnneeScolaire
    from apps.noyau.csv_utils import lire_csv
    from apps.noyau.exceptions import ErreurMetierBase

    annee = request.annee_scolaire_courante
    if annee and annee.statut != StatutAnneeScolaire.ACTIVE:
        annee = None
    resultat = None
    if request.method == "POST":
        fichier = request.FILES.get("fichier_csv")
        if not fichier:
            messages.error(request, "Sélectionnez un fichier CSV.")
        elif not annee:
            messages.error(request, "Aucune année scolaire active pour inscrire les élèves.")
        else:
            try:
                lecteur = lire_csv(
                    fichier,
                    {"matricule", "classe_code", "type_inscription", "frais_inscription", "observations"},
                )
                from apps.academique.models import Classe

                importees, erreurs = 0, []
                for numero, ligne in enumerate(lecteur, start=2):
                    try:
                        with transaction.atomic():
                            eleve = Eleve.objects.get(
                                ecole=request.etablissement,
                                matricule=(ligne.get("matricule") or "").strip(),
                                supprime_le__isnull=True,
                            )
                            classe = Classe.objects.get(
                                ecole=request.etablissement,
                                annee_scolaire=annee,
                                code=(ligne.get("classe_code") or "").strip(),
                            )
                            frais_brut = (ligne.get("frais_inscription") or "").strip()
                            frais = (
                                Decimal(frais_brut.replace(",", "."))
                                if frais_brut
                                else None
                            )
                            ServiceInscription(request.user).inscrire(
                                eleve=eleve,
                                annee=annee,
                                classe=classe,
                                type_inscription=(
                                    ligne.get("type_inscription") or ""
                                ).strip() or "nouveau",
                                frais_inscription=frais,
                                observations=(ligne.get("observations") or "").strip(),
                            )
                        importees += 1
                    except (
                        Eleve.DoesNotExist,
                        Eleve.MultipleObjectsReturned,
                        Classe.DoesNotExist,
                        Classe.MultipleObjectsReturned,
                        ErreurMetierBase,
                        ValidationError,
                        InvalidOperation,
                        ValueError,
                        IntegrityError,
                    ) as erreur:
                        erreurs.append(f"Ligne {numero} : {erreur}")
                resultat = {"importees": importees, "erreurs": erreurs}
            except ValueError as erreur:
                messages.error(request, f"Import impossible : {erreur}")

    return render(
        request,
        "noyau/importer_metier.html",
        {
            "titre": "Importer des inscriptions",
            "description": "Chaque inscription est créée en attente de validation. Le matricule doit désigner un élève de l’établissement et le code classe une classe de l’année active.",
            "entetes": "matricule;classe_code;type_inscription;frais_inscription;observations",
            "retour_url": "eleves:inscriptions",
            "resultat": resultat,
            "nombre": resultat["importees"] if resultat else 0,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@gerer_erreur_metier
def inscrire_groupe(request):
    form = forms.FormulaireInscriptionGroupe(
        request.POST if request.method == "POST" else None,
        ecole=request.etablissement,
    )
    if request.method == "POST" and form.is_valid():
        donnees = form.cleaned_data
        service = ServiceInscription(request.user)
        with transaction.atomic():
            for eleve in donnees["eleves"]:
                service.inscrire(
                    eleve=eleve,
                    annee=donnees["annee_scolaire"],
                    classe=donnees["classe"],
                    type_inscription=donnees["type_inscription"],
                    frais_inscription=donnees["frais_inscription"],
                    observations=donnees["observations"],
                )
        messages.success(
            request,
            f'{len(donnees["eleves"])} inscription(s) créée(s), en attente de validation.',
        )
        return redirect("eleves:inscriptions")

    return render(
        request,
        "eleves/inscrire_groupe.html",
        {
            "form": form,
            "annee_active": form.fields["annee_scolaire"].queryset.exists(),
            "eleves_disponibles": form.fields["eleves"].queryset.exists(),
        },
    )


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@gerer_erreur_metier
def valider_inscription(request, pk):
    inscription = get_object_or_404(Inscription, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        service = ServiceInscription(request.user)
        service.valider(inscription)
        messages.success(request, f"Inscription de {inscription.eleve.nom_complet} validée.")
        return redirect("eleves:inscriptions")
    return render(request, "eleves/valider_inscription.html", {"inscription": inscription})


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
@gerer_erreur_metier
def changer_classe(request, pk):
    inscription = get_object_or_404(Inscription, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        from apps.academique.models import Classe
        nouvelle_classe = get_object_or_404(Classe, pk=request.POST.get("nouvelle_classe"), ecole=request.etablissement)
        service = ServiceInscription(request.user)
        service.changer_de_classe(inscription, nouvelle_classe)
        messages.success(request, f"Élève transféré vers {nouvelle_classe.code}.")
        return redirect("eleves:detail", pk=inscription.eleve.pk)
    from apps.academique.models import Classe
    classes = Classe.objects.filter(annee_scolaire=inscription.annee_scolaire).exclude(pk=inscription.classe.pk)
    return render(request, "eleves/changer_classe.html", {"inscription": inscription, "classes": classes})


@login_required
@requiert_tenant
@requiert_permission("eleves.suspendre.toutes_classes")
@gerer_erreur_metier
def suspendre_eleve(request, pk):
    eleve = get_object_or_404(Eleve, pk=pk, ecole=request.etablissement)
    if request.method == "POST":
        motif = request.POST.get("motif", "")
        inscription = eleve.obtenir_inscription_courante()
        if inscription:
            service = ServiceInscription(request.user)
            service.suspendre(inscription, motif)
            messages.warning(request, f"{eleve.nom_complet} suspendu.")
        return redirect("eleves:detail", pk=pk)
    return render(request, "eleves/suspendre.html", {"eleve": eleve})


@login_required
@requiert_tenant
@requiert_une_permission(*PERMISSIONS_CONSULTER_ELEVES)
def historique_eleve(request, pk):
    eleves = Eleve.objects.filter(pk=pk, ecole=request.etablissement)
    permissions = _permissions_eleves(request)
    if _doit_limiter_aux_classes_propres(request, permissions):
        eleves = eleves.filter(inscriptions__classe__in=_classes_enseignant(request))
    eleve = get_object_or_404(eleves.distinct())
    mouvements = eleve.mouvements.select_related("enregistre_par").order_by("-date_mouvement")
    q = request.GET.get("q", "").strip()
    type_mouvement = request.GET.get("type", "")
    if q:
        mouvements = mouvements.filter(
            Q(motif__icontains=q)
            | Q(etablissement_destination__icontains=q)
            | Q(etablissement_origine__icontains=q)
            | Q(enregistre_par__nom__icontains=q)
            | Q(enregistre_par__prenom__icontains=q)
        )
    if type_mouvement in TypeMouvement.values:
        mouvements = mouvements.filter(type_mouvement=type_mouvement)
    else:
        type_mouvement = ""
    return render(
        request,
        "eleves/historique.html",
        {
            "eleve": eleve,
            "mouvements": mouvements,
            "q": q,
            "filtre_type": type_mouvement,
            "types_mouvement": TypeMouvement.choices,
        },
    )

# À COLLER dans apps/eleves/views.py : remplace l'ancienne fonction importer_eleves
# (les imports `datetime` et `csv` sont faits dans la fonction pour ne rien toucher en haut du fichier).


@login_required
@requiert_tenant
@requiert_permission("eleves.inscrire.toutes_classes")
def importer_eleves(request):
    """Import CSV d'élèves en masse : lit toutes les colonnes connues du modèle."""
    import csv, io, datetime

    # colonne CSV (ou alias) -> champ du modèle
    ALIAS = {
        "nom": "nom",
        "nom_famille": "nom",
        "nom de famille": "nom",
        "prenom": "prenom",
        "prenoms": "prenom",
        "prénom": "prenom",
        "prénoms": "prenom",
        "date_naissance": "date_naissance",
        "date de naissance": "date_naissance",
        "lieu_naissance": "lieu_naissance",
        "lieu naissance": "lieu_naissance",
        "departement_naissance": "departement_naissance",
        "departement naissance": "departement_naissance",
        "pays_naissance": "pays_naissance",
        "pays naissance": "pays_naissance",
        "sexe": "sexe",
        "nationalite": "nationalite",
        "nationalité": "nationalite",
        "adresse": "adresse",
        "adresse_domicile": "adresse",
        "adresse domicile": "adresse",
        "nom_pere": "nom_pere",
        "nom pere": "nom_pere",
        "telephone_parent1": "telephone_parent1",
        "telephone parent1": "telephone_parent1",
        "groupe_sanguin": "groupe_sanguin",
        "groupe sanguin": "groupe_sanguin",
        "statut": "statut",
        "matricule": "matricule",
    }
    champs_modele = {f.name for f in Eleve._meta.get_fields()}

    def lire_date(valeur):
        valeur = (valeur or "").strip()
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
            try:
                return datetime.datetime.strptime(valeur, fmt).date()
            except ValueError:
                continue
        raise ValueError(f"Date invalide : « {valeur} »")

    if request.method == "POST" and request.FILES.get("fichier_csv"):
        texte = request.FILES["fichier_csv"].read().decode("utf-8-sig")
        # séparateur « , » ou « ; » (Excel en français enregistre souvent avec « ; »)
        try:
            dialecte = csv.Sniffer().sniff(texte[:2048], delimiters=",;\t")
        except csv.Error:
            dialecte = csv.excel
        reader = csv.DictReader(io.StringIO(texte), dialect=dialecte)

        nb_crees, nb_ignores, erreurs = 0, 0, []
        colonnes_ignorees = set()

        for num, brut in enumerate(reader, start=2):  # ligne 1 = en-têtes
            try:
                ligne = {}
                for cle, val in brut.items():
                    cle_norm = (cle or "").strip().lower()
                    champ = ALIAS.get(cle_norm)
                    if not champ or champ == "photo":
                        if cle_norm and cle_norm != "photo":
                            colonnes_ignorees.add(cle)
                        continue
                    if champ not in champs_modele:
                        colonnes_ignorees.add(cle)
                        continue
                    ligne[champ] = (val or "").strip()

                if not ligne.get("nom") or not ligne.get("prenom"):
                    raise ValueError("nom ou prénom manquant")

                ligne["nom"] = ligne["nom"].upper()
                ligne["date_naissance"] = lire_date(ligne.get("date_naissance"))
                ligne["sexe"] = (ligne.get("sexe") or "M")[0].upper()
                # Le validateur du modèle n'accepte que « +509XXXXXXXX » : on retire espaces, points et tirets
                if ligne.get("telephone_parent1"):
                    ligne["telephone_parent1"] = "".join(
                        c for c in ligne["telephone_parent1"] if c.isdigit() or c == "+"
                    )
                matricule = ligne.pop("matricule", "")
                # Valeurs vides : on laisse le défaut du modèle (ex. nationalité)
                ligne = {k: v for k, v in ligne.items() if v not in ("", None)}

                if matricule:
                    cherche = {"matricule": matricule}
                else:  # évite les doublons si on réimporte le même fichier
                    cherche = {
                        "nom": ligne["nom"],
                        "prenom": ligne["prenom"],
                        "date_naissance": ligne["date_naissance"],
                    }

                # Matricule vide : Eleve.save() le génère (generer_matricule_eleve)
                _, cree = Eleve.objects.get_or_create(
                    ecole=request.etablissement,
                    **cherche,
                    defaults=ligne,
                )
                if cree:
                    nb_crees += 1
                else:
                    nb_ignores += 1
            except Exception as exc:
                erreurs.append(f"ligne {num} : {exc}")

        messages.success(
            request,
            f"{nb_crees} élève(s) importé(s), {nb_ignores} déjà existant(s), {len(erreurs)} erreur(s).",
        )
        if erreurs:
            messages.warning(
                request,
                "Détail : "
                + " ; ".join(erreurs[:5])
                + (" …" if len(erreurs) > 5 else ""),
            )
        if colonnes_ignorees:
            messages.info(
                request,
                "Colonnes non reconnues (ignorées) : "
                + ", ".join(sorted(colonnes_ignorees)),
            )
        return redirect("eleves:liste")
    return render(request, "eleves/importer.html")


def _generer_matricule(ecole) -> str:
    from django.db.models import Count
    nb = Eleve.tous_objets.filter(ecole=ecole).count()
    annee = __import__("django.utils.timezone", fromlist=["now"]).now().year
    return f"{ecole.slug[:3].upper()}-{annee}-{nb+1:04d}"
