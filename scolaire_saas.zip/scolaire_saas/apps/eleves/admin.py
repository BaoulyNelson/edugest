from django.contrib import admin
from apps.eleves.models import DossierDisciplinaire, Eleve, Inscription, MouvementEleve
from apps.noyau.admin import AdminTenant


@admin.register(Eleve)
class EleveAdmin(AdminTenant):
    list_display = ("matricule", "nom", "prenom", "ecole", "statut", "sexe")
    list_filter = ("ecole", "statut", "sexe")
    search_fields = ("matricule", "nom", "prenom", "ecole__nom", "ecole__slug")
    list_select_related = ("ecole",)


admin.site.register(
    (Inscription, MouvementEleve, DossierDisciplinaire),
    AdminTenant,
)
