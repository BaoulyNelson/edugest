from django.urls import path
from apps.badges import views
app_name = "badges"
urlpatterns = [
    path("", views.liste_badges, name="liste"),
    path("eleves/<uuid:inscription_id>/", views.badge_eleve, name="badge_eleve"),
    path("enseignants/<uuid:enseignant_id>/", views.badge_enseignant, name="badge_enseignant"),
    path("classe/<int:classe_id>/", views.badges_classe, name="badges_classe"),
    path("classe/<int:classe_id>/zip/", views.telecharger_zip_classe, name="zip_classe"),
    path("templates/", views.liste_templates, name="templates"),
]
