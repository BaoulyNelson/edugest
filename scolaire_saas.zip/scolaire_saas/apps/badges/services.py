"""apps/badges/services.py — Génération de badges."""
from apps.noyau.exceptions import OperationImpossibleError

class ServiceBadge:
    def __init__(self, ecole):
        self.ecole = ecole

    def generer_badge_eleve(self, inscription) -> bytes:
        from apps.badges.generateurs.badge_eleve import GenerateurBadgeEleve
        buf = GenerateurBadgeEleve(ecole=self.ecole).generer(inscription)
        return buf.read()
    
        # ↓ méthode manquante
    def generer_badge_enseignant(self, enseignant) -> bytes:
        from apps.badges.generateurs.badge_enseignant import GenerateurBadgeEnseignant
        buf = GenerateurBadgeEnseignant(ecole=self.ecole).generer(enseignant)
        return buf.read()

    def generer_badges_classe(self, classe) -> dict:
        import zipfile
        from io import BytesIO
        import logging
        from apps.eleves.models import Inscription, StatutInscription
        from apps.noyau.exceptions import OperationImpossibleError

        inscrits = Inscription.objects.filter(classe=classe, statut=StatutInscription.VALIDEE).select_related("eleve")
        if not inscrits.exists():
            raise OperationImpossibleError(
                f"Aucun élève avec une inscription validée dans la classe {classe.code}."
            )

        zip_buf = BytesIO()
        generes = 0
        logger = logging.getLogger("badges")
        with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for insc in inscrits:
                try:
                    pdf = self.generer_badge_eleve(insc)
                    zf.writestr(f"badge_{insc.eleve.matricule}.pdf", pdf)
                    generes += 1
                except Exception:
                    logger.exception("Échec de génération du badge pour %s", insc.pk)
        if not generes:
            raise OperationImpossibleError(
                f"Aucun badge n’a pu être généré pour la classe {classe.code}."
            )

        zip_buf.seek(0)
        return {"generes": generes, "zip_bytes": zip_buf.read()}
