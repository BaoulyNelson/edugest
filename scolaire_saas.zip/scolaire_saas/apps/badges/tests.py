from datetime import date

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.academique.models import AnneeScolaire, Classe, StatutAnneeScolaire
from apps.etablissements.models import Etablissement
from apps.parametrage.models import CycleEnseignement, Niveau
from apps.securite.models import PermissionGranulaire, Role, UtilisateurRole


@override_settings(
    STATICFILES_STORAGE="django.contrib.staticfiles.storage.StaticFilesStorage",
    STORAGES={
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    },
)
class AccesBadgesTests(TestCase):
    def setUp(self):
        self.utilisateur = get_user_model().objects.create_user(
            email="badges-sans-permission@example.com",
            nom="Badges",
            prenom="Test",
        )
        self.ecole = Etablissement.objects.create(
            slug="ecole-acces-badges",
            nom="École accès badges",
            ville="Port-au-Prince",
            cree_par=self.utilisateur,
        )
        self.client.force_login(self.utilisateur)
        self.client.defaults["HTTP_X_TENANT_SLUG"] = self.ecole.slug

    def test_listes_badges_et_modeles_refusees_sans_permission(self):
        for nom_url in ("badges:liste", "badges:templates"):
            with self.subTest(nom_url=nom_url):
                response = self.client.get(reverse(nom_url))

                self.assertEqual(response.status_code, 403)

    def test_listes_badges_et_modeles_accessibles_avec_permission(self):
        permission = PermissionGranulaire.objects.create(
            code="badges.generer.toutes_classes",
            description="Générer les badges de toutes les classes.",
            module="badges",
            action="generer",
            portee="toutes_classes",
        )
        role = Role.objects.create(
            ecole=self.ecole,
            code="directeur-badges-test",
            libelle="Directeur",
        )
        role.permissions.add(permission)
        UtilisateurRole.objects.create(
            ecole=self.ecole,
            utilisateur=self.utilisateur,
            role=role,
        )

        annee = AnneeScolaire.objects.create(
            ecole=self.ecole,
            libelle="2026-2027",
            date_debut=date(2026, 9, 1),
            date_fin=date(2027, 6, 30),
            statut=StatutAnneeScolaire.ACTIVE,
            est_courante=True,
        )
        cycle = CycleEnseignement.objects.create(
            ecole=self.ecole,
            code="TEST",
            libelle="Cycle de test",
        )
        niveau = Niveau.objects.create(
            ecole=self.ecole,
            cycle=cycle,
            code="N1",
            libelle="Niveau 1",
        )
        classe = Classe.objects.create(
            ecole=self.ecole,
            annee_scolaire=annee,
            niveau=niveau,
            code="N1-A",
            libelle="Niveau 1 A",
        )

        for nom_url in ("badges:liste", "badges:templates"):
            with self.subTest(nom_url=nom_url):
                response = self.client.get(reverse(nom_url))

                self.assertEqual(response.status_code, 200)

        response_liste = self.client.get(reverse("badges:liste"))
        self.assertContains(response_liste, "Aucun élève inscrit avec un dossier validé")

        response_zip = self.client.get(
            reverse("badges:zip_classe", kwargs={"classe_id": classe.pk})
        )
        self.assertEqual(response_zip.status_code, 302)
        self.assertRedirects(
            response_zip,
            reverse("badges:badges_classe", kwargs={"classe_id": classe.pk}),
        )
