"""Génère un badge PDF élève via ReportLab."""
from io import BytesIO
from reportlab.lib.pagesizes import landscape
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas as pdf_canvas

class GenerateurBadgeEleve:
    LARGEUR = 85 * mm
    HAUTEUR = 54 * mm

    def __init__(self, ecole):
        self.ecole = ecole
        self.couleur = colors.HexColor(ecole.couleur_principale or "#1a3c6e")

    def generer(self, inscription) -> BytesIO:
        buf = BytesIO()
        c = pdf_canvas.Canvas(buf, pagesize=(self.LARGEUR, self.HAUTEUR))
        # Fond coloré haut
        c.setFillColor(self.couleur)
        c.rect(0, self.HAUTEUR - 16*mm, self.LARGEUR, 16*mm, fill=1, stroke=0)
        # Nom école
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 8)
        nom_ecole = (self.ecole.nom_court or self.ecole.nom)[:35]
        c.drawCentredString(self.LARGEUR/2, self.HAUTEUR - 8*mm, nom_ecole.upper())
        # Zone info élève
        c.setFillColor(colors.black)
        c.setFont("Helvetica-Bold", 10)
        eleve = inscription.eleve
        c.drawString(5*mm, self.HAUTEUR - 24*mm, f"{eleve.prenom} {eleve.nom}".upper())
        c.setFont("Helvetica", 8)
        c.drawString(5*mm, self.HAUTEUR - 30*mm, f"Classe : {inscription.classe.code}")
        c.drawString(5*mm, self.HAUTEUR - 36*mm, f"Matricule : {eleve.matricule}")
        c.drawString(5*mm, self.HAUTEUR - 42*mm, f"Année : {inscription.annee_scolaire.libelle}")
        # QR code
        try:
            import qrcode
            donnees = f"ELEVE:{eleve.matricule}:{self.ecole.slug}"
            qr = qrcode.make(donnees)
            qr_buf = BytesIO(); qr.save(qr_buf, format="PNG"); qr_buf.seek(0)
            from reportlab.lib.utils import ImageReader
            c.drawImage(ImageReader(qr_buf), self.LARGEUR - 22*mm, 2*mm, width=20*mm, height=20*mm)
        except Exception:
            pass
        # Bordure
        c.setStrokeColor(self.couleur)
        c.setLineWidth(1)
        c.rect(0.5*mm, 0.5*mm, self.LARGEUR - 1*mm, self.HAUTEUR - 1*mm)
        c.save()
        buf.seek(0)
        return buf

