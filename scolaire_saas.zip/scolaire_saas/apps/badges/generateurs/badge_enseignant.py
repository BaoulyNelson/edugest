

"""Génère un badge PDF enseignant via ReportLab."""
from io import BytesIO
from reportlab.lib.pagesizes import landscape
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas as pdf_canvas


class GenerateurBadgeEnseignant:
    LARGEUR = 85 * mm
    HAUTEUR = 54 * mm

    def __init__(self, ecole):
        self.ecole = ecole
        self.couleur = colors.HexColor(ecole.couleur_principale or "#1a3c6e")
        # Couleur d'accent différente des élèves pour distinguer visuellement
        self.couleur_accent = colors.HexColor(ecole.couleur_secondaire or "#ffffff")

    def generer(self, enseignant) -> BytesIO:
        buf = BytesIO()
        c = pdf_canvas.Canvas(buf, pagesize=(self.LARGEUR, self.HAUTEUR))

        # ── Fond coloré haut ────────────────────────────────────────────────
        c.setFillColor(self.couleur)
        c.rect(0, self.HAUTEUR - 16*mm, self.LARGEUR, 16*mm, fill=1, stroke=0)

        # Nom de l'école
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 8)
        nom_ecole = (self.ecole.nom_court or self.ecole.nom)[:35]
        c.drawCentredString(self.LARGEUR / 2, self.HAUTEUR - 8*mm, nom_ecole.upper())

        # ── Bandeau "ENSEIGNANT" ─────────────────────────────────────────────
        c.setFillColor(colors.HexColor("#f59e0b"))   # ambre — distinct du badge élève
        c.rect(0, self.HAUTEUR - 21*mm, self.LARGEUR, 5*mm, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 7)
        c.drawCentredString(self.LARGEUR / 2, self.HAUTEUR - 18.5*mm, "ENSEIGNANT")

        # ── Informations enseignant ──────────────────────────────────────────
        c.setFillColor(colors.black)
        c.setFont("Helvetica-Bold", 10)
        nom_complet = f"{enseignant.prenom} {enseignant.nom}".upper()
        # Tronquer si trop long
        if len(nom_complet) > 28:
            nom_complet = nom_complet[:26] + "…"
        c.drawString(5*mm, self.HAUTEUR - 28*mm, nom_complet)

        c.setFont("Helvetica", 8)
        specialite = enseignant.get_specialite_principale_display()
        if len(specialite) > 32:
            specialite = specialite[:30] + "…"
        c.setFillColor(colors.HexColor("#374151"))
        c.drawString(5*mm, self.HAUTEUR - 34*mm, specialite)

        c.setFont("Helvetica", 7.5)
        c.setFillColor(colors.black)
        c.drawString(5*mm, self.HAUTEUR - 40*mm, f"Matricule : {enseignant.matricule}")

        # N° licence — signaler si provisoire
        licence = enseignant.numero_licence_menfp or "—"
        if licence.startswith("PROV-"):
            c.setFillColor(colors.HexColor("#dc2626"))
            label_licence = f"Lic. MENFP : {licence} ⚠"
        else:
            c.setFillColor(colors.black)
            label_licence = f"Lic. MENFP : {licence}"
        c.setFont("Helvetica", 7)
        c.drawString(5*mm, self.HAUTEUR - 46*mm, label_licence)

        # ── QR code ─────────────────────────────────────────────────────────
        try:
            import qrcode
            donnees = f"ENSEIGNANT:{enseignant.matricule}:{self.ecole.slug}"
            qr = qrcode.make(donnees)
            qr_buf = BytesIO()
            qr.save(qr_buf, format="PNG")
            qr_buf.seek(0)
            from reportlab.lib.utils import ImageReader
            c.drawImage(
                ImageReader(qr_buf),
                self.LARGEUR - 22*mm, 2*mm,
                width=20*mm, height=20*mm,
            )
        except Exception:
            pass

        # ── Bordure ─────────────────────────────────────────────────────────
        c.setStrokeColor(self.couleur)
        c.setLineWidth(1)
        c.rect(0.5*mm, 0.5*mm, self.LARGEUR - 1*mm, self.HAUTEUR - 1*mm)

        c.save()
        buf.seek(0)
        return buf