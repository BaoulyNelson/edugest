"""apps/badges/models.py — Templates de badges."""
from django.db import models
from apps.noyau.mixins import TenantModelMixin, HorodatageMixin

class TemplateBadge(TenantModelMixin, HorodatageMixin):
    """Template visuel d'un badge (couleurs, disposition, champs affichés)."""
    nom = models.CharField(max_length=80)
    type_badge = models.CharField(max_length=15, choices=[("eleve","Élève"),("enseignant","Enseignant")], default="eleve")
    est_actif = models.BooleanField(default=True)
    couleur_fond = models.CharField(max_length=7, default="#1a3c6e")
    couleur_texte = models.CharField(max_length=7, default="#ffffff")
    afficher_photo = models.BooleanField(default=True)
    afficher_qr = models.BooleanField(default=True)
    afficher_barcode = models.BooleanField(default=False)
    class Meta:
        verbose_name = "Template de badge"
        ordering = ["nom"]
    def __str__(self): return self.nom

class BadgeGenere(TenantModelMixin, HorodatageMixin):
    """Trace d'un badge généré."""
    inscription = models.ForeignKey("eleves.Inscription", null=True, blank=True, on_delete=models.SET_NULL, related_name="badges")
    enseignant = models.ForeignKey("enseignants.Enseignant", null=True, blank=True, on_delete=models.SET_NULL, related_name="badges")
    template = models.ForeignKey(TemplateBadge, null=True, on_delete=models.SET_NULL)
    fichier_pdf = models.FileField(upload_to="badges/%Y/", null=True, blank=True)
    date_generation = models.DateTimeField(auto_now_add=True)
    genere_par = models.ForeignKey("comptes.Utilisateur", null=True, on_delete=models.SET_NULL, related_name="+")
    class Meta:
        verbose_name = "Badge généré"
        ordering = ["-date_generation"]
