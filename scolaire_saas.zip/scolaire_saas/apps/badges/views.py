"""Vues de génération de badges."""
from itertools import count

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import FileResponse, HttpResponse
from apps.noyau.decorateurs import requiert_tenant, requiert_permission
from apps.academique.models import Classe
from apps.eleves.models import Inscription, StatutInscription
from django.db.models import Count, Q

@login_required
@requiert_tenant
@requiert_permission("badges.generer.toutes_classes")
def liste_badges(request):
    from apps.enseignants.models import Enseignant

    annee = request.annee_scolaire_courante
    recherche_classe = request.GET.get("classe", "").strip()
    recherche_enseignant = request.GET.get("enseignant", "").strip()

    classes = (
        Classe.objects
        .filter(ecole=request.etablissement, annee_scolaire=annee)
        .select_related("niveau")
        .annotate(
            nb_inscrits=Count(
                "inscriptions",
                filter=Q(inscriptions__statut=StatutInscription.VALIDEE),
            )
        )
        if annee else []
    )
    if recherche_classe and annee:
        classes = classes.filter(
            Q(code__icontains=recherche_classe)
            | Q(libelle__icontains=recherche_classe)
            | Q(niveau__libelle__icontains=recherche_classe)
        )

    enseignants = (
        Enseignant.objects
        .filter(ecole=request.etablissement, statut="actif")
        .order_by("nom", "prenom")
    )
    if recherche_enseignant:
        enseignants = enseignants.filter(
            Q(nom__icontains=recherche_enseignant)
            | Q(prenom__icontains=recherche_enseignant)
            | Q(matricule__icontains=recherche_enseignant)
            | Q(specialite_principale__icontains=recherche_enseignant)
        )

    return render(request, "badges/liste.html", {
        "classes":     classes,
        "annee":       annee,
        "enseignants": enseignants,
        "recherche_classe": recherche_classe,
        "recherche_enseignant": recherche_enseignant,
    })

@login_required
@requiert_tenant
@requiert_permission("badges.generer.toutes_classes")
def badge_eleve(request, inscription_id):
    inscription = get_object_or_404(Inscription, pk=inscription_id, ecole=request.etablissement)
    from apps.badges.services import ServiceBadge
    service = ServiceBadge(ecole=request.etablissement)
    pdf_bytes = service.generer_badge_eleve(inscription)
    return HttpResponse(pdf_bytes, content_type="application/pdf",
                        headers={"Content-Disposition": f"inline; filename=badge_{inscription.eleve.matricule}.pdf"})


@login_required
@requiert_tenant
@requiert_permission("badges.generer.toutes_classes")
def badge_enseignant(request, enseignant_id):
    from apps.enseignants.models import Enseignant
    from apps.badges.services import ServiceBadge

    enseignant = get_object_or_404(Enseignant, pk=enseignant_id, ecole=request.etablissement)
    service    = ServiceBadge(ecole=request.etablissement)
    pdf_bytes  = service.generer_badge_enseignant(enseignant)

    return HttpResponse(
        pdf_bytes,
        content_type="application/pdf",
        headers={
            "Content-Disposition": f'inline; filename="badge_{enseignant.matricule}.pdf"'
        },
    )

@login_required
@requiert_tenant
@requiert_permission("badges.generer.toutes_classes")
def badges_classe(request, classe_id):
    classe = get_object_or_404(Classe, pk=classe_id, ecole=request.etablissement)
    q = request.GET.get("q", "").strip()
    inscrits = Inscription.objects.filter(
        ecole=request.etablissement,
        classe=classe,
        statut=StatutInscription.VALIDEE,
    ).select_related("eleve")
    nb_inscrits = inscrits.count()
    if q:
        inscrits = inscrits.filter(
            Q(eleve__nom__icontains=q)
            | Q(eleve__prenom__icontains=q)
            | Q(eleve__matricule__icontains=q)
        )
    return render(
        request,
        "badges/classe.html",
        {
            "classe": classe,
            "inscrits": inscrits,
            "nb_inscrits": nb_inscrits,
            "q": q,
        },
    )


@login_required
@requiert_tenant
@requiert_permission("badges.generer.toutes_classes")
def telecharger_zip_classe(request, classe_id):
    classe = get_object_or_404(Classe, pk=classe_id, ecole=request.etablissement)
    if not Inscription.objects.filter(
        ecole=request.etablissement,
        classe=classe,
        statut=StatutInscription.VALIDEE,
    ).exists():
        messages.warning(
            request,
            "Aucun élève avec une inscription validée dans cette classe : "
            "aucune archive ZIP n’a été générée.",
        )
        return redirect("badges:badges_classe", classe_id=classe.pk)

    from apps.badges.services import ServiceBadge
    import io
    from apps.noyau.exceptions import OperationImpossibleError

    service = ServiceBadge(ecole=request.etablissement)
    try:
        resultat = service.generer_badges_classe(classe)
    except OperationImpossibleError as exc:
        messages.error(request, str(exc))
        return redirect("badges:badges_classe", classe_id=classe.pk)
    return HttpResponse(
        resultat["zip_bytes"],
        content_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=badges_{classe.code}.zip"}
    )


@login_required
@requiert_tenant
@requiert_permission("badges.generer.toutes_classes")
def liste_templates(request):
    return render(request, "badges/templates.html")
