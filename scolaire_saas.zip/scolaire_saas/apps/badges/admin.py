from django.contrib import admin
from apps.badges.models import BadgeGenere, TemplateBadge
from apps.noyau.admin import AdminTenant

admin.site.register((TemplateBadge, BadgeGenere), AdminTenant)
