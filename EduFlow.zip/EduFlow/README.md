# EduFlow

EduFlow est un ERP éducatif SaaS en cours de réalisation incrémentale. Les validations locales couvrent SQLite et PostgreSQL 18.6. La CI hébergée GitHub Actions n’a pas encore été exécutée et reste explicitement à valider.

## Stack vérifiée au cadrage

Références consultées le 28 octobre 2026 :

- Python 3.13 : installé localement en version 3.13.7 ; Django 6.1 prend en charge Python 3.13. Pour les environnements CI, `3.13` désigne la dernière micro-version disponible. La version locale n’est pas le dernier correctif de cette branche.
- Django 6.1.2 : dernière version publiée indiquée par le site officiel Django ; maintenance de sécurité annoncée jusqu’en décembre 2027.
- PostgreSQL 18.6 : dernière version mineure supportée indiquée par la politique de versionnement PostgreSQL consultée.
- Psycopg 3.3.6, python-dotenv 1.2.4, pytest 9.2.0, pytest-django 4.14.0 et Ruff 0.17.3 : versions verrouillées dans le projet. Suite complète de 66 tests validée localement sur PostgreSQL.

Les versions directes sont listées dans `requirements.in`. `requirements.txt` verrouille les versions directes et transitives vérifiées pour Python 3.13, sur Windows et Linux. Les hashes de distributions ne sont pas inclus ; toute mise à jour doit régénérer le verrou et vérifier les compatibilités.

## Installation locale (PowerShell)

```powershell
py -3.13 -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
$env:EDUFLOW_SECRET_KEY = (python -c "import secrets; print(secrets.token_urlsafe(64))")
python manage.py check
python manage.py migrate
python manage.py createsuperuser
pytest
ruff check .
python manage.py runserver
```

En développement, `EDUFLOW_DEBUG` est activé par défaut afin que `runserver` serve les fichiers statiques, y compris les styles de l’administration Django. `EDUFLOW_DEBUG` peut être défini explicitement dans `.env`; il doit rester désactivé en staging et en production. Sans configuration de base, le développement et les tests utilisent SQLite. Les e-mails sont écrits dans la console en développement ; configurez SMTP par variables `EDUFLOW_EMAIL_*` pour un environnement réel. Après avoir déployé, exécutez quotidiennement `python manage.py purger_compteurs_auth` et `python manage.py expirer_abonnements_saas`. PostgreSQL est la base de référence ; les tests CI y exécutent les migrations et la suite de tests.

L’administration Django expose les modèles métier à l’accès CRUD des comptes staff autorisés. Elle est globale et les écritures directes ne passent pas nécessairement par les services métier, les vérifications de tenant, les transitions financières ni les journaux d’audit. Réservez-la aux opérations de plateforme de confiance; pour les opérations courantes, utilisez les interfaces métier et SaaS.

## PostgreSQL local

Choisissez le serveur PostgreSQL déjà installé ou le service Docker Compose; les deux n’ont pas à écouter simultanément sur le port 5432. Django charge `.env` pour le développement et les tests; les variables déjà définies dans le processus gardent la priorité. Copiez le modèle, puis remplacez les paramètres de connexion par ceux de votre base locale :

```powershell
Copy-Item .env.example .env
notepad .env
```

Uniquement si vous préférez le serveur conteneurisé :

```powershell
docker compose up -d db
```

Après avoir configuré `.env` :

```powershell
python -m pip install -r requirements.txt
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py migrate
python -m pytest
ruff check .
```

Le fichier `.env.example` ne contient que des valeurs de remplacement; `.env` est une configuration locale et ne doit pas être livré ni utilisé comme configuration de production. Compose lit également `.env` pour démarrer sa base. Le projet utilise Psycopg 3 (`psycopg[binary]`); l’installation séparée de `psycopg2-binary` n’est pas nécessaire à cette configuration.

## Sécurité et limites de la fondation

- Le modèle `CompteUtilisateur` est le modèle d’authentification Django dès la première migration ; son identifiant est un UUID et l’e-mail normalisé est l’identifiant de connexion.
- La connexion exige une adresse vérifiée ; une invitation à usage unique vérifie l’adresse du destinataire. La récupération de mot de passe est fournie par Django et les sessions précédentes sont invalidées après réinitialisation.
- Les tentatives de connexion et de récupération sont limitées à cinq par paire adresse/IP sur quinze minutes ; les empreintes sont pseudonymisées et purgeables.
- Les opérations utilisateur sont des parcours Django classiques avec sessions, formulaires et protection CSRF. Les routes REST `/api/v1/` et la dépendance Django REST Framework ont été retirées ; les URL métier lisibles sont branchées dans `config/urls.py` et les services continuent d’appliquer les règles tenant, abonnement et audit.
- Le portail opérateur SaaS est une interface Django classique sous `/administration-saas/` et exige le droit Django `abonnements.gerer_abonnements_saas` (ou un superutilisateur). Le répertoire des établissements se trouve sous `/administration-saas/etablissements/`; les lectures transversales et mutations sont auditées. Le MVP ne branche aucun prestataire de paiement et ne stocke aucune donnée de carte.
- La page publique `/` permet de découvrir EduFlow et affiche uniquement les plans actifs, leurs tarifs, droits et quotas configurés. Les tarifs catalogue actuels sont Starter 2 500 HTG/mois, Professional 5 000 HTG/mois et Enterprise 7 500 HTG/mois; l’année vaut 12 mensualités sans remise. `/creer-etablissement/` permet au responsable d’envoyer une demande autonome avec vérification d’e-mail. Le plan explicitement codé `gratuit` est activé automatiquement pour sept jours après confirmation d’adresse, sans événement de paiement; le tenant est ensuite restreint à échéance. Les demandes payantes restent examinées par un opérateur, puis l’accès dépend de la confirmation du paiement.
- La RLS PostgreSQL n’est pas activée. Les vérifications applicatives restent obligatoires ; les tests A/B vérifient le contexte, les memberships, les invitations et les changements de rôles.
- Les configurations staging/production rejettent SQLite et exigent une clé secrète et des hôtes autorisés ; la mise en production exige encore une configuration HTTPS, secrets, sauvegardes et runbooks dédiée.
- MFA est recommandée mais optionnelle dans le MVP selon le choix utilisateur ; elle devra être réévaluée avant la production des rôles privilégiés.
- Le portail HTML authentifié comprend un tableau de bord contextualisé par établissement (`/tableau-de-bord/`), les apprenants (`/espace/apprenants/`), candidatures (`/espace/candidatures/`), inscriptions (`/inscriptions/`), groupes (`/espace/groupes/`), équipe (`/espace/equipe/`), séances et feuilles de présence (`/espace/presences/`), évaluations, notes, résultats et documents (`/espace/evaluations/`). Ces parcours sont limités au tenant et aux affectations du professeur ; les corrections exigent un motif lorsqu’il est nécessaire et sont auditées.
- Les pages authentifiées proposent aussi la recherche tenant-scoped (`/espace/recherche/`), les notifications, la messagerie privée, les plans de cours (`/espace/plans-de-cours/`), les devoirs (`/espace/devoirs/`), la création manuelle de quiz (`/espace/quiz/`), la bibliothèque (`/espace/bibliotheque/`) et les paramètres de l’établissement (`/espace/parametres/`). Les responsables peuvent lier un compte membre actif à un dossier apprenant depuis la liste des apprenants ; le portail `/espace/mes-cours/` affiche alors uniquement les contenus des groupes auxquels ce dossier est activement inscrit, sans fonctionnalité de remise de devoir. La bibliothèque est consultable en lecture par ces apprenants, avec les mêmes contrôles de tenant et de cours. La génération par IA externe reste désactivée sans fournisseur configuré. Les fichiers de la bibliothèque sont stockés sous `private/`, hors du répertoire média public, et ne sont délivrés qu’après vérification de l’accès au tenant et au cours.

Les écrans Django classiques de gestion sont accessibles via `/campus/`,
`/annees-academiques/`, `/periodes-academiques/`, `/programmes/`, `/niveaux/`,
`/cours/`, `/groupes/`, `/etudiants/`, `/admissions/`, `/inscriptions/`,
`/emplois-du-temps/`, `/presences/`, `/evaluations/`, `/finances/` et
`/rapports/`. Les formulaires concernés proposent une création rapide des
références liées sans quitter le formulaire principal. Aucun endpoint REST n’est
branché : les services métier sont appelés directement par les vues HTML.

## CI

Les fonctionnalités livrées en Phase 5 sont décrites dans
[la note Profils, admissions et inscriptions](docs/phase-5-profils-admissions-inscriptions.md);
la Phase 6 est décrite dans
[la note Enseignants, horaires et présences](docs/phase-6-enseignants-horaires-presences.md);
la Phase 7 est décrite dans
[la note Évaluations, notes, résultats et documents](docs/phase-7-evaluations-notes-resultats.md);
la Phase 8 est décrite dans
[la note Finances scolaires](docs/phase-8-finances-scolaires.md).
Le premier incrément de la Phase 9, avec rapports agrégés tenant-scoped, est
décrit dans [la note Rapports](docs/phase-9-rapports.md). Un premier flux
d’import CSV de candidatures (500 lignes maximum, validation atomique et
rejouable) et d’export CSV tenant-scoped, audité et non mis en cache est
également disponible dans l’espace admissions. Les imports/exports des autres
domaines, les grands traitements asynchrones et leur stockage privé avec
expiration, les rapports financiers et les autres améliorations UX restent à
réaliser.

La configuration CI cible Python 3.13 et PostgreSQL 18.6. Le même ensemble de contrôles (`ruff check .`, `manage.py check`, vérification des migrations, migrations fraîches et `pytest`) a été exécuté localement; les migrations sont à jour et les **103 tests ont réussi sur PostgreSQL**. Les **5 scénarios Phase 6**, **4 scénarios Phase 7** et **2 scénarios Phase 8** ont également été exécutés sur SQLite. Cela valide les parcours locaux, mais ne remplace pas l’exécution du workflow GitHub Actions : la CI hébergée reste explicitement non validée.

Pour le cadrage et les limites, consulter `docs\phase-0-audit.md`, `docs\phase-1-foundations.md`, `docs\phase-2-tenants.md`, `docs\phase-3-abonnements.md` et les ADR de `docs\adr\`.
