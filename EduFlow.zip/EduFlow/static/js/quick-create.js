(() => {
  const dialog = document.querySelector("[data-quick-create-dialog]");
  if (!(dialog instanceof HTMLDialogElement)) {
    return;
  }

  const content = dialog.querySelector("[data-quick-create-content]");
  const title = dialog.querySelector("[data-quick-create-title]");
  let targetSelect = null;

  document.addEventListener("click", async (event) => {
    const closeButton = event.target.closest("[data-quick-create-close]");
    if (closeButton) {
      dialog.close();
      return;
    }

    const trigger = event.target.closest("[data-quick-create-url]");
    if (!trigger) {
      return;
    }

    targetSelect = document.getElementById(trigger.dataset.quickCreateTarget);
    if (!(targetSelect instanceof HTMLSelectElement)) {
      return;
    }

    title.textContent = trigger.dataset.quickCreateLabel || "Créer une donnée";
    content.textContent = "Chargement…";
    dialog.showModal();
    try {
      const response = await fetch(trigger.dataset.quickCreateUrl, {
        headers: {"X-Requested-With": "XMLHttpRequest"},
      });
      if (!response.ok) {
        throw new Error(`Le formulaire n’a pas pu être chargé (${response.status}).`);
      }
      content.innerHTML = await response.text();
    } catch (error) {
      content.innerHTML = "";
      const alert = document.createElement("p");
      alert.className = "field-error";
      alert.setAttribute("role", "alert");
      alert.textContent = error.message;
      content.append(alert);
    }
  });

  dialog.addEventListener("submit", async (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || !form.matches("[data-quick-create-form]")) {
      return;
    }
    event.preventDefault();
    const submit = form.querySelector('button[type="submit"]');
    if (submit) {
      submit.disabled = true;
    }
    try {
      const response = await fetch(form.action, {
        method: "POST",
        body: new FormData(form),
        headers: {"X-Requested-With": "XMLHttpRequest"},
      });
      const contentType = response.headers.get("content-type") || "";
      if (response.status === 422 && contentType.includes("text/html")) {
        content.innerHTML = await response.text();
        return;
      }
      if (!response.ok || !contentType.includes("application/json")) {
        throw new Error(`La création a échoué (${response.status}).`);
      }
      const result = await response.json();
      if (!result.success || !targetSelect) {
        throw new Error("La création n’a pas renvoyé de donnée sélectionnable.");
      }
      let option = [...targetSelect.options].find((item) => item.value === result.id);
      if (!option) {
        option = new Option(result.label, result.id, true, true);
        targetSelect.add(option);
      }
      targetSelect.value = result.id;
      targetSelect.dispatchEvent(new Event("change", {bubbles: true}));
      dialog.close();
    } catch (error) {
      let alert = content.querySelector("[data-quick-create-error]");
      if (!alert) {
        alert = document.createElement("p");
        alert.className = "field-error";
        alert.setAttribute("role", "alert");
        alert.dataset.quickCreateError = "true";
        content.prepend(alert);
      }
      alert.textContent = error.message;
    } finally {
      if (submit && submit.isConnected) {
        submit.disabled = false;
      }
    }
  });
})();
