function mettreAJourValeurCouleur() {
  const couleur = document.getElementById("id_couleur_principale");
  const valeur = document.getElementById("tenant-profile-color-value");
  if (couleur && valeur) valeur.value = couleur.value.toUpperCase();
}

function mettreAJourOngletActif() {
  const hash = window.location.hash;
  document.querySelectorAll(".tenant-profile-tabs a").forEach((onglet) => {
    const actif = hash && onglet.hash === hash;
    onglet.classList.toggle("is-active", Boolean(actif));
    if (actif) {
      onglet.setAttribute("aria-current", "location");
    } else {
      onglet.removeAttribute("aria-current");
    }
  });
}

window.addEventListener("hashchange", mettreAJourOngletActif);
mettreAJourOngletActif();

document.addEventListener("input", (event) => {
  if (event.target.id === "id_couleur_principale") mettreAJourValeurCouleur();
});

document.addEventListener("click", async (event) => {
  const onglet = event.target.closest(".tenant-profile-tabs a");
  if (onglet) {
    document.querySelectorAll(".tenant-profile-tabs a").forEach((element) => {
      element.classList.toggle("is-active", element === onglet);
      if (element === onglet) {
        element.setAttribute("aria-current", "location");
      } else {
        element.removeAttribute("aria-current");
      }
    });
    return;
  }

  const preset = event.target.closest("[data-color-preset]");
  if (preset) {
    const couleur = document.getElementById("id_couleur_principale");
    if (couleur) {
      couleur.value = preset.dataset.colorPreset;
      couleur.dispatchEvent(new Event("input", { bubbles: true }));
      couleur.dispatchEvent(new Event("change", { bubbles: true }));
    }
    return;
  }

  const button = event.target.closest("[data-copy-text]");
  if (!button) return;

  const status = document.getElementById(button.dataset.copyStatus);
  if (!status) return;

  try {
    await navigator.clipboard.writeText(button.dataset.copyText);
    status.textContent = "Identifiant copié.";
  } catch {
    const champ = document.createElement("textarea");
    champ.value = button.dataset.copyText;
    champ.setAttribute("readonly", "");
    champ.style.position = "fixed";
    champ.style.opacity = "0";
    document.body.append(champ);
    champ.select();
    const copiee = document.execCommand("copy");
    champ.remove();
    status.textContent = copiee
      ? "Identifiant copié."
      : "Copie indisponible dans ce navigateur.";
  }
});
