(() => {
  const menu = document.querySelector(".mobile-more");

  if (!menu) {
    return;
  }

  const closeButton = menu.querySelector(".mobile-drawer-close");
  const backdrop = menu.querySelector(".mobile-drawer-backdrop");
  const summary = menu.querySelector("summary");
  const firstLink =
    menu.querySelector('.mobile-drawer-links a[aria-current="page"]') ||
    menu.querySelector(".mobile-drawer-links a");

  menu.addEventListener("toggle", () => {
    if (menu.open && firstLink) {
      firstLink.focus();
    }
  });

  const closeMenu = () => {
    if (!menu.open) {
      return;
    }
    menu.open = false;
    summary.focus();
  };

  closeButton.addEventListener("click", closeMenu);
  backdrop.addEventListener("click", closeMenu);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      if (document.querySelector(".logout-dialog[open]")) {
        return;
      }
      closeMenu();
      return;
    }

    if (event.key === "Tab" && menu.open) {
      const focusable = Array.from(
        menu.querySelectorAll(
          '.mobile-drawer a[href], .mobile-drawer button:not([disabled]), .mobile-drawer select:not([disabled])',
        ),
      );
      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });
})();
