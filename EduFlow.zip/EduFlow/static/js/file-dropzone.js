function initialiserZoneDepot(zone) {
  const input = zone.querySelector('input[type="file"]');
  if (!input || input.dataset.dropzoneReady === "true" || input.closest(".dropzone")) return;
  input.dataset.dropzoneReady = "true";

  const conteneur = document.createElement("div");
  conteneur.className = "file-upload-control";
  input.parentNode.insertBefore(conteneur, input);
  conteneur.append(input);

  const depot = document.createElement("div");
  depot.className = "file-upload-dropzone";
  depot.tabIndex = 0;
  depot.setAttribute("role", "group");
  depot.setAttribute("aria-label", "Zone de dépôt de fichier");

  const icone = document.createElement("span");
  icone.className = "file-upload-icon";
  icone.setAttribute("aria-hidden", "true");
  icone.textContent = "↑";

  const consigne = document.createElement("span");
  consigne.className = "file-upload-instruction";
  consigne.textContent = "Glissez-déposez votre fichier ici";

  const details = document.createElement("span");
  details.className = "file-upload-details";
  details.textContent = "ou";

  const parcourir = document.createElement("button");
  parcourir.type = "button";
  parcourir.className = "file-upload-browse";
  parcourir.textContent = "Parcourir";

  const fichiers = document.createElement("span");
  fichiers.className = "file-upload-selection";
  fichiers.setAttribute("aria-live", "polite");
  fichiers.textContent = "Aucun fichier sélectionné";

  depot.append(icone, consigne, details, parcourir, fichiers);
  conteneur.append(depot);

  const actualiserSelection = () => {
    const selection = Array.from(input.files || []);
    fichiers.textContent = selection.length
      ? selection.map((fichier) => fichier.name).join(", ")
      : "Aucun fichier sélectionné";
    depot.classList.toggle("has-file", selection.length > 0);
  };

  parcourir.addEventListener("click", () => input.click());
  input.addEventListener("change", actualiserSelection);
  depot.addEventListener("keydown", (event) => {
    if (event.target === depot && (event.key === "Enter" || event.key === " ")) {
      event.preventDefault();
      input.click();
    }
  });
  ["dragenter", "dragover"].forEach((nomEvenement) => {
    depot.addEventListener(nomEvenement, (event) => {
      event.preventDefault();
      depot.classList.add("is-dragover");
    });
  });
  ["dragleave", "drop"].forEach((nomEvenement) => {
    depot.addEventListener(nomEvenement, (event) => {
      event.preventDefault();
      depot.classList.remove("is-dragover");
    });
  });
  depot.addEventListener("drop", (event) => {
    const depots = event.dataTransfer?.files;
    if (!depots?.length) return;
    if (!input.multiple && depots.length > 1) {
      const transfert = new DataTransfer();
      transfert.items.add(depots[0]);
      input.files = transfert.files;
    } else {
      input.files = depots;
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
  });
}

function initialiserZonesDepot(racine = document) {
  racine.querySelectorAll('input[type="file"]').forEach((input) => {
    initialiserZoneDepot(input.parentElement);
  });
}

function demarrerZonesDepot() {
  initialiserZonesDepot();
  new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((noeud) => {
        if (noeud.nodeType === Node.ELEMENT_NODE) initialiserZonesDepot(noeud);
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", demarrerZonesDepot, { once: true });
} else {
  demarrerZonesDepot();
}
