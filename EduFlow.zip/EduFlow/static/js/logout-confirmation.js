(() => {
  const dialog = document.querySelector(".logout-dialog");

  if (!dialog || typeof dialog.showModal !== "function") {
    return;
  }

  const triggers = document.querySelectorAll("[data-open-logout-dialog]");
  const cancelButton = dialog.querySelector("[data-cancel-logout]");
  let lastTrigger = null;

  const restoreFocus = () => {
    if (lastTrigger && lastTrigger.isConnected) {
      lastTrigger.focus();
    }
    lastTrigger = null;
  };

  triggers.forEach((trigger) => {
    trigger.addEventListener("click", () => {
      lastTrigger = trigger;
      dialog.showModal();
      cancelButton.focus();
    });
  });

  cancelButton.addEventListener("click", () => {
    dialog.close();
    restoreFocus();
  });

  dialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    dialog.close();
    restoreFocus();
  });

  dialog.addEventListener("click", (event) => {
    if (event.target === dialog) {
      dialog.close();
    }
  });

  dialog.addEventListener("close", restoreFocus);
})();
