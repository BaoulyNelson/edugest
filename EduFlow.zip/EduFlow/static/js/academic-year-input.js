function formaterAnneeAcademique(champ) {
  const chiffresAvantCurseur = champ.value.slice(0, champ.selectionStart || 0).replace(/\D/g, "").length;
  const chiffres = champ.value.replace(/\D/g, "").slice(0, 8);
  const valeur = chiffres.length >= 4
    ? `${chiffres.slice(0, 4)}-${chiffres.slice(4)}`
    : chiffres;

  if (champ.value === valeur) return;

  champ.value = valeur;
  const positionCurseur = chiffresAvantCurseur + (chiffresAvantCurseur >= 4 ? 1 : 0);
  champ.setSelectionRange(positionCurseur, positionCurseur);
}

function initialiserChampAnneeAcademique(champ) {
  if (champ.dataset.academicYearReady === "true") return;
  champ.dataset.academicYearReady = "true";
  champ.addEventListener("input", () => formaterAnneeAcademique(champ));
  formaterAnneeAcademique(champ);
}

function initialiserChampsAnneeAcademique(racine = document) {
  if (racine.matches?.("[data-academic-year-input]")) {
    initialiserChampAnneeAcademique(racine);
  }
  racine.querySelectorAll?.("[data-academic-year-input]").forEach(initialiserChampAnneeAcademique);
}

function demarrerChampsAnneeAcademique() {
  initialiserChampsAnneeAcademique();
  new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((noeud) => {
        if (noeud.nodeType === Node.ELEMENT_NODE) initialiserChampsAnneeAcademique(noeud);
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", demarrerChampsAnneeAcademique, { once: true });
} else {
  demarrerChampsAnneeAcademique();
}
