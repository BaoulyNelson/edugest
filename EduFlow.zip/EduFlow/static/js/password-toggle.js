(() => {
  let generatedId = 0;

  function initializePasswordInputs(container = document) {
    for (const input of container.querySelectorAll('input[type="password"]')) {
      if (input.dataset.passwordToggleInitialized) continue;
      input.dataset.passwordToggleInitialized = "true";

      const wrapper = document.createElement("span");
      wrapper.className = "password-input-control";
      input.parentNode.insertBefore(wrapper, input);
      wrapper.append(input);

      if (!input.id) {
        generatedId += 1;
        input.id = `password-input-${generatedId}`;
      }

      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "password-visibility-toggle";
      toggle.setAttribute("aria-controls", input.id);
      toggle.setAttribute("aria-pressed", "false");
      toggle.setAttribute("aria-label", "Afficher le mot de passe");
      toggle.title = "Afficher le mot de passe";
      toggle.innerHTML =
        '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';

      toggle.addEventListener("click", () => {
        const visible = input.type === "password";
        input.type = visible ? "text" : "password";
        const label = visible ? "Masquer le mot de passe" : "Afficher le mot de passe";
        toggle.setAttribute("aria-pressed", String(visible));
        toggle.setAttribute("aria-label", label);
        toggle.title = label;
        toggle.innerHTML = visible
          ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 3 18 18"/><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a14.8 14.8 0 0 1-3.1 3.9"/><path d="M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10.8 10.8 0 0 0 3-.4"/></svg>'
          : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
      });

      wrapper.append(toggle);
    }
  }

  initializePasswordInputs();
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node instanceof HTMLElement) initializePasswordInputs(node);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
