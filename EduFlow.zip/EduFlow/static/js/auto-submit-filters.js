(() => {
  const searchDelay = 300;
  const timers = new WeakMap();

  function submit(form) {
    if (typeof form.requestSubmit === "function") {
      form.requestSubmit();
    } else {
      form.submit();
    }
  }

  document.addEventListener("input", (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.type !== "search") {
      return;
    }
    const form = input.form;
    if (!form || form.method.toLowerCase() !== "get") {
      return;
    }
    window.clearTimeout(timers.get(form));
    timers.set(form, window.setTimeout(() => submit(form), searchDelay));
  });

  document.addEventListener("change", (event) => {
    const control = event.target;
    if (!(control instanceof HTMLSelectElement || control instanceof HTMLInputElement)) {
      return;
    }
    const form = control.form;
    if (!form) {
      return;
    }
    if (form.dataset.autoSubmitOnChange === "true") {
      submit(form);
      return;
    }
    if (
      form.method.toLowerCase() === "get"
      && (control instanceof HTMLSelectElement || control.type === "date")
    ) {
      window.clearTimeout(timers.get(form));
      submit(form);
    }
  });
})();
