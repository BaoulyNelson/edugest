from django.core.mail.backends.console import EmailBackend as ConsoleBackend


class EmailBackend(ConsoleBackend):
    """Affiche les e-mails en clair dans la console (développement uniquement)."""

    def write_message(self, message):
        self.stream.write(
            f"\n{'=' * 70}\n"
            f"À      : {', '.join(message.to)}\n"
            f"Sujet  : {message.subject}\n"
            f"{'-' * 70}\n"
            f"{message.body}\n"
            f"{'=' * 70}\n"
        )
        self.stream.flush()
