"""Django settings for the EduFlow project."""

import os
import secrets
from pathlib import Path
from urllib.parse import urlparse

from django.core.exceptions import ImproperlyConfigured
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / ".env", override=False)

ENVIRONMENT = os.environ.get("EDUFLOW_ENV", "development").strip().lower()
if ENVIRONMENT not in {"development", "test", "staging", "production"}:
    raise ImproperlyConfigured("EDUFLOW_ENV must be development, test, staging, or production.")

SECRET_KEY = os.environ.get("EDUFLOW_SECRET_KEY")
if not SECRET_KEY:
    if ENVIRONMENT in {"staging", "production"}:
        raise ImproperlyConfigured("EDUFLOW_SECRET_KEY is required outside development and tests.")
    SECRET_KEY = secrets.token_urlsafe(64)


def _environment_flag(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized not in {"1", "true", "yes", "on", "0", "false", "no", "off"}:
        raise ImproperlyConfigured(f"{name} must be a boolean value.")
    return normalized in {"1", "true", "yes", "on"}


def _environment_list(name: str, default: tuple[str, ...] = ()) -> list[str]:
    value = os.environ.get(name)
    if value is None:
        return list(default)
    return [item.strip() for item in value.split(",") if item.strip()]


def _environment_integer(name: str, default: int) -> int:
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError as error:
        raise ImproperlyConfigured(f"{name} must be an integer.") from error


DEBUG = _environment_flag(
    "EDUFLOW_DEBUG",
    default=ENVIRONMENT == "development",
)
ALLOWED_HOSTS = _environment_list(
    "EDUFLOW_ALLOWED_HOSTS",
    ("localhost", "127.0.0.1") if ENVIRONMENT in {"development", "test"} else (),
)
if ENVIRONMENT in {"staging", "production"} and not ALLOWED_HOSTS:
    raise ImproperlyConfigured(
        "EDUFLOW_ALLOWED_HOSTS must be explicitly configured in staging and production."
    )

CSRF_TRUSTED_ORIGINS = _environment_list("EDUFLOW_CSRF_TRUSTED_ORIGINS")

EDUFLOW_BASE_URL = (
    os.environ.get("EDUFLOW_BASE_URL") or "http://localhost:8000"
).rstrip("/")
BASE_URL_PARTS = urlparse(EDUFLOW_BASE_URL)
if BASE_URL_PARTS.scheme not in {"http", "https"} or not BASE_URL_PARTS.netloc:
    raise ImproperlyConfigured("EDUFLOW_BASE_URL doit être une URL HTTP(S) absolue.")
if ENVIRONMENT in {"staging", "production"}:
    if BASE_URL_PARTS.scheme != "https":
        raise ImproperlyConfigured("EDUFLOW_BASE_URL doit utiliser HTTPS hors développement.")

MAIL_HOST = os.environ.get("EDUFLOW_EMAIL_HOST", "")
MAIL_PORT = _environment_integer("EDUFLOW_EMAIL_PORT", 587)
MAIL_TIMEOUT = _environment_integer("EDUFLOW_EMAIL_TIMEOUT", 10)
MAIL_USERNAME = os.environ.get("EDUFLOW_EMAIL_USER", "")
MAIL_PASSWORD = os.environ.get("EDUFLOW_EMAIL_PASSWORD", "")
MAIL_USE_TLS = _environment_flag("EDUFLOW_EMAIL_USE_TLS", True)
DEFAULT_FROM_EMAIL = os.environ.get("EDUFLOW_DEFAULT_FROM_EMAIL", "")
if ENVIRONMENT in {"staging", "production"}:
    if not MAIL_HOST or not DEFAULT_FROM_EMAIL:
        raise ImproperlyConfigured(
            "EDUFLOW_EMAIL_HOST et EDUFLOW_DEFAULT_FROM_EMAIL sont obligatoires en production."
        )
    MAILERS = {
        "default": {
            "BACKEND": "django.core.mail.backends.smtp.EmailBackend",
            "OPTIONS": {
                "host": MAIL_HOST,
                "port": MAIL_PORT,
                "username": MAIL_USERNAME,
                "password": MAIL_PASSWORD,
                "use_tls": MAIL_USE_TLS,
                "timeout": MAIL_TIMEOUT,
            },
        }
    }
else:
    DEFAULT_FROM_EMAIL = DEFAULT_FROM_EMAIL or "EduFlow <noreply@localhost>"
    MAILERS = {
        "default": {
            "BACKEND": os.environ.get(
                "EDUFLOW_EMAIL_BACKEND",
                "django.core.mail.backends.console.EmailBackend",
            )
        }
    }

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "applications.comptes.apps.ComptesConfig",
    "applications.organisations.apps.OrganisationsConfig",
    "applications.abonnements.apps.AbonnementsConfig",
    "applications.referentiels.apps.ReferentielsConfig",
    "applications.personnes.apps.PersonnesConfig",
    "applications.admissions.apps.AdmissionsConfig",
    "applications.inscriptions.apps.InscriptionsConfig",
    "applications.emplois_temps.apps.EmploisTempsConfig",
    "applications.presences.apps.PresencesConfig",
    "applications.evaluations.apps.EvaluationsConfig",
    "applications.finances.apps.FinancesConfig",
    "applications.tableau_de_bord.apps.TableauDeBordConfig",
    "applications.rapports.apps.RapportsConfig",
    "applications.notifications.apps.NotificationsConfig",
    "applications.messagerie.apps.MessagerieConfig",
    "applications.pedagogie.apps.PedagogieConfig",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "applications.notifications.context_processors.compteur_notifications",
                "applications.messagerie.context_processors.compteur_messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

DATABASE_ENGINE = os.environ.get("EDUFLOW_DB_ENGINE", "postgresql").strip().lower()
if DATABASE_ENGINE == "postgresql":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ.get("EDUFLOW_DB_NAME", "eduflow"),
            "USER": os.environ.get("EDUFLOW_DB_USER", "postgres"),
            "PASSWORD": os.environ.get("EDUFLOW_DB_PASSWORD", ""),
            "HOST": os.environ.get("EDUFLOW_DB_HOST", "127.0.0.1"),
            "PORT": os.environ.get("EDUFLOW_DB_PORT", "5432"),
            "CONN_MAX_AGE": 60,
        }
    }
elif DATABASE_ENGINE == "sqlite":
    if ENVIRONMENT in {"staging", "production"}:
        raise ImproperlyConfigured("SQLite is not supported for staging or production.")
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": os.environ.get("EDUFLOW_SQLITE_PATH", str(BASE_DIR / "db.sqlite3")),
        }
    }
else:
    raise ImproperlyConfigured("EDUFLOW_DB_ENGINE must be 'postgresql' or 'sqlite'.")

AUTH_USER_MODEL = "comptes.CompteUtilisateur"
AUTHENTICATION_BACKENDS = ["applications.comptes.backends.BackendCompteVerifie"]

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "fr"
LANGUAGES = [("fr", "Français")]
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_DIRS = [BASE_DIR / "static"]
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "/connexion/"
LOGIN_REDIRECT_URL = "/tableau-de-bord/"
LOGOUT_REDIRECT_URL = "/connexion/"

SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_SECURE = ENVIRONMENT in {"staging", "production"}
CSRF_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SECURE = ENVIRONMENT in {"staging", "production"}
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"
X_FRAME_OPTIONS = "DENY"

if ENVIRONMENT in {"staging", "production"}:
    if DEBUG:
        raise ImproperlyConfigured("EDUFLOW_DEBUG must be false in staging and production.")
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 31_536_000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = False
    SECURE_HSTS_PRELOAD = False
