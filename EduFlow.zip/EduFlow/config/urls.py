"""Configuration des URL du projet EduFlow."""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as vues_auth
from django.urls import include, path
from django.views.generic import RedirectView

from applications.comptes.views import (
    ConfirmationReinitialisationSecurisee,
    ConnexionLimitee,
    ReinitialisationMotDePasseLimitee,
)
from applications.evaluations.views import liste_evaluations
from applications.referentiels.views import (
    archiver_referentiel_web,
    creation_rapide_referentiel,
    formulaire_referentiel,
    gestion_referentiel,
)
from applications.tableau_de_bord.views import (
    liste_apprenants,
    liste_candidatures,
    liste_presences,
)

urlpatterns = [
    path("admin/", admin.site.urls),
    path(
        "referentiels/creation-rapide/<slug:slug>/",
        creation_rapide_referentiel,
        name="referentiel-creation-rapide",
    ),
    path(
        "referentiels/<slug:slug>/creer/",
        formulaire_referentiel,
        name="referentiel-creer",
    ),
    path(
        "referentiels/<slug:slug>/<uuid:objet_id>/archiver/",
        archiver_referentiel_web,
        name="referentiel-archiver",
    ),
    path(
        "referentiels/<slug:slug>/<uuid:objet_id>/",
        formulaire_referentiel,
        name="referentiel-modifier",
    ),
    path("campus/", gestion_referentiel, {"slug": "campus"}, name="campus"),
    path(
        "annees-academiques/",
        gestion_referentiel,
        {"slug": "annee-academique"},
        name="annees-academiques",
    ),
    path(
        "periodes-academiques/",
        gestion_referentiel,
        {"slug": "periode-academique"},
        name="periodes-academiques",
    ),
    path("programmes/", gestion_referentiel, {"slug": "programme"}, name="programmes"),
    path("niveaux/", gestion_referentiel, {"slug": "niveau"}, name="niveaux"),
    path("cours/", gestion_referentiel, {"slug": "cours"}, name="cours"),
    path("groupes/", gestion_referentiel, {"slug": "groupe"}, name="groupes"),
    path("etudiants/", liste_apprenants, name="etudiants"),
    path("admissions/", liste_candidatures, name="admissions"),
    path("inscriptions/", include("applications.inscriptions.html_urls")),
    path("presences/", liste_presences, name="presences"),
    path("evaluations/", liste_evaluations, name="evaluations"),
    path("finances/", include("applications.finances.html_urls")),
    path("rapports/", include("applications.rapports.html_urls")),
    path(
        "organisations/",
        RedirectView.as_view(pattern_name="parcours_tenant:accueil", permanent=False),
        name="organisations",
    ),
    path(
        "membres/",
        RedirectView.as_view(pattern_name="parcours_tenant:equipe", permanent=False),
        name="membres",
    ),
    path(
        "plateforme/abonnements/",
        RedirectView.as_view(
            pattern_name="administration_saas:abonnements",
            permanent=False,
        ),
        name="plateforme-abonnements",
    ),
    path("compte/", include("applications.comptes.urls")),
    path("", include("applications.organisations.urls")),
    path(
        "connexion/",
        ConnexionLimitee.as_view(template_name="comptes/connexion.html"),
        name="connexion",
    ),
    path(
        "deconnexion/",
        vues_auth.LogoutView.as_view(next_page="connexion"),
        name="deconnexion",
    ),
    path(
        "mot-de-passe/oublie/",
        ReinitialisationMotDePasseLimitee.as_view(
            template_name="comptes/formulaire_reinitialisation_mot_de_passe.html",
            email_template_name="comptes/email_reinitialisation_mot_de_passe.html",
            subject_template_name="comptes/password_reset_subject.txt",
            success_url="/mot-de-passe/envoye/",
        ),
        name="password_reset",
    ),
    path(
        "mot-de-passe/envoye/",
        vues_auth.PasswordResetDoneView.as_view(
            template_name="comptes/demande_reinitialisation_envoyee.html"
        ),
        name="password_reset_done",
    ),
    path(
        "mot-de-passe/reinitialiser/<uidb64>/<token>/",
        ConfirmationReinitialisationSecurisee.as_view(
            template_name="comptes/confirmer_nouveau_mot_de_passe.html",
            success_url="/mot-de-passe/reinitialise/",
        ),
        name="password_reset_confirm",
    ),
    path(
        "mot-de-passe/reinitialise/",
        vues_auth.PasswordResetCompleteView.as_view(
            template_name="comptes/reinitialisation_mot_de_passe_terminee.html"
        ),
        name="password_reset_complete",
    ),
    path("", include("applications.tableau_de_bord.urls")),
    path("", include("applications.personnes.html_urls")),
    path("", include("applications.messagerie.urls")),
    path("", include("applications.pedagogie.urls")),
    path("emplois-du-temps/", include("applications.emplois_temps.html_urls")),
    path(
        "administration-saas/",
        include("applications.abonnements.urls"),
    ),
    path("", include("applications.evaluations.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
