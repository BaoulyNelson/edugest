# Phase 4 — Référentiels éducatifs

> État actuel : les parcours des référentiels sont des pages Django sous `/campus/`, `/annees-academiques/`, `/periodes-academiques/`, `/programmes/`, `/niveaux/`, `/cours/` et `/groupes/`. Les routes REST mentionnées dans l’historique de livraison ont été retirées.

## Périmètre livré

- Une institution configurable par tenant pour le MVP, avec plusieurs campus.
- Paramètres régionaux initiaux Haïti, français, HTG, `America/Port-au-Prince`,
  date `DD/MM/YYYY` et indicatif `+509`. Le pays, la devise secondaire et les
  autres paramètres sont enregistrés par institution et restent modifiables.
- Années et périodes académiques configurables; les chevauchements entre années
  ne sont pas interdits. Une période doit rester dans les dates de son année.
- Programmes, niveaux, cours et groupes configurables sans hiérarchie universelle.
- Formulaires Django avec validation métier, écritures idempotentes et
  journalisées.

## Isolation et autorisations

Chaque page résout le tenant depuis la session, une adhésion active et un
abonnement autorisant l’accès. Les écritures exigent le rôle propriétaire,
administrateur ou gestionnaire dans un tenant actif. Les lectures d’objets et
les références entre objets sont filtrées au tenant et à son institution;
un identifiant connu d’un autre tenant n’accorde aucun accès.

Les paramètres de devise définissent la configuration institutionnelle. Ils ne
convertissent ni ne modifient les écritures financières existantes.

## Vérification

La suite complète de **41 tests** passe sur PostgreSQL 18.6 local. Ruff, les
contrôles Django, la vérification d’absence de migration manquante et
l’application de toutes les migrations sur une base temporaire neuve passent
également. La base temporaire a été supprimée après validation. La CI GitHub
Actions hébergée reste à exécuter; elle n’est pas déclarée validée.
