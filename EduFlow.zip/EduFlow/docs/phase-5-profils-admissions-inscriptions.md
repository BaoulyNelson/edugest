# Phase 5 — Profils, admissions et inscriptions

> État actuel : les parcours sont des pages et formulaires Django (`/admissions/`, `/inscriptions/`, `/etudiants/` et les pages `/espace/`). Les routes REST de cette phase ont été retirées.

## Périmètre livré

- Dossier personnel minimal, distinct d’un compte de connexion : prénom, nom,
  date de naissance facultative, courriel/téléphone facultatifs et identifiant
  externe facultatif. Aucun rapprochement automatique par nom ou date de
  naissance n’est effectué.
- Identifiant externe normalisé et unique par tenant lorsqu’il est renseigné.
  Les doublons à la création comme à la modification affichent une erreur de
  formulaire explicite.
- Candidature indépendante du compte utilisateur, rattachée à une institution,
  une année académique et un programme du même tenant.
- Workflow contrôlé : brouillon, soumise, à l’étude, admise, refusée ou retirée.
  La décision d’admission et la création du profil apprenant sont séparées de
  l’inscription scolaire.
- Inscription créée explicitement après admission, avec groupe facultatif,
  statuts actifs/interrompus/retirés/terminés et transferts pédagogiques datés.
- Historique des créations, changements de statut et transferts, sans copie des
  données personnelles.

## Parcours HTML et permissions

Les formulaires prennent en charge la création et la modification des
candidatures brouillon, les transitions d’admission, la création d’inscription,
les changements de statut, les transferts pédagogiques et la consultation de
l’historique.

Chaque accès exige le contexte tenant et une adhésion autorisée. Les dossiers
personnels et le parcours sont réservés aux rôles propriétaire, administrateur
et gestionnaire. Les requêtes d’objet et les références sont filtrées au tenant
et à l’institution; connaître l’identifiant d’un autre tenant ne donne aucun
accès. Les mutations métier sont transactionnelles, idempotentes quand une clé
est attendue et journalisées.

## Vérification historique

- **48 tests** passent sur PostgreSQL 18.6 local; les migrations sont appliquées
  sur la base de test créée par pytest.
- Les **7 tests Phase 5** passent également avec SQLite.
- `ruff check .`, `manage.py check` et `makemigrations --check --dry-run`
  passent.
- Les cas Phase 5 vérifient les transitions d’admission, l’idempotence,
  l’unicité des identifiants externes, les références/IDs inter-tenant, les
  restrictions par rôle, l’inscription, l’historique et les transferts.
- La CI GitHub Actions hébergée n’a pas été déclenchée et reste à valider.
