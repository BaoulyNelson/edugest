# EduFlow — Phase 2 : tenants, accès et invitations

**Statut : implémentée et validée localement sur SQLite et PostgreSQL 18.6; CI hébergée restante.** L’ensemble des 41 tests du projet passe sur PostgreSQL après les phases 0 à 4. Le workflow GitHub Actions n’a pas encore été exécuté.

## Décisions utilisateur

- Une invitation est un lien aléatoire à usage unique ; son acceptation prouve la possession de l’adresse e-mail et permet de créer un compte. Un compte existant à la même adresse rejoint le tenant via ce lien.
- MFA est recommandée pour les propriétaires et administrateurs mais optionnelle dans le MVP. Elle n’est pas implémentée et doit être réévaluée avant la mise en production.
- La période « essai » et les états commerciaux appartiennent à l’abonnement SaaS de la Phase 3, pas au statut opérationnel du tenant.

## Modèles et classifications

| Modèle | Portée | Règles principales |
|---|---|---|
| `CompteUtilisateur` | Global partagé | UUID, e-mail unique, date de vérification ; connexion refusée tant que l’adresse n’est pas vérifiée. |
| `Tenant` | Racine de propriété, gérée par le service plateforme | Cycle de vie séparé de l’abonnement ; clé d’idempotence unique. |
| `AdhesionTenant` | Tenant-owned | Un rôle et un état par compte/tenant ; un propriétaire actif maximum. |
| `InvitationTenant` | Tenant-owned | Adresse, rôle, expiration à 7 jours, statut, empreinte SHA-256 du jeton ; aucune conservation du jeton brut. |
| `EvenementAudit` | Journal transversal avec tenant optionnel | Acteur, action, ressource, motif et métadonnées non sensibles ; aucun e-mail ou jeton dans les métadonnées. |
| `CompteurTentativeAuthentification` | Global sécurité | HMAC de l’e-mail et de l’IP, fenêtre/expiration ; ni IP ni e-mail en clair. |

Rôles initiaux : propriétaire, administrateur, gestionnaire, enseignant et membre. Seuls propriétaire et administrateur gèrent invitations et adhésions. Une invitation ne peut pas attribuer le rôle propriétaire ; un workflow de transfert de propriété reste à concevoir. Le superutilisateur Django ne reçoit aucun accès tenant implicite et les modèles tenant ne sont pas exposés dans l’admin Django.

## Cycle de vie tenant

Transitions autorisées par le service transactionnel :

`demande → provisionnement → actif → restreint/suspendu/sortie → archivé`

Le tenant peut être réactivé depuis `restreint` ou `suspendu`. `archivé` est terminal ; aucune suppression immédiate de données n’est fournie. Tout passage à `restreint`, `suspendu`, `sortie` ou `archivé` exige un motif et produit un événement d’audit. Le provisioning crée dans une transaction le tenant, son propriétaire et les événements de transition. Une reprise avec la même clé UUID, le même propriétaire et le même nom retourne le résultat existant ; une réutilisation incohérente est rejetée.

## Inscription publique autonome (incrément du 29 octobre 2026)

Le parcours HTML public commence sur `/` et présente uniquement les `PlanSaaS` actifs, leurs tarifs et leurs droits/quota configurés. Le plan dont le code est `gratuit` et le prix nul donne accès pendant sept jours après vérification de l’adresse; les autres demandes restent soumises à l’examen opérateur puis à la confirmation du paiement.

| Route | Autorisation | Fonction |
|---|---|---|
| `GET /` | Publique | Page de découverte EduFlow et offres SaaS actives. Un utilisateur connecté rejoint son espace. |
| `GET/POST /creer-etablissement/` | Publique, CSRF, limite persistante par IP | Demande autonome du responsable : compte inactif, tenant `demande`, forfait actif, informations d’établissement et jeton e-mail à durée limitée. Un échec de distribution annule la transaction. |
| `GET/POST /verifier-inscription/<jeton>/` | Jeton aléatoire, GET sans mutation, POST protégé CSRF | Écran de confirmation puis vérification d’adresse; le jeton brut n’est pas stocké et expire après 24 h. Pour le plan `gratuit`, cette confirmation valide automatiquement la demande, active le tenant et un abonnement de sept jours, sans événement de paiement. |
| Action opérateur « Valider les demandes vérifiées » | Opérateur SaaS (`abonnements.gerer_abonnements_saas`) ou superutilisateur | Pour un plan payant : vérifie la demande, crée l’institution et l’adhésion propriétaire, prépare le tenant en `provisionnement`, active le compte et journalise la décision. L’abonnement et la confirmation du paiement restent nécessaires avant l’accès. |
| Action opérateur « Refuser les demandes sélectionnées » | Même permission, motif obligatoire | Refuse et journalise la demande; le compte et le tenant restent inaccessibles. |

Pour un plan payant, la validation d’une demande n’active ni le tenant ni un abonnement : le tenant reste en `provisionnement` jusqu’à la création du contrat et à la confirmation explicite du paiement. Le plan `gratuit` est une exception explicite : après vérification de l’adresse, il crée un abonnement actif de sept jours sans faux événement de paiement et le tenant passe à `actif`. À l’échéance, le contrôle d’accès refuse immédiatement les requêtes; la commande planifiée `python manage.py expirer_abonnements_saas` marque le contrat expiré et place le tenant en `restreint`. Aucun paiement en ligne ni activation par simple GET du lien de vérification n’est introduit.

## Parcours tenant HTML livrés

| Route | Autorisation | Fonction |
|---|---|---|
| Sélecteur d’établissement du tableau de bord | Session + adhésions actives | Liste uniquement les établissements accessibles au compte et stocke le choix dans la session. Chaque page métier résout ensuite l’adhésion côté serveur et vérifie l’abonnement. |
| `/espace/equipe/` (`GET/POST`) | Session + rôle propriétaire/administrateur + abonnement actif | Page Django pour lister les membres, ajuster rôle/accès et inviter par e-mail ; les changements passent par les services métier et sont audités. |
| `/invitation/accepter/` (`GET/POST`) | Jeton à usage unique, CSRF et limitation persistante par IP | Page Django protégée contre le cache ; vérification d’adresse et création/activation de l’adhésion atomiques. |

Les routes API tenant ont été retirées : la sélection et la résolution du contexte passent par les pages Django et la session. L’ancien `POST /api/v1/tenants/` ne créait qu’un tenant sans institution ni abonnement ; il n’était utilisé par aucun parcours du site et n’est pas conservé comme fonctionnalité utilisateur. Les autres flux de session sont `/connexion/`, `/deconnexion/` et `/mot-de-passe/...`. La récupération utilise les vues Django ; l’énumération de comptes n’est pas révélée. La redirection portant le jeton de réinitialisation est `no-store` et `no-referrer`; la page de formulaire, dont l’URL ne contient plus le jeton, reste `no-store` avec `same-origin` afin que le POST fonctionne sans affaiblir la validation CSRF. La réinitialisation invalide les sessions antérieures via le hash d’authentification Django.

**Évolution Phase 3 :** la résolution de contexte tenant exige désormais aussi un abonnement SaaS confirmé, non annulé et dans sa période. Les abonnements en attente, expirés ou annulés bloquent l’accès aux pages métier ; le sélecteur d’établissement et les routes publiques d’acceptation d’invitation restent séparés.

## Défenses implémentées

- Authentification par session, CSRF sur les formulaires HTML et backend qui exige une adresse vérifiée. Les routes REST des domaines métier ont depuis été retirées au profit des vues Django classiques.
- Limitation persistante à cinq échecs par e-mail/IP sur quinze minutes et vingt échecs par IP sur la même fenêtre, puis blocage de quinze minutes ; demandes de réinitialisation également limitées. Les empreintes HMAC dépendent du secret applicatif. Purge quotidienne à planifier avec `python manage.py purger_compteurs_auth`.
- Le provisioning et l’acceptation d’invitation sont transactionnels ; la réutilisation du jeton est idempotente et ne crée pas de deuxième compte/adhésion.
- Requêtes de liste filtrées par utilisateur/tenant avant pagination ; un utilisateur sans membership reçoit 404 sur le tenant sélectionné. Les changements de membership scoppent la recherche à l’adhésion du tenant actif.
- Contraintes DB pour les statuts/rôles, unicité membership, propriétaire actif unique et invitation pendante unique.
- Tests A/B couvrant sélection du tenant, listes, gestion des membres, rôles, révocation, répétition d’idempotence, invitation, expiration et suspension.

## Vérifications réellement exécutées

- `ruff check .` : réussi après la dernière correction d’import.
- `python manage.py check` : aucune anomalie détectée.
- `python manage.py makemigrations --check --dry-run` : aucun écart de migration.
- `EDUFLOW_SQLITE_PATH=:memory: python manage.py migrate --noinput` : toutes les migrations, y compris comptes et organisations, appliquées.
- `python -m pytest -p no:cacheprovider` : **25 tests réussis** après les dernières modifications.
- `python -m pip check` : aucune dépendance cassée.
- Validation ultérieure sur une base PostgreSQL 18.6 temporaire neuve : toutes les migrations appliquées et **41 tests du projet réussis**.
- CI hébergée GitHub Actions : non exécutée; ce statut reste distinct de la validation locale PostgreSQL.

## Limites avant toute production

- La CI hébergée reste à exécuter. MFA, PostgreSQL RLS et les tests d’isolation dédiés aux transactions concurrentes restent également hors validation.
- SMTP de production n’a pas été testé ; les valeurs d’environnement ne sont pas des secrets de dépôt.
- La purge du limiteur doit être planifiée ; la surveillance et la réponse aux incidents relèvent de la Phase 10.
- MFA reste optionnelle dans ce MVP conformément au choix de l’utilisateur.
- Il n’existe pas encore d’interface d’administration tenant, de transfert de propriétaire, d’accès support audité, de modèle éducatif ni d’activation PostgreSQL RLS.
