# EduFlow — Phase 3 : plans, abonnements et droits d’usage

> Historique : l’API REST décrite dans cette livraison n’est plus routée. Les opérations sont maintenant accessibles sous `/administration-saas/` via des vues, formulaires et templates Django; aucun chemin `/api/v1/` n’est actif.

**Statut : implémentée et validée sur SQLite et PostgreSQL 18.6 local; CI hébergée restante.**

## A. Objectifs

Séparer le contrat SaaS du statut opérationnel du tenant, contrôler côté serveur l’accès tenant et les droits des plans, et fournir un portail opérateur minimal pour le catalogue et les paiements manuels.

## B. Décisions approuvées

Les choix sont consignés dans [ADR 0003](./adr/0003-abonnements-saas-et-paiement-manuel.md).

- Aucun essai ni délai de grâce ; blocage dès l’échéance ou l’annulation.
- Paiement saisi et confirmé manuellement avant activation ; aucun prestataire ni stockage de carte bancaire.
- Renouvellement manuel par l’opérateur ; dates de début et fin explicites.
- Catalogue avec prix mensuel optionnel et devise configurable. Le prix annuel affiché est calculé comme douze mensualités, sans remise; modifier le catalogue ne change pas les événements financiers déjà enregistrés. Les trois brouillons actuellement configurés en PostgreSQL local coûtent 2 500 HTG/mois (Starter), 5 000 HTG/mois (Professional) et 7 500 HTG/mois (Enterprise), soit respectivement 30 000, 60 000 et 90 000 HTG/an. Ils restent inactifs tant que leurs droits et quotas ne sont pas configurés; seuls les plans actifs sont publiés. Aucun plan ni droit/quota n’est prérempli implicitement. Chaque paiement enregistre toujours son propre montant et sa devise ; le format de la devise est limité à trois lettres majuscules, sans validation ISO.
- Droits explicitement activés ; limite `null` signifie non plafonné ; une limite configurée est cumulée sur la période entière de l’abonnement.
- Remboursements manuels partiels ou totaux, audités et rattachés au paiement confirmé d’origine ; cumul des remboursements en attente/confirmés plafonné au montant initial. Un remboursement n’annule pas automatiquement l’abonnement.
- Accès opérateur dédié au droit Django `abonnements.gerer_abonnements_saas` (et aux superutilisateurs). Les états commerciaux ne modifient pas implicitement `Tenant.statut`.

## C. Fichiers ajoutés/modifiés

- Nouvelle application [applications/abonnements](../applications/abonnements) : modèles, services transactionnels et interface opérateur Django.
- Application des refus d’accès liés à l’abonnement dans [permissions.py](../applications/organisations/permissions.py).
- Enregistrement de l’application et de ses routes dans [settings.py](../config/settings.py) et [urls.py](../config/urls.py).
- Migrations initiale et permission opérateur : [0001_initial.py](../applications/abonnements/migrations/0001_initial.py), [0002_alter_plansaas_options.py](../applications/abonnements/migrations/0002_alter_plansaas_options.py).
- Tests de la Phase 3 et tests d’intégration de la nouvelle barrière d’accès.
- Schéma [OpenAPI des endpoints opérateur](./api/openapi-abonnements.json).
- Arbitrages et historique : [ADR](./adr/0003-abonnements-saas-et-paiement-manuel.md), [README](../README.md), note d’évolution dans [Phase 2](./phase-2-tenants.md).

## D. Modèles et migrations

| Modèle | Portée | Règles |
|---|---|---|
| `PlanSaaS` | Opérateur/global | Code unique, inactif par défaut, idempotent ; prix mensuel optionnel, devise explicite et aucun droit implicite. Le prix annuel de présentation vaut 12 × le mensuel. |
| `DroitUsage` | Catalogue global | Droit associé à un plan ; inactif par défaut ; code unique par plan ; limite positive ou `null`. |
| `Abonnement` | Un tenant | États en attente/actif/annulé/expiré ; période explicite ; un seul abonnement en attente ou actif par tenant. |
| `EvenementPaiement` | Opérateur, rattaché à un abonnement | Paiement/remboursement, montant Decimal positif, devise saisie, décision et référence ; aucune donnée de carte. |
| `EnregistrementUsage` | Tenant-owned | Tenant, abonnement et droit validés côté service ; quantité positive et clé d’idempotence. |

Les périodes sont semi-ouvertes : accès à partir de `commence_le`, refus dès `termine_le`. La vérification d’accès bloque même si l’état stocké n’a pas encore été rafraîchi ; la commande de purge marque ensuite les périodes échues et journalise la transition.

## E. Contrat REST historique (retiré)

Toutes les routes ci-dessous sont versionnées sous `/api/v1/platform/`, réservées à un opérateur autorisé, protégées par session/CSRF et auditées sur lecture ou mutation.

| Méthode et route | Fonction |
|---|---|
| `GET/POST /plans/` | Liste paginée et création idempotente d’un plan. |
| `PATCH /plans/<plan_id>/` | Configure/active le plan et ses droits ; les droits omis ne sont pas supprimés. |
| `GET /abonnements/` | Liste paginée transversale avec statut effectif. |
| `POST /tenants/<tenant_id>/abonnements/` | Crée une période en attente à dates explicites ; refuse plan inactif et période échue. |
| `POST /abonnements/<id>/paiements/` | Enregistre un paiement manuel ; ne donne pas encore accès. |
| `POST /paiements/<id>/confirmer/` | Confirme un paiement et active la période ; confirmer un remboursement n’a pas d’effet sur l’accès. |
| `POST /paiements/<id>/rejeter/` | Rejette l’événement avec motif obligatoire. |
| `POST /paiements/<id>/remboursements/` | Enregistre un remboursement partiel/total lié à l’original ; plafond cumulatif contrôlé. |
| `POST /abonnements/<id>/annuler/` | Annule immédiatement, motif obligatoire. |
| `GET /paiements/` | Liste paginée et auditée des événements financiers. |

Les créations de plan, période, paiement et remboursement exigent `Idempotency-Key` au format UUID. La réutilisation cohérente renvoie la ressource existante ; une charge différente produit un conflit. Les listes sont paginées. Le spécimen OpenAPI couvre le portail opérateur Phase 3, pas les routes Organisations de la Phase 2.

Les opérations courantes sont servies par des formulaires Django sous `/administration-saas/plans/`, `/administration-saas/etablissements/`, `/administration-saas/abonnements/` et `/administration-saas/paiements/`. Les services `verifier_droit()` et `enregistrer_usage()` restent des points d’intégration métier et sont appelés directement par le code Django, jamais via une API REST.

## F. Tests ajoutés

- Autorisation opérateur distincte d’un compte ordinaire et d’un simple compte `is_staff`.
- Création/rejeu de plan, absence de valeurs par défaut, modification d’un droit.
- Prix mensuel HTG, calcul du total annuel, validation et mise à jour par le portail opérateur.
- Cycle de paiement en attente → confirmation → activation ; rejet avec motif ; annulation immédiate.
- Contexte tenant bloqué sans abonnement effectif, et rétabli après paiement confirmé.
- Remboursement partiel audité, plafond cumulatif, sans effet automatique sur l’abonnement.
- Quota sur la période d’abonnement, rejeu idempotent, droit absent et usage d’un autre tenant refusés.
- Échéance sans grâce, expiration idempotente et événement d’audit.
- Réponses 404 contrôlées pour les ressources de décision/annulation absentes.
- Régression Phase 2 : les fixtures d’intégration ont un contrat actif explicite lorsque nécessaire.

## G. Commandes et résultats réellement vérifiés

- `python -m pytest -p no:cacheprovider` : **34 tests réussis**.
- `ruff check .` : **All checks passed**.
- `python manage.py check` : aucune anomalie.
- `python manage.py makemigrations --check --dry-run` : aucune migration manquante.
- `EDUFLOW_SQLITE_PATH=:memory: python manage.py migrate --noinput` : toutes les migrations, y compris les deux migrations d’abonnement, appliquées.
- `python -m pip check` : aucune dépendance cassée.
- Validation ultérieure sur une base PostgreSQL 18.6 temporaire neuve : toutes les migrations appliquées et **41 tests du projet réussis**.
- Le premier passage PostgreSQL a révélé six erreurs `FOR UPDATE` sur une jointure nullable; le verrouillage de la décision a été limité à l’événement (`of=("self",)`). Les neuf tests d’abonnement passent ensuite sur PostgreSQL.
- CI hébergée GitHub Actions : **non exécutée**.

## H. Limites et risques

- Les tests PostgreSQL valident les parcours et verrous exercés par la suite; les courses de concurrence réelles, les tests de connexions poolées et l’indexation sous charge ne sont pas couverts.
- Les événements de paiement sont saisis manuellement ; aucune facture SaaS, taxe, règle de prix, intégration bancaire, webhook, renouvellement automatique ou remboursement bancaire n’est fourni.
- La commande `python manage.py expirer_abonnements_saas` doit être planifiée ; elle n’est pas un worker autonome. L’accès est néanmoins bloqué à l’instant de fin même avant cette commande.
- Le catalogue n’a pas de seed ; un opérateur doit créer/activer un plan, ses droits, une période et confirmer un paiement.
- Le portail opérateur est maintenant une interface HTML dédiée, avec formulaires Django et protection CSRF.
- Les futurs modules doivent appliquer chaque entitlement et quota. Les utilitaires sont prêts, mais il n’y a aucun domaine éducatif auquel les brancher à ce stade.
- MFA, PostgreSQL RLS, les tests de connexions poolées et les contrôles d’isolation sur PostgreSQL ne sont pas implémentés.

## I. Critères d’acceptation

- **Satisfaits localement :** modèles distincts, droits et quotas côté service, workflow manuel, absence de grâce, annulation et remboursement audités, protection opérateur explicite, idempotence, migrations PostgreSQL et tests sur PostgreSQL 18.6.
- **Encore en attente/hors périmètre :** exécution CI hébergée, concurrence réelle, MFA, application des entitlements aux futurs domaines, ordonnanceur, UI opérateur dédiée et revue OpenAPI automatisée.

## J. Prochaine étape

Avant la Phase 4, confirmer le pays de lancement et les paramètres régionaux (langues, devises, fuseaux et calendriers), ainsi que la cardinalité client : un tenant par institution ou un tenant contractuel regroupant plusieurs institutions.
