# Phase 9 — Premier incrément de rapports

> État actuel : les rapports sont disponibles dans l’interface Django sous `/rapports/`; les routes REST de cette livraison ont été retirées.

## Périmètre livré

Cette livraison commence la Phase 9 par deux rapports HTML agrégés, sans
identité personnelle ni montants financiers :

- effectifs d’inscription par année académique, programme, groupe et statut;
- présences effectivement enregistrées par groupe et statut, sur une période
  demandée.

Le nombre d’effectifs désigne le nombre d’inscriptions, pas le nombre de
personnes uniques. Le rapport de présences ne calcule aucun taux et ne considère
pas une absence d’enregistrement comme une absence à une séance.

## Accès, portée et audit

Les deux routes exigent une adhésion active et l’un des rôles de gestion déjà
autorisés aux parcours éducatifs. Le tenant est résolu et validé par le
permissionnaire existant depuis `X-Tenant-ID`; les objets, années, programmes,
groupes et séances sont filtrés au tenant et à son institution. Un identifiant
d’année d’un autre tenant n’est pas divulgué.

Chaque consultation réussie crée un événement d’audit contenant le rapport et
ses filtres, mais ni résultats agrégés ni données personnelles.

## Paramètres de consultation HTML

Le formulaire de `/rapports/` propose les rapports d’effectifs par année
académique et de présences sur une plage de dates.

Le rapport d’effectifs exige une année académique du tenant courant.
Les dates du rapport de présences sont obligatoires, inclusives et limitées à
366 jours. Les résultats sont agrégés par statut et groupe sans pagination de dossiers;
ils ne contiennent aucune donnée de personne.

## Vérification

- `.\venv\Scripts\python.exe -m pytest applications\rapports\tests\test_rapports.py -q` :
  3 tests réussis, avec tests d’isolation inter-tenant, permissions, absence de
  données personnelles et limites de période.
- `.\venv\Scripts\python.exe -m pytest -q` : 80 tests réussis sur PostgreSQL
  local.
- `.\venv\Scripts\python.exe manage.py check` : réussi.
- `.\venv\Scripts\python.exe -m ruff check applications\rapports config\settings.py config\urls.py` :
  réussi.
- `.\venv\Scripts\python.exe manage.py makemigrations --check --dry-run` :
  aucune migration en attente.
- Aucun modèle n’est ajouté; aucune migration n’est nécessaire à cet incrément.
- La CI GitHub Actions hébergée et les tests navigateur n’ont pas été exécutés
  pour cet incrément.

## Suite de Phase 9

Les imports, exports privés et expirables, notifications métier, rapports
supplémentaires et amélioration UX restent à cadrer et à implémenter. Ce
premier incrément ne clôt pas la Phase 9.
