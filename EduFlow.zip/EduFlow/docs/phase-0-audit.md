# EduFlow — audit initial et cadrage (Phase 0)

## 1. Résumé de l’état existant

L’espace de travail contient les documents de référence et un prototype d’interface, mais pas encore une application.

| Ressource | État observé |
|---|---|
| `EduFlow_Prompt_maitre_Django_Multitenant.md` | Prompt maître fourni ; lu intégralement (169 lignes). |
| `EduFlow_Cahier_des_charges_Django_Multitenant.pdf` | Cahier fonctionnel et technique fourni ; extrait et lu intégralement (25 pages, 860 lignes de texte extraites). |
| `EduFlow_Prompt_maitre_Django_Multitenant.pdf` | Version PDF du prompt ; extrait et lu intégralement (7 pages, 258 lignes de texte extraites). |
| `ParcoursTenant.pdf` | Parcours métier illustratif ; extrait et lu intégralement (389 lignes de texte extraites). |
| `templates\tableau_de_bord\dashboard.html` | Maquette HTML statique du tableau de bord enseignant ; données fictives, liens `#` et calendrier JavaScript inline. |
| `static\css\dashboard_enseignant.css` | Feuille de style dédiée à la maquette. |
| `static\js\`, `static\images\` | Dossiers présents, sans fichier observé. |
| Backend, dépendances, migrations, tests, CI, conteneurs, documentation d’installation | Aucun fichier observé à l’audit initial. |
| Dépôt Git | Le répertoire de travail n’est pas un dépôt Git. |

Aucun code existant n’a été modifié pendant cet audit. Les PDF ont été extraits vers l’espace de session, pas dans le projet.

## 2. Architecture proposée

- Monolithe modulaire Django avec rendu serveur et applications dans `applications\`. DRF avait été envisagé à l’audit initial, puis écarté : aucune API REST n’est retenue.
- PostgreSQL en schéma partagé ; `tenant_id` explicite pour les données détenues par un tenant.
- Modèle `User` personnalisé défini avant toute première migration.
- Résolution tenant côté serveur, membership active, RBAC et queryset tenant-scoped ; l’ID ou le slug fourni par un client ne constitue jamais une autorisation.
- HTML/CSS/JavaScript pour l’interface initiale, en préservant la maquette existante jusqu’à son intégration réelle.
- Pas de RLS activée, de Celery/Redis ou de stockage objet avant que le besoin et les garanties d’exécution correspondantes soient établis.
- Séparation explicite entre plateforme SaaS, données éducatives et facturation scolaire.

Les catégories global partagé, tenant-owned et opérateur-only seront consignées modèle par modèle avant l’ajout des domaines concernés, puis vérifiées en CI.

## 3. Contradictions relevées et décisions approuvées

Les arbitrages suivants ont été confirmés avant toute modification du projet :

| Sujet | Contradiction des références | Décision |
|---|---|---|
| Base de données | Le prompt maître Markdown indique PostgreSQL ; le cahier et le PDF compagnon indiquent MySQL. | PostgreSQL, choisi par l’utilisateur. Le cahier attribue à tort à MySQL une RLS native équivalente à celle de PostgreSQL. |
| Frontend | Le prompt maître Markdown cible React/TypeScript ; le cahier et le PDF compagnon demandent HTML/CSS/JavaScript. | HTML/CSS/JavaScript, choisi par l’utilisateur et compatible avec la maquette existante. |
| Applications Django | Le Markdown utilise des noms de domaines anglais ; le PDF compagnon demande le dossier `applications\` et suggère des noms français. | Dossier `applications\` et noms français, choisis par l’utilisateur. |
| Accès opérateur | Le cahier décrit l’administrateur SaaS comme superuser ayant accès à toutes les données ; le prompt maître exige des accès transversaux séparés, protégés et audités. | Pas d’accès pédagogique global implicite. Toute intervention support sensible devra être autorisée, justifiée, limitée et auditée. |
| Portée et rythme | Le prompt interdit une génération monolithique ; le cahier propose un MVP couvrant plusieurs domaines. | Réalisation progressive de tout le MVP recommandé, avec critères/tests et compte rendu à chaque phase. |

Références : voir les ADR `docs\adr\0001-stack-et-organisation.md` et `docs\adr\0002-isolation-et-acces-operateur.md`.

## 4. Questions ouvertes, sans blocage avant la Phase 1

Ces décisions ne doivent pas être inventées et seront tranchées avant les phases qui en dépendent.

| Décision à prendre | Phase limite | Pourquoi |
|---|---:|---|
| Pays de lancement, langues prioritaires, devise(s), fuseau(s), calendrier(s) par défaut | Phase 4 | Déterminent les valeurs de configuration et les parcours de l’établissement. |
| Tenant représentant un client contractuel pouvant gérer plusieurs Institutions, ou une seule Institution dans le MVP | Phase 4 | Affecte la propriété des campus et les portées d’administration. |
| Vérification d’adresse e-mail, invitations, MFA requis, récupération et révocation de session | Phase 1–2 | Décision Phase 2 : l’invitation à usage unique vérifie l’e-mail et permet la création du compte ; la récupération révoque les sessions précédentes ; MFA est recommandée mais optionnelle dans le MVP et doit être réévaluée avant production. |
| Accès direct des élèves/étudiants et parents, consentement et données des mineurs | Phase 5 | Nécessite des décisions métier et juridiques selon le pays. |
| Période d’essai/grâce, blocage d’accès, renouvellement, annulation, remboursements et prestataire SaaS | Phase 3 — résolu | Aucun essai ni délai de grâce ; blocage à échéance, annulation immédiate, renouvellement et paiements manuels, remboursements partiels audités sans annulation implicite. Voir [ADR 0003](./adr/0003-abonnements-saas-et-paiement-manuel.md). |
| Règles de progression, barèmes, coefficients, arrondis, crédits, absences et publication | Phase 7 | Elles varient selon le programme et le pays. |
| Taxes, numérotation documentaire, remboursements et règles de conservation des pièces financières | Phase 8 | Les exigences légales et fiscales ne sont pas définies. |
| Fournisseur d’e-mail, stockage privé, hébergement, localisation, quotas, rétention, RPO/RTO et objectifs de disponibilité | Phase 9–10 | Ces choix ont des coûts opérationnels et des obligations contractuelles. |

## 5. Périmètre MVP et personas

### Inclus, selon le cahier des charges

- Inscription d’un établissement, provisioning, configuration initiale et gestion des memberships/rôles.
- Institutions/campus, années académiques, programmes/niveaux, cours, groupes/cohortes et inscriptions.
- Dossiers d’apprenants, personnel et tuteurs ; admissions et historique des parcours.
- Affectations, séances, emploi du temps simple, présence, évaluations et résultats de base.
- Frais, factures, encaissements, reçus et rapports financiers simples, sans comptabilité réglementaire générale.
- Plans SaaS, abonnements, entitlements et quotas côté serveur, distincts des finances scolaires.
- Imports/exports contrôlés, audit, notifications e-mail, rapports essentiels et documents privés.

### Hors périmètre initial ou à cadrer séparément

Microservices, LMS complet, visioconférence native, paie multi-pays, comptabilité générale certifiée, moteur de paiement propriétaire, stockage de données de carte, BI/IA prédictive, application mobile native et intégrations sur mesure.

### Personas prioritaires

1. **Propriétaire / administrateur d’établissement** : configure son tenant, campus, équipe et modules sans franchir la frontière d’un autre tenant.
2. **Opérateur SaaS** : suit demandes, provisionnement, plans et incidents ; n’accède pas implicitement aux dossiers pédagogiques.
3. **Secrétariat / admissions** : traite candidats et inscriptions selon ses autorisations.
4. **Enseignant / formateur** : consulte ses groupes affectés, saisit les présences et évaluations autorisées.
5. **Comptable / caissier** : gère frais, factures et paiements selon une séparation des tâches sensible.
6. **Élève / étudiant et parent / tuteur** : bénéficiaires possibles de portails à accès limité, à décider avant leur implémentation.

## 6. Glossaire initial

| Terme | Sens retenu |
|---|---|
| Tenant | Organisation cliente et frontière logique principale de propriété et d’isolation. |
| Institution | Entité éducative gérée par un tenant ; cardinalité à confirmer avant Phase 4. |
| Campus | Site ou unité organisationnelle d’une institution. |
| User | Identité de connexion globale, indépendante des profils éducatifs. |
| Membership | Appartenance d’un utilisateur à un tenant, avec état, rôle(s), portée et dates. |
| LearnerProfile / profil apprenant | Dossier éducatif d’une personne ; ne requiert pas de compte de connexion. |
| Enrollment / inscription | Relation historisée entre un apprenant et un parcours/période/groupe. |
| Subscription / abonnement SaaS | Contrat commercial entre le tenant et la plateforme ; distinct des frais scolaires. |
| Entitlement | Module, capacité ou quota autorisé par le plan et ses options. |
| RLS | Row-Level Security ; mécanisme de base de données disponible dans PostgreSQL, non à revendiquer pour MySQL natif. |

## 7. User stories prioritaires et portes de sortie

| Priorité | User story | Critère de sortie essentiel |
|---|---|---|
| P0 | En tant que futur propriétaire, je demande un espace et le provisioning peut être repris sans doublons. | Vérification d’identité et provisioning idempotent testés. |
| P0 | En tant que membre de plusieurs tenants, je ne vois que les données du tenant actif et autorisé. | Tests A/B pour liste, détail, mutation, relation inter-tenant et changement de tenant. |
| P0 | En tant qu’administrateur d’établissement, je gère des membres et permissions limitées à mon tenant. | RBAC explicite et endpoints privés fermés par défaut. |
| P1 | En tant qu’établissement, je configure campus, année, programmes et groupes sans perdre l’historique. | Contraintes et tests de cohérence/historique. |
| P1 | En tant que secrétariat, je transforme une candidature validée en parcours apprenant traçable. | Workflow autorisé, idempotent si rejoué, données privées protégées. |
| P1 | En tant qu’enseignant, je gère présences/évaluations uniquement sur les groupes qui me sont affectés. | Tests d’autorisation incluant les identifiants d’autres tenants. |
| P1 | En tant que comptable, je suis les frais scolaires sans les confondre avec l’abonnement SaaS. | Montants Decimal, devise explicite, annulations auditées. |
| P1 | En tant qu’opérateur, je gère les contrats SaaS sans accès général aux dossiers scolaires. | Portail distinct et accès sensible limité/audité. |

## 8. Risques initiaux

- **Critique — fuite inter-tenant** : toutes les voies de lecture/écriture doivent scoper avant les modules éducatifs ; un UUID opaque n’est pas un contrôle d’accès.
- **Élevé — décisions métier et juridiques manquantes** : pays, mineurs, finances et conservation nécessitent des validations avant les phases concernées.
- **Élevé — faux sentiment de sécurité RLS** : aucun RLS ne sera déclaré actif avant tests avec le véritable rôle DB, les connexions réutilisées, jobs et accès bulk/bruts.
- **Élevé — accès opérateur excessif** : le modèle superuser du cahier doit être limité conformément au principe de moindre privilège.
- **Moyen — maquette trompeuse** : l’interface existante est une démo statique, pas une fonctionnalité connectée ; ses chiffres/noms sont fictifs.
- **Moyen — périmètre important** : livrer chaque domaine séparément, sans masquer les échecs d’une phase.

## 9. Vérifications et état de phase

- Inventaire récursif des fichiers du projet : exécuté.
- Extraction et lecture complète des trois PDF présents : exécutées.
- Lecture complète du prompt maître Markdown : exécutée.
- Tests/build : non exécutés ; aucun projet applicatif ni dépendance n’existe à ce stade.
- Modifications applicatives : aucune pour cette phase.
- Porte de sortie Phase 0 : décisions structurantes documentées et accordées ; ADR et liste d’inconnues créés. Les règles ouvertes restent affectées à leur phase limite.
- Prochaine étape : Phase 1, fondations Django, vérification des versions supportées, environnement reproductible, configuration de sécurité, modèle utilisateur personnalisé, tests et migrations initiales.
