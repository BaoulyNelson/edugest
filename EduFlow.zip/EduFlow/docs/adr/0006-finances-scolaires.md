# ADR 0006 — Facturation, paiements et remboursements scolaires

- **Statut :** accepté par l’utilisateur
- **Portée :** Phase 8 du prompt maître

## Contexte

EduFlow doit couvrir les frais d’inscription et de scolarité sans supposer un
cadre comptable ou fiscal national qui n’a pas encore été confirmé. Les
opérations portent des données financières sensibles et doivent rester
strictement limitées au tenant actif. L’utilisateur a retenu la facturation
manuelle, les barèmes par programme et année, HTG par défaut et USD seulement
si configuré, sans conversion automatique.

## Décisions

- Un barème définit des lignes positives pour un programme et une année
  académique. Une facture est un brouillon créé manuellement depuis ce barème;
  ses lignes et sa devise sont copiées à la création.
- La référence `EF-AAAA-SSSSSS` est interne, séquentielle par tenant et année
  d’émission. Elle ne constitue pas une déclaration de conformité fiscale.
- Les brouillons sont modifiables et supprimables. Une facture émise peut être
  annulée avec motif uniquement si elle n’a jamais reçu d’allocation; son
  numéro reste réservé.
- Un paiement saisi est confirmé. Son montant doit correspondre exactement à
  la somme de ses allocations, lesquelles peuvent régler partiellement
  plusieurs factures du même tenant et de la même devise. Aucun excédent ni
  change implicite n’est accepté.
- Un remboursement est une nouvelle opération motivée et append-only, liée à
  une allocation existante; il ne dépasse jamais son montant net non remboursé.
- Espèces, virement, chèque et autre sont les modes autorisés; « autre » exige
  un libellé et une référence de transaction reste facultative.
- Chaque paiement produit un reçu basé sur un instantané conservé; seul un
  gestionnaire autorisé peut le lire ou l’imprimer en HTML privé.
- Les opérations réessayables sont protégées par une clé d’idempotence. Une
  réutilisation avec un contenu différent retourne un conflit.
- Seuls les propriétaires, administrateurs et gestionnaires du tenant peuvent
  gérer les dossiers financiers. Les taxes, pénalités, remises, intégrations de
  paiement, PDF et rôles élèves/parents ne sont pas introduits.

## Options écartées

- Numéroter les factures comme conformes au fisc haïtien sans validation
  réglementaire.
- Convertir automatiquement HTG et USD ou recalculer la devise d’une facture
  après sa création.
- Transformer un trop-perçu en crédit ou laisser une fraction d’un paiement
  sans affectation.
- Modifier ou supprimer un paiement après sa confirmation; les corrections
  passent par un remboursement distinct et audité.
- Ajouter taxes, pénalités, remises, paiements en ligne ou comptabilité
  générale avant validation de leurs règles métier.

## Conséquences

- Les totaux financiers peuvent être audités et rejoués sans muter les
  allocations ni les instantanés de reçus.
- Le statut de facture reflète le montant net payé après remboursements.
- Les numéros internes et reçus ne doivent pas être utilisés comme documents
  fiscaux officiels avant vérification des obligations haïtiennes.
- L’absence d’intégration de paiement signifie que la confirmation reflète la
  saisie manuelle d’un gestionnaire, pas une confirmation bancaire.
