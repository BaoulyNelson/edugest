# ADR 0005 — Calcul, publication et documents académiques

- **Statut :** accepté par l’utilisateur
- **Portée :** Phase 7 du prompt maître

## Contexte

Le cahier des charges demande des catégories, poids, barèmes, arrondis,
traitement des absences, règles de publication et documents, mais laisse les
règles de notes et de progression à décider par pays, programme et
établissement. Le dépôt possède déjà des périodes académiques, affectations,
groupes et inscriptions, mais aucun domaine d’évaluations, de notes ou de
documents générés. Les résultats peuvent concerner des mineurs et doivent
rester tenant-scoped et non exposés dans les journaux.

L’utilisateur a retenu une moyenne pondérée normalisée sur 100, sans seuil de
réussite universel; l’absence ne produit pas automatiquement un zéro; l’arrondi
d’affichage se fait à deux décimales; la publication revient aux gestionnaires;
les documents sont des pages HTML imprimables privées; le serializer de
personnes signalé reste hors périmètre de cette phase.

## Décisions

- Chaque évaluation fixe son barème maximal et un coefficient strictement
  positif. Les notes sont des décimaux et peuvent valoir zéro explicitement.
- La moyenne par cours et période est calculée en normalisant chaque note sur
  100 puis en appliquant son coefficient. Les absences justifiées et les notes
  non saisies ne pèsent pas dans la moyenne. Aucun seuil, promotion ou règle
  d’arrondi métier autre que l’affichage à deux décimales n’est imposé.
- L’absence justifiée est enregistrée explicitement sans note. Pour publier,
  chaque inscription dont la période d’inscription couvre la date de
  l’évaluation doit avoir une note ou une absence justifiée. Une absence non
  justifiée nécessite une note saisie explicitement.
- L’enseignant affecté peut créer des évaluations, saisir des notes et
  corriger un brouillon. Une évaluation avec notes ne peut plus être modifiée.
  La publication appartient aux rôles propriétaire, administrateur ou
  gestionnaire. Après publication, seules ces personnes peuvent corriger une
  note, avec motif obligatoire, historique et audit.
- Un résultat publié est consultable dans les API de gestion du tenant et par
  l’enseignant affecté; aucune consultation directe élève/parent n’est ajoutée
  sans comptes ni politique d’accès de ces profils.
- Un bulletin ou relevé est un instantané versionné des seuls résultats
  publiés, stocké dans la base et rendu sous forme HTML après autorisation.
  Réémission et révocation ne détruisent pas les versions précédentes. Une
  révocation exige un motif. Les réponses imprimables sont privées et non
  mises en cache.
- Aucun moteur PDF ni stockage de fichiers n’est introduit dans cette phase.

## Options écartées

- Une échelle commune (par exemple sur 20), des seuils de réussite ou des
  décisions de passage codés en dur : non universels et non validés.
- Transformer toute absence en zéro : cela confondrait absence, absence
  justifiée et note effectivement attribuée.
- Publier automatiquement dès qu’un enseignant saisit une note : cela
  contournerait le contrôle voulu par l’établissement.
- PDF/fichiers sans infrastructure de stockage privé déjà vérifiée : ajout de
  dépendances et d’une frontière de confidentialité non nécessaires au rendu
  HTML demandé.

## Conséquences

- Les établissements peuvent utiliser des barèmes hétérogènes tout en
  comparant les résultats normalisés par cours/période; la validation locale
  des règles de progression reste nécessaire avant tout usage officiel.
- Les anciens documents reflètent l’état des résultats au moment de leur
  émission; une correction ultérieure ne les réécrit pas.
- Les modèles de note et de document contiennent des données éducatives
  sensibles. Les historiques sont accessibles uniquement dans le périmètre de
  l’évaluation, et l’audit général ne copie pas les valeurs des notes.
- La consultation élève/parent, les PDF, les certificats et les règles de
  passage restent des décisions ouvertes pour les phases ultérieures.
