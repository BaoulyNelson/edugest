# ADR 0001 — Stack et organisation initiales

- **Statut :** supersédé sur le choix d’interface par la migration vers Django classique, sans API REST ni DRF.
- **Contexte :** les documents fournis divergent sur la base de données, le frontend et le nommage des applications. Le dépôt ne contient pas encore de backend.

## Décisions

1. Utiliser Python et Django, dans un monolithe modulaire.
2. Utiliser PostgreSQL avec un schéma partagé et un `tenant_id` explicite pour chaque modèle tenant-owned.
3. Utiliser HTML, CSS et JavaScript pour le frontend initial et préserver la maquette existante comme point de départ visuel.
4. Placer les applications métier sous `applications\` et utiliser des noms français.
5. Créer le modèle utilisateur personnalisé avant toute première migration.
6. N’ajouter Celery/Redis, stockage objet, cache distribué ou RLS qu’après besoin confirmé et validation technique.

## Motivations et écarts aux références

- Le prompt maître Markdown demande PostgreSQL et recommande React/TypeScript ; le cahier des charges et son PDF compagnon prescrivent MySQL et HTML/CSS/JavaScript. L’utilisateur a choisi PostgreSQL et HTML/CSS/JavaScript.
- PostgreSQL fournit une vraie RLS. L’affirmation du cahier concernant une RLS native MySQL est incorrecte ; l’option MySQL n’est donc pas retenue.
- Le PDF compagnon propose des apps françaises et le dossier `applications\`, retenus sur décision de l’utilisateur. Les noms et les chemins seront vérifiés contre les attentes Django, outils et imports.
- La maquette HTML/CSS déjà présente est conservée ; aucune dépendance frontend ni réécriture n’est justifiée à ce stade.

## Conséquences

- Les versions Python/Django/PostgreSQL et leurs correctifs devront être vérifiés auprès des sources maintenues, puis précisément verrouillés.
- PostgreSQL RLS n’est **pas** réputée activée par cet ADR. Son activation exigera des politiques exhaustives, un rôle applicatif réellement non privilégié, un contexte transactionnel réinitialisé et des tests de pool, tâches, bulk et requêtes brutes. Les querysets et services applicatifs resteront les contrôles obligatoires.
- Le cahier doit être lu avec cette décision de stack ; l’écart est assumé et ne doit pas être réintroduit silencieusement.
- Les noms français d’applications seront conservés, mais les identifiants requis par Django ou des dépendances peuvent rester dans les formes imposées par l’écosystème.

## Alternatives considérées

- **MySQL** : non retenu, car il contredit le prompt maître et ne permet pas la RLS native décrite par le cahier.
- **React/TypeScript** : non retenu pour l’interface initiale, car le cahier et le prototype déjà fourni sont en HTML/CSS/JavaScript ; réévaluation possible avec une justification ultérieure.
- **Schémas séparés par tenant** : non retenus pour le MVP ; ils ajoutent de la complexité d’exploitation et de migration sans exigence actuellement démontrée.
