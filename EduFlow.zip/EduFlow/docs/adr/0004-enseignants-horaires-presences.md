# ADR 0004 — Profils enseignants, horaires et présences

- **Statut :** accepté par l’utilisateur
- **Portée :** Phase 6 du prompt maître

## Contexte

Le prompt maître et le cahier des charges présentent les phases de livraison
dans un ordre différent. Le prompt maître place les affectations, horaires et
présences avant les évaluations; le cahier des charges place les finances
scolaires avant ces fonctions. L’utilisateur a choisi de continuer selon le
périmètre et l’ordre du prompt maître. Les besoins confirmés distinguent le
profil enseignant du compte, rendent le compte facultatif, demandent des
créneaux hebdomadaires et des séances datées explicites, et exigent un motif
lors des corrections de présence.

## Décisions

- Un profil enseignant est rattaché à un dossier personnel du tenant et peut
  exister sans compte de connexion. Un compte associé doit être membre actif du
  même tenant avec le rôle enseignant.
- Une affectation lie un profil enseignant, un cours, un groupe et une année
  académique dans un tenant et une institution.
- Les horaires hebdomadaires sont des créneaux modèles. Une occurrence est
  créée explicitement comme séance datée; elle conserve les heures et la salle
  copiées à sa création.
- Les chevauchements sont refusés pour un enseignant, un groupe ou une salle
  qui se recouvrent dans le temps sur le même campus.
- La feuille d’appel porte sur les inscriptions actives du groupe à la date de
  séance. Une inscription doit appartenir au groupe et couvrir la date pour
  recevoir une présence.
- La saisie est autorisée aux gestionnaires habilités et à l’enseignant affecté
  à la séance. Les enseignants ne peuvent consulter ni modifier les séances
  d’un collègue.
- Les corrections de statut exigent un motif, créent un historique et un
  événement d’audit; une répétition du statut courant est sans effet.
- Les salles restent des libellés texte et les séances ne sont pas générées
  automatiquement. Les évaluations, notes et leur publication sont reportées
  à la phase suivante du prompt maître.

## Conséquences

- Les API filtrent les objets par tenant/institution et restreignent la vue des
  enseignants à leurs affectations; cette vérification s’applique même lorsque
  l’identifiant d’un objet est connu.
- Les changements des créneaux n’altèrent pas les séances déjà créées.
- Le changement d’ordre par rapport au cahier des charges est intentionnel :
  la finance scolaire n’est pas déclarée livrée par cette phase.
- Les limites sur les salles et la génération des séances devront être
  réévaluées avec les besoins des établissements avant toute extension.
