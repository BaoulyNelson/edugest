# ADR 0002 — Isolation tenant et accès opérateur

- **Statut :** accepté
- **Contexte :** EduFlow héberge plusieurs organisations et peut traiter des données scolaires, financières, familiales et concernant des mineurs. Le cahier décrit l’administrateur SaaS comme superuser ayant accès à toutes les données, tandis que le prompt maître exige des opérations transversales séparées, protégées et auditées.

## Décisions

1. Le tenant est la frontière logique de propriété des données éducatives.
2. Pour les données tenant-owned, le contexte actif est résolu et validé côté serveur à partir d’une identité et d’une membership active ; un ID, slug, campus ou tenant fourni par le navigateur ne prouve aucune autorisation.
3. Les listes sont filtrées par queryset avant toute pagination ; les détails, mutations, relations, recherches, exports, fichiers et jobs appliquent la même portée.
4. Les créations fixent le tenant côté serveur ; les relations entre objets vérifient leur appartenance au même tenant.
5. Les fonctions opérateur transversales sont séparées des fonctions tenant ordinaires et exigent des permissions dédiées. L’accès support sensible requiert un motif, une portée/ durée limitée et un audit.
6. Un rôle superuser ou opérateur ne donne pas implicitement un accès libre aux dossiers pédagogiques.
7. La classification global partagé / tenant-owned / opérateur-only sera définie pour chaque modèle et vérifiée avant sa livraison.

## Conséquences

- Tous les endpoints privés seront protégés par défaut ; une permission objet seule ne filtrera pas les listes.
- Les tests adversariaux avec deux tenants semblables et des rôles différents sont une porte de sortie de la Phase 2 et devront accompagner tout modèle/endroit qui touche aux données tenant-owned.
- Une éventuelle RLS PostgreSQL complétera les contrôles applicatifs ; elle ne les remplacera pas.
- Les procédures d’urgence et support devront être explicitement autorisées et journalisées sans enregistrer de contenu éducatif sensible.

## Alternative écartée

- **Administrateur SaaS avec accès permanent à tous les dossiers** : rejetée car contraire au moindre privilège, aux exigences de confidentialité et à l’isolation attendue. Un accès exceptionnel contrôlé est préférable.
