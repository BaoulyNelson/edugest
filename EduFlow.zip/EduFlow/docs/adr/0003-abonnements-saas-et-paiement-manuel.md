# ADR 0003 — Abonnements SaaS et paiement manuel

- **Statut :** accepté par l’utilisateur, tarifs mis à jour le 29 octobre 2026
- **Portée :** Phase 3

## Contexte

EduFlow doit séparer les contrats SaaS des tenants et les finances scolaires. Les références initiales ne fixaient pas les tarifs ni les quotas. L’utilisateur a ensuite fourni les tarifs mensuels HTG ci-dessous; les droits, quotas, prestataires et autres règles commerciales restent à définir.

## Décisions

- Le catalogue de plans est configurable par un opérateur. Les tarifs mensuels fournis par l’utilisateur sont 2 500 HTG (Starter), 5 000 HTG (Professional) et 7 500 HTG (Enterprise). Le prix annuel affiché est strictement égal à douze mensualités, sans remise; ces prix ne changent pas les paiements déjà enregistrés. Aucun quota ou droit fonctionnel n’est prérempli.
- Un droit non configuré est refusé. Un droit explicitement actif avec une limite `null` est non plafonné ; une limite configurée est cumulée sur la période explicite de l’abonnement.
- Il n’y a ni période d’essai ni période de grâce. Une période d’abonnement comporte un début et une fin explicites. Le tenant n’accède aux routes tenant qu’après confirmation manuelle d’un paiement et uniquement pendant cette période.
- Les paiements et remboursements sont saisis manuellement par un opérateur. Aucun prestataire de paiement ni donnée de carte bancaire n’est intégré ou conservé. La devise est saisie pour chaque événement ; seule sa forme de trois lettres majuscules est validée, pas son appartenance à un registre ISO.
- Le renouvellement est manuel. L’annulation prend effet immédiatement et exige un motif. Les états d’abonnement restent distincts des états opérationnels du tenant.
- Les remboursements manuels peuvent être partiels ou totaux ; les montants confirmés ou en attente sont réservés et leur somme ne peut dépasser le paiement d’origine confirmé. Un remboursement ne modifie pas automatiquement l’accès ; une annulation est une action séparée.
- Les routes de gestion SaaS sont distinctes et réservées aux comptes `is_staff`. Les lectures transversales et mutations sont auditées sans conserver de données de carte ou de référence de paiement dans les détails d’audit.

## Conséquences

- Un tenant nouvellement provisionné n’a aucun accès tenant avant qu’un opérateur configure un plan, crée une période, enregistre un paiement et le confirme.
- Les domaines éducatifs devront vérifier les droits et mesurer toute ressource soumise à un quota via les services de l’application `abonnements`.
- Les notifications de renouvellement, les factures SaaS, les remboursements externes, les taxes, les cycles récurrents et l’intégration d’un prestataire restent hors périmètre.
- PostgreSQL reste la base de référence ; aucun RLS n’est revendiqué. Mise à jour du 28 octobre 2026 : migrations fraîches et suite de 41 tests validées localement sur PostgreSQL 18.6; le workflow CI hébergé reste à exécuter.

## Options écartées

- Quota, droit, essai ou période de grâce codés en dur : non justifiés par les décisions métier disponibles. Les trois tarifs HTG et la règle annuelle ×12 ont été explicitement fournis par l’utilisateur.
- Accès automatique après création du tenant ou simple saisie d’un paiement : risque d’accès sans confirmation opérateur.
- Résiliation différée à la fin de période, paiement automatisé et intégration de cartes : non approuvés pour le MVP.
- Modification automatique du statut opérationnel du tenant à chaque événement commercial : mélange des cycles de vie et source de transitions non auditées.
