# Phase 8 — Finances scolaires

> État actuel : les opérations sont réalisées dans les pages Django sous `/finances/`. Les routes REST décrites plus bas sont historiques et ont été retirées.

## Périmètre livré

- Barèmes de frais par année académique et programme, avec devise autorisée
  par les paramètres de l’institution. Les lignes sont copiées au brouillon
  de facture afin que les modifications ultérieures du barème ne réécrivent
  pas les factures existantes.
- Factures créées manuellement depuis un barème et une inscription compatible.
  Les brouillons sont modifiables ou supprimables; l’émission est explicite et
  attribue une référence interne séquentielle par tenant et année d’émission.
  Cette référence n’est pas présentée comme une numérotation fiscale certifiée.
- Une facture émise n’est annulable qu’en l’absence de toute allocation de
  paiement, et avec un motif obligatoire. Son numéro n’est jamais réutilisé.
- Paiements enregistrés comme confirmés à la saisie. Le montant doit être
  intégralement affecté à une ou plusieurs factures émises du même tenant et de
  la même devise. Les allocations partielles sont permises; les excédents, les
  doublons et les conversions automatiques sont refusés.
- Remboursements séparés, motivés, append-only et liés à une allocation
  précise. Le total remboursé ne peut dépasser cette allocation; le net payé
  et le statut de la facture sont recalculés sans modifier l’opération initiale.
- Reçu émis à l’enregistrement du paiement et conservé sous forme d’instantané
  immuable. Son rendu HTML est privé et non mis en cache.
- Opérations idempotentes pour les créations de barèmes, factures, paiements et
  remboursements. Une clé réutilisée avec un contenu différent est un conflit.

## Accès et isolation

Les modèles financiers héritent des objets tenant-owned et portent un tenant,
une institution et un créateur. Les routes exigent une adhésion active et un
rôle propriétaire, administrateur ou gestionnaire du tenant sélectionné.
Toutes les listes et références entrantes sont bornées par tenant et
institution; les identifiants d’un autre tenant ne permettent pas d’accéder
aux documents. Les opérations sensibles sont auditées sans copier les
montants ou les notes dans le détail d’audit.

## Routes REST historiques (retirées)

Routes versionnées sous `/api/v1/education/` :

- `GET/POST baremes-frais/` et `GET/PATCH/DELETE baremes-frais/<id>/` ;
- `GET/POST factures/` et `GET/PATCH/DELETE factures/<id>/` ;
- `POST factures/<id>/emettre/` et `POST factures/<id>/annuler/` ;
- `GET/POST paiements/` et `GET paiements/<id>/` ;
- `GET/POST paiements/<id>/remboursements/` ;
- `GET paiements/<id>/recu/` et `GET paiements/<id>/recu/impression/`.

Les listes étaient paginées. Les opérations de création exigeaient l’en-tête
`Idempotency-Key` contenant un UUID. Le reçu HTML répond avec
`Cache-Control: private, no-store` et `X-Robots-Tag: noindex, nofollow`.

## Choix métier et limites

- HTG reste la devise principale par défaut. USD n’est accepté que si
  l’institution l’a configuré; aucun taux de change n’est implicite. La devise
  d’une facture est figée depuis son barème.
- Les modes de paiement et de remboursement sont espèces, virement, chèque ou
  autre; le mode « autre » exige un libellé. Une référence de transaction est
  facultative.
- Taxes, pénalités, remises, paiements automatiques, comptabilité générale,
  consultation par élèves/parents, PDF et intégration à un prestataire sont
  hors périmètre.
- Les références `EF-AAAA-SSSSSS` sont internes à EduFlow. Les obligations
  fiscales haïtiennes, la séquence réglementaire, les reçus officiels et les
  règles de conservation doivent être confirmés avant tout usage comptable ou
  fiscal officiel.

## Migrations et vérification

- Migrations : `finances/0001_initial` et
  `finances/0002_remboursementpaiement_autre_mode_and_more`.
- La suite complète a réussi sur PostgreSQL 18.6 local : **59 tests**. Les
  **2 tests Phase 8** ont également réussi sur SQLite.
- `ruff check .`, `manage.py check` et `makemigrations --check --dry-run`
  passent; les migrations financières ont été appliquées à la base PostgreSQL
  locale.
- Les tests couvrent l’émission, l’idempotence, les conflits de clé, les
  allocations excédentaires, la devise incompatible, le remboursement plafonné,
  le recalcul du solde, le reçu HTML et les accès croisés entre tenants.
- La CI GitHub Actions hébergée reste explicitement non validée tant que son
  workflow n’a pas été exécuté.
