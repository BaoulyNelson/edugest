# EduFlow — Phase 1 : fondations (état d’exécution)

**Statut : fondation historique.** Django REST Framework avait été installé au démarrage puis a été retiré après migration des fonctionnalités vers des parcours Django classiques. Les validations de cette phase décrivent l’état au moment de sa livraison, pas l’architecture courante.

## A. Objectifs de l’incrément

Préparer la base Django, l’authentification personnalisée avant la première migration, les paramètres d’environnement, les tests initiaux, le verrou de dépendances et une CI PostgreSQL.

## B. Décisions et hypothèses

- Versions consultées auprès des sources officielles et PyPI : Django 6.1.2, PostgreSQL 18.6, Psycopg 3.3.6, python-dotenv 1.2.4, pytest 9.2.0, pytest-django 4.14.0, Ruff 0.17.3 et leurs dépendances transitives épinglées.
- Python 3.13 est la cible de CI et le runtime local disponible est 3.13.7 ; ce runtime local n’est pas le dernier correctif de sa branche.
- SQLite reste une option de commodité pour les tests locaux ; staging/production imposent PostgreSQL.
- En développement/tests sans secret défini, une clé éphémère est générée au démarrage ; staging/production exigent une clé explicitement fournie.
- Aucun endpoint d’authentification publique, de vérification e-mail ou de réinitialisation n’est exposé à cette phase.

## C. Fichiers créés/modifiés

- `manage.py`, `config\settings.py`, `config\urls.py`, `config\asgi.py`, `config\wsgi.py`.
- `applications\comptes\` : application, gestionnaire, modèle `CompteUtilisateur`, configuration admin, tests initiaux et migration `0001_initial.py`.
- `requirements.in`, `requirements.txt`, `pyproject.toml`, `.gitignore`, `.env.example`, `compose.yaml`.
- `.github\workflows\ci.yml`, `README.md`.

## D. Schéma et migrations

- `CompteUtilisateur` utilise l’e-mail normalisé comme identifiant et un UUID comme clé primaire.
- `AUTH_USER_MODEL` pointe vers ce modèle dès la configuration initiale, avant toute première migration.
- `applications\comptes\migrations\0001_initial.py` crée le modèle utilisateur avec clé primaire UUID, e-mail unique, groupes et permissions.
- `makemigrations --check --dry-run` confirme qu’aucune migration supplémentaire n’est nécessaire.
- `migrate --noinput` applique toutes les migrations Django et EduFlow sur SQLite en mémoire.

## E. Endpoints et workflows

- Seul l’admin Django est routé.
- Les pages utilisent l’authentification par session Django et la protection CSRF des formulaires.
- Aucun endpoint métier, endpoint `AllowAny` ni workflow d’inscription n’est implémenté.

## F. Tests ajoutés

Quatre tests couvrent la normalisation d’e-mail, le hachage du mot de passe, le rejet d’un e-mail vide, la validation du mot de passe superuser et les privilèges du superuser.

## G. Commandes et vérifications réellement exécutées

- Inventaire, extraction PDF et lecture intégrale des documents : exécutés et consignés dans `docs\phase-0-audit.md`.
- Diagnostic Python Pylance sur les fichiers source : « No errors found ».
- Installation dans `.venv` via `python -m pip install -r requirements.txt` : réussie ; `pip check` et `pip install --dry-run -r requirements.txt` passent.
- `ruff check .` : réussi.
- `python manage.py check` : aucune anomalie détectée.
- `python manage.py makemigrations comptes` : migration initiale générée ; `makemigrations --check --dry-run` ne détecte aucun écart.
- `EDUFLOW_SQLITE_PATH=:memory: python manage.py migrate --noinput` : toutes les migrations appliquées avec succès.
- `python -m pytest -p no:cacheprovider` : **4 tests réussis**.
- PostgreSQL local 18.6 : connexion Django vérifiée via `.env`; `ruff check .`, `manage.py check` et `makemigrations --check --dry-run` réussis.
- Base PostgreSQL temporaire neuve : toutes les migrations appliquées; **41 tests réussis**. La base temporaire a été supprimée après les tests.
- Le premier passage PostgreSQL a révélé six échecs dûs à un `SELECT FOR UPDATE` traversant une jointure nullable; le verrouillage a été limité à la ligne de l’événement (`of=("self",)`). Les neuf tests d’abonnement puis la suite entière passent.
- GitHub Actions : le workflow CI PostgreSQL est configuré, mais n’a pas été déclenché sur un runner hébergé; ce contrôle reste à exécuter.

## H. Limites et risques connus

- Le verrou contient des versions exactes, y compris `tzdata`, mais pas de hashes de distributions.
- Les migrations et tests ont été vérifiés localement sur PostgreSQL 18.6; le workflow CI hébergé reste non vérifié.
- Les garanties production (secrets, HTTPS, sauvegardes, rollback, observabilité) restent à établir avant la mise en service.

## I. Critères d’acceptation

| Critère | État |
|---|---|
| Configuration Django avec session/CSRF et autorisation API restrictive | Satisfait ; `manage.py check` passe. |
| `CompteUtilisateur` personnalisé défini avant toute migration | Satisfait ; migrations appliquées sur SQLite et PostgreSQL 18.6. |
| Versions compatibles et épinglées | Satisfait localement ; installation et dry-run du verrou passent. |
| Tests présents et exécutables | Satisfait ; 41 tests passent sur PostgreSQL 18.6. |
| Migrations validées sur PostgreSQL | Satisfait ; toutes les migrations appliquées sur une base temporaire neuve. |
| CI hébergée validée | En attente ; le workflow GitHub Actions n’a pas été déclenché. |
| Installation reproductible documentée | Satisfait localement ; installation depuis le verrou exécutée avec succès. |

## J. Prochaine étape

Déclencher le workflow GitHub Actions et vérifier son résultat; garder le critère CI non satisfait jusque-là.
