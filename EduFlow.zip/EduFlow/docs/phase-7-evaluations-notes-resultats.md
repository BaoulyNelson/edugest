# Phase 7 — Évaluations, notes, résultats et documents

## Périmètre livré

- Évaluations liées à une affectation existante, au cours et au groupe concernés,
  à une date et à une année académique. Une période académique peut être
  précisée; son tenant, son institution, son année et ses dates sont vérifiés.
- Barème maximal et coefficient positifs par évaluation. Les notes sont des
  `Decimal` et ne peuvent pas dépasser le barème.
- Saisie d’une note ou déclaration explicite d’absence justifiée. Une absence
  non justifiée doit recevoir une note explicitement saisie; aucune note zéro
  n’est créée automatiquement.
- Une évaluation ne peut être publiée qu’après saisie d’une note ou d’une
  absence justifiée pour chaque inscription dont les dates couvrent la date de
  l’évaluation. La publication est idempotente et auditée.
- Moyenne calculée séparément par cours et période (ou pour l’année si aucune
  période n’est renseignée) :

  `somme((note / barème maximal) × 100 × coefficient) / somme(coefficients)`

  Les absences justifiées sont exclues du calcul. Le calcul utilise `Decimal`;
  la moyenne est arrondie à deux décimales par arrondi commercial uniquement
  pour l’affichage. Aucun seuil de réussite, crédit, promotion ou arrondi
  intermédiaire universel n’est imposé.
- Corrections de notes avec motif obligatoire, historique avant/après et
  événement d’audit. Un enseignant affecté peut saisir et corriger une note
  d’évaluation en brouillon; après publication, seule la gestion du tenant peut
  corriger, toujours avec motif.
- Bulletins et relevés HTML imprimables, produits depuis un instantané
  immuable des résultats publiés. Les émissions sont versionnées; une
  réémission conserve la version précédente et la marque remplacée. La
  révocation conserve l’émission, exige un motif et affiche son état sur la
  version imprimable.

## Modèles et isolation

`Evaluation`, `NoteEvaluation`, `HistoriqueNote` et `DocumentResultat` sont des
modèles tenant-owned. Chaque requête vérifie le tenant et l’institution du
contexte; les références à une affectation, une période et une inscription
doivent appartenir à ce même périmètre et satisfaire les règles de groupe,
d’année et de dates. Les listes sont paginées. Les créations réessayables
acceptent une clé d’idempotence; la saisie des notes utilise une opération PUT
idempotente par évaluation et inscription.

Les notes et documents ne sont visibles qu’aux gestionnaires autorisés et aux
enseignants de l’affectation concernée. La publication est réservée aux rôles
propriétaire, administrateur et gestionnaire. L’émission, la lecture et la
révocation des documents ainsi que le relevé consolidé restent réservés aux
gestionnaires. La Phase 7 n’ajoute pas encore de compte élève/parent ni d’API
de consultation directe par ces profils.

## Interface Django classique

`/espace/evaluations/` permet aux gestionnaires et aux enseignants de leurs
propres affectations de créer et consulter les évaluations, de saisir des notes
ou des absences justifiées, et de corriger les notes avec motif. Les rôles de
gestion peuvent publier les résultats et corriger une évaluation publiée. Les
pages utilisent les formulaires Django avec CSRF, respectent le tenant actif et
sont privées du cache. Les résultats consolidés, historiques et documents
(émission versionnée, impression privée et révocation motivée) ont également
leurs parcours HTML.

## Migration vers HTML

Toutes les opérations utilisateur de la Phase 7 sont désormais disponibles
sous `/espace/evaluations/`. Les routes REST évaluations, notes, résultats et
documents ont été retirées ; la logique métier reste portée par les services
transactionnels et les règles d’accès tenant-scoped.

## Migrations et vérification

- Migrations : `evaluations/0001_initial` et
  `evaluations/0002_documentresultat_document_resultat_version_positive_and_more`.
- **57 tests** passent sur PostgreSQL 18.6 local pour la suite complète.
- Les tests de la Phase 7 couvrent les parcours HTML sur SQLite : idempotence,
  isolation tenant, calcul pondéré, historique, versions et révocation des
  documents.
- `ruff check .`, `manage.py check` et `makemigrations --check --dry-run`
  passent.
- Les scénarios couvrent l’idempotence, l’isolation entre tenants, la portée
  enseignant, les références d’inscriptions, les corrections motivées/auditées,
  le blocage de publication avec notes manquantes, les absences justifiées, le
  calcul pondéré, la version des documents et l’échappement HTML.
- La CI GitHub Actions hébergée n’a pas été exécutée et reste explicitement à
  valider.

## Limites restantes

- Les documents sont générés en HTML privé à la demande; aucun PDF ni stockage
  de fichier n’est ajouté.
- Les résultats publiés ne sont pas encore consultables par des comptes
  élèves/parents. Aucun compte de ces rôles n’est introduit dans cette phase.
- Les règles de seuil, de mention, d’arrondi réglementaire, de promotion, de
  crédits universitaires et de certification restent à configurer après
  validation métier; elles ne sont pas inventées ici.
- Une évaluation publiée n’est pas dépubliée; une correction de note est
  permise aux gestionnaires avec motif et historique.
- La publication d’une note n’émet pas automatiquement un document. L’émission,
  la réémission et la révocation sont des actions explicites des gestionnaires.
