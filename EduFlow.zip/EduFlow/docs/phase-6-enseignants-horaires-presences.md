# Phase 6 — Enseignants, horaires et présences

> État actuel : la gestion des horaires est une page Django sous `/emplois-du-temps/`; les séances et feuilles de présence sont accessibles sous `/espace/presences/`. Les routes REST de cette phase ont été retirées.

## Périmètre livré

- Profil enseignant distinct du dossier personnel et facultativement lié à un
  compte. Lorsqu’un compte est lié, il doit avoir une adhésion active avec le
  rôle enseignant dans le tenant concerné.
- Affectations d’un enseignant à un cours, un groupe et une année académique,
  avec dates explicites.
- Créneaux hebdomadaires récurrents avec contrôle des chevauchements pour
  l’enseignant, le groupe et la salle sur le même campus.
- Séances datées créées explicitement à partir d’un créneau. Les heures et la
  salle sont copiées lors de la création afin que les changements ultérieurs du
  créneau ne réécrivent pas les séances existantes.
- Feuille paginée des inscriptions actives du groupe à la date de la séance,
  avec le statut de présence éventuel.
- Présences avec les statuts présente, en retard, absente ou absence justifiée.
  Toute correction de statut exige un motif et ajoute une entrée d’historique
  ainsi qu’un événement d’audit. Répéter le même statut ne crée pas de
  correction.

## Parcours HTML et permissions

Les formulaires Django permettent de créer les profils enseignants, affectations,
créneaux, séances datées, puis d’enregistrer et corriger les présences et
consulter leur historique.

Les changements de profils et de planning sont réservés aux rôles propriétaire,
administrateur et gestionnaire. Les enseignants ne voient que leurs affectations
et séances, et ne peuvent saisir une présence que pour une séance qui leur est
affectée. Les gestionnaires autorisés peuvent gérer le planning et les
présences. Les objets et références sont filtrés par tenant et institution;
connaître l’identifiant d’un autre tenant ou d’une autre séance ne donne pas
d’accès.

## Vérification

- **53 tests** passent sur PostgreSQL 18.6 local; la suite complète applique les
  migrations à la base de test de pytest.
- Les **5 scénarios Phase 6** passent également sur SQLite.
- `ruff check .`, `manage.py check` et `makemigrations --check --dry-run`
  passent.
- Les tests Phase 6 couvrent l’adhésion enseignant et l’idempotence du profil,
  l’isolation tenant et la visibilité des affectations, les conflits de
  créneaux, la création explicite/idempotente des séances, les corrections de
  présence motivées et auditées, ainsi que l’interdiction d’accès entre
  enseignants.
- La CI GitHub Actions hébergée n’a pas été déclenchée et reste à valider.

## Limites connues

- Les salles restent des libellés texte; aucun référentiel de salles ou de
  ressources n’est inclus.
- Les occurrences ne sont pas générées automatiquement : chaque séance datée
  est créée explicitement.
- Il n’y a pas encore de gestion des exceptions calendaires ou des séances
  déplacées.
- Le périmètre ne comprend pas les évaluations, les notes ou leur publication.
- La présente phase suit l’ordre du prompt maître. Le cahier des charges place
  la finance scolaire avant ces fonctions; le périmètre finance est donc
  reporté et cet écart est consigné dans l’ADR 0004.
