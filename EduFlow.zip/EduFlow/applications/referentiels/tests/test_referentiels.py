"""Tests de configuration institutionnelle et d’isolation des référentiels."""

import uuid
from datetime import date

import pytest
from django.contrib import admin
from django.test import Client, RequestFactory
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.organisations.models import (
    AdhesionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
)
from applications.organisations.services import provisionner_tenant
from applications.referentiels.admin import AnneeAcademiqueAdmin
from applications.referentiels.forms import AnneeAcademiqueForm
from applications.referentiels.models import (
    AnneeAcademique,
    Campus,
    Institution,
    NiveauEtude,
    Programme,
    StatutAnneeAcademique,
)
from applications.referentiels.services import modifier_referentiel

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email: str):
    from django.contrib.auth import get_user_model

    return get_user_model().objects.create_user(email, "mot-de-passe-solide")


def _preparer_tenant(email: str, nom: str):
    proprietaire = _creer_utilisateur(email)
    tenant, _, _ = provisionner_tenant(
        createur=proprietaire,
        nom=nom,
        cle_idempotence=uuid.uuid4(),
    )
    rendre_tenant_abonne(tenant, proprietaire)
    Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=nom,
        type_educatif="ecole",
        cree_par=proprietaire,
    )
    return proprietaire, tenant


def test_member_can_read_but_cannot_manage_education_catalog():
    proprietaire, tenant = _preparer_tenant("owner@example.org", "École Alpha")
    campus = Campus.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        code="principal",
        nom="Campus principal",
    )
    membre = _creer_utilisateur("membre@example.org")
    membre.email_verifie_le = timezone.now()
    membre.save(update_fields=("email_verifie_le",))
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=membre,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    web_client = Client()
    web_client.force_login(membre)

    lecture = web_client.get(reverse("campus"))
    ecriture = web_client.post(
        reverse("campus"),
        {"code": "secondaire", "nom": "Campus secondaire"},
    )

    assert lecture.status_code == 200
    assert str(campus) in lecture.content.decode()
    assert "Ajouter :" not in lecture.content.decode()
    assert ecriture.status_code == 403
    assert not Campus.objects.filter(tenant=tenant, code="secondaire").exists()


def test_html_reference_page_and_quick_create_are_tenant_scoped():
    proprietaire, tenant = _preparer_tenant(
        "owner-html@example.org",
        "École HTML",
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(proprietaire)

    page = client.get(reverse("campus"))
    formulaire = client.get(reverse("referentiel-creer", args=("campus",)))
    modal = client.get(
        reverse("referentiel-creation-rapide", args=("campus",)),
        HTTP_X_REQUESTED_WITH="XMLHttpRequest",
    )
    creation = client.post(
        reverse("referentiel-creation-rapide", args=("campus",)),
        {
            "code": "principal",
            "nom": "Campus principal",
            "adresse": "Rue de l’École",
            "actif": "on",
        },
        HTTP_X_REQUESTED_WITH="XMLHttpRequest",
    )

    assert page.status_code == 200
    assert "Campus" in page.content.decode()
    assert reverse("referentiel-creer", args=("campus",)) in page.content.decode()
    assert 'name="code"' not in page.content.decode()
    assert formulaire.status_code == 200
    assert 'name="code"' in formulaire.content.decode()
    assert "Annuler" in formulaire.content.decode()
    assert modal.status_code == 200
    assert "data-quick-create-form" in modal.content.decode()
    assert creation.status_code == 200
    assert creation.json()["success"] is True
    assert Campus.objects.get(tenant=tenant, code="principal").nom == "Campus principal"


def test_niveau_page_loads_and_creates_levels_for_an_active_programme():
    proprietaire, tenant = _preparer_tenant(
        "owner-niveau-html@example.org",
        "École niveaux",
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    programme = Programme.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        code="primaire",
        nom="Cycle primaire",
    )
    client = Client()
    client.force_login(proprietaire)

    page = client.get(reverse("niveaux"))
    formulaire = client.get(reverse("referentiel-creer", args=("niveau",)))
    creation = client.post(
        reverse("referentiel-creer", args=("niveau",)),
        {
            "programme": str(programme.pk),
            "code": "premiere-annee",
            "nom": "Première année",
            "ordre": "1",
            "actif": "on",
        },
    )

    assert page.status_code == 200
    assert 'name="programme"' not in page.content.decode()
    assert 'name="programme"' in formulaire.content.decode()
    assert "Cycle primaire" in formulaire.content.decode()
    assert creation.status_code == 302
    assert NiveauEtude.objects.filter(
        tenant=tenant,
        programme=programme,
        code="premiere-annee",
    ).exists()


def test_html_reference_edit_updates_fields_and_status_with_audit():
    proprietaire, tenant = _preparer_tenant(
        "owner-edit-html@example.org",
        "École à modifier",
    )
    campus = Campus.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        code="principal",
        nom="Campus principal",
        adresse="Rue 1",
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(proprietaire)
    url = reverse("referentiel-modifier", args=("campus", campus.pk))
    page = client.get(url)
    modification = client.post(
        url,
        {
            "code": "principal",
            "nom": "Campus rénové",
            "adresse": "Rue 2",
            "actif": "",
        },
    )
    campus_objet = Campus.objects.get(pk=campus.pk)

    assert page.status_code == 200
    assert "Campus principal" in page.content.decode()
    assert "Annuler" in page.content.decode()
    assert modification.status_code == 302
    assert modification["Location"] == reverse("campus")
    assert campus_objet.nom == "Campus rénové"
    assert campus_objet.adresse == "Rue 2"
    assert not campus_objet.actif
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="referentiel.modifie",
        id_objet=str(campus_objet.pk),
    ).exists()


def test_archiving_from_list_is_audited_and_can_be_reversed_in_edit_form():
    proprietaire, tenant = _preparer_tenant(
        "owner-archive-campus@example.org",
        "École campus archivable",
    )
    campus = Campus.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        code="annexe",
        nom="Campus annexe",
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(proprietaire)
    liste_url = reverse("campus")
    archive_url = reverse("referentiel-archiver", args=("campus", campus.pk))

    liste = client.get(liste_url)
    archive = client.post(archive_url)
    campus.refresh_from_db()
    est_archive = not campus.actif
    reactivation = client.post(
        reverse("referentiel-modifier", args=("campus", campus.pk)),
        {
            "code": "annexe",
            "nom": "Campus annexe",
            "adresse": "",
            "actif": "on",
        },
    )
    campus.refresh_from_db()

    assert "Archiver" in liste.content.decode()
    assert archive.status_code == 302
    assert est_archive
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="referentiel.archive",
        id_objet=str(campus.pk),
    ).exists()
    assert reactivation.status_code == 302
    assert campus.actif


def test_archiving_academic_year_closes_it_without_deleting_it():
    proprietaire, tenant = _preparer_tenant(
        "owner-archive-year@example.org",
        "École année archivable",
    )
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        nom="2026-2027",
        statut=StatutAnneeAcademique.ACTIVE,
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(proprietaire)

    response = client.post(
        reverse("referentiel-archiver", args=("annee-academique", annee.pk))
    )
    annee.refresh_from_db()

    assert response.status_code == 302
    assert annee.statut == StatutAnneeAcademique.CLOTUREE
    assert AnneeAcademique.objects.filter(pk=annee.pk).exists()
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="referentiel.archive",
        id_objet=str(annee.pk),
    ).exists()


def test_html_reference_edit_rejects_objects_from_other_tenants():
    proprietaire_a, tenant_a = _preparer_tenant(
        "owner-edit-a@example.org",
        "École A",
    )
    proprietaire_b, tenant_b = _preparer_tenant(
        "owner-edit-b@example.org",
        "École B",
    )
    campus = Campus.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant_a,
        institution=tenant_a.institution,
        cree_par=proprietaire_a,
        code="principal",
        nom="Campus A",
    )
    for proprietaire in (proprietaire_a, proprietaire_b):
        proprietaire.email_verifie_le = timezone.now()
        proprietaire.save(update_fields=("email_verifie_le",))
    client_html = Client()
    client_html.force_login(proprietaire_b)

    response = client_html.get(
        reverse("referentiel-modifier", args=("campus", campus.pk)),
        HTTP_HOST="testserver",
    )

    assert response.status_code == 404


def test_academic_year_defaults_to_planned_and_requires_closing_before_activation():
    proprietaire, tenant = _preparer_tenant(
        "owner-academic-years@example.org",
        "École Années",
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(proprietaire)
    url = reverse("annees-academiques")
    formulaire_url = reverse("referentiel-creer", args=("annee-academique",))

    page = client.get(url)
    formulaire = client.get(formulaire_url)
    creation_2026 = client.post(formulaire_url, {"nom": "2026-2027"})
    annee_2026 = AnneeAcademique.objects.get(tenant=tenant, nom="2026-2027")
    creation_2027 = client.post(formulaire_url, {"nom": "2027-2028"})
    annee_2027 = AnneeAcademique.objects.get(tenant=tenant, nom="2027-2028")
    assert annee_2026.statut == StatutAnneeAcademique.PLANIFIEE
    assert annee_2027.statut == StatutAnneeAcademique.PLANIFIEE
    modifier_2026 = reverse(
        "referentiel-modifier",
        args=("annee-academique", annee_2026.pk),
    )
    modifier_2027 = reverse(
        "referentiel-modifier",
        args=("annee-academique", annee_2027.pk),
    )
    activation_initiale = client.post(
        modifier_2026,
        {"nom": "2026-2027", "statut": StatutAnneeAcademique.ACTIVE},
    )
    retour_planifie = client.post(
        modifier_2026,
        {"nom": "2026-2027", "statut": StatutAnneeAcademique.PLANIFIEE},
    )
    activation_concurrente = client.post(
        modifier_2027,
        {"nom": "2027-2028", "statut": StatutAnneeAcademique.ACTIVE},
    )
    annee_2026.refresh_from_db()
    annee_2027.refresh_from_db()
    cloture_2026 = client.post(
        modifier_2026,
        {"nom": "2026-2027", "statut": StatutAnneeAcademique.CLOTUREE},
    )
    activation_2027 = client.post(
        modifier_2027,
        {"nom": "2027-2028", "statut": StatutAnneeAcademique.ACTIVE},
    )
    reactivation_2026 = client.post(
        modifier_2026,
        {"nom": "2026-2027", "statut": StatutAnneeAcademique.ACTIVE},
    )
    annee_2026.refresh_from_db()
    annee_2027.refresh_from_db()

    assert page.status_code == 200
    assert 'name="nom"' not in page.content.decode()
    assert 'name="nom"' in formulaire.content.decode()
    assert 'name="statut"' not in formulaire.content.decode()
    assert 'name="debut"' not in formulaire.content.decode()
    assert 'name="fin"' not in formulaire.content.decode()
    assert creation_2026.status_code == 302
    assert creation_2027.status_code == 302
    assert activation_initiale.status_code == 302
    assert retour_planifie.status_code == 200
    assert "doit être clôturée" in retour_planifie.content.decode()
    assert activation_concurrente.status_code == 200
    assert "Clôturez l’année active" in activation_concurrente.content.decode()
    assert cloture_2026.status_code == 302
    assert activation_2027.status_code == 302
    assert reactivation_2026.status_code == 200
    assert "ne peut pas être réactivée" in reactivation_2026.content.decode()
    assert annee_2026.debut == date(2026, 9, 1)
    assert annee_2026.fin == date(2027, 6, 30)
    assert annee_2026.statut == StatutAnneeAcademique.CLOTUREE
    assert annee_2027.statut == StatutAnneeAcademique.ACTIVE
    assert (
        AnneeAcademique.objects.filter(
            tenant=tenant,
            statut=StatutAnneeAcademique.ACTIVE,
        ).count()
        == 1
    )


def test_academic_year_rejects_wrong_format_and_non_consecutive_years():
    proprietaire, _ = _preparer_tenant(
        "owner-invalid-academic-years@example.org",
        "École Année invalide",
    )
    proprietaire.email_verifie_le = timezone.now()
    proprietaire.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(proprietaire)
    url = reverse("referentiel-creer", args=("annee-academique",))

    mauvais_format = client.post(
        url,
        {"nom": "2026/2027", "statut": StatutAnneeAcademique.PLANIFIEE},
    )
    annee_non_consecutive = client.post(url, {"nom": "2023-2025"})
    annee_inversee = client.post(url, {"nom": "2027-2026"})

    assert mauvais_format.status_code == 200
    assert "format AAAA-AAAA" in mauvais_format.content.decode()
    assert annee_non_consecutive.status_code == 200
    assert "suivre immédiatement" in annee_non_consecutive.content.decode()
    assert annee_inversee.status_code == 200
    assert "suivre immédiatement" in annee_inversee.content.decode()
    assert not AnneeAcademique.objects.filter(tenant__nom="École Année invalide").exists()


def test_admin_can_only_choose_academic_year_status_after_creation():
    proprietaire, tenant = _preparer_tenant(
        "owner-admin-academic-years@example.org",
        "École Années admin",
    )
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        nom="2026-2027",
    )
    administration = AnneeAcademiqueAdmin(AnneeAcademique, admin.site)
    requete = RequestFactory().get("/admin/referentiels/anneeacademique/")
    requete.user = proprietaire

    formulaire_creation = administration.get_form(requete)
    formulaire_modification = administration.get_form(requete, obj=annee)

    assert "statut" not in formulaire_creation.base_fields
    assert "statut" in formulaire_modification.base_fields


def test_legacy_academic_year_can_be_closed_without_changing_its_dates():
    proprietaire, tenant = _preparer_tenant(
        "owner-legacy-academic-year@example.org",
        "École Année historique",
    )
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        nom="2020-2025",
        debut=date(2020, 9, 1),
        fin=date(2025, 6, 30),
    )
    formulaire = AnneeAcademiqueForm(
        {"nom": "2020-2025", "statut": StatutAnneeAcademique.CLOTUREE},
        tenant=tenant,
        institution=tenant.institution,
        acteur=proprietaire,
        instance=annee,
    )

    assert formulaire.is_valid(), formulaire.errors
    annee = modifier_referentiel(
        objet=annee,
        acteur=proprietaire,
        valeurs=formulaire.cleaned_data,
    )

    assert annee.statut == StatutAnneeAcademique.CLOTUREE
    assert annee.debut == date(2020, 9, 1)
    assert annee.fin == date(2025, 6, 30)
