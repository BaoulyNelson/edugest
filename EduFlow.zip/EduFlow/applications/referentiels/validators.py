"""Validations de paramètres régionaux extensibles."""

from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator

valider_pays = RegexValidator(
    r"^[A-Z]{2}$",
    "Le pays doit utiliser un code de deux lettres majuscules.",
)
valider_devise = RegexValidator(
    r"^[A-Z]{3}$",
    "La devise doit utiliser un code de trois lettres majuscules.",
)
valider_indicatif = RegexValidator(
    r"^\+[1-9]\d{0,3}$",
    "L’indicatif téléphonique doit commencer par + et contenir 1 à 4 chiffres.",
)


def valider_fuseau_horaire(valeur: str) -> None:
    """Vérifie qu’un fuseau IANA connu est configurable pour l’institution."""
    try:
        ZoneInfo(valeur)
    except (ZoneInfoNotFoundError, ValueError) as erreur:
        raise ValidationError("Le fuseau doit être un identifiant IANA valide.") from erreur
