"""Formulaires HTML des référentiels éducatifs tenant-scoped."""

from django import forms
from django.db.models import Q

from applications.referentiels.models import (
    AnneeAcademique,
    Campus,
    Cours,
    Groupe,
    NiveauEtude,
    PeriodeAcademique,
    Programme,
)


class FormulaireReferentiel(forms.ModelForm):
    """Construit les références uniquement depuis l’établissement actif."""

    def __init__(self, *args, tenant, institution, acteur, **kwargs):
        instance = kwargs.get("instance")
        if instance is None:
            kwargs["instance"] = self._meta.model(
                tenant=tenant,
                institution=institution,
                cree_par=acteur,
            )
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.setdefault("class", "saas-input")
            if isinstance(field, forms.ModelChoiceField):
                queryset = field.queryset.filter(
                    tenant=tenant,
                    institution=institution,
                )
                if hasattr(field.queryset.model, "actif"):
                    valeur_actuelle = (
                        getattr(self.instance, f"{field_name}_id", None)
                        if self.instance.pk
                        else None
                    )
                    queryset = queryset.filter(Q(actif=True) | Q(pk=valeur_actuelle))
                field.queryset = queryset


class CampusForm(FormulaireReferentiel):
    class Meta:
        model = Campus
        fields = ("code", "nom", "adresse", "actif")


class AnneeAcademiqueForm(FormulaireReferentiel):
    nom = forms.CharField(
        label="Année académique",
        max_length=9,
        widget=forms.TextInput(
            attrs={
                "placeholder": "2026-2027",
                "pattern": "[0-9]{4}-[0-9]{4}",
                "inputmode": "numeric",
                "autocomplete": "off",
                "maxlength": "9",
                "data-academic-year-input": "true",
            }
        ),
        help_text=(
            "Le tiret est ajouté automatiquement après les quatre premiers chiffres. "
            "Une nouvelle année est créée au statut Planifiée."
        ),
    )

    class Meta:
        model = AnneeAcademique
        fields = ("nom", "statut")

    def __init__(self, *args, **kwargs):
        est_creation = kwargs.get("instance") is None
        super().__init__(*args, **kwargs)
        if est_creation:
            self.fields.pop("statut")

    def clean_nom(self):
        nom = self.cleaned_data["nom"]
        if (
            len(nom) != 9
            or nom[4] != "-"
            or not nom[:4].isascii()
            or not nom[:4].isdigit()
            or not nom[5:].isascii()
            or not nom[5:].isdigit()
        ):
            raise forms.ValidationError(
                "Saisissez l’année au format AAAA-AAAA, par exemple 2026-2027."
            )
        nom_legacy_inchange = self.instance.pk and nom == self.instance.nom
        if int(nom[5:]) != int(nom[:4]) + 1 and not nom_legacy_inchange:
            raise forms.ValidationError(
                "La seconde année doit suivre immédiatement la première, "
                "par exemple 2026-2027."
            )
        return nom


class PeriodeAcademiqueForm(FormulaireReferentiel):
    class Meta:
        model = PeriodeAcademique
        fields = ("annee_academique", "code", "nom", "debut", "fin", "actif")
        widgets = {
            "debut": forms.DateInput(attrs={"type": "date"}),
            "fin": forms.DateInput(attrs={"type": "date"}),
        }


class ProgrammeForm(FormulaireReferentiel):
    class Meta:
        model = Programme
        fields = ("code", "nom", "description", "actif")
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}


class NiveauEtudeForm(FormulaireReferentiel):
    class Meta:
        model = NiveauEtude
        fields = ("programme", "code", "nom", "ordre", "actif")


class CoursForm(FormulaireReferentiel):
    class Meta:
        model = Cours
        fields = ("code", "nom", "description", "actif")
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}


class GroupeForm(FormulaireReferentiel):
    class Meta:
        model = Groupe
        fields = (
            "annee_academique",
            "campus",
            "programme",
            "niveau",
            "code",
            "nom",
            "type_groupe",
            "actif",
        )
