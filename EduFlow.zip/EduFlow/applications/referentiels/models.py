"""Institution et référentiels éducatifs configurables par tenant."""

import uuid
from datetime import date

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator, RegexValidator
from django.db import models
from django.db.models import Q
from django.utils.text import slugify

from applications.organisations.models import Tenant
from applications.referentiels.validators import (
    valider_devise,
    valider_fuseau_horaire,
    valider_indicatif,
    valider_pays,
)


def _chemin_fichier_institution(instance, filename: str, dossier: str) -> str:
    extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return f"institutions/{instance.tenant_id}/{dossier}/{uuid.uuid4().hex}.{extension}"


def chemin_logo_institution(instance, filename: str) -> str:
    return _chemin_fichier_institution(instance, filename, "logos")


def chemin_banniere_institution(instance, filename: str) -> str:
    return _chemin_fichier_institution(instance, filename, "bannieres")


def chemin_signature_institution(instance, filename: str) -> str:
    return _chemin_fichier_institution(instance, filename, "signatures")


class FormatDate(models.TextChoices):
    JOUR_MOIS_ANNEE = "DD/MM/YYYY", "Jour/Mois/Année"
    ANNEE_MOIS_JOUR = "YYYY-MM-DD", "Année-Mois-Jour"
    MOIS_JOUR_ANNEE = "MM/DD/YYYY", "Mois/Jour/Année"


class StatutAnneeAcademique(models.TextChoices):
    PLANIFIEE = "planifiee", "Planifiée"
    ACTIVE = "active", "Active"
    CLOTUREE = "cloturee", "Clôturée"


class Institution(models.Model):
    """Unique unité éducative du tenant dans le périmètre MVP."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    tenant = models.OneToOneField(
        Tenant,
        on_delete=models.PROTECT,
        related_name="institution",
    )
    slug = models.SlugField(max_length=100, unique=True, blank=True, db_index=False)
    nom = models.CharField(max_length=200)
    nom_court = models.CharField(max_length=80, blank=True)
    type_educatif = models.SlugField(max_length=40)
    code_officiel = models.CharField(max_length=80, blank=True)
    annee_fondation = models.PositiveSmallIntegerField(null=True, blank=True)
    responsable = models.CharField(max_length=180, blank=True)
    slogan = models.CharField(max_length=255, blank=True)
    pays = models.CharField(max_length=2, default="HT", validators=[valider_pays])
    adresse = models.CharField(max_length=300, blank=True)
    departement = models.CharField(max_length=100, blank=True)
    commune = models.CharField(max_length=100, blank=True)
    telephone = models.CharField(max_length=30, blank=True)
    email_officiel = models.EmailField(blank=True)
    site_web = models.URLField(max_length=200, blank=True)
    logo = models.ImageField(
        upload_to=chemin_logo_institution,
        blank=True,
        validators=[FileExtensionValidator(["jpg", "jpeg", "png", "webp"])],
    )
    banniere = models.ImageField(
        upload_to=chemin_banniere_institution,
        blank=True,
        validators=[FileExtensionValidator(["jpg", "jpeg", "png", "webp"])],
    )
    signature = models.ImageField(
        upload_to=chemin_signature_institution,
        blank=True,
        validators=[FileExtensionValidator(["jpg", "jpeg", "png", "webp"])],
    )
    couleur_principale = models.CharField(
        max_length=7,
        default="#2563EB",
        validators=[
            RegexValidator(
                r"^#[0-9A-Fa-f]{6}$",
                "La couleur doit être un code hexadécimal sur six caractères.",
            )
        ],
    )
    langue = models.CharField(max_length=12, default="fr")
    devise_principale = models.CharField(
        max_length=3,
        default="HTG",
        validators=[valider_devise],
    )
    devises_secondaires = models.JSONField(default=list, blank=True)
    fuseau_horaire = models.CharField(
        max_length=64,
        default="America/Port-au-Prince",
        validators=[valider_fuseau_horaire],
    )
    format_date = models.CharField(
        max_length=10,
        choices=FormatDate.choices,
        default=FormatDate.JOUR_MOIS_ANNEE,
    )
    indicatif_telephonique = models.CharField(
        max_length=5,
        default="+509",
        validators=[valider_indicatif],
    )
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="institutions_creees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("nom", "id")
        verbose_name = "institution"
        verbose_name_plural = "institutions"

    def __str__(self) -> str:
        return self.nom

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.nom_court or self.nom)[:90] or "etablissement"
            slug = base
            suffixe = 2
            while type(self).objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base[: 90 - len(str(suffixe))]}-{suffixe}"
                suffixe += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        erreurs = {}
        langues_disponibles = dict(settings.LANGUAGES)
        if self.langue not in langues_disponibles:
            erreurs["langue"] = "Cette langue n’est pas activée par la plateforme."
        if not isinstance(self.devises_secondaires, list) or not all(
            isinstance(devise, str) for devise in self.devises_secondaires
        ):
            erreurs["devises_secondaires"] = "Fournissez une liste de codes de devise."
        else:
            if len(self.devises_secondaires) != len(set(self.devises_secondaires)):
                erreurs["devises_secondaires"] = "Les devises secondaires doivent être uniques."
            elif self.devise_principale in self.devises_secondaires:
                erreurs["devises_secondaires"] = (
                    "La devise principale ne doit pas être répétée comme secondaire."
                )
            elif any(
                len(devise) != 3
                or not devise.isascii()
                or not devise.isupper()
                or not devise.isalpha()
                for devise in self.devises_secondaires
            ):
                erreurs["devises_secondaires"] = (
                    "Chaque devise doit utiliser trois lettres majuscules."
                )
        if erreurs:
            raise ValidationError(erreurs)


class ObjetReferentielTenant(models.Model):
    """Champs communs des tables éducatives détenues par un tenant."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.PROTECT,
        related_name="%(class)ss",
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.PROTECT,
        related_name="%(class)ss",
    )
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="%(class)ss_crees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

    def __str__(self) -> str:
        return self.nom

    def clean(self):
        super().clean()
        if self.tenant_id and self.institution_id and self.institution.tenant_id != self.tenant_id:
            raise ValidationError(
                {"institution": "L’institution doit appartenir au tenant sélectionné."}
            )


class Campus(ObjetReferentielTenant):
    """Site physique ou unité administrative de l’institution."""

    code = models.SlugField(max_length=40)
    nom = models.CharField(max_length=160)
    adresse = models.CharField(max_length=300, blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "code"),
                name="campus_tenant_code_unique",
            ),
        ]
        indexes = [models.Index(fields=("tenant", "actif"), name="campus_tenant_actif_idx")]
        verbose_name = "campus"
        verbose_name_plural = "campus"

    def __str__(self) -> str:
        return f"{self.nom} ({self.code})"


class AnneeAcademique(ObjetReferentielTenant):
    """Année indépendante par établissement ; aucun chevauchement n’est imposé."""

    nom = models.CharField(
        max_length=9,
        validators=[
            RegexValidator(
                r"^[0-9]{4}-[0-9]{4}$",
                "L’année doit respecter le format AAAA-AAAA, par exemple 2026-2027.",
            )
        ],
    )
    debut = models.DateField(blank=True, null=True)
    fin = models.DateField(blank=True, null=True)
    statut = models.CharField(
        max_length=12,
        choices=StatutAnneeAcademique.choices,
        default=StatutAnneeAcademique.PLANIFIEE,
    )

    class Meta:
        ordering = ("-debut", "nom")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "nom"),
                name="annee_tenant_nom_unique",
            ),
            models.CheckConstraint(
                condition=Q(fin__gt=models.F("debut")),
                name="annee_dates_valides",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutAnneeAcademique.values),
                name="annee_statut_valide",
            ),
            models.UniqueConstraint(
                fields=("tenant",),
                condition=Q(statut=StatutAnneeAcademique.ACTIVE),
                name="annee_tenant_active_unique",
            ),
        ]
        indexes = [
            models.Index(fields=("tenant", "debut"), name="annee_tenant_debut_idx"),
        ]
        verbose_name = "année académique"
        verbose_name_plural = "années académiques"

    def clean(self):
        super().clean()
        enregistrement_precedent = (
            type(self).objects.filter(pk=self.pk)
            .values_list("statut", "nom")
            .first()
            if self.pk
            else None
        )
        statut_precedent = enregistrement_precedent[0] if enregistrement_precedent else None
        nom_precedent = enregistrement_precedent[1] if enregistrement_precedent else None
        nom_legacy_inchange = nom_precedent is not None and self.nom == nom_precedent
        if enregistrement_precedent:
            if (
                statut_precedent == StatutAnneeAcademique.CLOTUREE
                and self.statut != StatutAnneeAcademique.CLOTUREE
            ):
                raise ValidationError(
                    {"statut": "Une année clôturée ne peut pas être réactivée."}
                )
            if (
                statut_precedent == StatutAnneeAcademique.ACTIVE
                and self.statut == StatutAnneeAcademique.PLANIFIEE
            ):
                raise ValidationError(
                    {"statut": "Une année active doit être clôturée avant de changer de statut."}
                )
            if (
                self.statut == StatutAnneeAcademique.ACTIVE
                and statut_precedent != StatutAnneeAcademique.ACTIVE
                and type(self).objects.filter(
                    tenant_id=self.tenant_id,
                    statut=StatutAnneeAcademique.ACTIVE,
                )
                .exclude(pk=self.pk)
                .exists()
            ):
                raise ValidationError(
                    {"statut": "Clôturez l’année active avant d’en activer une autre."}
                )
        if (
            len(self.nom) == 9
            and self.nom[4] == "-"
            and self.nom[:4].isdigit()
            and self.nom[5:].isdigit()
        ):
            debut_annee, fin_annee = (int(partie) for partie in self.nom.split("-"))
            if debut_annee == 0:
                raise ValidationError({"nom": "L’année de début doit être supérieure à zéro."})
            if fin_annee != debut_annee + 1:
                if not nom_legacy_inchange:
                    raise ValidationError(
                        {
                            "nom": (
                                "La seconde année doit suivre immédiatement la première, "
                                "par exemple 2026-2027."
                            )
                        }
                    )
            else:
                self.debut = date(debut_annee, 9, 1)
                self.fin = date(fin_annee, 6, 30)
        if self.debut and self.fin and self.fin <= self.debut:
            raise ValidationError({"fin": "La fin doit suivre le début de l’année."})


class PeriodeAcademique(ObjetReferentielTenant):
    """Période personnalisée appartenant à une année académique."""

    annee_academique = models.ForeignKey(
        AnneeAcademique,
        on_delete=models.PROTECT,
        related_name="periodes",
    )
    code = models.SlugField(max_length=40)
    nom = models.CharField(max_length=100)
    debut = models.DateField()
    fin = models.DateField()
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("debut", "code")
        constraints = [
            models.UniqueConstraint(
                fields=("annee_academique", "code"),
                name="periode_annee_code_unique",
            ),
            models.CheckConstraint(
                condition=Q(fin__gte=models.F("debut")),
                name="periode_dates_valides",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "annee_academique"),
                name="periode_tenant_annee_idx",
            ),
        ]
        verbose_name = "période académique"
        verbose_name_plural = "périodes académiques"

    def __str__(self) -> str:
        return f"{self.nom} — {self.annee_academique.nom}"

    def clean(self):
        super().clean()
        if self.annee_academique_id:
            annee = self.annee_academique
            if (
                self.tenant_id
                and annee.tenant_id != self.tenant_id
                or self.institution_id
                and annee.institution_id != self.institution_id
            ):
                raise ValidationError(
                    {"annee_academique": "L’année doit appartenir au même tenant."}
                )
            if self.debut and self.fin and self.fin < self.debut:
                raise ValidationError({"fin": "La fin doit suivre le début de la période."})
            if self.debut and self.fin and (self.debut < annee.debut or self.fin > annee.fin):
                raise ValidationError(
                    {"debut": "La période doit rester dans les bornes de son année académique."}
                )


class Programme(ObjetReferentielTenant):
    """Programme d’études ou filière, sans hiérarchie universelle imposée."""

    code = models.SlugField(max_length=40)
    nom = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "code"),
                name="programme_tenant_code_unique",
            ),
        ]
        indexes = [models.Index(fields=("tenant", "actif"), name="programme_tenant_actif_idx")]
        verbose_name = "programme"
        verbose_name_plural = "programmes"

    def __str__(self) -> str:
        return f"{self.nom} ({self.code})"


class NiveauEtude(ObjetReferentielTenant):
    """Niveau configurable à l’intérieur d’un programme."""

    programme = models.ForeignKey(
        Programme,
        on_delete=models.PROTECT,
        related_name="niveaux",
    )
    code = models.SlugField(max_length=40)
    nom = models.CharField(max_length=120)
    ordre = models.PositiveSmallIntegerField(null=True, blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("ordre", "nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("programme", "code"),
                name="niveau_programme_code_unique",
            ),
        ]
        indexes = [models.Index(fields=("tenant", "actif"), name="niveau_tenant_actif_idx")]
        verbose_name = "niveau d’étude"
        verbose_name_plural = "niveaux d’étude"

    def __str__(self) -> str:
        return f"{self.programme.nom} — {self.nom}"

    def clean(self):
        super().clean()
        if self.programme_id and (
            self.programme.tenant_id != self.tenant_id
            or self.programme.institution_id != self.institution_id
        ):
            raise ValidationError({"programme": "Le programme doit appartenir au même tenant."})


class Cours(ObjetReferentielTenant):
    """Matière, cours ou module réutilisable dans plusieurs parcours."""

    code = models.SlugField(max_length=40)
    nom = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "code"),
                name="cours_tenant_code_unique",
            ),
        ]
        indexes = [models.Index(fields=("tenant", "actif"), name="cours_tenant_actif_idx")]
        verbose_name = "cours"
        verbose_name_plural = "cours"

    def __str__(self) -> str:
        return f"{self.nom} ({self.code})"


class Groupe(ObjetReferentielTenant):
    """Classe, cohorte, section ou groupe d’atelier rattaché à une année."""

    annee_academique = models.ForeignKey(
        AnneeAcademique,
        on_delete=models.PROTECT,
        related_name="groupes",
    )
    campus = models.ForeignKey(
        Campus,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="groupes",
    )
    programme = models.ForeignKey(
        Programme,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="groupes",
    )
    niveau = models.ForeignKey(
        NiveauEtude,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="groupes",
    )
    code = models.SlugField(max_length=40)
    nom = models.CharField(max_length=160)
    type_groupe = models.SlugField(max_length=32, default="groupe")
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "annee_academique", "code"),
                name="groupe_annee_code_unique",
            ),
        ]
        indexes = [
            models.Index(fields=("tenant", "annee_academique"), name="groupe_tenant_annee_idx"),
            models.Index(fields=("tenant", "actif"), name="groupe_tenant_actif_idx"),
        ]
        verbose_name = "groupe pédagogique"
        verbose_name_plural = "groupes pédagogiques"

    def __str__(self) -> str:
        return f"{self.nom} ({self.code})"

    def clean(self):
        super().clean()
        erreurs = {}
        if self.annee_academique_id and (
            self.annee_academique.tenant_id != self.tenant_id
            or self.annee_academique.institution_id != self.institution_id
        ):
            erreurs["annee_academique"] = "L’année doit appartenir au même tenant."
        if self.campus_id and (
            self.campus.tenant_id != self.tenant_id
            or self.campus.institution_id != self.institution_id
        ):
            erreurs["campus"] = "Le campus doit appartenir au même tenant."
        if self.programme_id and (
            self.programme.tenant_id != self.tenant_id
            or self.programme.institution_id != self.institution_id
        ):
            erreurs["programme"] = "Le programme doit appartenir au même tenant."
        if self.niveau_id and (
            self.niveau.tenant_id != self.tenant_id
            or self.niveau.institution_id != self.institution_id
        ):
            erreurs["niveau"] = "Le niveau doit appartenir au même tenant."
        if self.niveau_id and self.programme_id and self.niveau.programme_id != self.programme_id:
            erreurs["niveau"] = "Le niveau doit appartenir au programme sélectionné."
        if erreurs:
            raise ValidationError(erreurs)
