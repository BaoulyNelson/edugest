from django.contrib import admin

from applications.referentiels.models import (
    AnneeAcademique,
    Campus,
    Cours,
    Groupe,
    Institution,
    NiveauEtude,
    PeriodeAcademique,
    Programme,
)


@admin.register(AnneeAcademique)
class AnneeAcademiqueAdmin(admin.ModelAdmin):
    def get_exclude(self, request, obj=None):
        exclude = super().get_exclude(request, obj)
        if obj is None and "statut" not in (exclude or ()):
            return tuple(exclude or ()) + ("statut",)
        return exclude


admin.site.register(
    (
        Institution,
        Campus,
        PeriodeAcademique,
        Programme,
        NiveauEtude,
        Cours,
        Groupe,
    )
)
