"""Écritures atomiques et auditées des référentiels éducatifs."""

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Model

from applications.organisations.models import EvenementAudit, Tenant
from applications.referentiels.models import (
    AnneeAcademique,
    Institution,
    StatutAnneeAcademique,
)


class ConflitIdempotenceReferentiel(Exception):
    """Clé d’idempotence réutilisée avec un autre contexte ou contenu."""


def _valider_candidat(objet: Model) -> None:
    objet.full_clean(
        exclude=("cle_idempotence",),
        validate_unique=False,
        validate_constraints=False,
    )


def _ecrire_audit(
    *,
    tenant: Tenant,
    acteur,
    objet: Model,
    action: str,
    champs: list[str] | None = None,
) -> None:
    EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=f"referentiel.{action}",
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        details={"champs": champs or []},
    )


def creer_referentiel(
    *,
    modele: type[Model],
    tenant: Tenant,
    acteur,
    valeurs: dict,
    cle_idempotence,
    institution: Institution | None = None,
) -> tuple[Model, bool]:
    valeurs_initiales = {
        **valeurs,
        "tenant": tenant,
        "cree_par": acteur,
        "cle_idempotence": cle_idempotence,
    }
    if modele is not Institution:
        valeurs_initiales["institution"] = institution
    if modele is AnneeAcademique:
        valeurs_initiales["statut"] = StatutAnneeAcademique.PLANIFIEE
    candidat = modele(**valeurs_initiales)
    _valider_candidat(candidat)

    with transaction.atomic():
        existant = (
            modele.objects.select_for_update().filter(cle_idempotence=cle_idempotence).first()
        )
        if existant is not None:
            if not _correspond_a_candidat(existant, candidat):
                raise ConflitIdempotenceReferentiel
            return existant, False

        if modele is Institution and Institution.objects.filter(tenant=tenant).exists():
            raise ConflitIdempotenceReferentiel

        try:
            candidat.save(force_insert=True)
        except IntegrityError as error:
            raise ConflitIdempotenceReferentiel from error
        _ecrire_audit(
            tenant=tenant,
            acteur=acteur,
            objet=candidat,
            action="cree",
            champs=sorted(valeurs),
        )
        return candidat, True


def _correspond_a_candidat(existant: Model, candidat: Model) -> bool:
    if existant.tenant_id != candidat.tenant_id or existant.cree_par_id != candidat.cree_par_id:
        return False
    if hasattr(existant, "institution_id") and (existant.institution_id != candidat.institution_id):
        return False
    champs = (
        champ
        for champ in candidat._meta.concrete_fields
        if champ.name
        not in {
            "id",
            "cle_idempotence",
            "tenant",
            "institution",
            "cree_par",
            "cree_le",
            "modifie_le",
        }
    )
    return all(
        getattr(existant, champ.attname) == getattr(candidat, champ.attname) for champ in champs
    )


def modifier_referentiel(
    *,
    objet: Model,
    acteur,
    valeurs: dict,
    action: str = "modifie",
) -> Model:
    with transaction.atomic():
        if isinstance(objet, AnneeAcademique):
            Tenant.objects.select_for_update().get(pk=objet.tenant_id)
        objet = type(objet).objects.select_for_update().get(pk=objet.pk)
        statut_precedent = (
            objet.statut if isinstance(objet, AnneeAcademique) else None
        )
        for nom, valeur in valeurs.items():
            setattr(objet, nom, valeur)
        if isinstance(objet, AnneeAcademique):
            if (
                statut_precedent == StatutAnneeAcademique.CLOTUREE
                and objet.statut != StatutAnneeAcademique.CLOTUREE
            ):
                raise ValidationError(
                    {"statut": "Une année clôturée ne peut pas être réactivée."}
                )
            if (
                statut_precedent == StatutAnneeAcademique.ACTIVE
                and objet.statut == StatutAnneeAcademique.PLANIFIEE
            ):
                raise ValidationError(
                    {"statut": "Une année active doit être clôturée avant de changer de statut."}
                )
            if (
                objet.statut == StatutAnneeAcademique.ACTIVE
                and statut_precedent != StatutAnneeAcademique.ACTIVE
                and AnneeAcademique.objects.filter(
                    tenant=objet.tenant,
                    statut=StatutAnneeAcademique.ACTIVE,
                )
                .exclude(pk=objet.pk)
                .exists()
            ):
                raise ValidationError(
                    {
                        "statut": (
                            "Clôturez l’année active avant d’activer cette année académique."
                        )
                    }
                )
        _valider_candidat(objet)
        try:
            objet.save()
        except IntegrityError as error:
            raise ValidationError(
                "La modification entre en conflit avec un référentiel existant."
            ) from error
        _ecrire_audit(
            tenant=objet.tenant,
            acteur=acteur,
            objet=objet,
            action=action,
            champs=sorted(valeurs),
        )
        return objet


def archiver_referentiel(*, objet: Model, acteur) -> tuple[Model, bool]:
    if isinstance(objet, AnneeAcademique):
        if objet.statut == StatutAnneeAcademique.CLOTUREE:
            return objet, False
        valeurs = {"statut": StatutAnneeAcademique.CLOTUREE}
    elif hasattr(objet, "actif"):
        if not objet.actif:
            return objet, False
        valeurs = {"actif": False}
    else:
        raise ValidationError("Ce référentiel ne peut pas être archivé.")

    return (
        modifier_referentiel(
            objet=objet,
            acteur=acteur,
            valeurs=valeurs,
            action="archive",
        ),
        True,
    )
