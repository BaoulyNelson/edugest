"""Configuration des référentiels éducatifs tenant-scoped."""

from django.apps import AppConfig


class ReferentielsConfig(AppConfig):
    """Application des institutions, campus et référentiels pédagogiques."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.referentiels"
    label = "referentiels"
    verbose_name = "Référentiels éducatifs"
