"""Vues HTML classiques pour gérer les référentiels éducatifs."""

import uuid

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.http import Http404, HttpResponseNotAllowed, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods

from applications.organisations.models import RoleAdhesion
from applications.referentiels.forms import (
    AnneeAcademiqueForm,
    CampusForm,
    CoursForm,
    GroupeForm,
    NiveauEtudeForm,
    PeriodeAcademiqueForm,
    ProgrammeForm,
)
from applications.referentiels.models import (
    AnneeAcademique,
    Campus,
    Cours,
    Groupe,
    NiveauEtude,
    PeriodeAcademique,
    Programme,
)
from applications.referentiels.services import (
    ConflitIdempotenceReferentiel,
    archiver_referentiel,
    creer_referentiel,
    modifier_referentiel,
)
from applications.tableau_de_bord.views import _exiger_espace, _page_privee

_REFERENTIELS = {
    "campus": ("Campus", Campus, CampusForm),
    "annee-academique": ("Année académique", AnneeAcademique, AnneeAcademiqueForm),
    "periode-academique": ("Période académique", PeriodeAcademique, PeriodeAcademiqueForm),
    "programme": ("Programme", Programme, ProgrammeForm),
    "niveau": ("Niveau d’étude", NiveauEtude, NiveauEtudeForm),
    "cours": ("Cours", Cours, CoursForm),
    "groupe": ("Groupe", Groupe, GroupeForm),
}

_ROLES_GESTION = {
    RoleAdhesion.PROPRIETAIRE,
    RoleAdhesion.ADMINISTRATEUR,
    RoleAdhesion.GESTIONNAIRE,
}

_URLS_LISTE_REFERENTIEL = {
    "campus": "campus",
    "annee-academique": "annees-academiques",
    "periode-academique": "periodes-academiques",
    "programme": "programmes",
    "niveau": "niveaux",
    "cours": "cours",
    "groupe": "groupes",
}


def _charger_referentiel(slug):
    try:
        return _REFERENTIELS[slug]
    except KeyError as error:
        raise Http404 from error


def _exiger_gestion(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return None, contexte
    if workspace.role not in _ROLES_GESTION:
        raise PermissionDenied(_("La gestion des référentiels est réservée aux gestionnaires."))
    return workspace, contexte


def _creer_objet(formulaire, *, workspace, acteur):
    return creer_referentiel(
        modele=formulaire._meta.model,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        acteur=acteur,
        valeurs=formulaire.cleaned_data,
        cle_idempotence=uuid.uuid4(),
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def gestion_referentiel(request, slug):
    libelle, modele, _classe_formulaire = _charger_referentiel(slug)
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    role_gestion = workspace.role in _ROLES_GESTION
    if request.method == "POST":
        if not role_gestion:
            raise PermissionDenied(
                _("La gestion des référentiels est réservée aux gestionnaires.")
            )
        return HttpResponseNotAllowed(["GET"])

    base = modele.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    )
    objets = base
    terme = request.GET.get("q", "").strip()
    if terme:
        objets = objets.filter(nom__icontains=terme)
    return render(
        request,
        "referentiels/liste.html",
        {
            **contexte,
            "libelle": libelle,
            "slug": slug,
            "objets": objets[:100],
            "terme": terme,
            "url_liste": reverse(_URLS_LISTE_REFERENTIEL[slug]),
            "role_gestion": role_gestion,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def formulaire_referentiel(request, slug, objet_id=None):
    libelle, modele, classe_formulaire = _charger_referentiel(slug)
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    base = modele.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    )
    objet = get_object_or_404(base, pk=objet_id) if objet_id is not None else None
    formulaire = classe_formulaire(
        request.POST or None,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        acteur=request.user,
        instance=objet,
    )
    url_liste = reverse(_URLS_LISTE_REFERENTIEL[slug])
    if request.method == "POST" and formulaire.is_valid():
        if objet is not None:
            try:
                objet = modifier_referentiel(
                    objet=objet,
                    acteur=request.user,
                    valeurs=formulaire.cleaned_data,
                )
            except ValidationError as error:
                _ajouter_erreur_modele(formulaire, error)
            else:
                messages.success(request, _("%(objet)s a été modifié.") % {"objet": objet})
                return redirect(url_liste)
        else:
            try:
                objet, cree = _creer_objet(
                    formulaire,
                    workspace=workspace,
                    acteur=request.user,
                )
            except ConflitIdempotenceReferentiel:
                formulaire.add_error(
                    None,
                    _("Cette création entre en conflit avec une donnée existante."),
                )
            except ValidationError as error:
                _ajouter_erreur_modele(formulaire, error)
            else:
                if cree:
                    messages.success(request, _("%(objet)s a été créé.") % {"objet": objet})
                return redirect(url_liste)

    return render(
        request,
        "referentiels/formulaire.html",
        {
            **contexte,
            "libelle": libelle,
            "slug": slug,
            "formulaire": formulaire,
            "objet_modifie": objet,
            "url_liste": url_liste,
        },
    )


@login_required
@_page_privee
@require_http_methods(["POST"])
def archiver_referentiel_web(request, slug, objet_id):
    _libelle, modele, _classe_formulaire = _charger_referentiel(slug)
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    objet = get_object_or_404(
        modele.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ),
        pk=objet_id,
    )
    try:
        objet, archive = archiver_referentiel(objet=objet, acteur=request.user)
    except ValidationError as error:
        messages.error(request, _(" ".join(error.messages)))
    else:
        if archive:
            messages.success(request, _("%(objet)s a été archivé.") % {"objet": objet})
    return redirect(_URLS_LISTE_REFERENTIEL[slug])


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def creation_rapide_referentiel(request, slug):
    _, _, classe_formulaire = _charger_referentiel(slug)
    workspace, _ = _exiger_gestion(request)
    if workspace is None:
        return JsonResponse({"success": False}, status=403)

    formulaire = classe_formulaire(
        request.POST or None,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        acteur=request.user,
    )
    if request.method == "POST":
        if formulaire.is_valid():
            try:
                objet, cree = _creer_objet(
                    formulaire,
                    workspace=workspace,
                    acteur=request.user,
                )
            except ConflitIdempotenceReferentiel:
                formulaire.add_error(
                    None,
                    _("Cette création entre en conflit avec une donnée existante."),
                )
            except ValidationError as error:
                _ajouter_erreur_modele(formulaire, error)
            else:
                return JsonResponse(
                    {
                        "success": True,
                        "id": str(objet.pk),
                        "label": str(objet),
                        "created": cree,
                    }
                )

    response = render(
        request,
        "referentiels/_formulaire_creation_rapide.html",
        {"formulaire": formulaire, "slug": slug},
        status=422 if request.method == "POST" else 200,
    )
    return response


def _ajouter_erreur_modele(formulaire, error):
    erreurs = getattr(error, "message_dict", None)
    if erreurs:
        for champ, messages_erreur in erreurs.items():
            formulaire.add_error(
                champ if champ in formulaire.fields else None,
                messages_erreur,
            )
    else:
        formulaire.add_error(None, error.messages)
