"""Parcours HTML de création des affectations, créneaux et séances."""

from uuid import UUID

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods

from applications.emplois_temps.forms import (
    FormulaireActivation,
    FormulaireAffectation,
    FormulaireCreneau,
    FormulaireSeance,
    FormulaireStatutSeance,
)
from applications.emplois_temps.models import (
    AffectationEnseignement,
    CreneauHoraire,
    Seance,
)
from applications.emplois_temps.services import (
    ConflitPlanification,
    creer_affectation,
    creer_creneau,
    creer_seance,
    modifier_activation,
    transitionner_seance,
)
from applications.presences.forms import FiltreDatePresenceForm
from applications.referentiels.views import _exiger_gestion
from applications.tableau_de_bord.views import _page_privee


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def gestion_emploi_temps(request):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    tenant = workspace.tenant
    institution = tenant.institution
    formulaires = {
        "affectation": FormulaireAffectation(
            request.POST
            if request.method == "POST" and request.POST.get("action") == "affectation"
            else None,
            tenant=tenant,
            institution=institution,
            acteur=request.user,
        ),
        "creneau": FormulaireCreneau(
            request.POST
            if request.method == "POST" and request.POST.get("action") == "creneau"
            else None,
            tenant=tenant,
            institution=institution,
            acteur=request.user,
        ),
        "seance": FormulaireSeance(
            request.POST
            if request.method == "POST" and request.POST.get("action") == "seance"
            else None,
            tenant=tenant,
            institution=institution,
        ),
    }
    if request.method == "POST":
        response = _traiter_mutation(request, workspace)
        if response is not None:
            return response
        response = _traiter_creation(request, workspace, formulaires)
        if response is not None:
            return response

    with timezone.override(institution.fuseau_horaire):
        aujourd_hui = timezone.localdate()
    filtre_date = FiltreDatePresenceForm(request.GET or None, initial={"date": aujourd_hui})
    date_selectionnee = aujourd_hui
    if filtre_date.is_bound and filtre_date.is_valid():
        date_selectionnee = filtre_date.cleaned_data["date"]

    base = {"tenant": tenant, "institution": institution}
    affectations = AffectationEnseignement.objects.filter(
        **base,
    ).select_related("enseignant__personne", "annee_academique", "groupe", "cours")
    creneaux = CreneauHoraire.objects.filter(**base).select_related(
        "affectation__cours",
        "affectation__groupe",
        "affectation__enseignant__personne",
    )
    seances = Seance.objects.filter(**base, date=date_selectionnee).select_related(
        "creneau__affectation__cours",
        "creneau__affectation__groupe",
    )
    return render(
        request,
        "emplois_temps/gestion.html",
        {
            **contexte,
            "date_selectionnee": date_selectionnee,
            "affectations": affectations,
            "creneaux": creneaux,
            "seances": seances,
            "filtre_date": filtre_date,
            "formulaire_affectation": formulaires["affectation"],
            "formulaire_creneau": formulaires["creneau"],
            "formulaire_seance": formulaires["seance"],
        },
    )


def _traiter_mutation(request, workspace):
    action = request.POST.get("action")
    if action not in {"activer_affectation", "activer_creneau", "statut_seance"}:
        return

    tenant = workspace.tenant
    institution = tenant.institution
    try:
        if action == "activer_affectation":
            objet = get_object_or_404(
                AffectationEnseignement.objects.filter(
                    tenant=tenant,
                    institution=institution,
                ),
                pk=request.POST.get("objet_id"),
            )
            formulaire = FormulaireActivation(request.POST)
            if not formulaire.is_valid():
                messages.error(request, _("La valeur d’activation est invalide."))
                return redirect("emplois_temps_web:gestion")
            objet = modifier_activation(
                objet=objet,
                acteur=request.user,
                actif=formulaire.cleaned_data["actif"],
            )
        elif action == "activer_creneau":
            objet = get_object_or_404(
                CreneauHoraire.objects.filter(
                    tenant=tenant,
                    institution=institution,
                ),
                pk=request.POST.get("objet_id"),
            )
            formulaire = FormulaireActivation(request.POST)
            if not formulaire.is_valid():
                messages.error(request, _("La valeur d’activation est invalide."))
                return redirect("emplois_temps_web:gestion")
            objet = modifier_activation(
                objet=objet,
                acteur=request.user,
                actif=formulaire.cleaned_data["actif"],
            )
        else:
            objet = get_object_or_404(
                Seance.objects.filter(
                    tenant=tenant,
                    institution=institution,
                ),
                pk=request.POST.get("objet_id"),
            )
            formulaire = FormulaireStatutSeance(request.POST)
            if not formulaire.is_valid():
                messages.error(request, _("Le statut sélectionné est invalide."))
                return redirect("emplois_temps_web:gestion")
            objet = transitionner_seance(
                seance=objet,
                acteur=request.user,
                nouveau_statut=formulaire.cleaned_data["statut"],
            )
    except ValidationError as error:
        for message in error.messages:
            messages.error(request, message)
    else:
        messages.success(request, _("%(objet)s a été mis à jour.") % {"objet": objet})
    return redirect("emplois_temps_web:gestion")


def _traiter_creation(request, workspace, formulaires):
    tenant = workspace.tenant
    institution = tenant.institution
    acteur = request.user
    action = request.POST.get("action")
    if action not in formulaires:
        raise PermissionDenied(_("Action de planification inconnue."))
    formulaire = formulaires[action]
    if not formulaire.is_valid():
        return

    try:
        if action == "affectation":
            objet, cree = creer_affectation(
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                valeurs={
                    key: value
                    for key, value in formulaire.cleaned_data.items()
                    if key != "cle_idempotence"
                },
                cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
            )
        elif action == "creneau":
            objet, cree = creer_creneau(
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                valeurs={
                    key: value
                    for key, value in formulaire.cleaned_data.items()
                    if key != "cle_idempotence"
                },
                cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
            )
        else:
            objet, cree = creer_seance(
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                creneau=formulaire.cleaned_data["creneau"],
                date=formulaire.cleaned_data["date"],
                cle_idempotence=UUID(str(formulaire.cleaned_data["cle_idempotence"])),
            )
    except ConflitPlanification:
        formulaire.add_error(
            None,
            _("Cette planification entre en conflit avec une donnée existante."),
        )
    except ValidationError as error:
        _ajouter_erreur(formulaire, error)
    else:
        if cree:
            messages.success(request, _("%(objet)s a été créé.") % {"objet": objet})
        url = reverse("emplois_temps_web:gestion")
        if action == "seance":
            url = f"{url}?date={formulaire.cleaned_data['date'].isoformat()}"
        return redirect(url)


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def creation_rapide_planification(request, slug):
    workspace, _ = _exiger_gestion(request)
    if workspace is None:
        return JsonResponse({"success": False}, status=403)
    if slug not in {"affectation", "creneau"}:
        raise Http404

    formulaire_classe = (
        FormulaireAffectation if slug == "affectation" else FormulaireCreneau
    )
    formulaire = formulaire_classe(
        request.POST or None,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        acteur=request.user,
    )
    if request.method == "POST" and formulaire.is_valid():
        try:
            service = creer_affectation if slug == "affectation" else creer_creneau
            objet, cree = service(
                tenant=workspace.tenant,
                institution=workspace.tenant.institution,
                acteur=request.user,
                valeurs={
                    key: value
                    for key, value in formulaire.cleaned_data.items()
                    if key != "cle_idempotence"
                },
                cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
            )
        except ConflitPlanification:
            formulaire.add_error(
                None,
                _("Cette planification entre en conflit avec une donnée existante."),
            )
        except ValidationError as error:
            _ajouter_erreur(formulaire, error)
        else:
            return JsonResponse(
                {
                    "success": True,
                    "id": str(objet.pk),
                    "label": str(objet),
                    "created": cree,
                }
            )

    return render(
        request,
        "emplois_temps/_formulaire_creation_rapide.html",
        {"formulaire": formulaire, "slug": slug},
        status=422 if request.method == "POST" else 200,
    )


def _ajouter_erreur(formulaire, error):
    erreurs = getattr(error, "message_dict", None)
    if erreurs:
        for champ, messages_erreur in erreurs.items():
            formulaire.add_error(
                champ if champ in formulaire.fields else None,
                messages_erreur,
            )
    else:
        formulaire.add_error(None, error.messages)
