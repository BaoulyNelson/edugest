"""Routes HTML publiques du module d’emploi du temps."""

from django.urls import path

from applications.emplois_temps.views import (
    creation_rapide_planification,
    gestion_emploi_temps,
)

app_name = "emplois_temps_web"

urlpatterns = [
    path("", gestion_emploi_temps, name="gestion"),
    path("creation-rapide/<slug:slug>/", creation_rapide_planification, name="creation-rapide"),
]
