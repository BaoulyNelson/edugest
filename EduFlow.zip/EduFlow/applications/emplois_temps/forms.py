"""Formulaires Django classiques de planification pédagogique."""

import uuid

from django import forms
from django.core.exceptions import ValidationError

from applications.emplois_temps.models import (
    AffectationEnseignement,
    CreneauHoraire,
    StatutSeance,
)
from applications.personnes.models import ProfilEnseignant


class FormulaireAffectation(forms.ModelForm):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)

    class Meta:
        model = AffectationEnseignement
        fields = (
            "enseignant",
            "annee_academique",
            "groupe",
            "cours",
            "date_debut",
            "date_fin",
        )
        widgets = {
            "date_debut": forms.DateInput(attrs={"type": "date"}),
            "date_fin": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, tenant, institution, acteur, **kwargs):
        kwargs.setdefault(
            "instance",
            AffectationEnseignement(
                tenant=tenant,
                institution=institution,
                cree_par=acteur,
            ),
        )
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["enseignant"].queryset = ProfilEnseignant.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        ).select_related("personne")
        self.fields["enseignant"].label_from_instance = lambda item: str(item.personne)
        for field in ("annee_academique", "groupe", "cours"):
            self.fields[field].queryset = self.fields[field].queryset.filter(
                tenant=tenant,
                institution=institution,
            )
            if field != "annee_academique":
                self.fields[field].queryset = self.fields[field].queryset.filter(actif=True)
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        if self.errors:
            return cleaned_data
        candidat = AffectationEnseignement(
            tenant=self.instance.tenant,
            institution=self.instance.institution,
            cree_par=self.instance.cree_par,
            cle_idempotence=cleaned_data["cle_idempotence"],
            **{
                field: value
                for field, value in cleaned_data.items()
                if field != "cle_idempotence"
            },
        )
        _valider_objet(candidat, self)
        return cleaned_data


class FormulaireCreneau(forms.ModelForm):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)

    class Meta:
        model = CreneauHoraire
        fields = (
            "affectation",
            "jour_semaine",
            "heure_debut",
            "heure_fin",
            "date_debut",
            "date_fin",
            "salle",
        )
        widgets = {
            "heure_debut": forms.TimeInput(attrs={"type": "time"}),
            "heure_fin": forms.TimeInput(attrs={"type": "time"}),
            "date_debut": forms.DateInput(attrs={"type": "date"}),
            "date_fin": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, tenant, institution, acteur, **kwargs):
        kwargs.setdefault(
            "instance",
            CreneauHoraire(tenant=tenant, institution=institution, cree_par=acteur),
        )
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["affectation"].queryset = AffectationEnseignement.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        ).select_related("cours", "groupe")
        self.fields["affectation"].label_from_instance = lambda item: (
            f"{item.cours.nom} — {item.groupe.nom}"
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        if self.errors:
            return cleaned_data
        candidat = CreneauHoraire(
            tenant=self.instance.tenant,
            institution=self.instance.institution,
            cree_par=self.instance.cree_par,
            cle_idempotence=cleaned_data["cle_idempotence"],
            **{
                field: value
                for field, value in cleaned_data.items()
                if field != "cle_idempotence"
            },
        )
        _valider_objet(candidat, self)
        return cleaned_data


class FormulaireSeance(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    creneau = forms.ModelChoiceField(
        queryset=CreneauHoraire.objects.none(),
        label="Créneau horaire",
    )
    date = forms.DateField(
        label="Date de la séance",
        widget=forms.DateInput(attrs={"type": "date"}),
    )

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["creneau"].queryset = CreneauHoraire.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
            affectation__actif=True,
        ).select_related("affectation__cours", "affectation__groupe")
        self.fields["creneau"].label_from_instance = lambda item: (
            f"{item.get_jour_semaine_display()} {item.heure_debut:%H:%M} — "
            f"{item.affectation.cours.nom}, {item.affectation.groupe.nom}"
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class FormulaireActivation(forms.Form):
    actif = forms.BooleanField(required=False)


class FormulaireStatutSeance(forms.Form):
    statut = forms.ChoiceField(
        choices=(
            (StatutSeance.ANNULEE, "Annulée"),
            (StatutSeance.TERMINEE, "Terminée"),
        ),
    )


def _valider_objet(objet, formulaire):
    try:
        objet.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
    except ValidationError as error:
        erreurs = getattr(error, "message_dict", None)
        if erreurs:
            for champ, messages_erreur in erreurs.items():
                formulaire.add_error(
                    champ if champ in formulaire.fields else None,
                    messages_erreur,
                )
        else:
            formulaire.add_error(None, error.messages)
