"""Fixtures partagées entre les parcours HTML des domaines éducatifs."""

import uuid
from datetime import date

from django.contrib.auth import get_user_model
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.admissions.models import Candidature, StatutCandidature
from applications.emplois_temps.models import AffectationEnseignement
from applications.inscriptions.models import Inscription
from applications.organisations.models import AdhesionTenant, RoleAdhesion, StatutAdhesion
from applications.organisations.services import provisionner_tenant
from applications.personnes.models import Personne, ProfilApprenant, ProfilEnseignant
from applications.referentiels.models import (
    AnneeAcademique,
    Cours,
    Groupe,
    Institution,
    Programme,
)


def _creer_utilisateur(email):
    return get_user_model().objects.create_user(email, "mot-de-passe-solide")


def _preparer_tenant(prefixe):
    proprietaire = _creer_utilisateur(f"{prefixe}-manager@example.org")
    tenant, _, _ = provisionner_tenant(
        createur=proprietaire,
        nom=f"Établissement {prefixe}",
        cle_idempotence=uuid.uuid4(),
    )
    rendre_tenant_abonne(tenant, proprietaire)
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=f"Institution {prefixe}",
        type_educatif="ecole",
        cree_par=proprietaire,
    )
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        nom="2026-2027",
        debut=date(2026, 9, 1),
        fin=date(2027, 6, 30),
    )
    programme = Programme.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        code=f"programme-{prefixe}",
        nom=f"Programme {prefixe}",
    )
    cours = Cours.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        code=f"mathematiques-{prefixe}",
        nom="Mathématiques",
    )
    groupe = Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        annee_academique=annee,
        programme=programme,
        code=f"groupe-{prefixe}",
        nom=f"Groupe {prefixe}",
    )
    compte_enseignant = _creer_utilisateur(f"{prefixe}-teacher@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=compte_enseignant,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    personne_enseignant = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        prenom="Ari",
        nom="Enseignant",
        identifiant_externe=f"PROF-{prefixe}",
    )
    profil = ProfilEnseignant.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        personne=personne_enseignant,
        compte=compte_enseignant,
    )
    return {
        "tenant": tenant,
        "institution": institution,
        "annee": annee,
        "programme": programme,
        "cours": cours,
        "groupe": groupe,
        "proprietaire": proprietaire,
        "enseignant": {"compte": compte_enseignant},
        "profil": profil,
    }


def _creer_affectation(contexte, *, profil=None, cours=None, cle=None):
    affectation, _ = AffectationEnseignement.objects.get_or_create(
        cle_idempotence=cle or uuid.uuid4(),
        defaults={
            "tenant": contexte["tenant"],
            "institution": contexte["institution"],
            "cree_par": contexte["proprietaire"],
            "enseignant": profil or contexte["profil"],
            "annee_academique": contexte["annee"],
            "groupe": contexte["groupe"],
            "cours": cours or contexte["cours"],
            "date_debut": date(2026, 9, 1),
            "date_fin": date(2027, 6, 30),
        },
    )
    return affectation


def _creer_inscription(contexte):
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        prenom="Mika",
        nom="Apprenant",
        identifiant_externe=f"EL-{contexte['tenant'].pk.hex[:8]}",
    )
    apprenant = ProfilApprenant.objects.create(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        personne=personne,
    )
    candidature = Candidature.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        reference=f"CAND-{uuid.uuid4().hex[:8]}",
        personne=personne,
        annee_academique=contexte["annee"],
        programme=contexte["programme"],
        statut=StatutCandidature.ADMISE,
        decidee_par=contexte["proprietaire"],
        decidee_le=timezone.now(),
    )
    return Inscription.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        candidature=candidature,
        apprenant=apprenant,
        annee_academique=contexte["annee"],
        programme=contexte["programme"],
        groupe=contexte["groupe"],
        date_debut=date(2026, 9, 1),
    )
