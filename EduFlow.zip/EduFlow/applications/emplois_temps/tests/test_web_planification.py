"""Tests des parcours HTML de planification et de saisie des présences."""

import uuid
from datetime import date, time

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.emplois_temps.models import (
    AffectationEnseignement,
    CreneauHoraire,
    Seance,
)
from applications.emplois_temps.tests.factories import (
    _creer_affectation,
    _creer_inscription,
    _preparer_tenant,
)
from applications.organisations.models import EvenementAudit
from applications.presences.models import HistoriquePresence, Presence, StatutPresence

pytestmark = pytest.mark.django_db


def _client_web(utilisateur, tenant):
    if utilisateur.email_verifie_le is None:
        utilisateur.email_verifie_le = timezone.now()
        utilisateur.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(utilisateur)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    return client


def test_manager_creates_assignment_slot_and_session_with_html_forms():
    contexte = _preparer_tenant("planning-web")
    client = _client_web(contexte["proprietaire"], contexte["tenant"])
    url = reverse("emplois_temps_web:gestion")
    cle_affectation = uuid.uuid4()

    page = client.get(url)
    affectation_response = client.post(
        url,
        {
            "action": "affectation",
            "cle_idempotence": str(cle_affectation),
            "enseignant": str(contexte["profil"].pk),
            "annee_academique": str(contexte["annee"].pk),
            "groupe": str(contexte["groupe"].pk),
            "cours": str(contexte["cours"].pk),
            "date_debut": "2026-09-01",
            "date_fin": "2027-06-30",
        },
    )
    affectation = AffectationEnseignement.objects.get(
        cle_idempotence=cle_affectation,
    )
    creneau_response = client.post(
        url,
        {
            "action": "creneau",
            "cle_idempotence": str(uuid.uuid4()),
            "affectation": str(affectation.pk),
            "jour_semaine": "lundi",
            "heure_debut": "08:00",
            "heure_fin": "09:00",
            "date_debut": "2026-09-01",
            "date_fin": "2027-06-30",
            "salle": "Salle 1",
        },
    )
    creneau = CreneauHoraire.objects.get(affectation=affectation)
    seance_response = client.post(
        url,
        {
            "action": "seance",
            "cle_idempotence": str(uuid.uuid4()),
            "creneau": str(creneau.pk),
            "date": "2026-09-07",
        },
    )
    seance = Seance.objects.get(creneau=creneau)

    assert page.status_code == 200
    assert affectation_response.status_code == 302
    assert creneau_response.status_code == 302
    assert seance_response.status_code == 302
    assert seance.date == date(2026, 9, 7)
    assert seance.heure_debut == time(8, 0)
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="emploi_temps.seance_creee",
        id_objet=str(seance.pk),
    ).exists()


def test_assigned_teacher_records_presence_and_audited_correction():
    contexte = _preparer_tenant("presence-web")
    affectation = _creer_affectation(contexte)
    creneau = CreneauHoraire.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        affectation=affectation,
        jour_semaine="lundi",
        heure_debut=time(8, 0),
        heure_fin=time(9, 0),
        date_debut=date(2026, 9, 1),
        date_fin=date(2027, 6, 30),
        salle="Salle 1",
    )
    seance = Seance.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        creneau=creneau,
        date=date(2026, 9, 7),
        heure_debut=creneau.heure_debut,
        heure_fin=creneau.heure_fin,
        salle=creneau.salle,
    )
    inscription = _creer_inscription(contexte)
    client = _client_web(contexte["enseignant"]["compte"], contexte["tenant"])
    url = reverse("tableau_de_bord:feuille-presence", args=(seance.pk,))

    roster = client.get(url)
    presence_response = client.post(
        url,
        {
            "presences-TOTAL_FORMS": "1",
            "presences-INITIAL_FORMS": "1",
            "presences-MIN_NUM_FORMS": "0",
            "presences-MAX_NUM_FORMS": "1000",
            "presences-0-inscription_id": str(inscription.pk),
            "presences-0-statut": StatutPresence.PRESENTE,
            "presences-0-motif_correction": "",
        },
    )
    presence = Presence.objects.get(seance=seance, inscription=inscription)
    correction = client.post(
        url,
        {
            "presences-TOTAL_FORMS": "1",
            "presences-INITIAL_FORMS": "1",
            "presences-MIN_NUM_FORMS": "0",
            "presences-MAX_NUM_FORMS": "1000",
            "presences-0-inscription_id": str(inscription.pk),
            "presences-0-statut": StatutPresence.ABSENTE,
            "presences-0-motif_correction": "Correction du relevé.",
        },
    )

    presence.refresh_from_db()
    assert roster.status_code == 200
    assert presence_response.status_code == 302
    assert correction.status_code == 302
    assert presence.statut == StatutPresence.ABSENTE
    assert HistoriquePresence.objects.filter(
        presence=presence,
        motif_correction="Correction du relevé.",
    ).exists()
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="presence.presence_corrigee",
        id_objet=str(presence.pk),
    ).exists()
