"""Affectations pédagogiques, horaires récurrents et séances datées."""

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.personnes.models import ObjetEducatifTenant, ProfilEnseignant
from applications.referentiels.models import AnneeAcademique, Cours, Groupe


class JourSemaine(models.TextChoices):
    LUNDI = "lundi", "Lundi"
    MARDI = "mardi", "Mardi"
    MERCREDI = "mercredi", "Mercredi"
    JEUDI = "jeudi", "Jeudi"
    VENDREDI = "vendredi", "Vendredi"
    SAMEDI = "samedi", "Samedi"
    DIMANCHE = "dimanche", "Dimanche"


class StatutSeance(models.TextChoices):
    PLANIFIEE = "planifiee", "Planifiée"
    ANNULEE = "annulee", "Annulée"
    TERMINEE = "terminee", "Terminée"


class AffectationEnseignement(ObjetEducatifTenant):
    """Affectation d’un enseignant à un cours et un groupe pour une période."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    enseignant = models.ForeignKey(
        ProfilEnseignant,
        on_delete=models.PROTECT,
        related_name="affectations",
    )
    annee_academique = models.ForeignKey(
        AnneeAcademique,
        on_delete=models.PROTECT,
        related_name="affectations_enseignement",
    )
    groupe = models.ForeignKey(
        Groupe,
        on_delete=models.PROTECT,
        related_name="affectations_enseignement",
    )
    cours = models.ForeignKey(
        Cours,
        on_delete=models.PROTECT,
        related_name="affectations_enseignement",
    )
    date_debut = models.DateField()
    date_fin = models.DateField()
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("date_debut", "groupe__nom", "cours__nom")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "enseignant", "annee_academique", "groupe", "cours"),
                name="affectation_enseignant_unique",
            ),
            models.CheckConstraint(
                condition=Q(date_fin__gte=models.F("date_debut")),
                name="affectation_dates_valides",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "enseignant", "actif"),
                name="affectation_tenant_ens_idx",
            ),
            models.Index(
                fields=("tenant", "groupe", "cours"),
                name="affectation_tenant_groupe_idx",
            ),
        ]
        verbose_name = "affectation pédagogique"
        verbose_name_plural = "affectations pédagogiques"

    def __str__(self) -> str:
        return f"{self.enseignant} — {self.cours} — {self.groupe}"

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("enseignant", self.enseignant if self.enseignant_id else None),
            ("annee_academique", self.annee_academique if self.annee_academique_id else None),
            ("groupe", self.groupe if self.groupe_id else None),
            ("cours", self.cours if self.cours_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if self.enseignant_id and not self.enseignant.actif:
            erreurs["enseignant"] = (
                "Un profil enseignant inactif ne peut pas recevoir d’affectation."
            )
        if self.groupe_id and not self.groupe.actif:
            erreurs["groupe"] = "Un groupe inactif ne peut pas recevoir d’affectation."
        if self.cours_id and not self.cours.actif:
            erreurs["cours"] = "Un cours inactif ne peut pas recevoir d’affectation."
        if self.annee_academique_id and self.groupe_id:
            if self.groupe.annee_academique_id != self.annee_academique_id:
                erreurs["groupe"] = "Le groupe doit appartenir à l’année sélectionnée."
        if self.annee_academique_id:
            if self.date_debut and self.date_debut < self.annee_academique.debut:
                erreurs["date_debut"] = "L’affectation doit commencer pendant l’année académique."
            if self.date_fin and self.date_fin > self.annee_academique.fin:
                erreurs["date_fin"] = "L’affectation doit finir pendant l’année académique."
        if self.date_debut and self.date_fin and self.date_fin < self.date_debut:
            erreurs["date_fin"] = "La fin doit être postérieure ou égale au début."
        if erreurs:
            raise ValidationError(erreurs)


class CreneauHoraire(ObjetEducatifTenant):
    """Créneau hebdomadaire récurrent au sein d’une affectation."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    affectation = models.ForeignKey(
        AffectationEnseignement,
        on_delete=models.PROTECT,
        related_name="creneaux",
    )
    jour_semaine = models.CharField(max_length=10, choices=JourSemaine.choices)
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    date_debut = models.DateField()
    date_fin = models.DateField()
    salle = models.CharField(max_length=100, blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("jour_semaine", "heure_debut", "salle")
        constraints = [
            models.CheckConstraint(
                condition=Q(heure_fin__gt=models.F("heure_debut")),
                name="creneau_heures_valides",
            ),
            models.CheckConstraint(
                condition=Q(date_fin__gte=models.F("date_debut")),
                name="creneau_dates_valides",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "jour_semaine", "heure_debut"),
                name="creneau_tenant_jour_idx",
            ),
        ]
        verbose_name = "créneau horaire"
        verbose_name_plural = "créneaux horaires"

    def __str__(self) -> str:
        return f"{self.get_jour_semaine_display()} {self.heure_debut}–{self.heure_fin}"

    def clean(self):
        super().clean()
        if self.affectation_id and (
            self.affectation.tenant_id != self.tenant_id
            or self.affectation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"affectation": "L’affectation doit appartenir au même tenant."}
            )
        if self.affectation_id and self.date_debut and self.date_fin:
            if (
                self.date_debut < self.affectation.date_debut
                or self.date_fin > self.affectation.date_fin
            ):
                raise ValidationError(
                    {"date_debut": "Le créneau doit rester dans les dates de l’affectation."}
                )
        if self.heure_debut and self.heure_fin and self.heure_fin <= self.heure_debut:
            raise ValidationError({"heure_fin": "La fin doit suivre le début."})
        if self.date_debut and self.date_fin and self.date_fin < self.date_debut:
            raise ValidationError({"date_fin": "La fin doit suivre ou égaler le début."})


class Seance(ObjetEducatifTenant):
    """Occurrence datée d’un créneau; ses heures sont figées à la création."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    creneau = models.ForeignKey(
        CreneauHoraire,
        on_delete=models.PROTECT,
        related_name="seances",
    )
    date = models.DateField()
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    salle = models.CharField(max_length=100, blank=True)
    statut = models.CharField(
        max_length=10,
        choices=StatutSeance.choices,
        default=StatutSeance.PLANIFIEE,
    )

    class Meta:
        ordering = ("date", "heure_debut")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "creneau", "date"),
                name="seance_creneau_date_unique",
            ),
            models.CheckConstraint(
                condition=Q(heure_fin__gt=models.F("heure_debut")),
                name="seance_heures_valides",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutSeance.values),
                name="seance_statut_valide",
            ),
        ]
        indexes = [
            models.Index(fields=("tenant", "date", "statut"), name="seance_tenant_date_idx"),
        ]
        verbose_name = "séance"
        verbose_name_plural = "séances"

    def __str__(self) -> str:
        return f"{self.creneau.affectation.cours} — {self.date}"

    def clean(self):
        super().clean()
        if self.creneau_id and (
            self.creneau.tenant_id != self.tenant_id
            or self.creneau.institution_id != self.institution_id
        ):
            raise ValidationError({"creneau": "Le créneau doit appartenir au même tenant."})
        if self.creneau_id and self.date:
            if not self.creneau.date_debut <= self.date <= self.creneau.date_fin:
                raise ValidationError({"date": "La date doit appartenir à la période du créneau."})
            jour = _JOURS_SHEMAINE[self.date.weekday()]
            if jour != self.creneau.jour_semaine:
                raise ValidationError({"date": "La date ne correspond pas au jour du créneau."})
        if self.heure_debut and self.heure_fin and self.heure_fin <= self.heure_debut:
            raise ValidationError({"heure_fin": "La fin doit suivre le début."})


_JOURS_SHEMAINE = (
    JourSemaine.LUNDI,
    JourSemaine.MARDI,
    JourSemaine.MERCREDI,
    JourSemaine.JEUDI,
    JourSemaine.VENDREDI,
    JourSemaine.SAMEDI,
    JourSemaine.DIMANCHE,
)
