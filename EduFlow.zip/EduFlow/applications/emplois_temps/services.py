"""Transactions des affectations pédagogiques et séances."""

import uuid

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from applications.emplois_temps.models import (
    AffectationEnseignement,
    CreneauHoraire,
    Seance,
    StatutSeance,
)
from applications.organisations.models import EvenementAudit, Tenant


class ConflitPlanification(Exception):
    """Une clé idempotente ou une ressource de planification est en conflit."""


def _journaliser(*, tenant, acteur, objet, action: str, champs: list[str]) -> None:
    EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=f"emploi_temps.{action}",
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        details={"champs": sorted(champs)},
    )


def _correspond(existant, candidat) -> bool:
    return (
        existant.tenant_id == candidat.tenant_id
        and existant.institution_id == candidat.institution_id
        and existant.cree_par_id == candidat.cree_par_id
        and all(
            getattr(existant, champ.attname) == getattr(candidat, champ.attname)
            for champ in candidat._meta.concrete_fields
            if champ.name
            not in {
                "id",
                "cle_idempotence",
                "tenant",
                "institution",
                "cree_par",
                "cree_le",
                "modifie_le",
            }
        )
    )


def _creer_objet(*, objet, acteur, action: str):
    objet.full_clean(
        exclude=("cle_idempotence",),
        validate_unique=False,
        validate_constraints=False,
    )
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=objet.tenant_id)
        existant = type(objet).objects.filter(
            cle_idempotence=objet.cle_idempotence
        ).first()
        if existant is not None:
            if _correspond(existant, objet):
                return existant, False
            raise ConflitPlanification
        try:
            with transaction.atomic():
                objet.save(force_insert=True)
        except IntegrityError as error:
            existant = type(objet).objects.filter(
                cle_idempotence=objet.cle_idempotence
            ).first()
            if existant is not None and _correspond(existant, objet):
                return existant, False
            raise ConflitPlanification from error
        _journaliser(
            tenant=objet.tenant,
            acteur=acteur,
            objet=objet,
            action=action,
            champs=[
                champ.name
                for champ in objet._meta.concrete_fields
                if champ.name
                not in {
                    "id",
                    "cle_idempotence",
                    "tenant",
                    "institution",
                    "cree_par",
                    "cree_le",
                    "modifie_le",
                }
            ],
        )
        return objet, True


def creer_affectation(
    *,
    tenant,
    institution,
    acteur,
    valeurs: dict,
    cle_idempotence: uuid.UUID,
):
    affectation = AffectationEnseignement(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        cle_idempotence=cle_idempotence,
        **valeurs,
    )
    return _creer_objet(objet=affectation, acteur=acteur, action="affectation_creee")


def _chevauchement_creneau(creneau: CreneauHoraire) -> bool:
    candidats = CreneauHoraire.objects.filter(
        tenant=creneau.tenant,
        actif=True,
        jour_semaine=creneau.jour_semaine,
        date_debut__lte=creneau.date_fin,
        date_fin__gte=creneau.date_debut,
        heure_debut__lt=creneau.heure_fin,
        heure_fin__gt=creneau.heure_debut,
    ).exclude(pk=creneau.pk).select_related("affectation__groupe")
    for existant in candidats:
        meme_enseignant = (
            existant.affectation.enseignant_id == creneau.affectation.enseignant_id
        )
        meme_groupe = existant.affectation.groupe_id == creneau.affectation.groupe_id
        meme_salle_meme_campus = (
            creneau.salle.strip()
            and existant.affectation.groupe.campus_id
            == creneau.affectation.groupe.campus_id
            and existant.salle.strip().casefold() == creneau.salle.strip().casefold()
        )
        if meme_enseignant or meme_groupe or meme_salle_meme_campus:
            return True
    return False


def creer_creneau(
    *,
    tenant,
    institution,
    acteur,
    valeurs: dict,
    cle_idempotence: uuid.UUID,
):
    creneau = CreneauHoraire(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        cle_idempotence=cle_idempotence,
        **valeurs,
    )
    creneau.full_clean(
        exclude=("cle_idempotence",),
        validate_unique=False,
        validate_constraints=False,
    )
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = CreneauHoraire.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if _correspond(existant, creneau):
                return existant, False
            raise ConflitPlanification
        if _chevauchement_creneau(creneau):
            raise ValidationError(
                {
                    "heure_debut": (
                        "Le créneau chevauche un horaire du même enseignant, groupe ou salle."
                    )
                }
            )
        try:
            creneau.save(force_insert=True)
        except IntegrityError as error:
            existant = CreneauHoraire.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existant is not None and _correspond(existant, creneau):
                return existant, False
            raise ConflitPlanification from error
        _journaliser(
            tenant=tenant,
            acteur=acteur,
            objet=creneau,
            action="creneau_cree",
            champs=["affectation", "jour_semaine", "heure_debut", "heure_fin", "salle"],
        )
        return creneau, True


def creer_seance(
    *,
    tenant,
    institution,
    acteur,
    creneau: CreneauHoraire,
    date,
    cle_idempotence: uuid.UUID,
):
    if not creneau.actif or not creneau.affectation.actif:
        raise ValidationError(
            "Un créneau ou une affectation inactive ne peut pas produire de séance."
        )
    seance = Seance(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        cle_idempotence=cle_idempotence,
        creneau=creneau,
        date=date,
        heure_debut=creneau.heure_debut,
        heure_fin=creneau.heure_fin,
        salle=creneau.salle,
    )
    return _creer_objet(objet=seance, acteur=acteur, action="seance_creee")


def modifier_activation(*, objet, acteur, actif: bool):
    with transaction.atomic():
        objet = type(objet).objects.select_for_update().get(
            pk=objet.pk,
            tenant_id=objet.tenant_id,
        )
        if objet.actif != actif:
            objet.actif = actif
            objet.save(update_fields=("actif", "modifie_le"))
            _journaliser(
                tenant=objet.tenant,
                acteur=acteur,
                objet=objet,
                action="ressource_modifiee",
                champs=["actif"],
            )
        return objet


def transitionner_seance(*, seance: Seance, acteur, nouveau_statut: str) -> Seance:
    with transaction.atomic():
        seance = Seance.objects.select_for_update().get(
            pk=seance.pk,
            tenant_id=seance.tenant_id,
        )
        if nouveau_statut == seance.statut:
            return seance
        if seance.statut != StatutSeance.PLANIFIEE or nouveau_statut not in (
            StatutSeance.ANNULEE,
            StatutSeance.TERMINEE,
        ):
            raise ValidationError("Cette transition de séance n’est pas autorisée.")
        if nouveau_statut == StatutSeance.ANNULEE and seance.presences.exists():
            raise ValidationError("Une séance avec des présences saisies ne peut pas être annulée.")
        seance.statut = nouveau_statut
        seance.save(update_fields=("statut", "modifie_le"))
        _journaliser(
            tenant=seance.tenant,
            acteur=acteur,
            objet=seance,
            action="seance_statut_modifie",
            champs=["statut"],
        )
        return seance
