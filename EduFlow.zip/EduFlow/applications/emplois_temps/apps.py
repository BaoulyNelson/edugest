"""Configuration des affectations et emplois du temps."""

from django.apps import AppConfig


class EmploisTempsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.emplois_temps"
    label = "emplois_temps"
    verbose_name = "Emplois du temps"
