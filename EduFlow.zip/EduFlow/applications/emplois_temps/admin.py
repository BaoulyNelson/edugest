from django.contrib import admin

from applications.emplois_temps.models import AffectationEnseignement, CreneauHoraire, Seance

admin.site.register((AffectationEnseignement, CreneauHoraire, Seance))
