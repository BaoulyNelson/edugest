"""Vues HTML de l’espace de travail EduFlow."""

import calendar
import csv
import io
from datetime import date, timedelta
from functools import wraps

from django.contrib import admin, messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import (
    PermissionDenied as DjangoPermissionDenied,
)
from django.core.exceptions import (
    ValidationError,
)
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Avg, Count, DateTimeField, Prefetch, Q, Window
from django.db.models.functions import RowNumber
from django.http import Http404, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import urlencode
from django.utils.translation import gettext as _
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from applications.abonnements.access import utilisateur_peut_gerer_abonnements_saas
from applications.abonnements.models import (
    Abonnement,
    EvenementPaiement,
    PlanSaaS,
    StatutAbonnement,
    StatutEvenementPaiement,
    TypeEvenementPaiement,
)
from applications.abonnements.services import journaliser_lecture_operateur
from applications.admissions.forms import (
    TRANSITIONS_CANDIDATURE_WEB,
    CandidatureCreationForm,
    CandidatureImportForm,
    CandidatureModificationForm,
    TransitionCandidatureForm,
)
from applications.admissions.imports import (
    ErreurImportCandidatures,
    importer_candidatures_csv,
)
from applications.admissions.models import Candidature, StatutCandidature
from applications.admissions.services import (
    ConflitIdempotenceAdmission,
    ConflitIdentifiantExterneAdmission,
    modifier_candidature_brouillon,
    transitionner_candidature,
)
from applications.admissions.services import (
    creer_candidature as creer_candidature_service,
)
from applications.emplois_temps.models import (
    AffectationEnseignement,
    Seance,
    StatutSeance,
)
from applications.evaluations.models import Evaluation, StatutEvaluation
from applications.inscriptions.models import Inscription, StatutInscription
from applications.notifications.models import Notification
from applications.organisations.access import resoudre_adhesion_active
from applications.organisations.models import (
    AdhesionTenant,
    DemandeInscriptionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
    StatutDemandeInscription,
    StatutTenant,
    Tenant,
)
from applications.pedagogie.models import (
    Devoir,
    PlanCours,
    Quiz,
    RessourcePedagogique,
)
from applications.personnes.forms import FormulaireLienCompteApprenant
from applications.personnes.models import ProfilApprenant, ProfilEnseignant
from applications.presences.forms import FiltreDatePresenceForm, PresenceFeuilleFormSet
from applications.presences.models import HistoriquePresence, Presence, StatutPresence
from applications.presences.services import enregistrer_presence
from applications.referentiels.models import (
    AnneeAcademique,
    FormatDate,
    Groupe,
    StatutAnneeAcademique,
)
from applications.referentiels.services import modifier_referentiel
from applications.tableau_de_bord.forms import FormulaireParametresEtablissement

SESSION_TENANT_KEY = "eduflow_tenant_actif"
ROLES_GESTION = {
    RoleAdhesion.PROPRIETAIRE,
    RoleAdhesion.ADMINISTRATEUR,
    RoleAdhesion.GESTIONNAIRE,
}
FORMATS_DATES = {
    FormatDate.JOUR_MOIS_ANNEE: "d/m/Y",
    FormatDate.ANNEE_MOIS_JOUR: "Y-m-d",
    FormatDate.MOIS_JOUR_ANNEE: "m/d/Y",
}


def _adhesions_disponibles(user):
    adhesions = list(
        AdhesionTenant.objects.filter(
            utilisateur=user,
            statut=StatutAdhesion.ACTIVE,
            tenant__statut__in=(StatutTenant.ACTIF, StatutTenant.RESTREINT),
            tenant__institution__isnull=False,
        )
        .select_related("tenant", "tenant__institution")
        .prefetch_related(
            Prefetch(
                "tenant__anneeacademiques",
                queryset=AnneeAcademique.objects.filter(
                    statut=StatutAnneeAcademique.ACTIVE,
                ),
                to_attr="annees_actives",
            )
        )
        .order_by("tenant__institution__nom", "tenant__nom")
    )
    for adhesion in adhesions:
        annees_actives = adhesion.tenant.annees_actives
        adhesion.annee_academique_active = annees_actives[0] if annees_actives else None
    return adhesions


def _contexte_espace(request):
    adhesions = _adhesions_disponibles(request.user)
    tenant_en_provisionnement = (
        AdhesionTenant.objects.filter(
            utilisateur=request.user,
            statut=StatutAdhesion.ACTIVE,
            role=RoleAdhesion.PROPRIETAIRE,
            tenant__statut=StatutTenant.PROVISIONNEMENT,
            tenant__demande_inscription__isnull=False,
        )
        .select_related("tenant", "tenant__institution", "tenant__demande_inscription__plan")
        .first()
    )
    tenant_id = request.session.get(SESSION_TENANT_KEY)
    adhesion = next(
        (item for item in adhesions if str(item.tenant_id) == str(tenant_id)),
        None,
    )
    if tenant_id and adhesion is None:
        request.session.pop(SESSION_TENANT_KEY, None)

    if adhesion is None and len(adhesions) == 1:
        adhesion = adhesions[0]
        request.session[SESSION_TENANT_KEY] = str(adhesion.tenant_id)

    acces_autorise = False
    if adhesion is not None:
        try:
            resoudre_adhesion_active(
                request.user,
                str(adhesion.tenant_id),
            )
        except DjangoPermissionDenied:
            pass
        else:
            acces_autorise = True
    profil_apprenant = None
    if adhesion is not None and acces_autorise:
        profil_apprenant = (
            ProfilApprenant.objects.filter(
                tenant=adhesion.tenant,
                institution=adhesion.tenant.institution,
                compte=request.user,
            )
            .select_related("personne")
            .first()
        )

    return {
        "adhesions": adhesions,
        "tenant_en_provisionnement": tenant_en_provisionnement,
        "workspace": adhesion,
        "workspace_accessible": acces_autorise,
        "role_gestion": adhesion is not None and adhesion.role in ROLES_GESTION,
        "role_gestion_pedagogique": (
            adhesion is not None
            and adhesion.role in ROLES_GESTION
            and (adhesion.role != RoleAdhesion.PROPRIETAIRE or request.user.is_superuser)
        ),
        "role_enseignant": (adhesion is not None and adhesion.role == RoleAdhesion.ENSEIGNANT),
        "profil_apprenant": profil_apprenant,
        "format_date": (
            FORMATS_DATES[adhesion.tenant.institution.format_date]
            if adhesion is not None
            else FORMATS_DATES[FormatDate.JOUR_MOIS_ANNEE]
        ),
    }


def _changer_espace(request, adhesions):
    tenant_id = request.POST.get("tenant_id", "")
    adhesion = next(
        (item for item in adhesions if str(item.tenant_id) == tenant_id),
        None,
    )
    if adhesion is None:
        raise Http404

    request.session[SESSION_TENANT_KEY] = str(adhesion.tenant_id)
    try:
        resoudre_adhesion_active(request.user, str(adhesion.tenant_id))
    except DjangoPermissionDenied:
        messages.warning(
            request,
            _("Cet établissement n’a pas d’abonnement actif. Les données restent indisponibles."),
        )
    else:
        messages.success(
            request,
            _("Établissement actif : %(name)s.") % {"name": adhesion.tenant.institution.nom},
        )
    return redirect("tableau_de_bord:accueil")


def _exiger_espace(request):
    contexte = _contexte_espace(request)
    if contexte["workspace"] is None:
        messages.info(request, _("Choisissez un établissement pour continuer."))
        return None, contexte
    if not contexte["workspace_accessible"]:
        raise DjangoPermissionDenied(
            _("Aucun abonnement actif ne permet d’accéder à cet établissement.")
        )
    return contexte["workspace"], contexte


def _paginate(queryset, request):
    return Paginator(queryset, 25).get_page(request.GET.get("page"))


def _page_privee(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        response = view(request, *args, **kwargs)
        response.headers["Cache-Control"] = "private, no-store"
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
        return response

    return wrapper


def _recherche(queryset, request, champs):
    terme = request.GET.get("q", "").strip()
    if terme:
        filtre = Q()
        for champ in champs:
            filtre |= Q(**{f"{champ}__icontains": terme})
        queryset = queryset.filter(filtre)
    return queryset, terme


def _candidatures_filtrees(workspace, request):
    queryset = Candidature.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    ).select_related("personne", "programme", "annee_academique")
    statut = request.GET.get("statut", "").strip()
    if statut in StatutCandidature.values:
        queryset = queryset.filter(statut=statut)
    queryset, terme = _recherche(
        queryset,
        request,
        ("reference", "personne__nom", "personne__prenom"),
    )
    return queryset, terme, statut if statut in StatutCandidature.values else ""


def _cellule_csv(valeur):
    texte = str(valeur or "")
    if texte.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return f"'{texte}"
    return texte


def _contexte_tableau_bord_operateur(request):
    journaliser_lecture_operateur(
        acteur=request.user,
        action="tableau_de_bord",
    )
    maintenant = timezone.now()
    return {
        "plateforme_operateur": True,
        "nombre_tenants": Tenant.objects.count(),
        "tenants_actifs": Tenant.objects.filter(statut=StatutTenant.ACTIF).count(),
        "demandes_en_attente": DemandeInscriptionTenant.objects.filter(
            statut=StatutDemandeInscription.EN_ATTENTE,
        ).count(),
        "abonnements_actifs": Abonnement.objects.filter(
            statut=StatutAbonnement.ACTIF,
            commence_le__lte=maintenant,
            termine_le__gt=maintenant,
        ).count(),
        "abonnements_en_attente": Abonnement.objects.filter(
            statut=StatutAbonnement.EN_ATTENTE,
        ).count(),
        "paiements_a_decider": EvenementPaiement.objects.filter(
            type_evenement=TypeEvenementPaiement.PAIEMENT,
            statut=StatutEvenementPaiement.ENREGISTRE,
        ).count(),
        "plans_actifs": PlanSaaS.objects.filter(actif=True).count(),
        "tenants_recents": Tenant.objects.order_by("-cree_le")[:5],
        "demandes_accessibles": request.user.has_perm(
            "organisations.traiter_demande_inscription_tenant",
        ),
    }


def _catalogue_admin_superuser(request):
    catalogue = []
    nombre_modeles = 0
    champs_recents = (
        "cree_le",
        "created_at",
        "date_joined",
        "modifie_le",
        "updated_at",
    )

    for application in admin.site.get_app_list(request):
        modeles = []
        for entree in application["models"]:
            modele = entree["model"]
            administration = admin.site._registry[modele]
            queryset = administration.get_queryset(request)
            champ_recent = next(
                (
                    champ
                    for nom in champs_recents
                    for champ in modele._meta.concrete_fields
                    if champ.name == nom and isinstance(champ, DateTimeField)
                ),
                None,
            )
            ordre_recent = [f"-{champ_recent.name}", "-pk"] if champ_recent else ["-pk"]
            elements_recents = list(
                queryset.order_by(*ordre_recent)
                .annotate(
                    _nombre_total=Window(expression=Count("pk")),
                    _position_recente=Window(
                        expression=RowNumber(),
                        order_by=ordre_recent,
                    ),
                )
                .filter(_position_recente__lte=3)
            )
            modeles.append(
                {
                    "nom": entree["name"],
                    "url": entree["admin_url"],
                    "nombre": elements_recents[0]._nombre_total if elements_recents else 0,
                    "elements_recents": elements_recents,
                },
            )
            nombre_modeles += 1
        catalogue.append(
            {
                "nom": application["name"],
                "modeles": modeles,
            },
        )

    return catalogue, nombre_modeles


def _calendrier_dashboard(aujourd_hui, jours_avec_seance):
    calendrier = calendar.Calendar(firstweekday=calendar.MONDAY)
    semaines = []
    for semaine in calendrier.monthdayscalendar(aujourd_hui.year, aujourd_hui.month):
        semaines.append(
            [
                {
                    "jour": jour,
                    "aujourd_hui": jour == aujourd_hui.day,
                    "a_seance": (
                        jour > 0
                        and date(aujourd_hui.year, aujourd_hui.month, jour) in jours_avec_seance
                    ),
                }
                for jour in semaine
            ]
        )
    return semaines


def _contexte_dashboard_etablissement(
    tenant,
    institution,
    profil_enseignant,
    profil_apprenant=None,
):
    with timezone.override(institution.fuseau_horaire):
        aujourd_hui = timezone.localdate()
    premier_jour = aujourd_hui.replace(day=1)
    dernier_jour = aujourd_hui.replace(
        day=calendar.monthrange(aujourd_hui.year, aujourd_hui.month)[1]
    )
    seances = Seance.objects.filter(
        tenant=tenant,
        institution=institution,
        date__gte=premier_jour,
        date__lte=dernier_jour,
        statut=StatutSeance.PLANIFIEE,
    ).select_related(
        "creneau__affectation__cours",
        "creneau__affectation__groupe",
    )
    if profil_enseignant:
        seances = seances.filter(
            creneau__affectation__enseignant=profil_enseignant,
            creneau__affectation__actif=True,
        )
    elif profil_apprenant:
        groupes = Inscription.objects.filter(
            tenant=tenant,
            institution=institution,
            apprenant=profil_apprenant,
            statut=StatutInscription.ACTIVE,
            groupe__isnull=False,
        ).values("groupe_id")
        seances = seances.filter(
            creneau__affectation__groupe_id__in=groupes,
            creneau__affectation__actif=True,
            creneau__affectation__enseignant__actif=True,
        )
    seances = list(seances.order_by("date", "heure_debut"))
    seances_du_jour = [seance for seance in seances if seance.date == aujourd_hui]
    seances_a_venir_queryset = Seance.objects.filter(
        tenant=tenant,
        institution=institution,
        date__gte=aujourd_hui,
        date__lte=aujourd_hui + timedelta(days=14),
        statut=StatutSeance.PLANIFIEE,
    ).select_related(
        "creneau__affectation__cours",
        "creneau__affectation__groupe",
    )
    if profil_enseignant:
        seances_a_venir_queryset = seances_a_venir_queryset.filter(
            creneau__affectation__enseignant=profil_enseignant,
            creneau__affectation__actif=True,
        )
    elif profil_apprenant:
        seances_a_venir_queryset = seances_a_venir_queryset.filter(
            creneau__affectation__groupe_id__in=groupes,
            creneau__affectation__actif=True,
            creneau__affectation__enseignant__actif=True,
        )
    seances_a_venir = list(seances_a_venir_queryset.order_by("date", "heure_debut")[:6])

    evaluations = Evaluation.objects.filter(
        tenant=tenant,
        institution=institution,
    ).select_related("affectation__cours", "affectation__groupe")
    if profil_enseignant:
        evaluations = evaluations.filter(affectation__enseignant=profil_enseignant)
    elif profil_apprenant:
        evaluations = evaluations.none()
    evaluations_a_venir = list(
        evaluations.filter(
            date_evaluation__gte=aujourd_hui,
            statut=StatutEvaluation.PUBLIEE,
        ).order_by("date_evaluation")[:5]
    )
    evaluations_recentes = list(evaluations.order_by("-date_evaluation", "-pk")[:5])

    resultats = []
    for evaluation in evaluations.filter(statut=StatutEvaluation.PUBLIEE).order_by(
        "-date_evaluation"
    )[:5]:
        resume = evaluation.notes.filter(note__isnull=False).aggregate(
            moyenne=Avg("note"),
            nombre=Count("pk"),
        )
        if resume["moyenne"] is not None:
            resultats.append(
                {
                    "nom": evaluation.titre,
                    "groupe": evaluation.affectation.groupe.nom,
                    "moyenne": round(
                        float(resume["moyenne"]) / float(evaluation.note_maximale) * 100
                    ),
                    "nombre": resume["nombre"],
                }
            )

    presences = Presence.objects.filter(
        tenant=tenant,
        institution=institution,
        seance__date__gte=premier_jour,
        seance__date__lte=aujourd_hui,
    )
    if profil_enseignant:
        presences = presences.filter(
            groupe__affectations_enseignement__enseignant=profil_enseignant,
            groupe__affectations_enseignement__actif=True,
        )
    elif profil_apprenant:
        presences = presences.none()
    resumes_presence = {
        resume["statut"]: resume["nombre"]
        for resume in presences.values("statut").annotate(nombre=Count("pk", distinct=True))
    }
    nombre_presences = sum(resumes_presence.values())
    nombre_presentes = resumes_presence.get(StatutPresence.PRESENTE, 0)

    return {
        "dashboard_today": aujourd_hui,
        "dashboard_month": aujourd_hui,
        "dashboard_calendar_weeks": _calendrier_dashboard(
            aujourd_hui,
            {seance.date for seance in seances},
        ),
        "dashboard_sessions_today": seances_du_jour[:5],
        "dashboard_upcoming_sessions": seances_a_venir,
        "dashboard_upcoming_evaluations": evaluations_a_venir,
        "dashboard_recent_evaluations": evaluations_recentes,
        "dashboard_performances": resultats,
        "dashboard_presence_summary": {
            "total": nombre_presences,
            "presentes": nombre_presentes,
            "retards": resumes_presence.get(StatutPresence.RETARD, 0),
            "absences": resumes_presence.get(StatutPresence.ABSENTE, 0)
            + resumes_presence.get(StatutPresence.JUSTIFIEE, 0),
            "pourcentage_presentes": (
                round(nombre_presentes / nombre_presences * 100) if nombre_presences else 0
            ),
        },
        "dashboard_sessions_today_count": len(seances_du_jour),
    }


def rediriger_accueil(request):
    """Envoie vers la connexion ou le tableau de bord existant."""
    destination = "tableau_de_bord:accueil" if request.user.is_authenticated else "connexion"
    return redirect(destination)


@login_required
@_page_privee
def tableau_de_bord(request):
    contexte = _contexte_espace(request)
    if request.method == "POST":
        return _changer_espace(request, contexte["adhesions"])

    workspace = contexte["workspace"]
    est_operateur_sans_espace = workspace is None and utilisateur_peut_gerer_abonnements_saas(
        request.user
    )
    donnees = {
        **contexte,
        "plateforme_operateur": False,
        "dashboard_home": True,
        "dashboard_role_label": _("Espace personnel"),
        "dashboard_description": _(
            "Les outils disponibles apparaîtront ici selon votre rôle et vos accès."
        ),
        "dashboard_greeting": _("Bienvenue sur votre espace EduFlow."),
        "dashboard_today": timezone.localdate(),
        "dashboard_month": timezone.localdate(),
        "dashboard_calendar_weeks": _calendrier_dashboard(timezone.localdate(), set()),
        "annee_active": None,
        "role_gestion": False,
        "statistiques": [],
        "profil_enseignant": None,
        "affectations": [],
        "dashboard_assignments": [],
        "prochaines_seances": [],
        "nombre_prochaines_seances": 0,
        "dashboard_stats": [],
        "dashboard_links": [],
        "dashboard_upcoming_sessions": [],
        "dashboard_sessions_today": [],
        "dashboard_upcoming_evaluations": [],
        "dashboard_recent_evaluations": [],
        "dashboard_performances": [],
        "dashboard_presence_summary": {
            "total": 0,
            "presentes": 0,
            "retards": 0,
            "absences": 0,
            "pourcentage_presentes": 0,
        },
        "dashboard_sessions_today_count": 0,
    }

    if est_operateur_sans_espace:
        donnees.update(_contexte_tableau_bord_operateur(request))
        donnees.update(
            {
                "dashboard_role_label": _("Opérateur de plateforme"),
                "dashboard_description": _(
                    "Pilotage des établissements, abonnements et opérations SaaS."
                ),
                "dashboard_greeting": _("Pilotez EduFlow en un coup d’œil."),
                "dashboard_stats": [
                    {
                        "label": _("Établissements"),
                        "value": donnees["nombre_tenants"],
                        "detail": _("%(count)s actif(s)") % {"count": donnees["tenants_actifs"]},
                        "icon": "i-building",
                        "tone": "blue",
                        "url": "administration_saas:etablissements",
                    },
                    {
                        "label": _("Abonnements actifs"),
                        "value": donnees["abonnements_actifs"],
                        "detail": _("Contrats actuellement ouverts"),
                        "icon": "i-subscriptions",
                        "tone": "green",
                        "url": "administration_saas:abonnements",
                        "query": "?statut=actif",
                    },
                    {
                        "label": _("Paiements à examiner"),
                        "value": donnees["paiements_a_decider"],
                        "detail": _("Décision opérateur requise"),
                        "icon": "i-payments",
                        "tone": "violet",
                        "url": "administration_saas:paiements",
                    },
                    {
                        "label": _("Demandes en attente"),
                        "value": donnees["demandes_en_attente"],
                        "detail": _("Établissements à étudier"),
                        "icon": "i-admissions",
                        "tone": "amber",
                        "url": "admin:organisations_demandeinscriptiontenant_changelist",
                    },
                    {
                        "label": _("Plans disponibles"),
                        "value": donnees["plans_actifs"],
                        "detail": _("Offres actives de la plateforme"),
                        "icon": "i-plans",
                        "tone": "blue",
                        "url": "administration_saas:plans",
                    },
                ],
                "dashboard_links": [
                    {
                        "label": _("Plans SaaS"),
                        "icon": "i-plans",
                        "url": "administration_saas:plans",
                    },
                    {
                        "label": _("Abonnements"),
                        "icon": "i-subscriptions",
                        "url": "administration_saas:abonnements",
                    },
                    {
                        "label": _("Paiements"),
                        "icon": "i-payments",
                        "url": "administration_saas:paiements",
                    },
                    {
                        "label": _("Administration"),
                        "icon": "i-shield",
                        "url": "admin:index",
                    },
                ],
            }
        )

    if request.user.is_superuser:
        if not est_operateur_sans_espace:
            journaliser_lecture_operateur(
                acteur=request.user,
                action="tableau_de_bord",
            )
        donnees["catalogue_admin"], donnees["nombre_modeles_admin"] = _catalogue_admin_superuser(
            request
        )

    if workspace and contexte["workspace_accessible"]:
        tenant = workspace.tenant
        institution = tenant.institution
        donnees["annee_active"] = (
            AnneeAcademique.objects.filter(
                tenant=tenant,
                institution=institution,
                statut=StatutAnneeAcademique.ACTIVE,
            )
            .order_by("-debut")
            .first()
        )
        donnees["dashboard_role_label"] = workspace.get_role_display()
        donnees["dashboard_description"] = _(
            "Votre espace de travail et les informations utiles à votre rôle."
        )
        donnees["dashboard_greeting"] = institution.nom

        profil_enseignant = None
        if workspace.role == RoleAdhesion.ENSEIGNANT:
            profil_enseignant = ProfilEnseignant.objects.filter(
                tenant=tenant,
                institution=institution,
                compte=request.user,
                actif=True,
            ).first()
        profil_apprenant_dashboard = (
            contexte["profil_apprenant"]
            if workspace.role not in ROLES_GESTION and workspace.role != RoleAdhesion.ENSEIGNANT
            else None
        )
        if (
            workspace.role in ROLES_GESTION
            or workspace.role == RoleAdhesion.ENSEIGNANT
            or profil_apprenant_dashboard is not None
        ):
            donnees.update(
                _contexte_dashboard_etablissement(
                    tenant,
                    institution,
                    profil_enseignant,
                    profil_apprenant_dashboard,
                )
            )

        if workspace.role in ROLES_GESTION:
            donnees["role_gestion"] = True
            nombre_apprenants = (
                Inscription.objects.filter(
                    tenant=tenant,
                    institution=institution,
                    statut=StatutInscription.ACTIVE,
                )
                .values("apprenant_id")
                .distinct()
                .count()
            )
            nombre_groupes = Groupe.objects.filter(
                tenant=tenant,
                institution=institution,
                actif=True,
            ).count()
            candidatures_a_traiter = Candidature.objects.filter(
                tenant=tenant,
                institution=institution,
                statut__in=(StatutCandidature.SOUMISE, StatutCandidature.EN_EXAMEN),
            ).count()
            donnees["statistiques"] = [
                {
                    "label": _("Apprenants actifs"),
                    "valeur": nombre_apprenants,
                    "url": "tableau_de_bord:apprenants",
                },
                {
                    "label": _("Groupes actifs"),
                    "valeur": nombre_groupes,
                    "url": "tableau_de_bord:groupes",
                },
                {
                    "label": _("Candidatures à traiter"),
                    "valeur": candidatures_a_traiter,
                    "url": "tableau_de_bord:candidatures",
                },
            ]
            donnees["dashboard_stats"] = [
                {
                    "label": _("Apprenants actifs"),
                    "value": nombre_apprenants,
                    "detail": _("Dans cet établissement"),
                    "icon": "i-users",
                    "tone": "blue",
                    "url": "tableau_de_bord:apprenants",
                },
                {
                    "label": _("Groupes actifs"),
                    "value": nombre_groupes,
                    "detail": _("Groupes pédagogiques"),
                    "icon": "i-classes",
                    "tone": "green",
                    "url": "tableau_de_bord:groupes",
                },
                {
                    "label": _("Candidatures à traiter"),
                    "value": candidatures_a_traiter,
                    "detail": _("En attente d’examen"),
                    "icon": "i-admissions",
                    "tone": "violet",
                    "url": "tableau_de_bord:candidatures",
                },
                {
                    "label": _("Séances aujourd’hui"),
                    "value": donnees["dashboard_sessions_today_count"],
                    "detail": _("Séances planifiées"),
                    "icon": "i-calendar",
                    "tone": "amber",
                    "url": "tableau_de_bord:presences",
                },
            ]
            donnees["dashboard_assignments"] = list(
                AffectationEnseignement.objects.filter(
                    tenant=tenant,
                    institution=institution,
                    actif=True,
                )
                .select_related("cours", "groupe", "annee_academique")
                .order_by("groupe__nom", "cours__nom")[:5]
            )
            donnees["dashboard_links"] = [
                {"label": _("Apprenants"), "icon": "i-users", "url": "tableau_de_bord:apprenants"},
                {
                    "label": _("Enseignants"),
                    "icon": "i-users",
                    "url": "personnes_web:enseignants",
                },
                {
                    "label": _("Admissions"),
                    "icon": "i-admissions",
                    "url": "tableau_de_bord:candidatures",
                },
                {"label": _("Groupes"), "icon": "i-classes", "url": "groupes"},
                {
                    "label": _("Présences"),
                    "icon": "i-calendar",
                    "url": "tableau_de_bord:presences",
                },
                {
                    "label": _("Évaluations"),
                    "icon": "i-grades",
                    "url": "evaluations_web:liste",
                },
                {
                    "label": _("Emploi du temps"),
                    "icon": "i-calendar",
                    "url": "emplois_temps_web:gestion",
                },
                {
                    "label": _("Années académiques"),
                    "icon": "i-calendar",
                    "url": "annees-academiques",
                },
                {
                    "label": _("Cours"),
                    "icon": "i-book",
                    "url": "cours",
                },
                {
                    "label": _("Finances"),
                    "icon": "i-payments",
                    "url": "finances_web:accueil",
                },
                {
                    "label": _("Rapports"),
                    "icon": "i-grades",
                    "url": "rapports_web:accueil",
                },
            ]
            if workspace.role == RoleAdhesion.PROPRIETAIRE and not request.user.is_superuser:
                donnees["dashboard_links"] = [
                    {
                        "label": _("Mes établissements"),
                        "icon": "i-building",
                        "url": "parcours_tenant:mes-etablissements",
                    },
                    {
                        "label": _("Années académiques"),
                        "icon": "i-calendar",
                        "url": "annees-academiques",
                    },
                    {"label": _("Campus"), "icon": "i-building", "url": "campus"},
                    {"label": _("Programmes"), "icon": "i-book", "url": "programmes"},
                    {"label": _("Niveaux"), "icon": "i-classes", "url": "niveaux"},
                    {"label": _("Cours"), "icon": "i-book", "url": "cours"},
                    {"label": _("Groupes"), "icon": "i-classes", "url": "groupes"},
                    {
                        "label": _("Équipe"),
                        "icon": "i-users",
                        "url": "parcours_tenant:equipe",
                    },
                    {
                        "label": _("Enseignants"),
                        "icon": "i-users",
                        "url": "personnes_web:enseignants",
                    },
                    {
                        "label": _("Admissions"),
                        "icon": "i-admissions",
                        "url": "tableau_de_bord:candidatures",
                    },
                    {
                        "label": _("Apprenants"),
                        "icon": "i-users",
                        "url": "tableau_de_bord:apprenants",
                    },
                    {
                        "label": _("Inscriptions"),
                        "icon": "i-admissions",
                        "url": "inscriptions_web:gestion",
                    },
                    {
                        "label": _("Emploi du temps"),
                        "icon": "i-calendar",
                        "url": "emplois_temps_web:gestion",
                    },
                    {
                        "label": _("Présences"),
                        "icon": "i-calendar",
                        "url": "tableau_de_bord:presences",
                    },
                    {
                        "label": _("Finances"),
                        "icon": "i-payments",
                        "url": "finances_web:accueil",
                    },
                    {
                        "label": _("Rapports"),
                        "icon": "i-grades",
                        "url": "rapports_web:accueil",
                    },
                ]
                donnees["dashboard_links_sequential"] = True
        elif workspace.role == RoleAdhesion.ENSEIGNANT:
            profil = profil_enseignant
            donnees["profil_enseignant"] = profil
            if profil:
                affectations = AffectationEnseignement.objects.filter(
                    tenant=tenant,
                    institution=institution,
                    enseignant=profil,
                    actif=True,
                ).select_related(
                    "cours",
                    "groupe",
                    "annee_academique",
                )
                donnees["affectations"] = list(affectations)
                donnees["dashboard_assignments"] = donnees["affectations"]
                donnees["statistiques"] = [
                    {
                        "label": _("Mes affectations"),
                        "valeur": affectations.count(),
                        "url": "tableau_de_bord:groupes",
                    },
                    {
                        "label": _("Mes groupes"),
                        "valeur": affectations.values("groupe_id").distinct().count(),
                        "url": "tableau_de_bord:groupes",
                    },
                ]
                groupes_ids = affectations.values_list("groupe_id", flat=True).distinct()
                nombre_apprenants = (
                    Inscription.objects.filter(
                        tenant=tenant,
                        institution=institution,
                        groupe_id__in=groupes_ids,
                        statut=StatutInscription.ACTIVE,
                    )
                    .values("apprenant_id")
                    .distinct()
                    .count()
                )
                nombre_evaluations = Evaluation.objects.filter(
                    tenant=tenant,
                    institution=institution,
                    affectation__enseignant=profil,
                ).count()
                donnees["nombre_prochaines_seances"] = len(donnees["dashboard_upcoming_sessions"])
                donnees["prochaines_seances"] = donnees["dashboard_upcoming_sessions"][:5]
                donnees["dashboard_stats"] = [
                    {
                        "label": _("Cours aujourd’hui"),
                        "value": donnees["dashboard_sessions_today_count"],
                        "detail": _("Séances planifiées"),
                        "icon": "i-calendar",
                        "tone": "blue",
                        "url": "tableau_de_bord:presences",
                    },
                    {
                        "label": _("Élèves de mes groupes"),
                        "value": nombre_apprenants,
                        "detail": _("Dans mes groupes"),
                        "icon": "i-users",
                        "tone": "green",
                        "url": "tableau_de_bord:groupes",
                    },
                    {
                        "label": _("Évaluations"),
                        "value": nombre_evaluations,
                        "detail": _("Créées dans mes cours"),
                        "icon": "i-grades",
                        "tone": "violet",
                        "url": "evaluations_web:liste",
                    },
                    {
                        "label": _("Groupes"),
                        "value": affectations.values("groupe_id").distinct().count(),
                        "detail": _("Groupes qui me sont affectés"),
                        "icon": "i-classes",
                        "tone": "amber",
                        "url": "tableau_de_bord:groupes",
                    },
                ]
                donnees["dashboard_links"] = [
                    {
                        "label": _("Mes groupes"),
                        "icon": "i-classes",
                        "url": "tableau_de_bord:groupes",
                    },
                    {
                        "label": _("Présences"),
                        "icon": "i-calendar",
                        "url": "tableau_de_bord:presences",
                    },
                    {
                        "label": _("Évaluations"),
                        "icon": "i-grades",
                        "url": "evaluations_web:liste",
                    },
                ]
            donnees["dashboard_role_label"] = _("Espace enseignant")
        elif contexte["profil_apprenant"] is not None:
            profil = contexte["profil_apprenant"]
            inscriptions_actives = Inscription.objects.filter(
                tenant=tenant,
                institution=institution,
                apprenant=profil,
                statut=StatutInscription.ACTIVE,
                groupe__isnull=False,
            )
            groupes_ids = inscriptions_actives.values_list("groupe_id", flat=True)
            affectations = AffectationEnseignement.objects.filter(
                tenant=tenant,
                institution=institution,
                groupe_id__in=groupes_ids,
                actif=True,
                enseignant__actif=True,
            ).select_related("cours", "groupe", "annee_academique")
            nombre_devoirs = Devoir.objects.filter(
                tenant=tenant,
                institution=institution,
                affectation__in=affectations,
                a_rendre_le__gte=donnees["dashboard_today"],
            ).count()
            nombre_plans = PlanCours.objects.filter(
                tenant=tenant,
                institution=institution,
                affectation__in=affectations,
            ).count()
            donnees["dashboard_role_label"] = _("Espace apprenant")
            donnees["dashboard_description"] = _(
                "Retrouvez les cours, plans et devoirs de vos groupes."
            )
            donnees["dashboard_greeting"] = str(profil.personne)
            donnees["dashboard_assignments"] = list(affectations[:5])
            donnees["dashboard_stats"] = [
                {
                    "label": _("Mes cours"),
                    "value": affectations.values("cours_id").distinct().count(),
                    "detail": _("Dans mes groupes actifs"),
                    "icon": "i-book",
                    "tone": "blue",
                    "url": "pedagogie:apprentissage",
                },
                {
                    "label": _("Devoirs à venir"),
                    "value": nombre_devoirs,
                    "detail": _("À remettre"),
                    "icon": "i-grades",
                    "tone": "amber",
                    "url": "pedagogie:apprentissage",
                },
                {
                    "label": _("Plans de cours"),
                    "value": nombre_plans,
                    "detail": _("Pour vos cours"),
                    "icon": "i-calendar",
                    "tone": "green",
                    "url": "pedagogie:apprentissage",
                },
            ]
            donnees["dashboard_links"] = [
                {
                    "label": _("Mes cours"),
                    "icon": "i-book",
                    "url": "pedagogie:apprentissage",
                },
                {
                    "label": _("Bibliothèque pédagogique"),
                    "icon": "i-book",
                    "url": "pedagogie:bibliotheque",
                },
            ]

    return render(request, "tableau_de_bord/dashboard.html", donnees)


@login_required
@_page_privee
def liste_apprenants(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied

    queryset = Inscription.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    ).select_related(
        "apprenant__personne",
        "apprenant__compte",
        "groupe",
        "programme",
        "annee_academique",
    )
    queryset, terme = _recherche(
        queryset,
        request,
        ("apprenant__personne__nom", "apprenant__personne__prenom"),
    )
    return render(
        request,
        "tableau_de_bord/liste_apprenants.html",
        {
            **contexte,
            "page": _paginate(queryset, request),
            "terme": terme,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def lier_compte_apprenant(request, apprenant_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if not contexte["role_gestion"]:
        raise DjangoPermissionDenied(
            _("Seuls les responsables peuvent lier un compte à un dossier apprenant.")
        )

    apprenant = get_object_or_404(
        ProfilApprenant.objects.select_related("personne", "compte").filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ),
        pk=apprenant_id,
    )
    formulaire = FormulaireLienCompteApprenant(
        request.POST if request.method == "POST" else None,
        instance=apprenant,
        tenant=workspace.tenant,
    )
    if request.method == "POST" and formulaire.is_valid():
        formulaire.save()
        messages.success(
            request,
            _("Le compte de %(name)s a été mis à jour.") % {"name": apprenant.personne},
        )
        return redirect("tableau_de_bord:apprenants")

    return render(
        request,
        "tableau_de_bord/lier_compte_apprenant.html",
        {
            **contexte,
            "apprenant": apprenant,
            "formulaire": formulaire,
        },
    )


@login_required
@_page_privee
def liste_candidatures(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied

    queryset, terme, statut = _candidatures_filtrees(workspace, request)
    page = _paginate(queryset, request)
    for candidature in page:
        candidature.transitions_disponibles = TRANSITIONS_CANDIDATURE_WEB[candidature.statut]
    return render(
        request,
        "tableau_de_bord/liste_candidatures.html",
        {
            **contexte,
            "page": page,
            "terme": terme,
            "statut_selectionne": statut,
            "statuts": StatutCandidature.choices,
            "transitions_candidature": TRANSITIONS_CANDIDATURE_WEB,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def importer_candidatures(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied

    tenant = workspace.tenant
    institution = tenant.institution
    form = CandidatureImportForm(
        request.POST or None,
        request.FILES or None,
        tenant=tenant,
        institution=institution,
    )
    if request.method == "POST" and form.is_valid():
        try:
            resultat = importer_candidatures_csv(
                contenu=form.cleaned_data["fichier_csv"].read(),
                tenant=tenant,
                institution=institution,
                acteur=request.user,
                annee_academique=form.cleaned_data["annee_academique"],
                programme=form.cleaned_data["programme"],
            )
        except ErreurImportCandidatures as erreur:
            for message in erreur.erreurs:
                form.add_error(None, message)
        else:
            messages.success(
                request,
                f"Import terminé : {resultat['creees']} candidature(s) créée(s), "
                f"{resultat['reprises']} reprise(s) idempotente(s).",
            )
            return redirect("tableau_de_bord:candidatures")

    return render(
        request,
        "tableau_de_bord/candidature_import.html",
        {
            **contexte,
            "form": form,
        },
    )


@login_required
@_page_privee
@require_GET
def exporter_candidatures_csv(request):
    workspace, _ = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied

    queryset, terme, statut = _candidatures_filtrees(workspace, request)
    EvenementAudit.objects.create(
        tenant=workspace.tenant,
        acteur=request.user,
        action="admission.candidatures_exportees",
        type_objet=Candidature._meta.label_lower,
        id_objet="csv",
        details={
            "nombre": queryset.count(),
            "statut": statut,
            "recherche_utilisee": bool(terme),
            "format": "csv",
        },
    )

    def lignes_csv():
        tampon = io.StringIO()
        redacteur = csv.writer(tampon)
        redacteur.writerow(
            (
                "reference",
                "prenom",
                "nom",
                "courriel",
                "telephone",
                "identifiant_externe",
                "programme",
                "annee_academique",
                "statut",
                "cree_le",
            )
        )
        yield "\ufeff" + tampon.getvalue()
        tampon.seek(0)
        tampon.truncate(0)
        for candidature in queryset.iterator(chunk_size=500):
            redacteur.writerow(
                _cellule_csv(valeur)
                for valeur in (
                    candidature.reference,
                    candidature.personne.prenom,
                    candidature.personne.nom,
                    candidature.personne.courriel,
                    candidature.personne.telephone,
                    candidature.personne.identifiant_externe,
                    candidature.programme.nom,
                    candidature.annee_academique.nom,
                    candidature.get_statut_display(),
                    candidature.cree_le.isoformat(),
                )
            )
            yield tampon.getvalue()
            tampon.seek(0)
            tampon.truncate(0)

    response = StreamingHttpResponse(
        lignes_csv(),
        content_type="text/csv; charset=utf-8",
    )
    response["Content-Disposition"] = 'attachment; filename="candidatures.csv"'
    return response


def _ajouter_erreur_formulaire(form, erreur):
    if hasattr(erreur, "message_dict"):
        for champ, erreurs in erreur.message_dict.items():
            form.add_error(champ if champ in form.fields else None, erreurs)
    else:
        form.add_error(None, erreur.messages)


@login_required
@_page_privee
def creer_candidature(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied
    tenant = workspace.tenant
    institution = tenant.institution
    form = CandidatureCreationForm(
        request.POST or None,
        tenant=tenant,
        institution=institution,
    )
    if request.method == "POST" and form.is_valid():
        try:
            candidature, _ = creer_candidature_service(
                tenant=tenant,
                institution=institution,
                acteur=request.user,
                identite=form.identite(),
                annee_academique=form.cleaned_data["annee_academique"],
                programme=form.cleaned_data["programme"],
                cle_idempotence=form.cleaned_data["cle_idempotence"],
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        except ConflitIdentifiantExterneAdmission:
            form.add_error(
                "identifiant_externe",
                "Cet identifiant externe est déjà utilisé dans cet établissement.",
            )
        except ConflitIdempotenceAdmission:
            form.add_error(
                None,
                "Cette création entre en conflit avec une autre opération. Réessayez.",
            )
        else:
            messages.success(
                request,
                f"La candidature {candidature.reference} a été créée en brouillon.",
            )
            return redirect("tableau_de_bord:candidatures")
    return render(
        request,
        "tableau_de_bord/candidature_form.html",
        {
            **contexte,
            "form": form,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_candidature_web(request, candidature_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied

    candidature = get_object_or_404(
        Candidature.objects.select_related(
            "personne",
            "programme",
            "annee_academique",
            "decidee_par",
        ).filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ),
        pk=candidature_id,
    )
    if request.method == "POST" and candidature.statut != StatutCandidature.BROUILLON:
        raise Http404

    formulaire = None
    if candidature.statut == StatutCandidature.BROUILLON:
        formulaire = CandidatureModificationForm(
            request.POST if request.method == "POST" else None,
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            candidature=candidature,
        )
        if request.method == "POST" and formulaire.is_valid():
            try:
                candidature = modifier_candidature_brouillon(
                    candidature_id=candidature.pk,
                    tenant=workspace.tenant,
                    acteur=request.user,
                    modifications=formulaire.cleaned_data,
                )
            except ConflitIdentifiantExterneAdmission:
                formulaire.add_error(
                    "identifiant_externe",
                    _("Cet identifiant externe est déjà utilisé dans cet établissement."),
                )
            except ValidationError as erreur:
                _ajouter_erreur_formulaire(formulaire, erreur)
            else:
                messages.success(
                    request,
                    _("La candidature %(reference)s a été modifiée.")
                    % {"reference": candidature.reference},
                )
                return redirect(
                    "tableau_de_bord:detail-candidature",
                    candidature_id=candidature.pk,
                )

    return render(
        request,
        "tableau_de_bord/candidature_detail.html",
        {
            **contexte,
            "candidature": candidature,
            "form": formulaire,
        },
    )


@login_required
@_page_privee
def transitionner_candidature_web(request, candidature_id, nouveau_statut):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied
    candidature = get_object_or_404(
        Candidature.objects.select_related(
            "personne",
            "programme",
            "annee_academique",
        ),
        pk=candidature_id,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    )
    transitions = TRANSITIONS_CANDIDATURE_WEB[candidature.statut]
    choix_transition = {valeur: libelle for valeur, libelle in transitions}
    if nouveau_statut not in choix_transition:
        raise Http404
    form = TransitionCandidatureForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            candidature = transitionner_candidature(
                candidature_id=candidature.pk,
                tenant=workspace.tenant,
                acteur=request.user,
                nouveau_statut=nouveau_statut,
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        else:
            messages.success(
                request,
                f"La candidature {candidature.reference} est maintenant "
                f"« {candidature.get_statut_display()} ».",
            )
            return redirect("tableau_de_bord:candidatures")
    return render(
        request,
        "tableau_de_bord/candidature_transition.html",
        {
            **contexte,
            "form": form,
            "candidature": candidature,
            "nouveau_statut": nouveau_statut,
            "libelle_transition": choix_transition[nouveau_statut],
            "est_admission": nouveau_statut == StatutCandidature.ADMISE,
            "est_refus": nouveau_statut == StatutCandidature.REFUSEE,
        },
    )


@login_required
@_page_privee
def liste_groupes(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    queryset = _groupes_accessibles(workspace, request.user)
    queryset, terme = _recherche(queryset, request, ("nom", "code", "programme__nom"))
    return render(
        request,
        "tableau_de_bord/liste_groupes.html",
        {
            **contexte,
            "page": _paginate(queryset, request),
            "terme": terme,
        },
    )


def _groupes_accessibles(workspace, utilisateur):
    tenant = workspace.tenant
    queryset = Groupe.objects.filter(
        tenant=tenant,
        institution=tenant.institution,
    ).select_related("programme", "annee_academique", "campus")

    if workspace.role == RoleAdhesion.ENSEIGNANT:
        profil = ProfilEnseignant.objects.filter(
            tenant=tenant,
            institution=tenant.institution,
            compte=utilisateur,
            actif=True,
        ).first()
        if profil is None:
            return queryset.none()
        return queryset.filter(
            affectations_enseignement__tenant=tenant,
            affectations_enseignement__enseignant=profil,
            affectations_enseignement__actif=True,
        ).distinct()
    if workspace.role not in ROLES_GESTION:
        raise DjangoPermissionDenied
    return queryset


def _seances_accessibles(workspace, utilisateur):
    tenant = workspace.tenant
    queryset = Seance.objects.filter(
        tenant=tenant,
        institution=tenant.institution,
        creneau__tenant=tenant,
        creneau__institution=tenant.institution,
    ).select_related(
        "creneau__affectation__cours",
        "creneau__affectation__groupe",
        "creneau__affectation__enseignant__personne",
    )
    if workspace.role in ROLES_GESTION:
        return queryset
    if workspace.role != RoleAdhesion.ENSEIGNANT:
        raise DjangoPermissionDenied

    profil = ProfilEnseignant.objects.filter(
        tenant=tenant,
        institution=tenant.institution,
        compte=utilisateur,
        actif=True,
    ).first()
    if profil is None:
        return queryset.none()
    return queryset.filter(
        creneau__affectation__tenant=tenant,
        creneau__affectation__institution=tenant.institution,
        creneau__affectation__enseignant=profil,
        creneau__affectation__actif=True,
    )


@login_required
@_page_privee
@require_GET
def recherche_globale(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if workspace.role not in ROLES_GESTION | {RoleAdhesion.ENSEIGNANT}:
        raise DjangoPermissionDenied

    terme = request.GET.get("q", "").strip()
    erreur = ""
    categories = []
    if len(terme) > 100:
        erreur = _("La recherche est limitée à 100 caractères.")
    elif terme and len(terme) < 2:
        erreur = _("Saisissez au moins deux caractères.")
    elif terme:
        tenant = workspace.tenant
        filtres_liste = f"?{urlencode({'q': terme})}"

        if workspace.role in ROLES_GESTION:
            inscriptions = (
                Inscription.objects.filter(
                    tenant=tenant,
                    institution=tenant.institution,
                )
                .filter(
                    Q(apprenant__personne__nom__icontains=terme)
                    | Q(apprenant__personne__prenom__icontains=terme)
                )
                .select_related("apprenant__personne", "groupe", "programme")
                .distinct()
            )
            resultats_apprenants = [
                {
                    "titre": str(inscription.apprenant.personne),
                    "detail": inscription.groupe.nom if inscription.groupe_id else "",
                    "url": f"{reverse('tableau_de_bord:apprenants')}{filtres_liste}",
                }
                for inscription in inscriptions[:8]
            ]
            categories.append(
                {
                    "titre": _("Apprenants"),
                    "resultats": resultats_apprenants,
                    "tout_voir": f"{reverse('tableau_de_bord:apprenants')}{filtres_liste}",
                }
            )

            candidatures = _candidatures_filtrees(workspace, request)[0]
            resultats_candidatures = [
                {
                    "titre": str(candidature.personne),
                    "detail": candidature.reference,
                    "url": f"{reverse('tableau_de_bord:candidatures')}{filtres_liste}",
                }
                for candidature in candidatures[:8]
            ]
            categories.append(
                {
                    "titre": _("Admissions"),
                    "resultats": resultats_candidatures,
                    "tout_voir": f"{reverse('tableau_de_bord:candidatures')}{filtres_liste}",
                }
            )

        groupes = _groupes_accessibles(workspace, request.user).filter(
            Q(nom__icontains=terme) | Q(code__icontains=terme) | Q(programme__nom__icontains=terme)
        )
        resultats_groupes = [
            {
                "titre": groupe.nom,
                "detail": groupe.programme.nom if groupe.programme_id else groupe.code,
                "url": f"{reverse('tableau_de_bord:groupes')}{filtres_liste}",
            }
            for groupe in groupes[:8]
        ]
        categories.append(
            {
                "titre": _("Groupes et classes"),
                "resultats": resultats_groupes,
                "tout_voir": f"{reverse('tableau_de_bord:groupes')}{filtres_liste}",
            }
        )

        evaluations = Evaluation.objects.filter(
            tenant=tenant,
            institution=tenant.institution,
        ).select_related("affectation__cours", "affectation__groupe")
        if workspace.role == RoleAdhesion.ENSEIGNANT:
            evaluations = evaluations.filter(
                affectation__enseignant__compte=request.user,
                affectation__enseignant__actif=True,
                affectation__actif=True,
            )
        evaluations = evaluations.filter(
            Q(titre__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
        categories.append(
            {
                "titre": _("Évaluations"),
                "resultats": [
                    {
                        "titre": evaluation.titre,
                        "detail": (
                            f"{evaluation.affectation.cours.nom} · "
                            f"{evaluation.affectation.groupe.nom}"
                        ),
                        "url": reverse(
                            "evaluations_web:detail",
                            kwargs={"evaluation_id": evaluation.pk},
                        ),
                    }
                    for evaluation in evaluations[:8]
                ],
            }
        )

        affectations_recherche = AffectationEnseignement.objects.filter(
            tenant=tenant,
            institution=tenant.institution,
            actif=True,
            enseignant__actif=True,
        )
        if workspace.role == RoleAdhesion.ENSEIGNANT:
            affectations_recherche = affectations_recherche.filter(
                enseignant__compte=request.user,
            )
        plans_cours = PlanCours.objects.filter(
            tenant=tenant,
            institution=tenant.institution,
            affectation__in=affectations_recherche,
        ).select_related("affectation__cours", "affectation__groupe")
        devoirs = Devoir.objects.filter(
            tenant=tenant,
            institution=tenant.institution,
            affectation__in=affectations_recherche,
        ).select_related("affectation__cours", "affectation__groupe")
        plans_cours = plans_cours.filter(
            Q(titre__icontains=terme)
            | Q(objectifs__icontains=terme)
            | Q(contenu__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
        devoirs = devoirs.filter(
            Q(titre__icontains=terme)
            | Q(consignes__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
        categories.extend(
            (
                {
                    "titre": _("Plans de cours"),
                    "resultats": [
                        {
                            "titre": plan.titre,
                            "detail": (
                                f"{plan.affectation.cours.nom} · "
                                f"{plan.affectation.groupe.nom} · {plan.date:%d/%m/%Y}"
                            ),
                            "url": (f"{reverse('pedagogie:plans')}?{urlencode({'q': terme})}"),
                        }
                        for plan in plans_cours[:8]
                    ],
                    "tout_voir": (f"{reverse('pedagogie:plans')}?{urlencode({'q': terme})}"),
                },
                {
                    "titre": _("Devoirs"),
                    "resultats": [
                        {
                            "titre": devoir.titre,
                            "detail": (
                                f"{devoir.affectation.cours.nom} · "
                                f"{devoir.affectation.groupe.nom} · "
                                f"{devoir.a_rendre_le:%d/%m/%Y}"
                            ),
                            "url": (f"{reverse('pedagogie:devoirs')}?{urlencode({'q': terme})}"),
                        }
                        for devoir in devoirs[:8]
                    ],
                    "tout_voir": (f"{reverse('pedagogie:devoirs')}?{urlencode({'q': terme})}"),
                },
            )
        )

        quiz = Quiz.objects.filter(
            tenant=tenant,
            institution=tenant.institution,
            affectation__in=affectations_recherche,
            actif=True,
        ).filter(
            Q(titre__icontains=terme)
            | Q(description__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
        ressources = (
            RessourcePedagogique.objects.filter(
                tenant=tenant,
                institution=tenant.institution,
            )
            .filter(Q(affectation__isnull=True) | Q(affectation__in=affectations_recherche))
            .filter(
                Q(titre__icontains=terme)
                | Q(description__icontains=terme)
                | Q(affectation__cours__nom__icontains=terme)
                | Q(affectation__groupe__nom__icontains=terme)
            )
        )
        categories.extend(
            (
                {
                    "titre": _("Quiz"),
                    "resultats": [
                        {
                            "titre": element.titre,
                            "detail": (
                                f"{element.affectation.cours.nom} · "
                                f"{element.affectation.groupe.nom}"
                            ),
                            "url": (f"{reverse('pedagogie:quiz')}?{urlencode({'q': terme})}"),
                        }
                        for element in quiz.select_related(
                            "affectation__cours", "affectation__groupe"
                        )[:8]
                    ],
                    "tout_voir": (f"{reverse('pedagogie:quiz')}?{urlencode({'q': terme})}"),
                },
                {
                    "titre": _("Bibliothèque pédagogique"),
                    "resultats": [
                        {
                            "titre": element.titre,
                            "detail": (
                                element.affectation.cours.nom
                                if element.affectation_id
                                else _("Partagée dans l’établissement")
                            ),
                            "url": (
                                f"{reverse('pedagogie:bibliotheque')}?{urlencode({'q': terme})}"
                            ),
                        }
                        for element in ressources.select_related("affectation__cours")[:8]
                    ],
                    "tout_voir": (f"{reverse('pedagogie:bibliotheque')}?{urlencode({'q': terme})}"),
                },
            )
        )

        seances = _seances_accessibles(workspace, request.user).filter(
            Q(creneau__affectation__cours__nom__icontains=terme)
            | Q(creneau__affectation__groupe__nom__icontains=terme)
            | Q(creneau__affectation__enseignant__personne__nom__icontains=terme)
            | Q(creneau__affectation__enseignant__personne__prenom__icontains=terme)
            | Q(salle__icontains=terme)
        )
        categories.append(
            {
                "titre": _("Emploi du temps"),
                "resultats": [
                    {
                        "titre": (
                            f"{seance.creneau.affectation.cours.nom} · "
                            f"{seance.creneau.affectation.groupe.nom}"
                        ),
                        "detail": (
                            f"{seance.date:%d/%m/%Y} · "
                            f"{seance.heure_debut:%H:%M}–{seance.heure_fin:%H:%M}"
                        ),
                        "url": reverse(
                            "tableau_de_bord:feuille-presence",
                            kwargs={"seance_id": seance.pk},
                        ),
                    }
                    for seance in seances[:8]
                ],
            }
        )

    return render(
        request,
        "tableau_de_bord/recherche.html",
        {
            **contexte,
            "terme": terme,
            "erreur_recherche": erreur,
            "categories_recherche": categories,
            "a_des_resultats": any(categorie["resultats"] for categorie in categories),
        },
    )


@login_required
@_page_privee
@require_GET
def liste_notifications(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    notifications = Notification.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        destinataire=request.user,
    )
    return render(
        request,
        "notifications/liste.html",
        {
            **contexte,
            "page": _paginate(notifications, request),
            "notifications_non_lues": notifications.filter(lue_le__isnull=True).count(),
        },
    )


@login_required
@_page_privee
@require_POST
def ouvrir_notification(request, notification_id):
    workspace, _ = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    notification = get_object_or_404(
        Notification.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            destinataire=request.user,
        ),
        pk=notification_id,
    )
    if notification.lue_le is None:
        Notification.objects.filter(pk=notification.pk, lue_le__isnull=True).update(
            lue_le=timezone.now()
        )
    return redirect(notification.url or reverse("tableau_de_bord:notifications"))


@login_required
@_page_privee
@require_POST
def marquer_notifications_lues(request):
    workspace, _ = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    Notification.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        destinataire=request.user,
        lue_le__isnull=True,
    ).update(lue_le=timezone.now())
    messages.success(request, _("Toutes les notifications sont marquées comme lues."))
    return redirect("tableau_de_bord:notifications")


@login_required
@_page_privee
@require_GET
def liste_presences(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    with timezone.override(workspace.tenant.institution.fuseau_horaire):
        aujourd_hui = timezone.localdate()
    formulaire_date = FiltreDatePresenceForm(
        request.GET or None,
        initial={"date": aujourd_hui},
    )
    date_selectionnee = aujourd_hui
    if formulaire_date.is_bound and formulaire_date.is_valid():
        date_selectionnee = formulaire_date.cleaned_data["date"]

    seances = list(
        _seances_accessibles(workspace, request.user)
        .filter(date=date_selectionnee)
        .order_by("heure_debut", "pk")
    )
    groupes_ids = {seance.creneau.affectation.groupe_id for seance in seances}
    nombre_apprenants_par_groupe = {}
    if groupes_ids:
        nombre_apprenants_par_groupe = dict(
            Inscription.objects.filter(
                tenant=workspace.tenant,
                institution=workspace.tenant.institution,
                groupe_id__in=groupes_ids,
                statut=StatutInscription.ACTIVE,
                date_debut__lte=date_selectionnee,
            )
            .filter(Q(date_fin__isnull=True) | Q(date_fin__gte=date_selectionnee))
            .values("groupe_id")
            .annotate(nombre=Count("pk"))
            .values_list("groupe_id", "nombre")
        )

    compteurs_par_seance = {}
    if seances:
        for ligne in (
            Presence.objects.filter(
                tenant=workspace.tenant,
                institution=workspace.tenant.institution,
                seance_id__in=[seance.pk for seance in seances],
                inscription__statut=StatutInscription.ACTIVE,
                inscription__date_debut__lte=date_selectionnee,
            )
            .filter(
                Q(inscription__date_fin__isnull=True)
                | Q(inscription__date_fin__gte=date_selectionnee)
            )
            .values("seance_id", "statut")
            .annotate(nombre=Count("pk"))
        ):
            compteurs_par_seance.setdefault(ligne["seance_id"], {})[ligne["statut"]] = ligne[
                "nombre"
            ]

    resume_journee = {
        "total": len(seances),
        "a_faire": 0,
        "en_cours": 0,
        "completes": 0,
        "annulees": 0,
    }
    for seance in seances:
        groupe_id = seance.creneau.affectation.groupe_id
        compteurs = compteurs_par_seance.get(seance.pk, {})
        seance.nombre_apprenants = nombre_apprenants_par_groupe.get(groupe_id, 0)
        seance.nombre_renseignes = sum(compteurs.values())
        seance.nombre_restants = max(
            seance.nombre_apprenants - seance.nombre_renseignes,
            0,
        )
        seance.progression = (
            round(seance.nombre_renseignes * 100 / seance.nombre_apprenants)
            if seance.nombre_apprenants
            else 0
        )
        seance.compteurs_presence = {
            "presente": compteurs.get(StatutPresence.PRESENTE, 0),
            "retard": compteurs.get(StatutPresence.RETARD, 0),
            "justifiee": compteurs.get(StatutPresence.JUSTIFIEE, 0),
            "absente": compteurs.get(StatutPresence.ABSENTE, 0),
        }

        if seance.statut == StatutSeance.ANNULEE:
            seance.etat_feuille = "annulee"
            seance.etat_feuille_libelle = "Annulée"
            resume_journee["annulees"] += 1
        elif seance.nombre_apprenants and seance.nombre_renseignes >= seance.nombre_apprenants:
            seance.etat_feuille = "complete"
            seance.etat_feuille_libelle = "Complète"
            seance.action_feuille = "Voir la feuille"
            resume_journee["completes"] += 1
        elif seance.nombre_renseignes:
            seance.etat_feuille = "cours"
            seance.etat_feuille_libelle = "En cours"
            seance.action_feuille = "Continuer l’appel"
            resume_journee["en_cours"] += 1
        else:
            seance.etat_feuille = "todo"
            seance.etat_feuille_libelle = "Non commencée"
            seance.action_feuille = "Faire l’appel"
            resume_journee["a_faire"] += 1

    return render(
        request,
        "presences/presenceListe.html",
        {
            **contexte,
            "formulaire_date": formulaire_date,
            "date_selectionnee": date_selectionnee,
            "date_aujourd_hui": aujourd_hui,
            "seances": seances,
            "seances_matin": [seance for seance in seances if seance.heure_debut.hour < 12],
            "seances_apres_midi": [seance for seance in seances if seance.heure_debut.hour >= 12],
            "resume_journee": resume_journee,
            "date_precedente": date_selectionnee - timedelta(days=1),
            "date_suivante": date_selectionnee + timedelta(days=1),
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def feuille_presence(request, seance_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    seance = get_object_or_404(
        _seances_accessibles(workspace, request.user),
        pk=seance_id,
    )
    inscriptions = list(
        Inscription.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            groupe=seance.creneau.affectation.groupe,
            statut=StatutInscription.ACTIVE,
            date_debut__lte=seance.date,
        )
        .filter(Q(date_fin__isnull=True) | Q(date_fin__gte=seance.date))
        .select_related("apprenant__personne")
        .order_by("apprenant__personne__nom", "apprenant__personne__prenom")
    )
    presences_existantes = {
        presence.inscription_id: presence
        for presence in Presence.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            seance=seance,
            inscription__in=inscriptions,
        )
    }
    initial = [
        {
            "inscription_id": inscription.pk,
            "statut": (
                presences_existantes[inscription.pk].statut
                if inscription.pk in presences_existantes
                else ""
            ),
        }
        for inscription in inscriptions
    ]
    formset = PresenceFeuilleFormSet(
        request.POST or None,
        initial=initial,
        prefix="presences",
        inscription_ids=(inscription.pk for inscription in inscriptions),
    )
    for form, inscription in zip(formset.forms, inscriptions):
        form.inscription = inscription
        form.presence = presences_existantes.get(inscription.pk)

    erreur_feuille = ""
    if request.method == "POST":
        if seance.statut == StatutSeance.ANNULEE:
            erreur_feuille = "Une séance annulée ne peut pas recevoir de présence."
        elif formset.is_valid():
            nouvelles = 0
            corrections = 0
            try:
                with transaction.atomic():
                    for form in formset:
                        statut = form.cleaned_data["statut"]
                        if not statut:
                            continue
                        inscription_id = form.cleaned_data["inscription_id"]
                        presence, creee = enregistrer_presence(
                            tenant=workspace.tenant,
                            institution=workspace.tenant.institution,
                            seance_id=seance.pk,
                            inscription_id=inscription_id,
                            acteur=request.user,
                            statut=statut,
                            motif_correction=form.cleaned_data["motif_correction"],
                        )
                        if creee:
                            nouvelles += 1
                        elif (
                            inscription_id in presences_existantes
                            and presences_existantes[inscription_id].statut != statut
                        ):
                            corrections += 1
            except (ValidationError, Inscription.DoesNotExist) as erreur:
                detail = (
                    "; ".join(erreur.messages)
                    if isinstance(erreur, ValidationError)
                    else "Une inscription a changé pendant la saisie."
                )
                erreur_feuille = f"La feuille n’a pas été enregistrée. {detail}"
            else:
                if nouvelles or corrections:
                    messages.success(
                        request,
                        f"Feuille enregistrée : {nouvelles} nouvelle(s) présence(s), "
                        f"{corrections} correction(s).",
                    )
                else:
                    messages.info(request, "Aucune modification de présence à enregistrer.")
                return redirect(
                    "tableau_de_bord:feuille-presence",
                    seance_id=seance.pk,
                )

    return render(
        request,
        "presences/presenceDetail.html",
        {
            **contexte,
            "seance": seance,
            "formset": formset,
            "erreur_feuille": erreur_feuille,
            "statut_annulee": seance.statut == StatutSeance.ANNULEE,
        },
    )


@login_required
@_page_privee
@require_GET
def historique_presence(request, presence_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    presence = get_object_or_404(
        Presence.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            seance__in=_seances_accessibles(workspace, request.user),
        ).select_related(
            "inscription__apprenant__personne",
            "seance__creneau__affectation__cours",
            "seance__creneau__affectation__groupe",
        ),
        pk=presence_id,
    )
    historique = (
        HistoriquePresence.objects.filter(
            tenant=workspace.tenant,
            institution=presence.institution,
            presence=presence,
        )
        .select_related("acteur")
        .order_by("-cree_le", "-id")
    )
    return render(
        request,
        "presences/historique.html",
        {
            **contexte,
            "presence": presence,
            "historique": historique,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def parametres_etablissement(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    if not contexte["role_gestion"]:
        raise DjangoPermissionDenied(
            _("Seuls les responsables peuvent modifier les paramètres de l’établissement.")
        )

    formulaire = FormulaireParametresEtablissement(
        request.POST if request.method == "POST" else None,
        request.FILES if request.method == "POST" else None,
        instance=workspace.tenant.institution,
    )
    if request.method == "POST" and formulaire.is_valid():
        try:
            modifier_referentiel(
                objet=formulaire.instance,
                acteur=request.user,
                valeurs=formulaire.cleaned_data,
            )
        except ValidationError as error:
            _ajouter_erreur_formulaire(formulaire, error)
        else:
            messages.success(
                request,
                _("Les paramètres de l’établissement ont été enregistrés."),
            )
            return redirect("tableau_de_bord:parametres")

    return render(
        request,
        "tableau_de_bord/parametres.html",
        {
            **contexte,
            "formulaire": formulaire,
        },
    )
