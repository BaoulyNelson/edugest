"""Formulaires de configuration de l’établissement."""

from django import forms
from django.conf import settings
from django.core.validators import RegexValidator
from django.utils import timezone

from applications.organisations.forms import TYPES_ETABLISSEMENT
from applications.referentiels.models import Institution

TAILLE_MAX_IMAGE_ETABLISSEMENT = 5 * 1024 * 1024
TYPES_IMAGE_ETABLISSEMENT = ("image/jpeg", "image/png", "image/webp")


class FormulaireParametresEtablissement(forms.ModelForm):
    """Champs d’établissement que les responsables peuvent modifier."""

    langue = forms.ChoiceField(choices=())
    type_educatif = forms.ChoiceField(
        choices=TYPES_ETABLISSEMENT,
        label="Type d’établissement",
    )
    devises_secondaires = forms.CharField(
        required=False,
        label="Devises secondaires",
        help_text="Codes de devise séparés par des virgules, par exemple USD, CAD.",
        widget=forms.Textarea(attrs={"rows": 2}),
    )
    telephone = forms.CharField(
        required=False,
        max_length=30,
        validators=[
            RegexValidator(
                r"^\+?[0-9 .()\-]{6,30}$",
                "Saisissez un numéro de téléphone valide.",
            )
        ],
    )
    annee_fondation = forms.IntegerField(
        required=False,
        min_value=1500,
        max_value=timezone.localdate().year,
        widget=forms.NumberInput(attrs={"min": "1500", "max": str(timezone.localdate().year)}),
    )
    couleur_principale = forms.CharField(
        widget=forms.TextInput(attrs={"type": "color"}),
    )
    site_web = forms.URLField(required=False, assume_scheme="https")
    logo = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={"accept": ",".join(TYPES_IMAGE_ETABLISSEMENT)}),
    )
    banniere = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={"accept": ",".join(TYPES_IMAGE_ETABLISSEMENT)}),
    )
    signature = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={"accept": ",".join(TYPES_IMAGE_ETABLISSEMENT)}),
    )

    class Meta:
        model = Institution
        fields = (
            "nom",
            "nom_court",
            "type_educatif",
            "code_officiel",
            "annee_fondation",
            "responsable",
            "slogan",
            "pays",
            "adresse",
            "departement",
            "commune",
            "telephone",
            "email_officiel",
            "site_web",
            "logo",
            "banniere",
            "signature",
            "couleur_principale",
            "langue",
            "devise_principale",
            "devises_secondaires",
            "fuseau_horaire",
            "format_date",
            "indicatif_telephonique",
        )
        labels = {
            "nom": "Nom de l’établissement",
            "nom_court": "Nom court (bulletins et en-têtes)",
            "type_educatif": "Type d’établissement",
            "code_officiel": "Code officiel MENFP",
            "annee_fondation": "Année de fondation",
            "responsable": "Directeur ou responsable",
            "slogan": "Slogan",
            "pays": "Code pays",
            "adresse": "Adresse complète",
            "departement": "Département",
            "commune": "Commune",
            "telephone": "Téléphone officiel",
            "email_officiel": "E-mail officiel",
            "site_web": "Site web",
            "logo": "Logo",
            "banniere": "Bannière",
            "signature": "Signature ou cachet",
            "couleur_principale": "Couleur principale",
            "langue": "Langue",
            "devise_principale": "Devise principale",
            "devises_secondaires": "Devises secondaires",
            "fuseau_horaire": "Fuseau horaire",
            "format_date": "Format des dates",
            "indicatif_telephonique": "Indicatif téléphonique",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["langue"].choices = settings.LANGUAGES
        if self.instance.type_educatif and self.instance.type_educatif not in dict(
            TYPES_ETABLISSEMENT
        ):
            self.fields["type_educatif"].choices = (
                (self.instance.type_educatif, f"{self.instance.type_educatif} (actuel)"),
                *TYPES_ETABLISSEMENT,
            )
        self.initial["devises_secondaires"] = ", ".join(self.instance.devises_secondaires)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"

    def clean_annee_fondation(self):
        annee = self.cleaned_data.get("annee_fondation")
        if annee is not None and annee > timezone.localdate().year:
            raise forms.ValidationError("L’année de fondation ne peut pas être future.")
        return annee

    def _valider_image(self, champ):
        image = self.cleaned_data.get(champ)
        if image and hasattr(image, "content_type"):
            if image.size > TAILLE_MAX_IMAGE_ETABLISSEMENT:
                raise forms.ValidationError("L’image ne doit pas dépasser 5 Mo.")
            if image.content_type not in TYPES_IMAGE_ETABLISSEMENT:
                raise forms.ValidationError("Utilisez une image JPG, PNG ou WEBP.")
        return image

    def clean_logo(self):
        return self._valider_image("logo")

    def clean_banniere(self):
        return self._valider_image("banniere")

    def clean_signature(self):
        return self._valider_image("signature")

    def clean_devises_secondaires(self):
        return [
            devise.strip()
            for devise in self.cleaned_data["devises_secondaires"].split(",")
            if devise.strip()
        ]
