"""Routes HTML du tableau de bord."""

from django.urls import path

from applications.tableau_de_bord.views import (
    creer_candidature,
    detail_candidature_web,
    exporter_candidatures_csv,
    feuille_presence,
    historique_presence,
    importer_candidatures,
    lier_compte_apprenant,
    liste_apprenants,
    liste_candidatures,
    liste_groupes,
    liste_notifications,
    liste_presences,
    marquer_notifications_lues,
    ouvrir_notification,
    parametres_etablissement,
    recherche_globale,
    rediriger_accueil,
    tableau_de_bord,
    transitionner_candidature_web,
)

app_name = "tableau_de_bord"

urlpatterns = [
    path("", rediriger_accueil, name="racine"),
    path("tableau-de-bord/", tableau_de_bord, name="accueil"),
    path("espace/parametres/", parametres_etablissement, name="parametres"),
    path("espace/recherche/", recherche_globale, name="recherche"),
    path("espace/notifications/", liste_notifications, name="notifications"),
    path(
        "espace/notifications/marquer-toutes-lues/",
        marquer_notifications_lues,
        name="notifications-marquer-lues",
    ),
    path(
        "espace/notifications/<uuid:notification_id>/ouvrir/",
        ouvrir_notification,
        name="notification-ouvrir",
    ),
    path("espace/apprenants/", liste_apprenants, name="apprenants"),
    path(
        "espace/apprenants/<uuid:apprenant_id>/compte/",
        lier_compte_apprenant,
        name="lier-compte-apprenant",
    ),
    path("espace/candidatures/", liste_candidatures, name="candidatures"),
    path(
        "espace/candidatures/importer/",
        importer_candidatures,
        name="importer-candidatures",
    ),
    path(
        "espace/candidatures/exporter.csv",
        exporter_candidatures_csv,
        name="exporter-candidatures",
    ),
    path("espace/candidatures/creer/", creer_candidature, name="creer-candidature"),
    path(
        "espace/candidatures/<uuid:candidature_id>/",
        detail_candidature_web,
        name="detail-candidature",
    ),
    path(
        "espace/candidatures/<uuid:candidature_id>/<str:nouveau_statut>/",
        transitionner_candidature_web,
        name="transition-candidature",
    ),
    path("espace/groupes/", liste_groupes, name="groupes"),
    path("espace/presences/", liste_presences, name="presences"),
    path(
        "espace/presences/<uuid:seance_id>/",
        feuille_presence,
        name="feuille-presence",
    ),
    path(
        "espace/presences/historique/<uuid:presence_id>/",
        historique_presence,
        name="historique-presence",
    ),
]
