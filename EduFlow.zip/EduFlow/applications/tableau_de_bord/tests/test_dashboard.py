"""Tests du rendu HTML authentifié et de l’isolation du tableau de bord."""

import io
import uuid
from datetime import date, time

import pytest
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client
from django.urls import reverse
from django.utils import timezone
from PIL import Image

from applications.abonnements.models import Abonnement
from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.admissions.models import Candidature, StatutCandidature
from applications.admissions.services import transitionner_candidature
from applications.emplois_temps.models import (
    AffectationEnseignement,
    CreneauHoraire,
    Seance,
)
from applications.inscriptions.models import Inscription, StatutInscription
from applications.notifications.models import Notification
from applications.notifications.services import creer_notification
from applications.organisations.models import (
    AdhesionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
    StatutTenant,
    Tenant,
)
from applications.personnes.models import Personne, ProfilApprenant, ProfilEnseignant
from applications.presences.forms import FiltreDatePresenceForm
from applications.presences.models import HistoriquePresence, Presence, StatutPresence
from applications.referentiels.models import (
    AnneeAcademique,
    Cours,
    Groupe,
    Institution,
    Programme,
    StatutAnneeAcademique,
)

pytestmark = pytest.mark.django_db


def test_presence_date_filter_renders_native_date_format():
    form = FiltreDatePresenceForm(initial={"date": date(2026, 3, 2)})

    assert 'value="2026-03-02"' in str(form["date"])


def _creer_utilisateur(email, *, first_name=""):
    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        first_name=first_name,
        email_verifie_le=timezone.now(),
    )


def _creer_tenant(nom, proprietaire):
    tenant = Tenant.objects.create(
        nom=nom,
        statut=StatutTenant.ACTIF,
        cle_idempotence=uuid.uuid4(),
        cree_par=proprietaire,
    )
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=f"Établissement {nom}",
        type_educatif="ecole",
        cree_par=proprietaire,
    )
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=proprietaire,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    rendre_tenant_abonne(tenant, proprietaire)
    return tenant, institution


def _creer_donnees_educatives(tenant, institution, acteur, identifiant):
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        nom="2025-2026",
        debut=date(2025, 9, 1),
        fin=date(2026, 6, 30),
        statut=StatutAnneeAcademique.ACTIVE,
    )
    programme = Programme.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        code=f"programme-{identifiant.lower()}",
        nom=f"Programme {identifiant}",
    )
    groupe = Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        annee_academique=annee,
        programme=programme,
        code=f"groupe-{identifiant.lower()}",
        nom=f"Groupe {identifiant}",
    )
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        prenom=f"Prénom {identifiant}",
        nom=f"Nom {identifiant}",
    )
    candidature = Candidature.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        reference=f"CAND-{identifiant}",
        personne=personne,
        annee_academique=annee,
        programme=programme,
        statut=StatutCandidature.SOUMISE,
    )
    apprenant = ProfilApprenant.objects.create(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        personne=personne,
    )
    Inscription.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        candidature=candidature,
        apprenant=apprenant,
        annee_academique=annee,
        programme=programme,
        groupe=groupe,
        statut=StatutInscription.ACTIVE,
        date_debut=date(2025, 9, 1),
    )
    return {
        "annee": annee,
        "programme": programme,
        "groupe": groupe,
    }


def test_anonymous_dashboard_access_redirects_to_login():
    response = Client().get(reverse("tableau_de_bord:accueil"))

    assert response.status_code == 302
    assert response["Location"] == "/connexion/?next=/tableau-de-bord/"


def test_root_shows_public_homepage_to_anonymous_users():
    response = Client().get("/")

    assert response.status_code == 200
    assert "Créer mon établissement" in response.content.decode()


def test_root_redirects_authenticated_users_to_existing_dashboard():
    utilisateur = _creer_utilisateur("root-dashboard@example.org")
    client = Client()
    client.force_login(utilisateur)

    response = client.get("/")

    assert response.status_code == 302
    assert response["Location"] == reverse("tableau_de_bord:accueil")


def test_owner_dashboard_quick_links_follow_the_setup_and_operations_order():
    proprietaire = _creer_utilisateur("owner-quick-links@example.org")
    tenant, _ = _creer_tenant("Parcours propriétaire", proprietaire)
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()

    response = client.get(reverse("tableau_de_bord:accueil"))
    contenu = response.content.decode()
    urls = [
        reverse("parcours_tenant:mes-etablissements"),
        reverse("annees-academiques"),
        reverse("campus"),
        reverse("programmes"),
        reverse("niveaux"),
        reverse("cours"),
        reverse("groupes"),
        reverse("parcours_tenant:equipe"),
        reverse("personnes_web:enseignants"),
        reverse("tableau_de_bord:candidatures"),
        reverse("tableau_de_bord:apprenants"),
        reverse("inscriptions_web:gestion"),
        reverse("emplois_temps_web:gestion"),
        reverse("tableau_de_bord:presences"),
        reverse("finances_web:accueil"),
        reverse("rapports_web:accueil"),
    ]

    assert response.status_code == 200
    assert "Les espaces utiles à votre activité." in contenu
    assert contenu.count('class="dashboard-quicklink-step"') == len(urls)
    panneau_lateral = contenu.split('<aside class="app-sidebar">', 1)[1].split(
        "</aside>",
        1,
    )[0]
    for url in urls:
        assert f'href="{url}"' in panneau_lateral
    liens_rapides = contenu.split('class="dashboard-panel dashboard-quicklinks"', 1)[
        1
    ].split("</section>", 1)[0]
    manquants = [url for url in urls if f'href="{url}"' not in liens_rapides]
    assert not manquants, manquants
    positions = [liens_rapides.index(f'href="{url}"') for url in urls]
    assert positions == sorted(
        positions
    )


def test_manager_can_link_an_active_member_account_to_an_apprenant_only_within_tenant():
    proprietaire = _creer_utilisateur("link-learner-owner@example.org")
    tenant, institution = _creer_tenant("Liaison apprenant", proprietaire)
    _creer_donnees_educatives(tenant, institution, proprietaire, "LINK")
    apprenant = ProfilApprenant.objects.get(tenant=tenant)

    proprietaire_etranger = _creer_utilisateur("link-learner-foreign-owner@example.org")
    tenant_etranger, _ = _creer_tenant("Liaison étrangère", proprietaire_etranger)
    compte_etranger = _creer_utilisateur("link-learner-foreign@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant_etranger,
        utilisateur=compte_etranger,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire_etranger,
    )
    compte_local = _creer_utilisateur("link-learner-local@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=compte_local,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )

    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    url = reverse(
        "tableau_de_bord:lier-compte-apprenant",
        kwargs={"apprenant_id": apprenant.pk},
    )

    refus = client.post(url, {"compte": str(compte_etranger.pk)})
    assert refus.status_code == 200
    assert not ProfilApprenant.objects.get(pk=apprenant.pk).compte_id

    liaison = client.post(url, {"compte": str(compte_local.pk)})

    assert liaison.status_code == 302
    assert ProfilApprenant.objects.get(pk=apprenant.pk).compte == compte_local

    client.force_login(compte_local)
    tableau = client.get(reverse("tableau_de_bord:accueil"))

    assert tableau.status_code == 200
    contenu = tableau.content.decode()
    assert "Espace apprenant" in contenu
    assert reverse("pedagogie:apprentissage") in contenu
    assert contenu.count('class="dashboard-primary-link"') == 1
    assert f'href="{reverse("pedagogie:apprentissage")}"' in contenu
    assert "Mes cours" in contenu


def test_platform_operator_without_tenant_sees_saas_dashboard_not_educational_records():
    operateur = _creer_utilisateur("platform-dashboard@example.org")
    operateur.is_superuser = True
    operateur.is_staff = True
    operateur.save(update_fields=("is_superuser", "is_staff"))
    proprietaire = _creer_utilisateur("platform-dashboard-owner@example.org")
    tenant, _ = _creer_tenant("Établissement opérationnel", proprietaire)
    tenant.statut = StatutTenant.ACTIF
    tenant.save(update_fields=("statut",))
    client = Client()
    client.force_login(operateur)

    response = client.get(reverse("tableau_de_bord:accueil"))
    contenu = response.content.decode()

    assert response.status_code == 200
    assert response.content.decode().count('class="mobile-nav-item') == 5
    assert response.content.decode().count("mobile-drawer-duplicate") == 3
    assert "Pilotage des établissements, abonnements et opérations SaaS." in contenu
    assert "Vue d’ensemble de la plateforme" in contenu
    assert "Établissement opérationnel" in contenu
    assert f'href="{reverse("administration_saas:etablissements")}"' in contenu
    assert "Abonnements actifs" in contenu
    assert "Plans disponibles" in contenu
    assert contenu.count('class="dashboard-primary-link"') == 1
    assert "Piloter la plateforme" in contenu
    assert 'class="global-search-form"' not in contenu
    assert 'class="notification-link"' not in contenu
    assert 'class="message-link"' not in contenu
    assert response.context["dashboard_stats"][0]["url"] == ("administration_saas:etablissements")
    assert response.context["dashboard_stats"][1]["query"] == "?statut=actif"
    assert f'href="{reverse("administration_saas:abonnements")}?statut=actif"' in contenu
    assert "Aucun établissement accessible" not in contenu
    assert "Administration technique" not in contenu
    for model_admin in (
        "organisations_tenant",
        "comptes_compteutilisateur",
        "organisations_evenementaudit",
    ):
        assert reverse(f"admin:{model_admin}_changelist") in contenu
    assert response.context["abonnements_actifs"] == 1
    assert response.context["plans_actifs"] == 1
    assert response.context["nombre_modeles_admin"] == sum(
        len(application["modeles"]) for application in response.context["catalogue_admin"]
    )
    comptes_admin = next(
        modele
        for application in response.context["catalogue_admin"]
        for modele in application["modeles"]
        if modele["url"] == reverse("admin:comptes_compteutilisateur_changelist")
    )
    assert comptes_admin["nombre"] >= 2
    assert any(
        "platform-dashboard@example.org" in str(compte)
        for compte in comptes_admin["elements_recents"]
    )
    assert reverse("admin:organisations_demandeinscriptiontenant_changelist") in contenu
    assert EvenementAudit.objects.filter(
        acteur=operateur,
        tenant__isnull=True,
        action="operateur.tableau_de_bord.consulte",
    ).exists()


def test_platform_dashboard_see_all_links_to_tenant_directory():
    operateur = _creer_utilisateur("platform-dashboard-link@example.org")
    operateur.is_superuser = True
    operateur.is_staff = True
    operateur.save(update_fields=("is_superuser", "is_staff"))
    client = Client()
    client.force_login(operateur)

    response = client.get(reverse("tableau_de_bord:accueil"))

    assert response.status_code == 200
    assert f'href="{reverse("administration_saas:etablissements")}"' in response.content.decode()
    assert response.context["dashboard_stats"][0]["url"] == ("administration_saas:etablissements")


def test_staff_without_saas_permission_does_not_get_platform_dashboard():
    staff = _creer_utilisateur("platform-dashboard-staff@example.org")
    staff.is_staff = True
    staff.save(update_fields=("is_staff",))
    client = Client()
    client.force_login(staff)

    response = client.get(reverse("tableau_de_bord:accueil"))
    contenu = response.content.decode()

    assert response.status_code == 200
    assert "Aucun établissement accessible" in contenu
    assert "Vue d’ensemble de la plateforme" not in contenu
    assert "Données de toute la plateforme" not in contenu
    assert reverse("admin:comptes_compteutilisateur_changelist") not in contenu


def test_global_search_is_limited_to_the_active_tenant():
    proprietaire = _creer_utilisateur("search-owner@example.org")
    tenant_actif, _ = _creer_tenant("Recherche", proprietaire)
    tenant_secondaire, _ = _creer_tenant("Confidentiel", proprietaire)
    _creer_donnees_educatives(
        tenant_actif,
        tenant_actif.institution,
        proprietaire,
        "RechercheAlpha",
    )
    _creer_donnees_educatives(
        tenant_secondaire,
        tenant_secondaire.institution,
        proprietaire,
        "SecretBeta",
    )
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant_actif.pk)
    session.save()

    response = client.get(
        reverse("tableau_de_bord:recherche"),
        {"q": "RechercheAlpha"},
    )
    autre_tenant = client.get(
        reverse("tableau_de_bord:recherche"),
        {"q": "SecretBeta"},
    )

    assert response.status_code == 200
    assert "Groupe RechercheAlpha" in response.content.decode()
    assert "Prénom RechercheAlpha Nom RechercheAlpha" in response.content.decode()
    assert "Groupe SecretBeta" not in autre_tenant.content.decode()
    assert "Aucun élément accessible" in autre_tenant.content.decode()


def test_global_search_rejects_short_queries_and_hides_students_from_teachers():
    proprietaire = _creer_utilisateur("search-teacher-owner@example.org")
    tenant, institution = _creer_tenant("Recherche enseignante", proprietaire)
    enseignant = _creer_utilisateur("search-teacher@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=enseignant,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    _creer_donnees_educatives(tenant, institution, proprietaire, "PriveTeacher")
    client = Client()
    client.force_login(enseignant)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()

    trop_court = client.get(reverse("tableau_de_bord:recherche"), {"q": "x"})
    recherche_enseignant = client.get(
        reverse("tableau_de_bord:recherche"),
        {"q": "PriveTeacher"},
    )

    assert trop_court.status_code == 200
    assert "Saisissez au moins deux caractères." in trop_court.content.decode()
    assert recherche_enseignant.status_code == 200
    assert "Prénom PriveTeacher Nom PriveTeacher" not in recherche_enseignant.content.decode()
    assert "Groupe PriveTeacher" not in recherche_enseignant.content.decode()


def test_notifications_are_tenant_scoped_and_marked_read_with_post():
    proprietaire = _creer_utilisateur("notification-owner@example.org")
    tenant_actif, institution_active = _creer_tenant("Notifications", proprietaire)
    tenant_secondaire, institution_secondaire = _creer_tenant(
        "Notifications privées",
        proprietaire,
    )
    notification = creer_notification(
        tenant=tenant_actif,
        institution=institution_active,
        destinataire=proprietaire,
        titre="Nouvelle information",
        message="Un événement de l’établissement actif.",
        url="/tableau-de-bord/",
    )
    creer_notification(
        tenant=tenant_secondaire,
        institution=institution_secondaire,
        destinataire=proprietaire,
        titre="Information confidentielle",
    )
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant_actif.pk)
    session.save()

    liste = client.get(reverse("tableau_de_bord:notifications"))
    ouverte = client.post(
        reverse(
            "tableau_de_bord:notification-ouvrir",
            kwargs={"notification_id": notification.pk},
        )
    )
    liste_apres_lecture = client.get(reverse("tableau_de_bord:notifications"))

    assert liste.status_code == 200
    assert "Nouvelle information" in liste.content.decode()
    assert "Information confidentielle" not in liste.content.decode()
    assert "1 notification non lue" in liste.content.decode()
    assert ouverte.status_code == 302
    assert ouverte["Location"] == "/tableau-de-bord/"
    assert liste_apres_lecture.status_code == 200
    assert "Nouvelle information" in liste_apres_lecture.content.decode()
    assert "Non lue" not in liste_apres_lecture.content.decode()
    assert notification.__class__.objects.get(pk=notification.pk).lue_le is not None


def test_notification_rejects_external_redirect_urls():
    proprietaire = _creer_utilisateur("notification-url-owner@example.org")
    tenant, institution = _creer_tenant("Notification URL", proprietaire)

    with pytest.raises(ValidationError):
        creer_notification(
            tenant=tenant,
            institution=institution,
            destinataire=proprietaire,
            titre="Lien non sûr",
            url="https://example.org",
        )


def test_submitted_admission_notifies_other_active_managers():
    proprietaire = _creer_utilisateur("notification-admission-owner@example.org")
    tenant, institution = _creer_tenant("Admissions notifications", proprietaire)
    gestionnaire = _creer_utilisateur("notification-admission-manager@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=gestionnaire,
        role=RoleAdhesion.GESTIONNAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    _creer_donnees_educatives(
        tenant,
        institution,
        proprietaire,
        "NotificationAdmission",
    )
    candidature = Candidature.objects.get(
        tenant=tenant,
        personne__prenom="Prénom NotificationAdmission",
    )
    candidature.statut = StatutCandidature.BROUILLON
    candidature.save(update_fields=("statut",))

    transitionner_candidature(
        candidature_id=candidature.pk,
        tenant=tenant,
        acteur=proprietaire,
        nouveau_statut=StatutCandidature.SOUMISE,
    )

    assert Notification.objects.filter(
        destinataire=gestionnaire,
        tenant=tenant,
        categorie="admission",
        titre="Nouvelle candidature à traiter",
    ).exists()
    assert not Notification.objects.filter(
        destinataire=proprietaire,
        tenant=tenant,
        titre="Nouvelle candidature à traiter",
    ).exists()


def test_login_redirects_to_dashboard_and_honors_next():
    utilisateur = _creer_utilisateur("dashboard-login@example.org")
    client = Client()

    response = client.post(
        reverse("connexion"),
        {"username": utilisateur.email, "password": "mot-de-passe-solide"},
    )

    assert response.status_code == 302
    assert response["Location"] == reverse("tableau_de_bord:accueil")

    response = Client().post(
        reverse("connexion"),
        {
            "username": utilisateur.email,
            "password": "mot-de-passe-solide",
            "next": reverse("parcours_tenant:equipe"),
        },
    )

    assert response.status_code == 302
    assert response["Location"] == reverse("parcours_tenant:equipe")


def test_logout_remains_post_only_and_requires_csrf():
    utilisateur = _creer_utilisateur("dashboard-logout@example.org")
    client = Client(enforce_csrf_checks=True)
    client.force_login(utilisateur)

    page = client.get(reverse("tableau_de_bord:accueil"))
    sans_csrf = client.post(reverse("deconnexion"))
    jeton_csrf = client.cookies["csrftoken"].value
    avec_csrf = client.post(
        reverse("deconnexion"),
        HTTP_X_CSRFTOKEN=jeton_csrf,
    )
    dashboard_apres_deconnexion = client.get(reverse("tableau_de_bord:accueil"))

    assert page.status_code == 200
    assert sans_csrf.status_code == 403
    assert avec_csrf.status_code == 302
    assert avec_csrf["Location"] == reverse("connexion")
    assert dashboard_apres_deconnexion.status_code == 302
    contenu = page.content.decode()
    assert contenu.count("data-open-logout-dialog") == 2
    assert '<dialog class="logout-dialog"' in contenu
    assert "Voulez-vous vraiment vous déconnecter" in contenu
    assert "Rester connecté" in contenu
    assert 'method="post" action="/deconnexion/"' in contenu
    assert 'name="csrfmiddlewaretoken"' in contenu


def test_authenticated_dashboard_shows_only_current_users_active_memberships():
    utilisateur = _creer_utilisateur(
        "dashboard-owner@example.org",
        first_name="Ari",
    )
    autre_utilisateur = _creer_utilisateur("other-owner@example.org")
    gestionnaire = _creer_utilisateur("dashboard-teacher@example.org")
    tenant, institution = _creer_tenant("École visible", utilisateur)
    tenant_autre, institution_autre = _creer_tenant("École privée", autre_utilisateur)
    AdhesionTenant.objects.create(
        tenant=tenant_autre,
        utilisateur=utilisateur,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.SUSPENDUE,
        cree_par=autre_utilisateur,
    )
    tenant_enseignant, institution_enseignant = _creer_tenant(
        "École enseignante",
        gestionnaire,
    )
    AdhesionTenant.objects.create(
        tenant=tenant_enseignant,
        utilisateur=utilisateur,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=gestionnaire,
    )
    client = Client()
    client.force_login(utilisateur)

    response = client.get(reverse("tableau_de_bord:accueil"))
    password_reset_page = client.get(reverse("password_reset"))

    assert response.status_code == 200
    assert password_reset_page.status_code == 200
    assert response["Cache-Control"] == "private, no-store"
    assert response["X-Robots-Tag"] == "noindex, nofollow"
    assert "Ari" in response.content.decode()
    assert institution.nom in response.content.decode()
    assert institution_enseignant.nom in response.content.decode()
    assert institution_autre.nom not in response.content.decode()
    assert reverse("password_reset") in response.content.decode()
    assert 'action="/deconnexion/"' in response.content.decode()
    assert 'href="#"' not in response.content.decode()
    assert "/api/v1/" not in response.content.decode()
    assert "Mme Ria" not in response.content.decode()
    assert "12 tâches" not in response.content.decode()


def test_tenant_selection_is_membership_scoped_and_dashboard_is_role_aware():
    utilisateur = _creer_utilisateur("tenant-switch@example.org")
    autre_utilisateur = _creer_utilisateur("tenant-owner@example.org")
    tenant_a, institution_a = _creer_tenant("Tenant A", utilisateur)
    tenant_b, institution_b = _creer_tenant("Tenant B", autre_utilisateur)
    AdhesionTenant.objects.create(
        tenant=tenant_b,
        utilisateur=utilisateur,
        role=RoleAdhesion.GESTIONNAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=autre_utilisateur,
    )
    _creer_donnees_educatives(tenant_a, institution_a, utilisateur, "ALPHA")
    _creer_donnees_educatives(tenant_b, institution_b, autre_utilisateur, "BRAVO")
    institution_a.format_date = "YYYY-MM-DD"
    institution_a.save(update_fields=("format_date",))

    client = Client()
    client.force_login(utilisateur)
    forbidden = client.post(
        reverse("tableau_de_bord:accueil"),
        {"tenant_id": str(uuid.uuid4())},
    )
    selection = client.post(
        reverse("tableau_de_bord:accueil"),
        {"tenant_id": str(tenant_a.pk)},
    )
    dashboard = client.get(reverse("tableau_de_bord:accueil"))

    assert forbidden.status_code == 404
    assert selection.status_code == 302
    assert dashboard.status_code == 200
    assert "Propriétaire" in dashboard.content.decode()
    contenu = dashboard.content.decode()
    assert "2025-2026" in contenu
    assert institution_b.nom in contenu
    assert 'class="tenant-switcher-logo"' in contenu
    assert "tenant-switcher-option" in contenu
    assert contenu.count("Établissement actif : Établissement Tenant A.") == 1
    assert contenu.count('class="dashboard-primary-link"') == 1
    assert f'href="{reverse("parcours_tenant:mes-etablissements")}"' in contenu
    assert "Créer un autre établissement" not in contenu
    assert contenu.count('class="mobile-nav-item') == 5
    assert f'href="{reverse("parcours_tenant:mes-etablissements")}"' in contenu
    assert "Mes établissements" in contenu
    assert reverse("parcours_tenant:inscription") in contenu
    assert reverse("rapports_web:accueil") in contenu
    assert f'href="{reverse("evaluations_web:liste")}"' not in contenu
    assert f'href="{reverse("pedagogie:devoirs")}"' not in contenu
    assert f'href="{reverse("pedagogie:quiz")}"' not in contenu
    assert [item["valeur"] for item in dashboard.context["statistiques"]] == [1, 1, 1]

    apprenants = client.get(reverse("tableau_de_bord:apprenants"))
    candidatures = client.get(reverse("tableau_de_bord:candidatures"))
    groupes = client.get(reverse("tableau_de_bord:groupes"))

    assert apprenants.status_code == 200
    assert "Prénom ALPHA Nom ALPHA" in apprenants.content.decode()
    assert "Prénom BRAVO Nom BRAVO" not in apprenants.content.decode()
    assert candidatures.status_code == 200
    assert "CAND-ALPHA" in candidatures.content.decode()
    assert "CAND-BRAVO" not in candidatures.content.decode()
    candidature_alpha = Candidature.objects.get(reference="CAND-ALPHA")
    assert timezone.localtime(candidature_alpha.cree_le).date().isoformat() in (
        candidatures.content.decode()
    )
    assert groupes.status_code == 200
    assert "Groupe ALPHA" in groupes.content.decode()
    assert "Groupe BRAVO" not in groupes.content.decode()

    client.post(
        reverse("tableau_de_bord:accueil"),
        {"tenant_id": str(tenant_b.pk)},
    )
    donnees_tenant_b = client.get(reverse("tableau_de_bord:apprenants"))
    assert donnees_tenant_b.status_code == 200
    assert "Prénom BRAVO Nom BRAVO" in donnees_tenant_b.content.decode()
    assert "Prénom ALPHA Nom ALPHA" not in donnees_tenant_b.content.decode()


def test_teacher_cannot_open_management_lists_or_see_other_groups():
    proprietaire = _creer_utilisateur("owner-teacher-access@example.org")
    enseignant = _creer_utilisateur("teacher-access@example.org")
    tenant, institution = _creer_tenant("Tenant enseignant", proprietaire)
    adhesion = AdhesionTenant.objects.get(tenant=tenant, utilisateur=proprietaire)
    adhesion.utilisateur = enseignant
    adhesion.role = RoleAdhesion.ENSEIGNANT
    adhesion.save(update_fields=("utilisateur", "role"))
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        proprietaire,
        "ENSEIGNANT",
    )
    Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        annee_academique=donnees["annee"],
        programme=donnees["programme"],
        code="groupe-non-affecte",
        nom="Groupe non affecté",
    )
    cours = Cours.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        code="cours-enseignant",
        nom="Cours enseignant",
    )
    personne_enseignant = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        prenom="Prof",
        nom="Enseignant",
    )
    profil = ProfilEnseignant.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        personne=personne_enseignant,
        compte=enseignant,
    )
    AffectationEnseignement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        enseignant=profil,
        annee_academique=donnees["annee"],
        groupe=donnees["groupe"],
        cours=cours,
        date_debut=date(2026, 1, 1),
        date_fin=date(2026, 6, 30),
    )

    client = Client()
    client.force_login(enseignant)
    dashboard = client.get(reverse("tableau_de_bord:accueil"))
    apprenants = client.get(reverse("tableau_de_bord:apprenants"))
    candidatures = client.get(reverse("tableau_de_bord:candidatures"))
    creer_candidature = client.get(reverse("tableau_de_bord:creer-candidature"))
    groupes = client.get(reverse("tableau_de_bord:groupes"))

    assert dashboard.status_code == 200
    assert dashboard.content.decode().count('class="mobile-nav-item') == 5
    contenu = dashboard.content.decode()
    assert "Espace enseignant" in contenu
    assert "Cours enseignant" in contenu
    assert contenu.count('class="dashboard-primary-link"') == 1
    assert f'href="{reverse("tableau_de_bord:groupes")}"' in contenu
    assert "Mes cours" in contenu
    assert [item["valeur"] for item in dashboard.context["statistiques"]] == [1, 1]
    assert "Apprenants" not in dashboard.content.decode()
    assert apprenants.status_code == 403
    assert candidatures.status_code == 403
    assert creer_candidature.status_code == 403
    assert groupes.status_code == 200
    assert "Groupe ENSEIGNANT" in groupes.content.decode()
    assert "Groupe non affecté" not in groupes.content.decode()


def test_missing_active_subscription_blocks_tenant_data():
    utilisateur = _creer_utilisateur("tenant-no-subscription@example.org")
    tenant, institution = _creer_tenant("Tenant sans abonnement", utilisateur)
    _creer_donnees_educatives(tenant, institution, utilisateur, "BLOQUE")
    Abonnement.objects.filter(tenant=tenant).delete()

    client = Client()
    client.force_login(utilisateur)
    dashboard = client.get(reverse("tableau_de_bord:accueil"))
    groupes = client.get(reverse("tableau_de_bord:groupes"))

    assert dashboard.status_code == 200
    assert "Accès temporairement indisponible" in dashboard.content.decode()
    assert "BLOQUE" not in dashboard.content.decode()
    assert groupes.status_code == 403


def test_native_admission_workflow_creates_draft_then_profile_only_on_acceptance():
    utilisateur = _creer_utilisateur("admission-web@example.org")
    tenant, institution = _creer_tenant("Admissions web", utilisateur)
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        utilisateur,
        "WEB",
    )
    client = Client(enforce_csrf_checks=True)
    client.force_login(utilisateur)
    creation_url = reverse("tableau_de_bord:creer-candidature")

    creation_page = client.get(creation_url)
    csrf_token = client.cookies["csrftoken"].value
    cle = creation_page.context["form"].initial["cle_idempotence"]
    payload = {
        "cle_idempotence": str(cle),
        "prenom": "Camille",
        "nom": "Candidat",
        "date_naissance": "2010-03-15",
        "courriel": "CAM.PILLE@example.org",
        "telephone": "509-555-0101",
        "identifiant_externe": " cand-2026 ",
        "annee_academique": str(donnees["annee"].pk),
        "programme": str(donnees["programme"].pk),
    }

    sans_csrf = client.post(creation_url, payload)
    response = client.post(
        creation_url,
        payload,
        HTTP_X_CSRFTOKEN=csrf_token,
    )

    assert creation_page.status_code == 200
    assert sans_csrf.status_code == 403
    assert response.status_code == 302
    candidature = Candidature.objects.get(
        tenant=tenant,
        personne__identifiant_externe="CAND-2026",
    )
    assert candidature.statut == StatutCandidature.BROUILLON
    assert candidature.personne.courriel == "cam.pille@example.org"
    assert (
        ProfilApprenant.objects.filter(
            tenant=tenant,
            personne=candidature.personne,
        ).exists()
        is False
    )
    assert "Soumettre" in client.get(reverse("tableau_de_bord:candidatures")).content.decode()
    detail_url = reverse(
        "tableau_de_bord:detail-candidature",
        args=(candidature.pk,),
    )
    detail = client.get(detail_url)
    modification = client.post(
        detail_url,
        {
            "prenom": "Camille",
            "nom": "Candidat corrigé",
            "date_naissance": "2010-03-15",
            "courriel": "camille.corrige@example.org",
            "telephone": "509-555-0102",
            "identifiant_externe": "CAND-2026",
            "annee_academique": str(donnees["annee"].pk),
            "programme": str(donnees["programme"].pk),
        },
        HTTP_X_CSRFTOKEN=client.cookies["csrftoken"].value,
    )
    candidature.refresh_from_db()
    candidature.personne.refresh_from_db()
    assert detail.status_code == 200
    assert "Modifier le brouillon" in detail.content.decode()
    assert modification.status_code == 302
    assert candidature.personne.nom == "Candidat corrigé"
    assert candidature.personne.courriel == "camille.corrige@example.org"

    soumission_url = reverse(
        "tableau_de_bord:transition-candidature",
        args=(candidature.pk, StatutCandidature.SOUMISE),
    )
    assert client.get(soumission_url).status_code == 200
    csrf_token = client.cookies["csrftoken"].value
    assert (
        client.post(
            soumission_url,
            {"confirmation": "oui"},
            HTTP_X_CSRFTOKEN=csrf_token,
        ).status_code
        == 302
    )
    examen_url = reverse(
        "tableau_de_bord:transition-candidature",
        args=(candidature.pk, StatutCandidature.EN_EXAMEN),
    )
    assert (
        client.post(
            examen_url,
            {"confirmation": "oui"},
            HTTP_X_CSRFTOKEN=csrf_token,
        ).status_code
        == 302
    )

    admission_url = reverse(
        "tableau_de_bord:transition-candidature",
        args=(candidature.pk, StatutCandidature.ADMISE),
    )
    admission_page = client.get(admission_url)
    assert admission_page.status_code == 200
    assert "ne crée pas d’inscription scolaire" in admission_page.content.decode()
    admission = client.post(
        admission_url,
        {"confirmation": "oui"},
        HTTP_X_CSRFTOKEN=csrf_token,
    )

    assert admission.status_code == 302
    candidature.refresh_from_db()
    assert candidature.statut == StatutCandidature.ADMISE
    resultat_admission = client.get(reverse("tableau_de_bord:candidatures"))
    assert (
        f"La candidature {candidature.reference} est maintenant « Admise »."
        in resultat_admission.content.decode()
    )
    assert candidature.decidee_par == utilisateur
    assert ProfilApprenant.objects.filter(
        tenant=tenant,
        personne=candidature.personne,
    ).exists()
    assert not Inscription.objects.filter(candidature=candidature).exists()
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        acteur=utilisateur,
        action="admission.candidature_creee",
        id_objet=str(candidature.pk),
    ).exists()

    inscriptions_url = reverse("inscriptions_web:gestion")
    inscriptions_page = client.get(inscriptions_url)
    formulaire = inscriptions_page.context["formulaire"]
    creation_inscription = client.post(
        inscriptions_url,
        {
            "cle_idempotence": str(formulaire.initial["cle_idempotence"]),
            "candidature": str(candidature.pk),
            "groupe": str(donnees["groupe"].pk),
            "date_debut": "2025-09-01",
        },
        HTTP_X_CSRFTOKEN=csrf_token,
    )
    assert inscriptions_page.status_code == 200
    assert creation_inscription.status_code == 302
    inscription = Inscription.objects.get(candidature=candidature)
    assert inscription.apprenant.personne == candidature.personne
    assert inscription.groupe == donnees["groupe"]


def test_native_admission_form_rejects_foreign_references_and_duplicate_identifier():
    utilisateur = _creer_utilisateur("admission-scope@example.org")
    tenant, institution = _creer_tenant("Admission scope", utilisateur)
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        utilisateur,
        "SCOPE",
    )
    autre_utilisateur = _creer_utilisateur("admission-foreign@example.org")
    autre_tenant, autre_institution = _creer_tenant(
        "Admission étrangère",
        autre_utilisateur,
    )
    donnees_etrangeres = _creer_donnees_educatives(
        autre_tenant,
        autre_institution,
        autre_utilisateur,
        "FOREIGN",
    )
    client = Client()
    client.force_login(utilisateur)
    url = reverse("tableau_de_bord:creer-candidature")
    formulaire = client.get(url)
    cle = formulaire.context["form"].initial["cle_idempotence"]
    base = {
        "cle_idempotence": str(cle),
        "prenom": "Autre",
        "nom": "Candidat",
        "annee_academique": str(donnees["annee"].pk),
        "programme": str(donnees["programme"].pk),
    }
    personne_existante = Personne.objects.get(
        tenant=tenant,
        nom="Nom SCOPE",
    )
    personne_existante.identifiant_externe = "EL-SCOPE"
    personne_existante.save(update_fields=("identifiant_externe",))

    reference_etrangere = client.post(
        url,
        {
            **base,
            "annee_academique": str(donnees_etrangeres["annee"].pk),
            "programme": str(donnees_etrangeres["programme"].pk),
        },
    )
    identifiant_duplique = client.post(
        url,
        {
            **base,
            "identifiant_externe": "EL-SCOPE",
        },
    )

    assert reference_etrangere.status_code == 200
    assert "Sélectionnez un choix valide" in reference_etrangere.content.decode()
    assert identifiant_duplique.status_code == 200
    assert "déjà utilisé" in identifiant_duplique.content.decode()
    assert Candidature.objects.filter(tenant=tenant).count() == 1


def test_native_admission_transition_cannot_access_another_tenant_candidate():
    utilisateur = _creer_utilisateur("admission-isolation@example.org")
    _creer_tenant("Admissions isolées", utilisateur)
    autre_utilisateur = _creer_utilisateur("admission-isolation-other@example.org")
    autre_tenant, autre_institution = _creer_tenant(
        "Autres admissions",
        autre_utilisateur,
    )
    _creer_donnees_educatives(
        autre_tenant,
        autre_institution,
        autre_utilisateur,
        "OTHER",
    )
    candidature = Candidature.objects.get(
        tenant=autre_tenant,
        reference="CAND-OTHER",
    )
    client = Client()
    client.force_login(utilisateur)

    response = client.get(
        reverse(
            "tableau_de_bord:transition-candidature",
            args=(candidature.pk, StatutCandidature.EN_EXAMEN),
        )
    )

    assert response.status_code == 404
    candidature.refresh_from_db()
    assert candidature.tenant == autre_tenant
    assert candidature.statut == StatutCandidature.SOUMISE


def test_establishment_settings_are_editable_by_managers_only(tmp_path, settings):
    proprietaire = _creer_utilisateur("settings-owner@example.org")
    tenant, institution = _creer_tenant("Paramètres", proprietaire)
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    settings.MEDIA_ROOT = tmp_path
    image = io.BytesIO()
    Image.new("RGB", (2, 2), color="green").save(image, format="PNG")

    page = client.get(reverse("tableau_de_bord:parametres"))
    response = client.post(
        reverse("tableau_de_bord:parametres"),
        {
            "nom": "École des Paramètres",
            "type_educatif": "universite",
            "pays": "HT",
            "langue": "fr",
            "devise_principale": "HTG",
            "couleur_principale": "#2563EB",
            "devises_secondaires": "USD, CAD",
            "fuseau_horaire": "America/Port-au-Prince",
            "format_date": "YYYY-MM-DD",
            "indicatif_telephonique": "+509",
            "logo": SimpleUploadedFile(
                "logo.png",
                image.getvalue(),
                content_type="image/png",
            ),
        },
    )

    assert page.status_code == 200
    assert "Paramètres de l’établissement" in page.content.decode()
    assert 'enctype="multipart/form-data"' in page.content.decode()
    assert response.status_code == 302
    institution.refresh_from_db()
    assert institution.nom == "École des Paramètres"
    assert institution.format_date == "YYYY-MM-DD"
    assert institution.devises_secondaires == ["USD", "CAD"]
    assert institution.logo.name.startswith(f"institutions/{tenant.pk}/logos/")
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="referentiel.modifie",
        type_objet="referentiels.institution",
        id_objet=str(institution.pk),
    ).exists()

    invalide = client.post(
        reverse("tableau_de_bord:parametres"),
        {
            "nom": "École des Paramètres",
            "type_educatif": "universite",
            "pays": "HT",
            "langue": "fr",
            "devise_principale": "HTG",
            "couleur_principale": "#2563EB",
            "devises_secondaires": "USD, HTG",
            "fuseau_horaire": "America/Port-au-Prince",
            "format_date": "YYYY-MM-DD",
            "indicatif_telephonique": "+509",
        },
    )
    assert invalide.status_code == 200
    assert "devise principale ne doit pas être répétée" in invalide.content.decode()
    institution.refresh_from_db()
    assert institution.devises_secondaires == ["USD", "CAD"]

    enseignant = _creer_utilisateur("settings-teacher@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=enseignant,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client.force_login(enseignant)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()

    forbidden = client.get(reverse("tableau_de_bord:parametres"))

    assert forbidden.status_code == 403


def test_native_admission_csv_import_is_atomic_and_idempotent():
    utilisateur = _creer_utilisateur("admission-csv@example.org")
    tenant, institution = _creer_tenant("Admissions CSV", utilisateur)
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        utilisateur,
        "CSV",
    )
    client = Client()
    client.force_login(utilisateur)
    url = reverse("tableau_de_bord:importer-candidatures")
    contenu = (
        b"prenom,nom,date_naissance,courriel,telephone,identifiant_externe\n"
        b"Nadia,Import,2010-03-04,nadia@example.org,555-0101,CSV-001\n"
    )

    def importer(donnees_csv):
        return client.post(
            url,
            {
                "fichier_csv": SimpleUploadedFile(
                    "candidatures.csv",
                    donnees_csv,
                    content_type="text/csv",
                ),
                "annee_academique": str(donnees["annee"].pk),
                "programme": str(donnees["programme"].pk),
            },
        )

    premiere = importer(contenu)
    reprise = importer(contenu)

    assert premiere.status_code == 302
    assert reprise.status_code == 302
    assert Candidature.objects.filter(tenant=tenant).count() == 2
    personne = Personne.objects.get(tenant=tenant, identifiant_externe="CSV-001")
    candidature = Candidature.objects.get(tenant=tenant, personne=personne)
    assert candidature.statut == StatutCandidature.BROUILLON
    assert (
        EvenementAudit.objects.filter(
            tenant=tenant,
            action="admission.candidatures_importees",
        ).count()
        == 2
    )

    invalide = importer(
        b"prenom,nom,date_naissance,identifiant_externe\n"
        b"Lina,Valide,,CSV-002\n"
        b"Marc,Invalide,31-12-2010,CSV-003\n"
    )

    assert invalide.status_code == 200
    assert "Ligne 3" in invalide.content.decode()
    assert not Personne.objects.filter(tenant=tenant, identifiant_externe="CSV-002").exists()
    assert Candidature.objects.filter(tenant=tenant).count() == 2


def test_native_admission_csv_import_rejects_foreign_references_and_external_id_conflicts():
    utilisateur = _creer_utilisateur("admission-csv-scope@example.org")
    tenant, institution = _creer_tenant("Admissions CSV scope", utilisateur)
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        utilisateur,
        "SCOPE",
    )
    personne_existante = Personne.objects.get(tenant=tenant, nom="Nom SCOPE")
    personne_existante.identifiant_externe = "EXISTING-001"
    personne_existante.save(update_fields=("identifiant_externe",))

    autre_utilisateur = _creer_utilisateur("admission-csv-foreign@example.org")
    autre_tenant, autre_institution = _creer_tenant(
        "Admissions CSV étrangères",
        autre_utilisateur,
    )
    donnees_etrangeres = _creer_donnees_educatives(
        autre_tenant,
        autre_institution,
        autre_utilisateur,
        "FOREIGN",
    )
    client = Client()
    client.force_login(utilisateur)
    url = reverse("tableau_de_bord:importer-candidatures")

    def envoyer(annee, programme, identifiant):
        return client.post(
            url,
            {
                "fichier_csv": SimpleUploadedFile(
                    "candidatures.csv",
                    (f"prenom,nom,identifiant_externe\nAlex,Import,{identifiant}\n").encode(),
                    content_type="text/csv",
                ),
                "annee_academique": str(annee.pk),
                "programme": str(programme.pk),
            },
        )

    reference_etrangere = envoyer(
        donnees_etrangeres["annee"],
        donnees["programme"],
        "CSV-FOREIGN",
    )
    identifiant_duplique = envoyer(
        donnees["annee"],
        donnees["programme"],
        "existing-001",
    )

    assert reference_etrangere.status_code == 200
    assert identifiant_duplique.status_code == 200
    assert Candidature.objects.filter(tenant=tenant).count() == 1
    assert Candidature.objects.filter(tenant=autre_tenant).count() == 1


def test_native_admission_csv_export_is_tenant_scoped_audited_and_formula_safe():
    utilisateur = _creer_utilisateur("admission-export@example.org")
    tenant, institution = _creer_tenant("Admissions export", utilisateur)
    _creer_donnees_educatives(tenant, institution, utilisateur, "EXPORT")
    personne = Personne.objects.get(tenant=tenant, nom="Nom EXPORT")
    personne.nom = "=FORMULE()"
    personne.save(update_fields=("nom",))

    autre_utilisateur = _creer_utilisateur("admission-export-other@example.org")
    autre_tenant, autre_institution = _creer_tenant(
        "Admissions export autre",
        autre_utilisateur,
    )
    _creer_donnees_educatives(
        autre_tenant,
        autre_institution,
        autre_utilisateur,
        "OTHER",
    )
    client = Client()
    client.force_login(utilisateur)
    response = client.get(reverse("tableau_de_bord:exporter-candidatures"))
    contenu = b"".join(response.streaming_content).decode("utf-8-sig")

    assert response.status_code == 200
    assert response["Content-Type"].startswith("text/csv")
    assert response["Cache-Control"] == "private, no-store"
    assert "CAND-EXPORT" in contenu
    assert "CAND-OTHER" not in contenu
    assert "'=FORMULE()" in contenu
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        acteur=utilisateur,
        action="admission.candidatures_exportees",
    ).exists()


def test_native_admission_csv_tools_are_restricted_to_management_roles():
    proprietaire = _creer_utilisateur("admission-csv-owner@example.org")
    tenant, institution = _creer_tenant("Admissions CSV roles", proprietaire)
    utilisateur = _creer_utilisateur("admission-csv-teacher@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=utilisateur,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client = Client()
    client.force_login(utilisateur)

    importation = client.get(reverse("tableau_de_bord:importer-candidatures"))
    exportation = client.get(reverse("tableau_de_bord:exporter-candidatures"))

    assert importation.status_code == 403
    assert exportation.status_code == 403


def _creer_seance_html(tenant, institution, acteur, donnees, enseignant, identifiant):
    cours = Cours.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        code=f"cours-presence-{identifiant.lower()}",
        nom=f"Cours {identifiant}",
    )
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        prenom=f"Prof {identifiant}",
        nom="Présence",
    )
    profil = ProfilEnseignant.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        personne=personne,
        compte=enseignant,
    )
    affectation = AffectationEnseignement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        enseignant=profil,
        annee_academique=donnees["annee"],
        groupe=donnees["groupe"],
        cours=cours,
        date_debut=date(2025, 9, 1),
        date_fin=date(2026, 6, 30),
    )
    creneau = CreneauHoraire.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        affectation=affectation,
        jour_semaine="lundi",
        heure_debut=time(8),
        heure_fin=time(9),
        date_debut=date(2025, 9, 1),
        date_fin=date(2026, 6, 30),
    )
    return Seance.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        creneau=creneau,
        date=date(2026, 3, 2),
        heure_debut=time(8),
        heure_fin=time(9),
        salle="Salle A",
    )


def test_native_attendance_sheet_records_and_audits_corrections():
    gestionnaire = _creer_utilisateur("presence-web-manager@example.org")
    tenant, institution = _creer_tenant("Présences web", gestionnaire)
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        gestionnaire,
        "PRESENCE",
    )
    seance = _creer_seance_html(
        tenant,
        institution,
        gestionnaire,
        donnees,
        gestionnaire,
        "PRESENCE",
    )
    inscription = Inscription.objects.get(tenant=tenant)
    client = Client()
    client.force_login(gestionnaire)

    liste = client.get(
        reverse("tableau_de_bord:presences"),
        {"date": seance.date.isoformat()},
    )
    feuille_url = reverse(
        "tableau_de_bord:feuille-presence",
        args=(seance.pk,),
    )
    feuille = client.get(feuille_url)
    payload = {
        "presences-TOTAL_FORMS": "1",
        "presences-INITIAL_FORMS": "1",
        "presences-MIN_NUM_FORMS": "0",
        "presences-MAX_NUM_FORMS": "1000",
        "presences-0-inscription_id": str(inscription.pk),
        "presences-0-statut": StatutPresence.PRESENTE,
        "presences-0-motif_correction": "",
    }
    saisie = client.post(feuille_url, payload)

    assert liste.status_code == 200
    assert "Cours PRESENCE" in liste.content.decode()
    assert feuille.status_code == 200
    assert "Prénom PRESENCE Nom PRESENCE" in feuille.content.decode()
    assert saisie.status_code == 302
    assert Presence.objects.get(seance=seance, inscription=inscription).statut == (
        StatutPresence.PRESENTE
    )
    assert (
        HistoriquePresence.objects.filter(
            presence__seance=seance,
            type_operation="saisie",
        ).count()
        == 1
    )

    payload["presences-0-statut"] = StatutPresence.ABSENTE
    correction_sans_motif = client.post(feuille_url, payload)
    assert correction_sans_motif.status_code == 200
    assert "motif" in correction_sans_motif.content.decode().lower()
    assert Presence.objects.get(seance=seance, inscription=inscription).statut == (
        StatutPresence.PRESENTE
    )

    payload["presences-0-motif_correction"] = "Erreur lors de la saisie initiale."
    correction = client.post(feuille_url, payload)
    assert correction.status_code == 302
    assert Presence.objects.get(seance=seance, inscription=inscription).statut == (
        StatutPresence.ABSENTE
    )
    assert HistoriquePresence.objects.filter(
        presence__seance=seance,
        type_operation="correction",
        motif_correction="Erreur lors de la saisie initiale.",
    ).exists()
    presence = Presence.objects.get(seance=seance, inscription=inscription)
    historique = client.get(reverse("tableau_de_bord:historique-presence", args=(presence.pk,)))
    assert historique.status_code == 200
    assert "Erreur lors de la saisie initiale." in historique.content.decode()


def test_teacher_attendance_pages_only_include_assigned_sessions():
    proprietaire = _creer_utilisateur("presence-teacher-owner@example.org")
    enseignant = _creer_utilisateur("presence-teacher@example.org")
    tenant, institution = _creer_tenant("Présences enseignant", proprietaire)
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=enseignant,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        proprietaire,
        "TEACHER",
    )
    seance_affectee = _creer_seance_html(
        tenant,
        institution,
        proprietaire,
        donnees,
        enseignant,
        "ASSIGNE",
    )
    seance_non_affectee = _creer_seance_html(
        tenant,
        institution,
        proprietaire,
        donnees,
        proprietaire,
        "AUTRE",
    )
    client = Client()
    client.force_login(enseignant)

    liste = client.get(
        reverse("tableau_de_bord:presences"),
        {"date": seance_affectee.date.isoformat()},
    )
    feuille_autorisee = client.get(
        reverse("tableau_de_bord:feuille-presence", args=(seance_affectee.pk,)),
    )
    feuille_interdite = client.get(
        reverse("tableau_de_bord:feuille-presence", args=(seance_non_affectee.pk,)),
    )

    assert liste.status_code == 200
    assert "Cours ASSIGNE" in liste.content.decode()
    assert "Cours AUTRE" not in liste.content.decode()
    assert feuille_autorisee.status_code == 200
    assert feuille_interdite.status_code == 404


def test_html_timetable_workflow_creates_a_session_visible_on_attendance_page():
    proprietaire = _creer_utilisateur("planning-owner@example.org")
    enseignant = _creer_utilisateur("planning-teacher@example.org")
    tenant, institution = _creer_tenant("Planification HTML", proprietaire)
    donnees = _creer_donnees_educatives(
        tenant,
        institution,
        proprietaire,
        "PLANNING",
    )
    personne_enseignant = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        prenom="Alex",
        nom="Enseignant",
    )
    profil_enseignant = ProfilEnseignant.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        personne=personne_enseignant,
        compte=enseignant,
    )
    cours = Cours.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        code="planning",
        nom="Cours de planification",
    )
    client = Client()
    client.force_login(proprietaire)
    planning_url = reverse("emplois_temps_web:gestion")
    planning_page = client.get(planning_url)

    affectation = client.post(
        planning_url,
        {
            "action": "affectation",
            "cle_idempotence": str(
                planning_page.context["formulaire_affectation"].initial["cle_idempotence"]
            ),
            "enseignant": str(profil_enseignant.pk),
            "annee_academique": str(donnees["annee"].pk),
            "groupe": str(donnees["groupe"].pk),
            "cours": str(cours.pk),
            "date_debut": "2025-09-01",
            "date_fin": "2026-06-30",
        },
    )
    assert planning_page.status_code == 200
    assert affectation.status_code == 302
    objet_affectation = AffectationEnseignement.objects.get(
        tenant=tenant,
        enseignant=profil_enseignant,
        cours=cours,
    )
    desactivation_affectation = client.post(
        planning_url,
        {
            "action": "activer_affectation",
            "objet_id": str(objet_affectation.pk),
            "actif": "false",
        },
    )
    objet_affectation.refresh_from_db()
    assert desactivation_affectation.status_code == 302
    assert not objet_affectation.actif
    client.post(
        planning_url,
        {
            "action": "activer_affectation",
            "objet_id": str(objet_affectation.pk),
            "actif": "true",
        },
    )
    objet_affectation.refresh_from_db()
    assert objet_affectation.actif
    creneau_page = client.get(planning_url)
    creneau = client.post(
        planning_url,
        {
            "action": "creneau",
            "cle_idempotence": str(
                creneau_page.context["formulaire_creneau"].initial["cle_idempotence"]
            ),
            "affectation": str(objet_affectation.pk),
            "jour_semaine": "lundi",
            "heure_debut": "08:00",
            "heure_fin": "09:00",
            "date_debut": "2025-09-01",
            "date_fin": "2026-06-30",
            "salle": "A1",
        },
    )
    assert creneau.status_code == 302
    objet_creneau = CreneauHoraire.objects.get(affectation=objet_affectation)
    desactivation_creneau = client.post(
        planning_url,
        {
            "action": "activer_creneau",
            "objet_id": str(objet_creneau.pk),
            "actif": "false",
        },
    )
    objet_creneau.refresh_from_db()
    assert desactivation_creneau.status_code == 302
    assert not objet_creneau.actif
    client.post(
        planning_url,
        {
            "action": "activer_creneau",
            "objet_id": str(objet_creneau.pk),
            "actif": "true",
        },
    )
    objet_creneau.refresh_from_db()
    assert objet_creneau.actif
    seance_page = client.get(planning_url)
    seance = client.post(
        planning_url,
        {
            "action": "seance",
            "cle_idempotence": str(
                seance_page.context["formulaire_seance"].initial["cle_idempotence"]
            ),
            "creneau": str(objet_creneau.pk),
            "date": "2026-03-02",
        },
    )
    assert seance.status_code == 302
    objet_seance = Seance.objects.get(creneau=objet_creneau, date=date(2026, 3, 2))
    assert objet_seance
    planning_jour = client.get(planning_url, {"date": "2026-03-02"})
    assert planning_jour.status_code == 200
    assert "Terminer" in planning_jour.content.decode()
    statut_seance = client.post(
        planning_url,
        {
            "action": "statut_seance",
            "objet_id": str(objet_seance.pk),
            "statut": "terminee",
        },
    )
    objet_seance.refresh_from_db()
    assert statut_seance.status_code == 302
    assert objet_seance.statut == "terminee"

    attendance = client.get(
        reverse("tableau_de_bord:presences"),
        {"date": "2026-03-02"},
    )
    assert attendance.status_code == 200
    assert "Cours de planification" in attendance.content.decode()
