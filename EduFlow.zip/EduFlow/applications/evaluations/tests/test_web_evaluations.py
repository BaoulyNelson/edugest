"""Parcours HTML de création, saisie et publication des évaluations."""

import uuid

import pytest
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.emplois_temps.tests.factories import (
    _creer_affectation,
    _creer_inscription,
    _preparer_tenant,
)
from applications.evaluations.models import (
    DocumentResultat,
    Evaluation,
    NoteEvaluation,
    StatutDocumentResultat,
    StatutEvaluation,
)
from applications.organisations.models import (
    AdhesionTenant,
    RoleAdhesion,
    StatutAdhesion,
)

pytestmark = pytest.mark.django_db


def _client_web(utilisateur, tenant):
    if utilisateur.email_verifie_le is None:
        utilisateur.email_verifie_le = timezone.now()
        utilisateur.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(utilisateur)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    return client


def _client_gestionnaire(contexte):
    gestionnaire = get_user_model().objects.create_user(
        f"manager-{uuid.uuid4().hex}@example.org",
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )
    AdhesionTenant.objects.create(
        tenant=contexte["tenant"],
        utilisateur=gestionnaire,
        role=RoleAdhesion.GESTIONNAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=contexte["proprietaire"],
    )
    return _client_web(gestionnaire, contexte["tenant"])


def test_web_evaluation_creation_grade_correction_and_publication():
    contexte = _preparer_tenant("assess-web-flow")
    affectation = _creer_affectation(contexte)
    inscription = _creer_inscription(contexte)
    page_liste = reverse("evaluations_web:liste")
    enseignant = _client_web(
        contexte["enseignant"]["compte"],
        contexte["tenant"],
    )
    gestionnaire = _client_gestionnaire(contexte)
    cle_idempotence = str(uuid.uuid4())

    liste = enseignant.get(page_liste)
    assert liste.status_code == 200
    assert liste["Cache-Control"] == "private, no-store"
    assert b"Nouvelle \xc3\xa9valuation" in liste.content

    creation = enseignant.post(
        page_liste,
        {
            "cle_idempotence": cle_idempotence,
            "affectation": affectation.pk,
            "periode": "",
            "titre": "Contrôle continu",
            "date_evaluation": "2026-09-10",
            "note_maximale": "20",
            "coefficient": "1",
        },
    )
    assert creation.status_code == 302
    reprise = enseignant.post(
        page_liste,
        {
            "cle_idempotence": cle_idempotence,
            "affectation": affectation.pk,
            "periode": "",
            "titre": "Contrôle continu",
            "date_evaluation": "2026-09-10",
            "note_maximale": "20",
            "coefficient": "1",
        },
    )
    assert reprise.status_code == 302
    evaluation = Evaluation.objects.get(titre="Contrôle continu")
    assert Evaluation.objects.filter(tenant=contexte["tenant"]).count() == 1
    url_detail = reverse(
        "evaluations_web:detail",
        args=(evaluation.pk,),
    )
    url_note = reverse(
        "evaluations_web:note",
        args=(evaluation.pk, inscription.pk),
    )
    url_publication = reverse("evaluations_web:publier", args=(evaluation.pk,))
    assert enseignant.get(url_detail).status_code == 200

    publication_incomplete = gestionnaire.post(url_publication)
    assert publication_incomplete.status_code == 302
    evaluation.refresh_from_db()
    assert evaluation.statut == StatutEvaluation.BROUILLON

    saisie = enseignant.post(url_note, {"note": "15"})
    assert saisie.status_code == 302
    note = NoteEvaluation.objects.get(evaluation=evaluation)
    assert note.note == 15

    correction_sans_motif = gestionnaire.post(url_note, {"note": "16"})
    assert correction_sans_motif.status_code == 302
    note.refresh_from_db()
    assert note.note == 15

    correction = gestionnaire.post(
        url_note,
        {"note": "16", "motif_correction": "Erreur de saisie vérifiée."},
    )
    assert correction.status_code == 302
    note.refresh_from_db()
    assert note.note == 16

    publication_enseignant = enseignant.post(url_publication)
    assert publication_enseignant.status_code == 403
    publication = gestionnaire.post(url_publication)
    assert publication.status_code == 302
    evaluation.refresh_from_db()
    assert evaluation.statut == StatutEvaluation.PUBLIEE

    correction_enseignant = enseignant.post(url_note, {"note": "17"})
    assert correction_enseignant.status_code == 403
    correction_gestionnaire = gestionnaire.post(
        url_note,
        {"note": "17", "motif_correction": "Rectification approuvée."},
    )
    assert correction_gestionnaire.status_code == 302
    note.refresh_from_db()
    assert note.note == 17


def test_web_evaluations_are_tenant_and_role_scoped():
    contexte = _preparer_tenant("assess-web-scope-a")
    autre_contexte = _preparer_tenant("assess-web-scope-b")
    affectation = _creer_affectation(contexte)
    evaluation = Evaluation.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        affectation_id=affectation.pk,
        titre="Évaluation privée",
        date_evaluation="2026-09-10",
        note_maximale="20",
        coefficient="1",
    )
    membre = get_user_model().objects.create_user(
        "assess-web-member@example.org",
        "mot-de-passe-solide",
    )
    AdhesionTenant.objects.create(
        tenant=contexte["tenant"],
        utilisateur=membre,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=contexte["proprietaire"],
    )

    autre_tenant = _client_gestionnaire(autre_contexte)
    membre_web = _client_web(membre, contexte["tenant"])
    proprietaire_web = _client_web(contexte["proprietaire"], contexte["tenant"])
    url_detail = reverse("evaluations_web:detail", args=(evaluation.pk,))
    url_liste = reverse("evaluations_web:liste")

    assert autre_tenant.get(url_detail).status_code == 404
    assert proprietaire_web.get(url_liste).status_code == 403
    assert membre_web.get(url_liste).status_code == 403
    tentative_reference_etrangere = autre_tenant.post(
        url_liste,
        {
            "cle_idempotence": str(uuid.uuid4()),
            "affectation": affectation.pk,
            "periode": "",
            "titre": "Référence interdite",
            "date_evaluation": "2026-09-10",
            "note_maximale": "20",
            "coefficient": "1",
        },
    )
    assert tentative_reference_etrangere.status_code == 200
    assert not Evaluation.objects.filter(
        tenant=autre_contexte["tenant"],
        titre="Référence interdite",
    ).exists()


def test_web_note_history_results_and_result_document_lifecycle():
    contexte = _preparer_tenant("assess-web-docs")
    affectation = _creer_affectation(contexte)
    inscription = _creer_inscription(contexte)
    enseignant = _client_web(
        contexte["enseignant"]["compte"],
        contexte["tenant"],
    )
    gestionnaire = _client_gestionnaire(contexte)
    url_liste = reverse("evaluations_web:liste")

    creation = enseignant.post(
        url_liste,
        {
            "cle_idempotence": str(uuid.uuid4()),
            "affectation": affectation.pk,
            "periode": "",
            "titre": "Résultats de trimestre",
            "date_evaluation": "2026-09-10",
            "note_maximale": "20",
            "coefficient": "1",
        },
    )
    assert creation.status_code == 302
    evaluation = Evaluation.objects.get(titre="Résultats de trimestre")
    note_url = reverse(
        "evaluations_web:note",
        args=(evaluation.pk, inscription.pk),
    )
    enseignant.post(note_url, {"note": "17"})
    note = NoteEvaluation.objects.get(evaluation=evaluation)
    historique_url = reverse("evaluations_web:historique-note", args=(note.pk,))
    historique = enseignant.get(historique_url)
    assert historique.status_code == 200
    assert "Saisie" in historique.content.decode()

    publication = gestionnaire.post(
        reverse("evaluations_web:publier", args=(evaluation.pk,))
    )
    assert publication.status_code == 302
    evaluation.refresh_from_db()
    assert evaluation.statut == StatutEvaluation.PUBLIEE
    resultats_url = reverse(
        "evaluations_web:resultats-inscription",
        args=(inscription.pk,),
    )
    resultats = gestionnaire.get(resultats_url)
    assert resultats.status_code == 200
    assert resultats.context["resultats"][0]["evaluations"][0]["note"] == "17.0000"

    emission = gestionnaire.post(
        resultats_url,
        {
            "action": "emettre",
            "cle_idempotence": str(uuid.uuid4()),
            "type_document": "bulletin",
        },
    )
    assert emission.status_code == 302
    document = DocumentResultat.objects.get(inscription_id=inscription.pk)
    detail_url = reverse("evaluations_web:document", args=(document.pk,))
    assert gestionnaire.get(detail_url).status_code == 200
    impression = gestionnaire.get(
        reverse("evaluations_web:imprimer-document", args=(document.pk,))
    )
    assert impression.status_code == 200
    assert impression["Cache-Control"] == "private, no-store"
    assert "Résultats de trimestre" in impression.content.decode()

    revoquer = gestionnaire.post(
        reverse("evaluations_web:revoquer-document", args=(document.pk,)),
        {"motif": "Erreur sur l’identité du dossier."},
    )
    assert revoquer.status_code == 302
    document.refresh_from_db()
    assert document.statut == "revoque"
    assert document.motif_retrait == "Erreur sur l’identité du dossier."


def test_web_weighted_results_document_versions_and_tenant_scope():
    contexte = _preparer_tenant("assess-docs-versioned")
    autre_contexte = _preparer_tenant("assess-docs-other")
    affectation = _creer_affectation(contexte)
    inscription = _creer_inscription(contexte)
    enseignant = _client_web(
        contexte["enseignant"]["compte"],
        contexte["tenant"],
    )
    gestionnaire = _client_gestionnaire(contexte)
    autre_tenant = _client_gestionnaire(autre_contexte)
    url_liste = reverse("evaluations_web:liste")

    evaluations = (
        ("Examen court", "10", "1", "8"),
        ("Examen long", "50", "3", "25"),
    )
    creees = []
    for titre, maximum, coefficient, note_value in evaluations:
        creation = enseignant.post(
            url_liste,
            {
                "cle_idempotence": str(uuid.uuid4()),
                "affectation": affectation.pk,
                "periode": "",
                "titre": titre,
                "date_evaluation": "2026-09-10",
                "note_maximale": maximum,
                "coefficient": coefficient,
            },
        )
        assert creation.status_code == 302
        evaluation = Evaluation.objects.get(titre=titre)
        creees.append(evaluation)
        note_url = reverse(
            "evaluations_web:note",
            args=(evaluation.pk, inscription.pk),
        )
        assert enseignant.post(note_url, {"note": note_value}).status_code == 302
        assert gestionnaire.post(
            reverse("evaluations_web:publier", args=(evaluation.pk,))
        ).status_code == 302

    resultats_url = reverse(
        "evaluations_web:resultats-inscription",
        args=(inscription.pk,),
    )
    resultats = gestionnaire.get(resultats_url)
    assert resultats.status_code == 200
    assert resultats.context["resultats"][0]["moyenne_sur_100"] == "57.50"

    cle_document = str(uuid.uuid4())
    payload = {
        "action": "emettre",
        "cle_idempotence": cle_document,
        "type_document": "bulletin",
    }
    premiere_emission = gestionnaire.post(resultats_url, payload)
    reprise = gestionnaire.post(resultats_url, payload)
    document = DocumentResultat.objects.get(inscription_id=inscription.pk)
    assert premiere_emission.status_code == 302
    assert reprise.status_code == 302
    assert DocumentResultat.objects.filter(inscription_id=inscription.pk).count() == 1

    impression_url = reverse("evaluations_web:imprimer-document", args=(document.pk,))
    assert autre_tenant.get(
        reverse("evaluations_web:document", args=(document.pk,))
    ).status_code == 404
    assert enseignant.get(impression_url).status_code == 403
    impression = gestionnaire.get(impression_url)
    assert impression.status_code == 200
    assert impression["Cache-Control"] == "private, no-store"
    instantane_initial = document.instantane

    note_url = reverse(
        "evaluations_web:note",
        args=(creees[1].pk, inscription.pk),
    )
    assert enseignant.post(
        note_url,
        {"note": "30", "motif_correction": "Tentative non autorisée."},
    ).status_code == 403
    assert gestionnaire.post(
        note_url,
        {"note": "30", "motif_correction": "Correction vérifiée."},
    ).status_code == 302

    nouvelle_emission = gestionnaire.post(
        resultats_url,
        {
            "action": "emettre",
            "cle_idempotence": str(uuid.uuid4()),
            "type_document": "bulletin",
        },
    )
    assert nouvelle_emission.status_code == 302
    documents = list(
        DocumentResultat.objects.filter(inscription_id=inscription.pk).order_by(
            "version"
        )
    )
    document.refresh_from_db()
    assert len(documents) == 2
    assert document.statut == StatutDocumentResultat.REMPLACE
    assert document.instantane == instantane_initial
    assert documents[1].version == 2

    revoquer = gestionnaire.post(
        reverse("evaluations_web:revoquer-document", args=(documents[1].pk,)),
        {"motif": "Réédition nécessaire."},
    )
    assert revoquer.status_code == 302
    documents[1].refresh_from_db()
    assert documents[1].statut == StatutDocumentResultat.REVOQUE
    impression_revoquee = gestionnaire.get(
        reverse("evaluations_web:imprimer-document", args=(documents[1].pk,))
    )
    assert "DOCUMENT RÉVOQUÉ" in impression_revoquee.content.decode()
