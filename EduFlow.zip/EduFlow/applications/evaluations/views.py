"""Vues Django classiques de gestion des évaluations et de leurs notes."""

from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods, require_POST

from applications.evaluations.forms import (
    DocumentResultatForm,
    EvaluationForm,
    NoteEvaluationForm,
    RevoquerDocumentForm,
)
from applications.evaluations.models import (
    DocumentResultat,
    Evaluation,
    NoteEvaluation,
    StatutDocumentResultat,
    StatutEvaluation,
)
from applications.evaluations.services import (
    ConflitEvaluation,
    creer_document_resultat,
    creer_evaluation,
    historique_notes,
    inscriptions_eligibles,
    publier_evaluation,
    resultats_inscription,
    revoquer_document_resultat,
    saisir_note,
)
from applications.inscriptions.models import Inscription
from applications.organisations.access import resoudre_adhesion_active
from applications.organisations.models import RoleAdhesion

SESSION_TENANT_KEY = "eduflow_tenant_actif"
ROLES_GESTION = {
    RoleAdhesion.PROPRIETAIRE,
    RoleAdhesion.ADMINISTRATEUR,
    RoleAdhesion.GESTIONNAIRE,
}
ROLES_EVALUATIONS = (
    ROLES_GESTION - {RoleAdhesion.PROPRIETAIRE}
) | {RoleAdhesion.ENSEIGNANT}


def _espace_evaluations(view):
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        tenant_id = request.session.get(SESSION_TENANT_KEY)
        if not tenant_id:
            messages.info(request, "Choisissez un établissement pour continuer.")
            return redirect("tableau_de_bord:accueil")
        adhesion = resoudre_adhesion_active(request.user, str(tenant_id))
        if (
            adhesion.role not in ROLES_EVALUATIONS
            and not request.user.is_superuser
        ):
            raise PermissionDenied
        request.adhesion_tenant = adhesion
        response = view(request, *args, **kwargs)
        response.headers["Cache-Control"] = "private, no-store"
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
        return response

    return wrapped


def _evaluations_tenant(request):
    tenant = request.adhesion_tenant.tenant
    evaluations = Evaluation.objects.filter(
        tenant=tenant,
        institution=tenant.institution,
    ).select_related(
        "affectation__cours",
        "affectation__groupe",
        "affectation__enseignant__personne",
        "periode",
    )
    if request.adhesion_tenant.role == RoleAdhesion.ENSEIGNANT:
        evaluations = evaluations.filter(
            affectation__enseignant__compte=request.user,
            affectation__enseignant__actif=True,
        )
    return evaluations


def _formulaire_evaluation(request):
    adhesion = request.adhesion_tenant
    return EvaluationForm(
        request.POST or None,
        tenant=adhesion.tenant,
        institution=adhesion.tenant.institution,
        acteur=request.user,
        role=adhesion.role,
    )


def _contexte_espace(request):
    adhesion = request.adhesion_tenant
    est_gestionnaire = adhesion.role in ROLES_GESTION
    return {
        "workspace": adhesion,
        "workspace_accessible": True,
        "role_gestion": est_gestionnaire,
        "role_gestion_pedagogique": est_gestionnaire
        and (
            adhesion.role != RoleAdhesion.PROPRIETAIRE
            or request.user.is_superuser
        ),
        "role_enseignant": adhesion.role == RoleAdhesion.ENSEIGNANT,
    }


@login_required
@_espace_evaluations
@require_http_methods(["GET", "POST"])
def liste_evaluations(request):
    formulaire = _formulaire_evaluation(request)
    if request.method == "POST":
        if formulaire.is_valid():
            valeurs = {
                champ: formulaire.cleaned_data[champ]
                for champ in (
                    "affectation",
                    "periode",
                    "titre",
                    "date_evaluation",
                    "note_maximale",
                    "coefficient",
                )
            }
            try:
                evaluation, _ = creer_evaluation(
                    tenant=request.adhesion_tenant.tenant,
                    institution=request.adhesion_tenant.tenant.institution,
                    acteur=request.user,
                    valeurs=valeurs,
                    cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
                )
            except ConflitEvaluation:
                formulaire.add_error(
                    None,
                    "Cette soumission entre en conflit avec une autre évaluation.",
                )
            except ValidationError as error:
                erreurs = getattr(error, "message_dict", None)
                if erreurs:
                    for champ, contenu in erreurs.items():
                        formulaire.add_error(
                            champ if champ in formulaire.fields else None,
                            contenu,
                        )
                else:
                    formulaire.add_error(None, error.messages)
            else:
                messages.success(request, "L’évaluation a été créée.")
                return redirect("evaluations_web:detail", evaluation_id=evaluation.pk)

    contexte = {
        "formulaire": formulaire,
        "evaluations": _evaluations_tenant(request),
        "role_gestion": request.adhesion_tenant.role in ROLES_GESTION,
    }
    contexte.update(_contexte_espace(request))
    return render(request, "evaluations/liste.html", contexte)


@login_required
@_espace_evaluations
@require_http_methods(["GET"])
def detail_evaluation(request, evaluation_id):
    evaluation = get_object_or_404(_evaluations_tenant(request), pk=evaluation_id)
    inscriptions = inscriptions_eligibles(evaluation)
    notes = {
        note.inscription_id: note
        for note in NoteEvaluation.objects.filter(
            tenant=request.adhesion_tenant.tenant,
            evaluation=evaluation,
            inscription__in=inscriptions,
        )
    }
    lignes = [
        {
            "inscription": inscription,
            "note": notes.get(inscription.pk),
            "formulaire": NoteEvaluationForm(
                initial={
                    "note": (notes[inscription.pk].note if inscription.pk in notes else None),
                    "absence_justifiee": (
                        notes[inscription.pk].absence_justifiee
                        if inscription.pk in notes
                        else False
                    ),
                },
                note_maximale=evaluation.note_maximale,
            ),
        }
        for inscription in inscriptions
    ]
    contexte = {
        "evaluation": evaluation,
        "lignes": lignes,
        "role_gestion": request.adhesion_tenant.role in ROLES_GESTION,
    }
    contexte.update(_contexte_espace(request))
    return render(request, "evaluations/detail.html", contexte)


@login_required
@_espace_evaluations
@require_POST
def enregistrer_note(request, evaluation_id, inscription_id):
    evaluation = get_object_or_404(_evaluations_tenant(request), pk=evaluation_id)
    gestionnaire = request.adhesion_tenant.role in ROLES_GESTION
    if evaluation.statut == StatutEvaluation.PUBLIEE and not gestionnaire:
        raise PermissionDenied("Seul un gestionnaire peut corriger une évaluation publiée.")
    inscription = get_object_or_404(
        inscriptions_eligibles(evaluation),
        pk=inscription_id,
    )
    formulaire = NoteEvaluationForm(
        request.POST,
        note_maximale=evaluation.note_maximale,
    )
    if not formulaire.is_valid():
        for erreur in formulaire.non_field_errors():
            messages.error(request, erreur)
        for champ, erreurs in formulaire.errors.items():
            if champ != "__all__":
                messages.error(request, f"{formulaire.fields[champ].label} : {', '.join(erreurs)}")
        return redirect("evaluations_web:detail", evaluation_id=evaluation.pk)

    try:
        saisir_note(
            evaluation_id=evaluation.pk,
            inscription_id=inscription.pk,
            tenant=request.adhesion_tenant.tenant,
            institution=evaluation.institution,
            acteur=request.user,
            note=formulaire.cleaned_data["note"],
            absence_justifiee=formulaire.cleaned_data["absence_justifiee"],
            motif_correction=formulaire.cleaned_data["motif_correction"],
            gestionnaire=gestionnaire,
        )
    except ValidationError as error:
        erreurs = getattr(error, "message_dict", None)
        messages.error(
            request,
            "; ".join(
                message
                for valeurs in (erreurs or {"__all__": error.messages}).values()
                for message in valeurs
            ),
        )
    else:
        messages.success(
            request,
            f"La note de {inscription.apprenant.personne} a été enregistrée.",
        )
    return redirect("evaluations_web:detail", evaluation_id=evaluation.pk)


@login_required
@_espace_evaluations
@require_POST
def publier_evaluation_web(request, evaluation_id):
    if request.adhesion_tenant.role not in ROLES_GESTION:
        raise PermissionDenied("Seul un gestionnaire peut publier les résultats.")
    evaluation = get_object_or_404(_evaluations_tenant(request), pk=evaluation_id)
    try:
        publier_evaluation(
            evaluation_id=evaluation.pk,
            tenant=request.adhesion_tenant.tenant,
            institution=evaluation.institution,
            acteur=request.user,
        )
    except ValidationError as error:
        messages.error(request, "; ".join(error.messages))
    else:
        messages.success(request, "Les résultats ont été publiés.")
    return redirect("evaluations_web:detail", evaluation_id=evaluation.pk)


def _exiger_gestionnaire(request):
    if request.adhesion_tenant.role not in ROLES_GESTION:
        raise PermissionDenied("Cette opération est réservée aux gestionnaires.")


def _documents_inscription(request, inscription):
    return DocumentResultat.objects.filter(
        tenant=request.adhesion_tenant.tenant,
        institution=inscription.institution,
        inscription=inscription,
    )


@login_required
@_espace_evaluations
@require_http_methods(["GET", "POST"])
def resultats_inscription_web(request, inscription_id):
    _exiger_gestionnaire(request)
    tenant = request.adhesion_tenant.tenant
    inscription = get_object_or_404(
        Inscription.objects.select_related(
            "apprenant__personne",
            "annee_academique",
            "groupe",
            "programme",
        ),
        pk=inscription_id,
        tenant=tenant,
        institution=tenant.institution,
    )
    formulaire = DocumentResultatForm(
        request.POST if request.POST.get("action") == "emettre" else None
    )
    if request.method == "POST":
        if request.POST.get("action") != "emettre":
            formulaire.add_error(None, "Cette opération n’est pas reconnue.")
        elif formulaire.is_valid():
            try:
                document, _ = creer_document_resultat(
                    tenant=tenant,
                    institution=inscription.institution,
                    inscription_id=inscription.pk,
                    acteur=request.user,
                    type_document=formulaire.cleaned_data["type_document"],
                    cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
                )
            except ConflitEvaluation:
                formulaire.add_error(
                    None,
                    "Cette émission entre en conflit avec un document existant.",
                )
            except ValidationError as error:
                _ajouter_erreurs(formulaire, error)
            else:
                messages.success(request, "Le document de résultats a été émis.")
                return redirect(
                    "evaluations_web:document",
                    document_id=document.pk,
                )

    documents = _documents_inscription(request, inscription)
    contexte = {
        **_contexte_espace(request),
        "inscription": inscription,
        "resultats": resultats_inscription(inscription=inscription),
        "documents": documents,
        "formulaire": formulaire,
    }
    return render(request, "evaluations/resultats_inscription.html", contexte)


@login_required
@_espace_evaluations
@require_http_methods(["GET"])
def historique_note_web(request, note_id):
    note = get_object_or_404(
        NoteEvaluation.objects.filter(
            tenant=request.adhesion_tenant.tenant,
            institution=request.adhesion_tenant.tenant.institution,
            evaluation__in=_evaluations_tenant(request),
        ).select_related(
            "evaluation",
            "inscription__apprenant__personne",
        ),
        pk=note_id,
    )
    contexte = {
        **_contexte_espace(request),
        "note": note,
        "historique": historique_notes(
            tenant=request.adhesion_tenant.tenant,
            institution=note.institution,
            note=note,
        ),
    }
    return render(request, "evaluations/historique_note.html", contexte)


@login_required
@_espace_evaluations
@require_http_methods(["GET"])
def detail_document_resultat_web(request, document_id):
    _exiger_gestionnaire(request)
    tenant = request.adhesion_tenant.tenant
    document = get_object_or_404(
        DocumentResultat.objects.select_related(
            "inscription__apprenant__personne",
        ),
        pk=document_id,
        tenant=tenant,
        institution=tenant.institution,
    )
    contexte = {
        **_contexte_espace(request),
        "document": document,
        "formulaire": RevoquerDocumentForm(),
        "peut_revoquer": document.statut == StatutDocumentResultat.EMIS,
    }
    return render(request, "evaluations/document_resultat_detail.html", contexte)


@login_required
@_espace_evaluations
@require_POST
def revoquer_document_resultat_web(request, document_id):
    _exiger_gestionnaire(request)
    tenant = request.adhesion_tenant.tenant
    document = get_object_or_404(
        DocumentResultat.objects.select_related("inscription"),
        pk=document_id,
        tenant=tenant,
        institution=tenant.institution,
    )
    formulaire = RevoquerDocumentForm(request.POST)
    if formulaire.is_valid():
        try:
            revoquer_document_resultat(
                document_id=document.pk,
                tenant=tenant,
                institution=document.institution,
                acteur=request.user,
                motif=formulaire.cleaned_data["motif"],
            )
        except ValidationError as error:
            _ajouter_erreurs(formulaire, error)
        else:
            messages.success(request, "Le document de résultats a été révoqué.")
            return redirect("evaluations_web:document", document_id=document.pk)
    for erreurs in formulaire.errors.values():
        for erreur in erreurs:
            messages.error(request, erreur)
    return redirect("evaluations_web:document", document_id=document.pk)


@login_required
@_espace_evaluations
@require_http_methods(["GET"])
def imprimer_document_resultat_web(request, document_id):
    _exiger_gestionnaire(request)
    tenant = request.adhesion_tenant.tenant
    document = get_object_or_404(
        DocumentResultat.objects.select_related("inscription"),
        pk=document_id,
        tenant=tenant,
        institution=tenant.institution,
    )
    return render(
        request,
        "evaluations/document_resultat.html",
        {
            "document": document,
            "instantane": document.instantane,
            "est_revoque": document.statut == StatutDocumentResultat.REVOQUE,
            "est_remplace": document.statut == StatutDocumentResultat.REMPLACE,
        },
    )


def _ajouter_erreurs(formulaire, error):
    erreurs = getattr(error, "message_dict", None)
    if erreurs:
        for champ, messages_erreur in erreurs.items():
            formulaire.add_error(
                champ if champ in formulaire.fields else None,
                messages_erreur,
            )
    else:
        formulaire.add_error(None, error.messages)
