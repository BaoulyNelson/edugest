"""Formulaires Django classiques des évaluations et des notes."""

import uuid

from django import forms
from django.core.exceptions import ValidationError as DjangoValidationError

from applications.emplois_temps.models import AffectationEnseignement
from applications.evaluations.models import Evaluation, TypeDocumentResultat
from applications.organisations.models import RoleAdhesion
from applications.referentiels.models import PeriodeAcademique


class EvaluationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    affectation = forms.ModelChoiceField(
        label="Cours et groupe",
        queryset=AffectationEnseignement.objects.none(),
    )
    periode = forms.ModelChoiceField(
        label="Période académique",
        queryset=PeriodeAcademique.objects.none(),
        required=False,
    )
    titre = forms.CharField(label="Nom de l’évaluation", max_length=200)
    date_evaluation = forms.DateField(
        label="Date",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    note_maximale = forms.DecimalField(
        label="Note maximale",
        max_digits=10,
        decimal_places=4,
        min_value=0,
        widget=forms.NumberInput(attrs={"step": "0.0001", "min": "0.0001"}),
    )
    coefficient = forms.DecimalField(
        label="Coefficient",
        max_digits=10,
        decimal_places=4,
        min_value=0,
        initial=1,
        widget=forms.NumberInput(attrs={"step": "0.0001", "min": "0.0001"}),
    )

    def __init__(self, *args, tenant, institution, acteur, role, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        affectations = AffectationEnseignement.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
            enseignant__actif=True,
        ).select_related("cours", "groupe", "enseignant__personne")
        if role == RoleAdhesion.ENSEIGNANT:
            affectations = affectations.filter(enseignant__compte=acteur)
        self.fields["affectation"].queryset = affectations
        self.fields["affectation"].label_from_instance = lambda affectation: (
            f"{affectation.cours.nom} — {affectation.groupe.nom} "
            f"({affectation.enseignant.personne})"
        )
        self.fields["periode"].queryset = PeriodeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        self.tenant = tenant
        self.institution = institution
        self.acteur = acteur

    def clean(self):
        cleaned_data = super().clean()
        if self.errors:
            return cleaned_data
        candidat = Evaluation(
            tenant=self.tenant,
            institution=self.institution,
            cree_par=self.acteur,
            **cleaned_data,
        )
        try:
            candidat.full_clean(
                exclude=("cle_idempotence",),
                validate_unique=False,
                validate_constraints=False,
            )
        except DjangoValidationError as error:
            erreurs = getattr(error, "message_dict", None)
            if erreurs:
                for champ, messages in erreurs.items():
                    self.add_error(champ if champ in self.fields else None, messages)
            else:
                self.add_error(None, error.messages)
        return cleaned_data


class NoteEvaluationForm(forms.Form):
    note = forms.DecimalField(
        label="Note",
        max_digits=10,
        decimal_places=4,
        required=False,
        widget=forms.NumberInput(attrs={"step": "0.0001", "min": "0"}),
    )
    absence_justifiee = forms.BooleanField(
        label="Absence justifiée",
        required=False,
    )
    motif_correction = forms.CharField(
        label="Motif de correction",
        max_length=250,
        required=False,
        widget=forms.TextInput(
            attrs={"placeholder": "Obligatoire pour modifier une note existante"}
        ),
    )

    def __init__(self, *args, note_maximale, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["note"].max_value = note_maximale

    def clean(self):
        cleaned_data = super().clean()
        note = cleaned_data.get("note")
        absence_justifiee = cleaned_data.get("absence_justifiee", False)
        if note is None and not absence_justifiee:
            self.add_error(
                "note",
                "Saisissez une note ou cochez « Absence justifiée ».",
            )
        elif note is not None and absence_justifiee:
            self.add_error(
                "absence_justifiee",
                "Une absence justifiée ne peut pas avoir de note.",
            )
        return cleaned_data


class DocumentResultatForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    type_document = forms.ChoiceField(
        label="Type de document",
        choices=TypeDocumentResultat.choices,
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class RevoquerDocumentForm(forms.Form):
    motif = forms.CharField(
        label="Motif de révocation",
        max_length=250,
        widget=forms.Textarea(attrs={"rows": 3, "class": "saas-input"}),
    )
