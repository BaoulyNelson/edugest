"""Évaluations, notes, historique et documents académiques tenant-scoped."""

import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.emplois_temps.models import AffectationEnseignement
from applications.inscriptions.models import Inscription
from applications.personnes.models import ObjetEducatifTenant
from applications.referentiels.models import PeriodeAcademique


class StatutEvaluation(models.TextChoices):
    BROUILLON = "brouillon", "Brouillon"
    PUBLIEE = "publiee", "Publiée"


class TypeOperationNote(models.TextChoices):
    SAISIE = "saisie", "Saisie"
    CORRECTION = "correction", "Correction"


class TypeDocumentResultat(models.TextChoices):
    BULLETIN = "bulletin", "Bulletin"
    RELEVE = "releve", "Relevé de notes"


class StatutDocumentResultat(models.TextChoices):
    EMIS = "emis", "Émis"
    REMPLACE = "remplace", "Remplacé"
    REVOQUE = "revoque", "Révoqué"


class Evaluation(ObjetEducatifTenant):
    """Évaluation rattachée à une affectation et une période facultative."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    affectation = models.ForeignKey(
        AffectationEnseignement,
        on_delete=models.PROTECT,
        related_name="evaluations",
    )
    periode = models.ForeignKey(
        PeriodeAcademique,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="evaluations",
    )
    titre = models.CharField(max_length=200)
    date_evaluation = models.DateField()
    note_maximale = models.DecimalField(max_digits=10, decimal_places=4)
    coefficient = models.DecimalField(max_digits=10, decimal_places=4, default=1)
    statut = models.CharField(
        max_length=10,
        choices=StatutEvaluation.choices,
        default=StatutEvaluation.BROUILLON,
    )

    class Meta:
        ordering = ("date_evaluation", "titre", "id")
        constraints = [
            models.CheckConstraint(
                condition=Q(note_maximale__gt=0),
                name="evaluation_note_max_positive",
            ),
            models.CheckConstraint(
                condition=Q(coefficient__gt=0),
                name="evaluation_coefficient_positif",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutEvaluation.values),
                name="evaluation_statut_valide",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "affectation", "date_evaluation"),
                name="evaluation_tenant_affect_idx",
            ),
            models.Index(
                fields=("tenant", "statut", "date_evaluation"),
                name="evaluation_tenant_statut_idx",
            ),
        ]
        verbose_name = "évaluation"
        verbose_name_plural = "évaluations"

    def __str__(self) -> str:
        return f"{self.titre} — {self.affectation.cours}"

    def clean(self):
        super().clean()
        erreurs = {}
        if self.affectation_id and (
            self.affectation.tenant_id != self.tenant_id
            or self.affectation.institution_id != self.institution_id
        ):
            erreurs["affectation"] = (
                "L’affectation doit appartenir au même tenant et à la même institution."
            )
        if self.affectation_id and self.date_evaluation:
            if not (
                self.affectation.date_debut
                <= self.date_evaluation
                <= self.affectation.date_fin
            ):
                erreurs["date_evaluation"] = (
                    "La date doit se situer dans la période de l’affectation."
                )
        if self.periode_id and self.affectation_id:
            periode = self.periode
            if (
                periode.tenant_id != self.tenant_id
                or periode.institution_id != self.institution_id
                or periode.annee_academique_id
                != self.affectation.annee_academique_id
            ):
                erreurs["periode"] = (
                    "La période doit appartenir à l’année de l’affectation."
                )
            elif self.date_evaluation and not (
                periode.debut <= self.date_evaluation <= periode.fin
            ):
                erreurs["date_evaluation"] = (
                    "La date doit se situer dans la période académique sélectionnée."
                )
        if self.note_maximale is not None and self.note_maximale <= 0:
            erreurs["note_maximale"] = "Le barème maximal doit être supérieur à zéro."
        if self.coefficient is not None and self.coefficient <= 0:
            erreurs["coefficient"] = "Le coefficient doit être supérieur à zéro."
        if erreurs:
            raise ValidationError(erreurs)


class NoteEvaluation(ObjetEducatifTenant):
    """Note ou absence justifiée d’une inscription à une évaluation."""

    evaluation = models.ForeignKey(
        Evaluation,
        on_delete=models.PROTECT,
        related_name="notes",
    )
    inscription = models.ForeignKey(
        Inscription,
        on_delete=models.PROTECT,
        related_name="notes_evaluations",
    )
    note = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        null=True,
        blank=True,
    )
    absence_justifiee = models.BooleanField(default=False)

    class Meta:
        ordering = ("inscription__apprenant__personne__nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "evaluation", "inscription"),
                name="note_tenant_evaluation_ins_unique",
            ),
            models.CheckConstraint(
                condition=Q(note__isnull=True, absence_justifiee=True)
                | Q(note__isnull=False, absence_justifiee=False),
                name="note_absence_justifiee_coherente",
            ),
            models.CheckConstraint(
                condition=Q(note__isnull=True) | Q(note__gte=0),
                name="note_non_negative",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "evaluation", "inscription"),
                name="note_tenant_evalu_ins_idx",
            ),
        ]
        verbose_name = "note d’évaluation"
        verbose_name_plural = "notes d’évaluation"

    def __str__(self) -> str:
        return f"{self.inscription} — {self.evaluation}"

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("evaluation", self.evaluation if self.evaluation_id else None),
            ("inscription", self.inscription if self.inscription_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if self.evaluation_id and self.inscription_id:
            evaluation = self.evaluation
            inscription = self.inscription
            affectation = evaluation.affectation
            if inscription.groupe_id != affectation.groupe_id:
                erreurs["inscription"] = (
                    "L’inscription doit appartenir au groupe de l’affectation."
                )
            if inscription.annee_academique_id != affectation.annee_academique_id:
                erreurs["inscription"] = (
                    "L’inscription doit appartenir à l’année de l’affectation."
                )
            if (
                inscription.date_debut > evaluation.date_evaluation
                or inscription.date_fin
                and inscription.date_fin < evaluation.date_evaluation
            ):
                erreurs["inscription"] = (
                    "L’inscription doit couvrir la date de l’évaluation."
                )
            if self.note is not None and self.note > evaluation.note_maximale:
                erreurs["note"] = "La note ne peut pas dépasser le barème maximal."
        if self.absence_justifiee and self.note is not None:
            erreurs["note"] = "Une absence justifiée ne peut pas avoir de note."
        elif not self.absence_justifiee and self.note is None:
            erreurs["note"] = "Saisissez une note ou déclarez une absence justifiée."
        if erreurs:
            raise ValidationError(erreurs)


class HistoriqueNote(models.Model):
    """Historique restreint des saisies et corrections de notes."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        "organisations.Tenant",
        on_delete=models.PROTECT,
        related_name="historiques_notes",
    )
    institution = models.ForeignKey(
        "referentiels.Institution",
        on_delete=models.PROTECT,
        related_name="historiques_notes",
    )
    note_evaluation = models.ForeignKey(
        NoteEvaluation,
        on_delete=models.PROTECT,
        related_name="historique",
    )
    acteur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="historiques_notes_crees",
    )
    type_operation = models.CharField(
        max_length=12,
        choices=TypeOperationNote.choices,
    )
    avant = models.JSONField(default=dict, blank=True)
    apres = models.JSONField(default=dict)
    motif_correction = models.CharField(max_length=250, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("cree_le", "id")
        indexes = [
            models.Index(
                fields=("tenant", "note_evaluation", "cree_le"),
                name="hist_note_tenant_date_idx",
            ),
        ]
        verbose_name = "historique de note"
        verbose_name_plural = "historiques de notes"

    def __str__(self) -> str:
        return f"{self.type_operation} — {self.note_evaluation_id}"

    def clean(self):
        super().clean()
        if self.note_evaluation_id and (
            self.note_evaluation.tenant_id != self.tenant_id
            or self.note_evaluation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"note_evaluation": "La note doit appartenir au même tenant."}
            )
        if (
            self.type_operation == TypeOperationNote.CORRECTION
            and not self.motif_correction.strip()
        ):
            raise ValidationError(
                {"motif_correction": "Un motif est obligatoire pour corriger une note."}
            )


class DocumentResultat(ObjetEducatifTenant):
    """Version figée d’un bulletin ou relevé privé et réémissible."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    inscription = models.ForeignKey(
        Inscription,
        on_delete=models.PROTECT,
        related_name="documents_resultats",
    )
    type_document = models.CharField(
        max_length=10,
        choices=TypeDocumentResultat.choices,
    )
    version = models.PositiveIntegerField()
    statut = models.CharField(
        max_length=10,
        choices=StatutDocumentResultat.choices,
        default=StatutDocumentResultat.EMIS,
    )
    instantane = models.JSONField()
    emis_le = models.DateTimeField(auto_now_add=True)
    revoque_le = models.DateTimeField(null=True, blank=True)
    motif_retrait = models.CharField(max_length=250, blank=True)

    class Meta:
        ordering = ("-version", "-emis_le")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "inscription", "type_document", "version"),
                name="document_resultat_version_unique",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutDocumentResultat.values),
                name="document_resultat_statut_valide",
            ),
            models.CheckConstraint(
                condition=Q(version__gte=1),
                name="document_resultat_version_positive",
            ),
            models.CheckConstraint(
                condition=Q(type_document__in=TypeDocumentResultat.values),
                name="document_resultat_type_valide",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "inscription", "type_document", "version"),
                name="doc_res_ten_ver_idx",
            ),
        ]
        verbose_name = "document de résultats"
        verbose_name_plural = "documents de résultats"

    def __str__(self) -> str:
        return f"{self.type_document} v{self.version} — {self.inscription}"

    def clean(self):
        super().clean()
        if self.inscription_id and (
            self.inscription.tenant_id != self.tenant_id
            or self.inscription.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"inscription": "L’inscription doit appartenir au même tenant."}
            )
        if not isinstance(self.instantane, dict):
            raise ValidationError({"instantane": "L’instantané doit être un objet."})
        if self.statut == StatutDocumentResultat.REVOQUE and not self.motif_retrait.strip():
            raise ValidationError(
                {"motif_retrait": "Un motif est obligatoire pour révoquer un document."}
            )
