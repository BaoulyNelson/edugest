from django.contrib import admin

from applications.evaluations.models import (
    DocumentResultat,
    Evaluation,
    HistoriqueNote,
    NoteEvaluation,
)

admin.site.register((Evaluation, NoteEvaluation, HistoriqueNote, DocumentResultat))
