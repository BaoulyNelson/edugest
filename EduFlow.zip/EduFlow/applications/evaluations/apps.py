"""Configuration des évaluations et résultats académiques."""

from django.apps import AppConfig


class EvaluationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.evaluations"
    label = "evaluations"
    verbose_name = "Évaluations et résultats"
