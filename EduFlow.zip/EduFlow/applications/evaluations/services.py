"""Transactions métier des évaluations, notes et documents de résultats."""

import uuid
from decimal import ROUND_HALF_UP, Decimal, localcontext

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import F, Q, QuerySet
from django.utils import timezone

from applications.evaluations.models import (
    DocumentResultat,
    Evaluation,
    HistoriqueNote,
    NoteEvaluation,
    StatutDocumentResultat,
    StatutEvaluation,
    TypeOperationNote,
)
from applications.inscriptions.models import Inscription
from applications.organisations.models import EvenementAudit, Tenant


class ConflitEvaluation(Exception):
    """Une clé idempotente ou une ressource d’évaluation est en conflit."""


def _auditer(*, tenant, acteur, objet, action: str, champs: list[str], motif: str = ""):
    EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=f"evaluations.{action}",
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        motif=motif,
        details={"champs": sorted(champs)},
    )


def _correspond(existant, candidat) -> bool:
    return (
        existant.tenant_id == candidat.tenant_id
        and existant.institution_id == candidat.institution_id
        and existant.cree_par_id == candidat.cree_par_id
        and all(
            getattr(existant, champ.attname) == getattr(candidat, champ.attname)
            for champ in candidat._meta.concrete_fields
            if champ.name
            not in {
                "id",
                "cle_idempotence",
                "tenant",
                "institution",
                "cree_par",
                "cree_le",
                "modifie_le",
            }
        )
    )


def creer_evaluation(
    *,
    tenant,
    institution,
    acteur,
    valeurs: dict,
    cle_idempotence: uuid.UUID,
) -> tuple[Evaluation, bool]:
    evaluation = Evaluation(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        cle_idempotence=cle_idempotence,
        **valeurs,
    )
    evaluation.full_clean(
        exclude=("cle_idempotence",),
        validate_unique=False,
        validate_constraints=False,
    )
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existante = Evaluation.objects.filter(
            cle_idempotence=cle_idempotence
        ).first()
        if existante is not None:
            if _correspond(existante, evaluation):
                return existante, False
            raise ConflitEvaluation
        try:
            with transaction.atomic():
                evaluation.save(force_insert=True)
        except IntegrityError as error:
            existante = Evaluation.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existante is not None and _correspond(existante, evaluation):
                return existante, False
            raise ConflitEvaluation from error
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=evaluation,
            action="evaluation_creee",
            champs=["affectation", "periode", "titre", "date_evaluation"],
        )
        return evaluation, True


def modifier_evaluation(
    *,
    evaluation_id,
    tenant,
    institution,
    acteur,
    valeurs: dict,
) -> Evaluation:
    with transaction.atomic():
        evaluation = Evaluation.objects.select_for_update().get(
            pk=evaluation_id,
            tenant=tenant,
            institution=institution,
            statut=StatutEvaluation.BROUILLON,
        )
        if evaluation.notes.exists():
            raise ValidationError(
                "Une évaluation ne peut plus être modifiée après la première saisie de note."
            )
        for champ, valeur in valeurs.items():
            setattr(evaluation, champ, valeur)
        evaluation.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        evaluation.save(update_fields=(*valeurs.keys(), "modifie_le"))
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=evaluation,
            action="evaluation_modifiee",
            champs=list(valeurs),
        )
        return evaluation


def inscriptions_eligibles(evaluation: Evaluation) -> QuerySet[Inscription]:
    """Renvoie les inscriptions du groupe couvrant la date de l’évaluation."""
    inscriptions = Inscription.objects.filter(
        tenant=evaluation.tenant,
        institution=evaluation.institution,
        groupe_id=evaluation.affectation.groupe_id,
        annee_academique_id=evaluation.affectation.annee_academique_id,
        date_debut__lte=evaluation.date_evaluation,
    ).filter(
        Q(date_fin__isnull=True) | Q(date_fin__gte=evaluation.date_evaluation)
    )
    return inscriptions.select_related("apprenant__personne")


def publier_evaluation(
    *,
    evaluation_id,
    tenant,
    institution,
    acteur,
) -> tuple[Evaluation, bool]:
    with transaction.atomic():
        evaluation = (
            Evaluation.objects.select_for_update()
            .select_related("affectation")
            .get(pk=evaluation_id, tenant=tenant, institution=institution)
        )
        if evaluation.statut == StatutEvaluation.PUBLIEE:
            return evaluation, False
        inscriptions = inscriptions_eligibles(evaluation)
        if not inscriptions.exists():
            raise ValidationError(
                "Aucune inscription ne couvre la date de cette évaluation."
            )
        notes_saisies = NoteEvaluation.objects.filter(
            tenant=tenant,
            evaluation=evaluation,
        ).values("inscription_id")
        if inscriptions.exclude(pk__in=notes_saisies).exists():
            raise ValidationError(
                "Chaque inscription admissible doit avoir une note ou une absence justifiée "
                "avant la publication."
            )
        evaluation.statut = StatutEvaluation.PUBLIEE
        evaluation.save(update_fields=("statut", "modifie_le"))
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=evaluation,
            action="evaluation_publiee",
            champs=["statut"],
        )
        return evaluation, True


def saisir_note(
    *,
    evaluation_id,
    inscription_id,
    tenant,
    institution,
    acteur,
    note: Decimal | None,
    absence_justifiee: bool,
    motif_correction: str = "",
    gestionnaire: bool,
) -> tuple[NoteEvaluation, bool]:
    with transaction.atomic():
        evaluation = (
            Evaluation.objects.select_for_update()
            .select_related("affectation")
            .get(pk=evaluation_id, tenant=tenant, institution=institution)
        )
        inscription = Inscription.objects.select_for_update(of=("self",)).get(
            pk=inscription_id,
            tenant=tenant,
            institution=institution,
        )
        if not inscriptions_eligibles(evaluation).filter(pk=inscription.pk).exists():
            raise ValidationError(
                {"inscription": "Cette inscription ne couvre pas la date de l’évaluation."}
            )
        if note is not None and (note < 0 or note > evaluation.note_maximale):
            raise ValidationError(
                {"note": "La note doit être comprise entre zéro et le barème maximal."}
            )
        if absence_justifiee == (note is not None):
            raise ValidationError(
                "Fournissez une note ou déclarez une absence justifiée, mais pas les deux."
            )
        if evaluation.statut == StatutEvaluation.PUBLIEE and not gestionnaire:
            raise ValidationError(
                "Seul un gestionnaire peut corriger une évaluation déjà publiée."
            )

        existante = (
            NoteEvaluation.objects.select_for_update()
            .filter(
                tenant=tenant,
                evaluation=evaluation,
                inscription=inscription,
            )
            .first()
        )
        if existante and (
            existante.note == note
            and existante.absence_justifiee == absence_justifiee
        ):
            return existante, False

        motif = motif_correction.strip()
        if existante and not motif:
            raise ValidationError(
                {"motif_correction": "Un motif est obligatoire pour corriger une note."}
            )
        if evaluation.statut == StatutEvaluation.PUBLIEE and not motif:
            raise ValidationError(
                {"motif_correction": "Un motif est obligatoire après publication."}
            )

        avant = (
            {
                "note": str(existante.note) if existante.note is not None else None,
                "absence_justifiee": existante.absence_justifiee,
            }
            if existante
            else {}
        )
        if existante:
            enregistrement = existante
            enregistrement.note = note
            enregistrement.absence_justifiee = absence_justifiee
            enregistrement.full_clean(
                validate_unique=False,
                validate_constraints=False,
            )
            enregistrement.save(
                update_fields=("note", "absence_justifiee", "modifie_le")
            )
            type_operation = TypeOperationNote.CORRECTION
        else:
            enregistrement = NoteEvaluation(
                tenant=tenant,
                institution=institution,
                cree_par=acteur,
                evaluation=evaluation,
                inscription=inscription,
                note=note,
                absence_justifiee=absence_justifiee,
            )
            enregistrement.full_clean(
                validate_unique=False,
                validate_constraints=False,
            )
            try:
                with transaction.atomic():
                    enregistrement.save(force_insert=True)
            except IntegrityError:
                enregistrement = NoteEvaluation.objects.get(
                    tenant=tenant,
                    evaluation=evaluation,
                    inscription=inscription,
                )
                if (
                    enregistrement.note == note
                    and enregistrement.absence_justifiee == absence_justifiee
                ):
                    return enregistrement, False
                raise
            type_operation = TypeOperationNote.SAISIE

        apres = {
            "note": str(enregistrement.note) if enregistrement.note is not None else None,
            "absence_justifiee": enregistrement.absence_justifiee,
        }
        HistoriqueNote.objects.create(
            tenant=tenant,
            institution=institution,
            note_evaluation=enregistrement,
            acteur=acteur,
            type_operation=type_operation,
            avant=avant,
            apres=apres,
            motif_correction=motif if type_operation == TypeOperationNote.CORRECTION else "",
        )
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=enregistrement,
            action=(
                "note_corrigee"
                if type_operation == TypeOperationNote.CORRECTION
                else "note_saisie"
            ),
            champs=["note", "absence_justifiee"],
        )
        return enregistrement, True


def historique_notes(*, tenant, institution, note: NoteEvaluation):
    return HistoriqueNote.objects.filter(
        tenant=tenant,
        institution=institution,
        note_evaluation=note,
    ).select_related("acteur")


def _calculer_resultats(inscription: Inscription) -> list[dict]:
    evaluations = list(
        Evaluation.objects.filter(
            tenant=inscription.tenant,
            institution=inscription.institution,
            affectation__annee_academique_id=inscription.annee_academique_id,
            affectation__groupe_id=inscription.groupe_id,
            statut=StatutEvaluation.PUBLIEE,
            date_evaluation__gte=inscription.date_debut,
        )
        .filter(
            affectation__date_debut__lte=F("date_evaluation"),
            affectation__date_fin__gte=F("date_evaluation"),
        )
        .select_related("affectation__cours", "periode")
        .order_by("date_evaluation", "titre", "id")
    )
    evaluations = [
        evaluation
        for evaluation in evaluations
        if inscription.date_fin is None
        or evaluation.date_evaluation <= inscription.date_fin
    ]
    if not evaluations:
        return []
    notes = {
        note.evaluation_id: note
        for note in NoteEvaluation.objects.filter(
            tenant=inscription.tenant,
            inscription=inscription,
            evaluation_id__in=[evaluation.pk for evaluation in evaluations],
        )
    }

    groupes = {}
    with localcontext() as contexte_decimal:
        contexte_decimal.prec = 38
        for evaluation in evaluations:
            cle = (
                evaluation.affectation.cours_id,
                evaluation.periode_id,
            )
            resultat = groupes.setdefault(
                cle,
                {
                    "cours": evaluation.affectation.cours.nom,
                    "periode": evaluation.periode.nom if evaluation.periode else None,
                    "evaluations": [],
                    "somme_ponderee": Decimal("0"),
                    "somme_coefficients": Decimal("0"),
                },
            )
            note = notes.get(evaluation.pk)
            note_valeur = note.note if note and not note.absence_justifiee else None
            resultat["evaluations"].append(
                {
                    "titre": evaluation.titre,
                    "date": evaluation.date_evaluation.isoformat(),
                    "note": str(note_valeur) if note_valeur is not None else None,
                    "note_maximale": str(evaluation.note_maximale),
                    "coefficient": str(evaluation.coefficient),
                    "absence_justifiee": bool(note and note.absence_justifiee),
                }
            )
            if note_valeur is not None:
                resultat["somme_ponderee"] += (
                    note_valeur
                    * Decimal("100")
                    / evaluation.note_maximale
                    * evaluation.coefficient
                )
                resultat["somme_coefficients"] += evaluation.coefficient

    resultat_final = []
    for resultat in groupes.values():
        if resultat["somme_coefficients"]:
            moyenne = (
                resultat["somme_ponderee"] / resultat["somme_coefficients"]
            ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            moyenne_affichee = str(moyenne)
        else:
            moyenne_affichee = None
        resultat_final.append(
            {
                "cours": resultat["cours"],
                "periode": resultat["periode"],
                "moyenne_sur_100": moyenne_affichee,
                "evaluations": resultat["evaluations"],
            }
        )
    return resultat_final


def _meme_document(existant, *, tenant, institution, inscription, acteur, type_document):
    return (
        existant.tenant_id == tenant.pk
        and existant.institution_id == institution.pk
        and existant.inscription_id == inscription.pk
        and existant.cree_par_id == acteur.pk
        and existant.type_document == type_document
    )


def creer_document_resultat(
    *,
    tenant,
    institution,
    inscription_id,
    acteur,
    type_document: str,
    cle_idempotence: uuid.UUID,
) -> tuple[DocumentResultat, bool]:
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = DocumentResultat.objects.filter(
            cle_idempotence=cle_idempotence
        ).first()
        if existant is not None:
            inscription_existante = Inscription.objects.filter(
                pk=existant.inscription_id,
                tenant=tenant,
                institution=institution,
            ).first()
            if inscription_existante and _meme_document(
                existant,
                tenant=tenant,
                institution=institution,
                inscription=inscription_existante,
                acteur=acteur,
                type_document=type_document,
            ):
                return existant, False
            raise ConflitEvaluation

        inscription = Inscription.objects.select_for_update(of=("self",)).get(
            pk=inscription_id,
            tenant=tenant,
            institution=institution,
        )
        resultats = _calculer_resultats(inscription)
        if not resultats:
            raise ValidationError(
                "Aucun résultat publié ne permet d’émettre ce document."
            )
        derniere_version = (
            DocumentResultat.objects.filter(
                tenant=tenant,
                inscription=inscription,
                type_document=type_document,
            )
            .order_by("-version")
            .first()
        )
        instantane = {
            "apprenant": {
                "prenom": inscription.apprenant.personne.prenom,
                "nom": inscription.apprenant.personne.nom,
                "identifiant": inscription.apprenant.personne.identifiant_externe,
            },
            "annee_academique": {
                "nom": inscription.annee_academique.nom,
                "debut": inscription.annee_academique.debut.isoformat(),
                "fin": inscription.annee_academique.fin.isoformat(),
            },
            "groupe": inscription.groupe.nom if inscription.groupe else "",
            "resultats": resultats,
        }
        document = DocumentResultat(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=cle_idempotence,
            inscription=inscription,
            type_document=type_document,
            version=derniere_version.version + 1 if derniere_version else 1,
            statut=StatutDocumentResultat.EMIS,
            instantane=instantane,
        )
        document.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        try:
            document.save(force_insert=True)
        except IntegrityError as error:
            existant = DocumentResultat.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existant and _meme_document(
                existant,
                tenant=tenant,
                institution=institution,
                inscription=inscription,
                acteur=acteur,
                type_document=type_document,
            ):
                return existant, False
            raise ConflitEvaluation from error

        if derniere_version and derniere_version.statut == StatutDocumentResultat.EMIS:
            derniere_version.statut = StatutDocumentResultat.REMPLACE
            derniere_version.save(update_fields=("statut", "modifie_le"))
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=document,
            action="document_emis",
            champs=["inscription", "type_document", "version"],
        )
        return document, True


def revoquer_document_resultat(
    *,
    document_id,
    tenant,
    institution,
    acteur,
    motif: str,
) -> tuple[DocumentResultat, bool]:
    with transaction.atomic():
        document = DocumentResultat.objects.select_for_update().get(
            pk=document_id,
            tenant=tenant,
            institution=institution,
        )
        if document.statut == StatutDocumentResultat.REVOQUE:
            return document, False
        if document.statut == StatutDocumentResultat.REMPLACE:
            raise ValidationError(
                "Une version remplacée ne peut pas être révoquée; révoquez la version courante."
            )
        motif = motif.strip()
        if not motif:
            raise ValidationError({"motif": "Un motif est obligatoire."})
        document.statut = StatutDocumentResultat.REVOQUE
        document.revoque_le = timezone.now()
        document.motif_retrait = motif
        document.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        document.save(
            update_fields=("statut", "revoque_le", "motif_retrait", "modifie_le")
        )
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=document,
            action="document_revoque",
            champs=["statut", "revoque_le"],
            motif=motif,
        )
        return document, True


def resultats_inscription(*, inscription: Inscription) -> list[dict]:
    return _calculer_resultats(inscription)
