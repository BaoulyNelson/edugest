"""Routes HTML des évaluations et de la saisie des notes."""

from django.urls import path

from applications.evaluations.views import (
    detail_document_resultat_web,
    detail_evaluation,
    enregistrer_note,
    historique_note_web,
    imprimer_document_resultat_web,
    liste_evaluations,
    publier_evaluation_web,
    resultats_inscription_web,
    revoquer_document_resultat_web,
)

app_name = "evaluations_web"

urlpatterns = [
    path("espace/evaluations/", liste_evaluations, name="liste"),
    path(
        "espace/evaluations/<uuid:evaluation_id>/",
        detail_evaluation,
        name="detail",
    ),
    path(
        "espace/evaluations/<uuid:evaluation_id>/notes/<uuid:inscription_id>/",
        enregistrer_note,
        name="note",
    ),
    path(
        "espace/evaluations/<uuid:evaluation_id>/publier/",
        publier_evaluation_web,
        name="publier",
    ),
    path(
        "espace/evaluations/notes/<uuid:note_id>/historique/",
        historique_note_web,
        name="historique-note",
    ),
    path(
        "espace/evaluations/resultats/<uuid:inscription_id>/",
        resultats_inscription_web,
        name="resultats-inscription",
    ),
    path(
        "espace/evaluations/documents/<uuid:document_id>/",
        detail_document_resultat_web,
        name="document",
    ),
    path(
        "espace/evaluations/documents/<uuid:document_id>/revoquer/",
        revoquer_document_resultat_web,
        name="revoquer-document",
    ),
    path(
        "espace/evaluations/documents/<uuid:document_id>/impression/",
        imprimer_document_resultat_web,
        name="imprimer-document",
    ),
]
