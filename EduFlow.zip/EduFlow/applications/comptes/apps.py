"""Configuration de l’application de comptes."""

from django.apps import AppConfig


class ComptesConfig(AppConfig):
    """Application des identités de connexion globales."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.comptes"
    label = "comptes"
    verbose_name = "Comptes"
