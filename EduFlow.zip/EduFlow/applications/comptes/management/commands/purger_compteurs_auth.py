"""Purge périodique des empreintes de limitation anciennes."""

from django.core.management.base import BaseCommand

from applications.comptes.limites import purger_compteurs_expires


class Command(BaseCommand):
    help = "Supprime les compteurs d’authentification inactifs depuis plus de 24 heures."

    def handle(self, *args, **options):
        nombre = purger_compteurs_expires()
        self.stdout.write(self.style.SUCCESS(f"{nombre} compteur(s) supprimé(s)."))
