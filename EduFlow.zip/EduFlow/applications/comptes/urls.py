"""Routes de gestion du compte connecté."""

from django.urls import path

from applications.comptes import views

app_name = "comptes"

urlpatterns = [
    path("profil/", views.profil, name="profil"),
    # comptes/urls.py
    path("profil/photo/supprimer/", views.supprimer_photo, name="supprimer_photo"),
]
