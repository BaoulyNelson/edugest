"""Vues de connexion et récupération avec limitation persistante."""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.views import LoginView, PasswordResetConfirmView, PasswordResetView
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from applications.comptes.forms import FormulairePhotoProfil
from applications.comptes.limites import (
    NOMBRE_MAX_TENTATIVES_IP,
    empreinte_requete,
    enregistrer_tentative,
    est_bloquee,
    reinitialiser_tentatives,
)


def _empreinte(request, action: str, identifiant: str) -> str:
    return empreinte_requete(
        action=action,
        identifiant=identifiant,
        adresse_ip=request.META.get("REMOTE_ADDR", ""),
    )


@login_required
def profil(request):
    """Met à jour la photo du compte actuellement connecté."""
    photo_precedente = request.user.photo_profil
    form = FormulairePhotoProfil(
        request.POST or None,
        request.FILES or None,
        instance=request.user,
    )
    if request.method == "POST" and form.is_valid():
        compte = form.save()
        if photo_precedente and photo_precedente.name != compte.photo_profil.name:
            photo_precedente.storage.delete(photo_precedente.name)
        messages.success(request, "Votre photo de profil a été mise à jour.")
        return redirect("comptes:profil")
    from applications.tableau_de_bord.views import _contexte_espace

    contexte = _contexte_espace(request)
    contexte["administration_saas"] = False
    contexte["plateforme_operateur"] = request.user.is_staff and request.user.has_perm(
        "abonnements.gerer_abonnements_saas"
    )
    contexte["form"] = form
    return render(request, "comptes/profil.html", contexte)

@login_required
@require_POST
def supprimer_photo(request):
    user = request.user
    if user.photo_profil:
        user.photo_profil.delete(save=False)
        user.photo_profil = None
        user.save(update_fields=["photo_profil"])
        messages.success(request, "Votre photo de profil a été supprimée.")
    return redirect("comptes:profil")



class ConnexionLimitee(LoginView):
    """Limite les échecs par adresse e-mail et adresse IP."""

    def dispatch(self, request, *args, **kwargs):
        identifiant = request.POST.get("username", "")
        self.empreinte = _empreinte(
            request,
            "connexion",
            identifiant,
        )
        self.empreinte_ip = _empreinte(request, "connexion-ip", "")
        if request.method == "POST" and (
            est_bloquee(self.empreinte) or est_bloquee(self.empreinte_ip)
        ):
            return render(
                request,
                self.template_name,
                {
                    "form": AuthenticationForm(request),
                    "erreur_limite": True,
                },
                status=429,
            )
        return super().dispatch(request, *args, **kwargs)

    def form_invalid(self, form):
        enregistrer_tentative(self.empreinte)
        enregistrer_tentative(
            self.empreinte_ip,
            nombre_max=NOMBRE_MAX_TENTATIVES_IP,
        )
        return super().form_invalid(form)

    def form_valid(self, form):
        reinitialiser_tentatives(self.empreinte)
        reinitialiser_tentatives(self.empreinte_ip)
        return super().form_valid(form)


class ReinitialisationMotDePasseLimitee(PasswordResetView):
    """Limite les demandes répétées de réinitialisation par adresse/IP."""

    def dispatch(self, request, *args, **kwargs):
        self.empreinte = _empreinte(
            request,
            "reinitialisation",
            request.POST.get("email", ""),
        )
        self.empreinte_ip = _empreinte(request, "reinitialisation-ip", "")
        if request.method == "POST" and (
            est_bloquee(self.empreinte) or est_bloquee(self.empreinte_ip)
        ):
            return self.render_to_response(
                self.get_context_data(form=self.get_form(), erreur_limite=True),
                status=429,
            )
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        enregistrer_tentative(self.empreinte)
        enregistrer_tentative(
            self.empreinte_ip,
            nombre_max=NOMBRE_MAX_TENTATIVES_IP,
        )
        return super().form_valid(form)


class ConfirmationReinitialisationSecurisee(PasswordResetConfirmView):
    """Empêche la mise en cache ou la transmission du jeton de réinitialisation."""

    def dispatch(self, request, *args, **kwargs):
        response = super().dispatch(request, *args, **kwargs)
        response["Cache-Control"] = "no-store"
        response["Referrer-Policy"] = (
            "same-origin" if kwargs.get("token") == self.reset_url_token else "no-referrer"
        )
        return response
