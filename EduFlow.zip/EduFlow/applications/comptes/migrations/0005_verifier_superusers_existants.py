from django.db import migrations
from django.utils import timezone


def verifier_superusers_existants(apps, schema_editor):
    CompteUtilisateur = apps.get_model("comptes", "CompteUtilisateur")
    CompteUtilisateur.objects.using(schema_editor.connection.alias).filter(
        is_superuser=True,
        email_verifie_le__isnull=True,
    ).update(email_verifie_le=timezone.now())


class Migration(migrations.Migration):
    dependencies = [
        ("comptes", "0004_compteurtentativeauthentification_auth_counter_tentatives_non_negatives"),
    ]

    operations = [
        migrations.RunPython(verifier_superusers_existants, migrations.RunPython.noop),
    ]
