"""Administration des comptes de connexion."""

from django.contrib import admin, messages
from django.contrib.auth.admin import UserAdmin
from django.utils import timezone

from applications.comptes.models import CompteurTentativeAuthentification, CompteUtilisateur


@admin.register(CompteUtilisateur)
class AdministrationCompteUtilisateur(UserAdmin):
    """Interface d’administration du compte sans champ username."""

    ordering = ("email",)
    readonly_fields = ("email_verifie_le",)
    list_display = (
        "email",
        "first_name",
        "last_name",
        "email_verifie_le",
        "is_staff",
        "is_active",
    )
    search_fields = ("email", "first_name", "last_name")
    actions = ("verifier_adresses_email",)
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Vérification", {"fields": ("email_verifie_le",)}),
        ("Informations personnelles", {"fields": ("first_name", "last_name")}),
        (
            "Autorisations",
            {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")},
        ),
        ("Dates importantes", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "password1", "password2", "is_staff", "is_superuser"),
            },
        ),
    )

    def save_model(self, request, obj, form, change):
        if change:
            email_precedent = (
                CompteUtilisateur.objects.filter(pk=obj.pk)
                .values_list("email", flat=True)
                .first()
            )
            if email_precedent and email_precedent.casefold() != obj.email.casefold():
                obj.email_verifie_le = None
        if obj.is_superuser or (not change and request.user.is_superuser):
            obj.email_verifie_le = obj.email_verifie_le or timezone.now()
        super().save_model(request, obj, form, change)

    @admin.action(description="Vérifier les adresses e-mail des comptes sélectionnés")
    def verifier_adresses_email(self, request, queryset):
        nombre = queryset.filter(email_verifie_le__isnull=True).update(
            email_verifie_le=timezone.now(),
        )
        self.message_user(
            request,
            f"{nombre} adresse(s) e-mail vérifiée(s).",
            level=messages.SUCCESS,
        )


@admin.register(CompteurTentativeAuthentification)
class AdministrationCompteurTentative(admin.ModelAdmin):
    list_display = ("empreinte", "nombre_tentatives", "fenetre_commencee_le", "bloque_jusqua")
    search_fields = ("empreinte",)
