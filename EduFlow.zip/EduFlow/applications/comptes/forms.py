"""Formulaires de gestion du compte connecté."""

from django import forms

from applications.comptes.models import CompteUtilisateur

TAILLE_MAX_PHOTO = 5 * 1024 * 1024  # 5 Mo
TYPES_PHOTO_AUTORISES = ("image/jpeg", "image/png", "image/webp")


class FormulairePhotoProfil(forms.ModelForm):
    """Permet de définir, remplacer ou retirer une photo de profil."""

    photo_profil = forms.ImageField(
        label="Photo de profil",
        required=False,
        widget=forms.ClearableFileInput(
            attrs={"accept": ",".join(TYPES_PHOTO_AUTORISES)}
        ),
    )

    class Meta:
        model = CompteUtilisateur
        fields = ("photo_profil",)

    def clean_photo_profil(self):
        photo = self.cleaned_data.get("photo_profil")

        # Aucun nouveau fichier envoyé (ou fichier existant conservé)
        if not photo or not hasattr(photo, "content_type"):
            return photo

        if photo.size > TAILLE_MAX_PHOTO:
            raise forms.ValidationError("La photo ne doit pas dépasser 5 Mo.")

        if photo.content_type not in TYPES_PHOTO_AUTORISES:
            raise forms.ValidationError(
                "Format non pris en charge. Utilisez JPG, PNG ou WEBP."
            )

        return photo
