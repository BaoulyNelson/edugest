"""Modèles d’identité globale."""

import uuid

from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator
from django.db import models
from django.db.models import Q

from applications.comptes.managers import GestionnaireComptes


def chemin_photo_profil(instance, filename: str) -> str:
    """Stocke chaque nouvelle photo dans un chemin propre au compte."""
    extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return f"profils/{instance.pk}/{uuid.uuid4().hex}.{extension}"


class CompteUtilisateur(AbstractUser):
    """Compte de connexion global, indépendant des profils éducatifs."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    username = None
    email = models.EmailField("adresse e-mail", unique=True)
    email_verifie_le = models.DateTimeField("adresse e-mail vérifiée le", blank=True, null=True)
    photo_profil = models.ImageField(
        "photo de profil",
        upload_to=chemin_photo_profil,
        blank=True,
        validators=[FileExtensionValidator(["jpg", "jpeg", "png", "webp"])],
    )

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS: list[str] = []

    objects = GestionnaireComptes()

    class Meta:
        verbose_name = "compte utilisateur"
        verbose_name_plural = "comptes utilisateurs"

    def __str__(self) -> str:
        return self.email


class CompteurTentativeAuthentification(models.Model):
    """Compteur de limitation indexé sur une empreinte pseudonyme, jamais sur une IP brute."""

    empreinte = models.CharField(max_length=64, unique=True)
    nombre_tentatives = models.PositiveSmallIntegerField(default=0)
    fenetre_commencee_le = models.DateTimeField()
    bloque_jusqua = models.DateTimeField(null=True, blank=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=Q(nombre_tentatives__gte=0),
                name="auth_counter_tentatives_non_negatives",
            ),
        ]
        indexes = [
            models.Index(fields=("modifie_le",), name="auth_counter_updated_idx"),
        ]
        verbose_name = "compteur de tentatives d’authentification"
        verbose_name_plural = "compteurs de tentatives d’authentification"

    def __str__(self) -> str:
        return "Compteur de tentatives d’authentification"
