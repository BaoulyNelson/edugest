"""Backend qui n’authentifie que les comptes actifs dont l’adresse est vérifiée."""

from django.contrib.auth.backends import ModelBackend


class BackendCompteVerifie(ModelBackend):
    """Refuse la connexion tant que l’adresse e-mail n’a pas été prouvée."""

    def user_can_authenticate(self, user) -> bool:
        return super().user_can_authenticate(user) and user.email_verifie_le is not None
