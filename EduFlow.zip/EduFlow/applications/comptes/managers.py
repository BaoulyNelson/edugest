"""Gestionnaire du modèle de compte personnalisé."""

from django.contrib.auth.base_user import BaseUserManager
from django.utils import timezone


class GestionnaireComptes(BaseUserManager):
    """Crée des comptes à partir d’une adresse e-mail normalisée."""

    use_in_migrations = True

    def create_user(self, email: str, password: str | None = None, **extra_fields):
        if not email or not email.strip():
            raise ValueError("Une adresse e-mail est obligatoire.")

        normalized_email = self.normalize_email(email.strip()).casefold()
        account = self.model(email=normalized_email, **extra_fields)
        account.set_password(password)
        account.save(using=self._db)
        return account

    def create_superuser(self, email: str, password: str, **extra_fields):
        if not password:
            raise ValueError("Un mot de passe est obligatoire pour un superutilisateur.")
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        extra_fields["email_verifie_le"] = extra_fields.get("email_verifie_le") or timezone.now()

        if extra_fields["is_staff"] is not True:
            raise ValueError("Un superutilisateur doit avoir is_staff=True.")
        if extra_fields["is_superuser"] is not True:
            raise ValueError("Un superutilisateur doit avoir is_superuser=True.")

        return self.create_user(email, password, **extra_fields)
