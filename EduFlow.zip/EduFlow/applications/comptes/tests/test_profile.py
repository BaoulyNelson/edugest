"""Tests de mise à jour de la photo de profil."""

from io import BytesIO

import pytest
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, override_settings
from django.urls import reverse
from django.utils import timezone
from PIL import Image

pytestmark = pytest.mark.django_db


def _image_png(nom: str = "profil.png") -> SimpleUploadedFile:
    contenu = BytesIO()
    Image.new("RGB", (4, 4), color=(37, 99, 235)).save(contenu, format="PNG")
    return SimpleUploadedFile(nom, contenu.getvalue(), content_type="image/png")


def _connecter_client():
    utilisateur = get_user_model().objects.create_user(
        "profil@example.org",
        "mot-de-passe-solide",
        first_name="Ari",
        email_verifie_le=timezone.now(),
    )
    client = Client()
    client.force_login(utilisateur)
    return utilisateur, client


def test_profile_page_requires_authentication():
    response = Client().get(reverse("comptes:profil"))

    assert response.status_code == 302
    assert response["Location"].startswith("/connexion/")


def test_user_can_upload_replace_and_remove_their_profile_photo(tmp_path):
    with override_settings(MEDIA_ROOT=tmp_path):
        utilisateur, client = _connecter_client()
        response = client.get(reverse("comptes:profil"))

        assert response.status_code == 200
        assert "Photo de profil" in response.content.decode()

        uploaded = client.post(
            reverse("comptes:profil"),
            {"photo_profil": _image_png()},
        )
        assert uploaded.status_code == 302
        utilisateur.refresh_from_db()
        ancienne_photo = utilisateur.photo_profil
        assert ancienne_photo
        assert ancienne_photo.storage.exists(ancienne_photo.name)
        dashboard = client.get(reverse("tableau_de_bord:accueil"))
        assert ancienne_photo.url in dashboard.content.decode()

        remplacee = client.post(
            reverse("comptes:profil"),
            {"photo_profil": _image_png("nouvelle.png")},
        )
        assert remplacee.status_code == 302
        utilisateur.refresh_from_db()
        assert utilisateur.photo_profil
        assert not ancienne_photo.storage.exists(ancienne_photo.name)

        supprimee = client.post(
            reverse("comptes:profil"),
            {"photo_profil-clear": "on"},
        )
        assert supprimee.status_code == 302
        utilisateur.refresh_from_db()
        assert not utilisateur.photo_profil
        dashboard = client.get(reverse("tableau_de_bord:accueil"))
        assert ancienne_photo.url not in dashboard.content.decode()


def test_profile_rejects_non_image_uploads(tmp_path):
    with override_settings(MEDIA_ROOT=tmp_path):
        utilisateur, client = _connecter_client()
        response = client.post(
            reverse("comptes:profil"),
            {
                "photo_profil": SimpleUploadedFile(
                    "profil.png",
                    b"ceci n'est pas une image",
                    content_type="image/png",
                )
            },
        )

        assert response.status_code == 200
        assert "photo_profil" in response.context["form"].errors
        utilisateur.refresh_from_db()
        assert not utilisateur.photo_profil
