"""Tests de vérification d’adresse, de récupération et de limitation des tentatives."""

import re
from urllib.parse import urlparse

import pytest
from django.contrib.auth import get_user_model
from django.core import mail
from django.test import Client, override_settings
from django.urls import reverse
from django.utils import timezone

from applications.comptes.models import CompteurTentativeAuthentification

pytestmark = pytest.mark.django_db

MAILERS_LOCAL = {
    "default": {"BACKEND": "django.core.mail.backends.locmem.EmailBackend"},
}


def _creer_utilisateur(email: str, *, verifie: bool = True):
    attributs = {"email_verifie_le": timezone.now()} if verifie else {}
    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        **attributs,
    )


def test_unverified_account_cannot_login_until_its_email_is_verified():
    compte = _creer_utilisateur("non-verifie@example.org", verifie=False)
    client = Client()

    assert client.login(username=compte.email, password="mot-de-passe-solide") is False
    compte.email_verifie_le = timezone.now()
    compte.save(update_fields=("email_verifie_le",))
    assert client.login(username=compte.email, password="mot-de-passe-solide") is True


def test_login_is_blocked_after_five_failed_attempts():
    _creer_utilisateur("connexion@example.org")
    client = Client()

    for _ in range(5):
        response = client.post(
            "/connexion/",
            {"username": "connexion@example.org", "password": "incorrect"},
        )
        assert response.status_code == 200
    response = client.post(
        "/connexion/",
        {"username": "connexion@example.org", "password": "incorrect"},
    )

    assert response.status_code == 429
    assert (
        CompteurTentativeAuthentification.objects.filter(
            nombre_tentatives=5,
        ).count()
        == 2
    )


def test_login_rejects_null_origin_and_accepts_same_site_post():
    compte = _creer_utilisateur("csrf-origin@example.org")
    client = Client(enforce_csrf_checks=True)
    page = client.get("/connexion/")
    csrf_token = client.cookies["csrftoken"].value

    assert page.status_code == 200
    assert "/static/js/password-toggle.js" in page.content.decode()
    assert "/static/css/password-toggle.css" in page.content.decode()
    admin_page = Client().get("/admin/login/")
    assert admin_page.status_code == 200
    assert "/static/css/admin-theme.css" not in admin_page.content.decode()
    assert "/static/js/password-toggle.js" not in admin_page.content.decode()
    assert "/static/css/file-upload.css?v=dropzone-1" in admin_page.content.decode()
    assert "/static/js/file-dropzone.js?v=dropzone-1" in admin_page.content.decode()

    origine_opaque = client.post(
        "/connexion/",
        {"username": compte.email, "password": "mot-de-passe-solide"},
        HTTP_ORIGIN="null",
        HTTP_X_CSRFTOKEN=csrf_token,
    )
    origine_locale = client.post(
        "/connexion/",
        {"username": compte.email, "password": "mot-de-passe-solide"},
        HTTP_ORIGIN="http://testserver",
        HTTP_X_CSRFTOKEN=csrf_token,
    )

    assert origine_opaque.status_code == 403
    assert origine_locale.status_code == 302


def test_login_page_links_to_public_tenant_signup():
    response = Client().get(reverse("connexion"))
    contenu = response.content.decode()

    assert response.status_code == 200
    assert reverse("parcours_tenant:inscription") in contenu
    assert "Créer un établissement" in contenu
    assert '<body class="public-page public-login-page">' in contenu
    assert f'href="{reverse("parcours_tenant:accueil")}#fonctionnalites' in contenu
    assert "auth-layout" not in contenu
    assert "auth-aside" not in contenu


def test_login_ip_limit_cannot_be_bypassed_by_changing_email():
    client = Client()

    for index in range(20):
        response = client.post(
            "/connexion/",
            {"username": f"inconnu-{index}@example.org", "password": "incorrect"},
        )
        assert response.status_code == 200
    response = client.post(
        "/connexion/",
        {"username": "autre@example.org", "password": "incorrect"},
    )

    assert response.status_code == 429


@override_settings(MAILERS=MAILERS_LOCAL)
def test_password_reset_is_rate_limited_and_does_not_reveal_unknown_accounts():
    client = Client()

    for _ in range(5):
        response = client.post(
            "/mot-de-passe/oublie/",
            {"email": "inconnu@example.org"},
        )
        assert response.status_code == 302
    response = client.post(
        "/mot-de-passe/oublie/",
        {"email": "inconnu@example.org"},
    )

    assert response.status_code == 429
    assert len(mail.outbox) == 0


@override_settings(MAILERS=MAILERS_LOCAL)
def test_password_reset_changes_password_and_revokes_existing_sessions():
    compte = _creer_utilisateur("recuperation@example.org")
    session_client = Client()
    assert session_client.login(
        username=compte.email,
        password="mot-de-passe-solide",
    )
    reset_client = Client()

    demande = reset_client.post(
        "/mot-de-passe/oublie/",
        {"email": compte.email},
    )
    assert demande.status_code == 302
    lien = re.search(
        r"http://testserver(/mot-de-passe/reinitialiser/\S+)",
        mail.outbox[0].body,
    ).group(1)
    page_initiale = reset_client.get(lien)
    assert page_initiale.status_code == 302
    assert page_initiale["Cache-Control"] == "no-store"
    assert page_initiale["Referrer-Policy"] == "no-referrer"
    page = reset_client.get(lien, follow=True)
    confirmation_url = urlparse(page.wsgi_request.path).path
    reponse = reset_client.post(
        confirmation_url,
        {
            "new_password1": "nouveau-mot-de-passe-solide",
            "new_password2": "nouveau-mot-de-passe-solide",
        },
        follow=True,
    )

    compte.refresh_from_db()
    session_revoquee = session_client.get(reverse("tableau_de_bord:accueil"))
    assert reponse.status_code == 200
    assert compte.check_password("nouveau-mot-de-passe-solide")
    assert session_revoquee.status_code == 302
    assert session_revoquee["Location"].startswith("/connexion/?next=")


@override_settings(MAILERS=MAILERS_LOCAL)
def test_password_reset_form_allows_same_origin_post_but_rejects_null_origin():
    compte = _creer_utilisateur("csrf-recuperation@example.org")
    client = Client()
    client.post(
        "/mot-de-passe/oublie/",
        {"email": compte.email},
    )
    lien = re.search(
        r"http://testserver(/mot-de-passe/reinitialiser/\S+)",
        mail.outbox[0].body,
    ).group(1)

    csrf_client = Client(enforce_csrf_checks=True)
    page_initiale = csrf_client.get(lien)
    assert page_initiale.status_code == 302
    assert page_initiale["Referrer-Policy"] == "no-referrer"
    page_formulaire = csrf_client.get(lien, follow=True)
    assert page_formulaire.status_code == 200
    assert page_formulaire["Referrer-Policy"] == "same-origin"

    chemin_propre = urlparse(page_formulaire.wsgi_request.path).path
    csrf_token = csrf_client.cookies["csrftoken"].value
    origine_nulle = csrf_client.post(
        chemin_propre,
        {
            "new_password1": "nouveau-mot-de-passe-solide",
            "new_password2": "nouveau-mot-de-passe-solide",
        },
        HTTP_X_CSRFTOKEN=csrf_token,
        HTTP_ORIGIN="null",
    )
    assert origine_nulle.status_code == 403

    confirmation = csrf_client.post(
        chemin_propre,
        {
            "new_password1": "nouveau-mot-de-passe-solide",
            "new_password2": "nouveau-mot-de-passe-solide",
        },
        HTTP_X_CSRFTOKEN=csrf_token,
        HTTP_ORIGIN="http://testserver",
    )
    compte.refresh_from_db()
    assert confirmation.status_code == 302
    assert compte.check_password("nouveau-mot-de-passe-solide")
