"""Tests du modèle de compte global."""

import pytest
from django.contrib.admin.sites import AdminSite
from django.contrib.auth import get_user_model
from django.test import RequestFactory
from django.utils import timezone

from applications.comptes.admin import AdministrationCompteUtilisateur

CompteUtilisateur = get_user_model()


@pytest.mark.django_db
def test_create_user_normalizes_email_and_hashes_password():
    account = CompteUtilisateur.objects.create_user("  ECOLE@EXAMPLE.ORG ", "mot-de-passe-solide")

    assert account.email == "ecole@example.org"
    assert account.check_password("mot-de-passe-solide")
    assert not account.is_staff
    assert not account.is_superuser
    assert account.pk is not None


def test_create_user_requires_email():
    with pytest.raises(ValueError, match="adresse e-mail"):
        CompteUtilisateur.objects.create_user(" ", "mot-de-passe-solide")


@pytest.mark.django_db
def test_create_superuser_requires_password():
    with pytest.raises(ValueError, match="mot de passe"):
        CompteUtilisateur.objects.create_superuser("admin@example.org", "")


@pytest.mark.django_db
def test_create_superuser_sets_required_flags():
    account = CompteUtilisateur.objects.create_superuser(
        "admin@example.org",
        "mot-de-passe-solide",
    )

    assert account.is_staff
    assert account.is_superuser
    assert account.is_active
    assert account.email_verifie_le is not None


@pytest.mark.django_db
def test_changing_email_in_admin_requires_verification_again():
    operator = CompteUtilisateur.objects.create_superuser(
        "operator@example.org",
        "mot-de-passe-solide",
    )
    account = CompteUtilisateur.objects.create_user(
        "initial@example.org",
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )
    account.email = "nouveau@example.org"
    admin = AdministrationCompteUtilisateur(CompteUtilisateur, AdminSite())

    request = RequestFactory().post("/admin/")
    request.user = operator
    admin.save_model(request, account, None, change=True)

    account.refresh_from_db()
    assert account.email_verifie_le is None
    assert operator.email_verifie_le is not None


@pytest.mark.django_db
def test_admin_marks_superuser_email_as_verified():
    operator = CompteUtilisateur.objects.create_superuser(
        "operator@example.org",
        "mot-de-passe-solide",
    )
    account = CompteUtilisateur.objects.create_user(
        "superuser@example.org",
        "mot-de-passe-solide",
    )
    account.is_superuser = True
    account.is_staff = True
    admin = AdministrationCompteUtilisateur(CompteUtilisateur, AdminSite())
    request = RequestFactory().post("/admin/")
    request.user = operator

    admin.save_model(request, account, None, change=True)

    account.refresh_from_db()
    assert account.email_verifie_le is not None
