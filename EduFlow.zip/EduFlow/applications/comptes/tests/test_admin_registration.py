import pytest
from django.apps import apps
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse

from applications.organisations.models import DemandeInscriptionTenant

pytestmark = pytest.mark.django_db


def test_all_concrete_application_models_are_registered_in_django_admin():
    models = (
        model
        for app in apps.get_app_configs()
        if app.name.startswith("applications.")
        for model in app.get_models()
    )

    non_administered = [
        model._meta.label for model in models if not admin.site.is_registered(model)
    ]

    assert non_administered == []


def test_superuser_can_open_domain_model_lists_and_add_forms_in_admin():
    user = get_user_model().objects.create_superuser(
        "admin-registration@example.org",
        "a-strong-test-password",
    )
    client = Client()
    client.force_login(user)

    index = client.get(reverse("admin:index"))
    assert index.status_code == 200
    assert "Tenants" in index.content.decode()
    assert "Paiements" in index.content.decode()

    for app in apps.get_app_configs():
        if not app.name.startswith("applications."):
            continue
        for model in app.get_models():
            opts = model._meta
            changelist = client.get(
                reverse(f"admin:{opts.app_label}_{opts.model_name}_changelist")
            )
            add_form = client.get(reverse(f"admin:{opts.app_label}_{opts.model_name}_add"))

            assert changelist.status_code == 200, opts.label
            if model is DemandeInscriptionTenant:
                assert add_form.status_code == 403, opts.label
            else:
                assert add_form.status_code == 200, opts.label


def test_superuser_created_account_is_email_verified_in_admin():
    operator = get_user_model().objects.create_superuser(
        "admin-creator@example.org",
        "a-strong-test-password",
    )
    client = Client()
    client.force_login(operator)

    response = client.post(
        reverse("admin:comptes_compteutilisateur_add"),
        {
            "email": "created-in-admin@example.org",
            "password1": "a-strong-test-password",
            "password2": "a-strong-test-password",
            "_save": "Enregistrer",
        },
    )

    assert response.status_code == 302
    account = get_user_model().objects.get(email="created-in-admin@example.org")
    assert account.email_verifie_le is not None


def test_superuser_can_verify_selected_email_addresses_in_bulk():
    operator = get_user_model().objects.create_superuser(
        "admin-action@example.org",
        "a-strong-test-password",
    )
    account = get_user_model().objects.create_user(
        "selected-account@example.org",
        "a-strong-test-password",
    )
    client = Client()
    client.force_login(operator)

    response = client.post(
        reverse("admin:comptes_compteutilisateur_changelist"),
        {
            "action": "verifier_adresses_email",
            "_selected_action": [str(account.pk)],
            "index": "0",
        },
        follow=True,
    )

    assert response.status_code == 200
    account.refresh_from_db()
    assert account.email_verifie_le is not None
