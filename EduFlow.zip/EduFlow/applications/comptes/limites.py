"""Limitation persistante des tentatives de connexion et de récupération."""

import hashlib
import hmac
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from applications.comptes.models import CompteurTentativeAuthentification

FENETRE_TENTATIVES = timedelta(minutes=15)
DUREE_BLOCAGE = timedelta(minutes=15)
NOMBRE_MAX_TENTATIVES = 5
NOMBRE_MAX_TENTATIVES_IP = 20
DUREE_CONSERVATION = timedelta(days=1)


def empreinte_requete(*, action: str, identifiant: str, adresse_ip: str) -> str:
    """Produit une clé opaque à partir de l’adresse et de l’IP du demandeur."""
    contenu = f"{action}\0{identifiant.strip().casefold()}\0{adresse_ip}".encode()
    return hmac.new(settings.SECRET_KEY.encode("utf-8"), contenu, hashlib.sha256).hexdigest()


def est_bloquee(empreinte: str) -> bool:
    """Réinitialise une fenêtre expirée ou indique si le délai de blocage court encore."""
    compteur = CompteurTentativeAuthentification.objects.filter(empreinte=empreinte).first()
    if compteur is None:
        return False
    maintenant = timezone.now()
    if compteur.bloque_jusqua and compteur.bloque_jusqua > maintenant:
        return True
    if compteur.fenetre_commencee_le + FENETRE_TENTATIVES <= maintenant:
        compteur.delete()
    elif compteur.bloque_jusqua:
        compteur.nombre_tentatives = 0
        compteur.bloque_jusqua = None
        compteur.fenetre_commencee_le = maintenant
        compteur.save(
            update_fields=(
                "nombre_tentatives",
                "bloque_jusqua",
                "fenetre_commencee_le",
                "modifie_le",
            )
        )
    return False


def enregistrer_tentative(
    empreinte: str,
    *,
    nombre_max: int = NOMBRE_MAX_TENTATIVES,
) -> None:
    """Compte une tentative et applique le seuil adapté à sa portée."""
    maintenant = timezone.now()
    with transaction.atomic():
        compteur, _ = CompteurTentativeAuthentification.objects.get_or_create(
            empreinte=empreinte,
            defaults={"fenetre_commencee_le": maintenant},
        )
        compteur = CompteurTentativeAuthentification.objects.select_for_update().get(
            pk=compteur.pk
        )
        if compteur.fenetre_commencee_le + FENETRE_TENTATIVES <= maintenant:
            compteur.nombre_tentatives = 0
            compteur.fenetre_commencee_le = maintenant
            compteur.bloque_jusqua = None
        compteur.nombre_tentatives += 1
        if compteur.nombre_tentatives >= nombre_max:
            compteur.bloque_jusqua = maintenant + DUREE_BLOCAGE
        compteur.save(
            update_fields=(
                "nombre_tentatives",
                "fenetre_commencee_le",
                "bloque_jusqua",
                "modifie_le",
            )
        )


def reinitialiser_tentatives(empreinte: str) -> None:
    """Supprime le compteur après une connexion réussie."""
    CompteurTentativeAuthentification.objects.filter(empreinte=empreinte).delete()


def purger_compteurs_expires() -> int:
    """Supprime les empreintes qui n’ont pas été modifiées depuis 24 heures."""
    seuil = timezone.now() - DUREE_CONSERVATION
    nombre, _ = CompteurTentativeAuthentification.objects.filter(modifie_le__lt=seuil).delete()
    return nombre
