"""Parcours HTML de gestion des profils apprenants et enseignants."""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods

from applications.admissions.services import (
    ConflitIdentifiantExterneAdmission,
    modifier_profil_apprenant,
)
from applications.personnes.forms import (
    FormulaireActivationProfil,
    FormulaireProfilApprenant,
    FormulaireProfilEnseignant,
)
from applications.personnes.models import ProfilApprenant, ProfilEnseignant
from applications.personnes.services import (
    ConflitProfilEnseignant,
    creer_profil_enseignant,
    modifier_donnees_profil_enseignant,
    modifier_profil_enseignant,
)
from applications.referentiels.views import _exiger_gestion
from applications.tableau_de_bord.views import _page_privee, _paginate


@login_required
@_page_privee
@require_http_methods(["GET"])
def profils_apprenants_html(request):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    profils = ProfilApprenant.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    ).select_related("personne", "compte")
    terme = request.GET.get("q", "").strip()
    if terme:
        profils = profils.filter(
            Q(personne__prenom__icontains=terme)
            | Q(personne__nom__icontains=terme)
            | Q(personne__identifiant_externe__icontains=terme)
            | Q(compte__email__icontains=terme)
        )
    return render(
        request,
        "personnes/apprenants.html",
        {
            **contexte,
            "page": _paginate(profils, request),
            "terme": terme,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def profils_enseignants_html(request):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    tenant = workspace.tenant
    institution = tenant.institution

    if request.method == "POST":
        profil = get_object_or_404(
            ProfilEnseignant.objects.filter(tenant=tenant, institution=institution),
            pk=request.POST.get("profil_id"),
        )
        activation = FormulaireActivationProfil(request.POST)
        if activation.is_valid():
            modifier_profil_enseignant(
                profil=profil,
                acteur=request.user,
                actif=activation.cleaned_data["actif"],
            )
            messages.success(request, _("Le statut du profil enseignant a été mis à jour."))
            return redirect("personnes_web:enseignants")
        messages.error(request, _("La valeur d’activation est invalide."))

    profils = ProfilEnseignant.objects.filter(
        tenant=tenant,
        institution=institution,
    ).select_related("personne", "compte")
    terme = request.GET.get("q", "").strip()
    if terme:
        profils = profils.filter(
            Q(personne__prenom__icontains=terme)
            | Q(personne__nom__icontains=terme)
            | Q(personne__identifiant_externe__icontains=terme)
            | Q(compte__email__icontains=terme)
        )
    return render(
        request,
        "personnes/enseignants.html",
        {
            **contexte,
            "profils": profils,
            "terme": terme,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def formulaire_profil_enseignant_html(request, profil_id=None):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    profil = None
    initial = None
    if profil_id is not None:
        profil = get_object_or_404(
            ProfilEnseignant.objects.select_related("personne", "compte").filter(
                tenant=workspace.tenant,
                institution=workspace.tenant.institution,
            ),
            pk=profil_id,
        )
        initial = {
            "cle_idempotence": profil.cle_idempotence,
            "prenom": profil.personne.prenom,
            "nom": profil.personne.nom,
            "courriel": profil.personne.courriel,
            "telephone": profil.personne.telephone,
            "identifiant_externe": profil.personne.identifiant_externe,
            "compte": profil.compte_id,
        }
    formulaire = FormulaireProfilEnseignant(
        request.POST or None,
        initial=initial,
        tenant=workspace.tenant,
        profil_actuel=profil,
    )
    if request.method == "POST" and formulaire.is_valid():
        identite = {
            champ: formulaire.cleaned_data[champ]
            for champ in ("prenom", "nom", "courriel", "telephone", "identifiant_externe")
        }
        try:
            if profil is None:
                profil, cree = creer_profil_enseignant(
                    tenant=workspace.tenant,
                    institution=workspace.tenant.institution,
                    acteur=request.user,
                    identite=identite,
                    compte=formulaire.cleaned_data["compte"],
                    cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
                )
            else:
                profil = modifier_donnees_profil_enseignant(
                    profil=profil,
                    acteur=request.user,
                    identite=identite,
                    compte=formulaire.cleaned_data["compte"],
                )
                cree = False
        except ConflitProfilEnseignant:
            formulaire.add_error(None, _("Ce profil, cet identifiant ou ce compte existe déjà."))
        except ValidationError as error:
            erreurs = getattr(error, "message_dict", None)
            if erreurs:
                for champ, details in erreurs.items():
                    formulaire.add_error(
                        champ if champ in formulaire.fields else None,
                        details,
                    )
            else:
                formulaire.add_error(None, error.messages)
        else:
            if cree:
                messages.success(
                    request,
                    _("Le profil de %(personne)s a été créé.") % {"personne": profil},
                )
            else:
                messages.success(
                    request,
                    _("Le profil de %(personne)s a été modifié.") % {"personne": profil},
                )
            return redirect("personnes_web:enseignants")

    return render(
        request,
        "personnes/formulaire_enseignant.html",
        {
            **contexte,
            "formulaire": formulaire,
            "profil": profil,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def modifier_profil_apprenant_html(request, profil_id):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    profil = get_object_or_404(
        ProfilApprenant.objects.select_related("personne").filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ),
        pk=profil_id,
    )
    initial = {
        champ: getattr(profil.personne, champ)
        for champ in (
            "prenom",
            "nom",
            "date_naissance",
            "courriel",
            "telephone",
            "identifiant_externe",
        )
    }
    formulaire = FormulaireProfilApprenant(
        request.POST if request.method == "POST" else None,
        initial=initial,
    )
    if request.method == "POST" and formulaire.is_valid():
        try:
            modifier_profil_apprenant(
                profil_id=profil.pk,
                tenant=workspace.tenant,
                acteur=request.user,
                modifications=formulaire.cleaned_data,
            )
        except ConflitIdentifiantExterneAdmission:
            formulaire.add_error(
                "identifiant_externe",
                _("Cet identifiant externe est déjà utilisé dans l’établissement."),
            )
        except ValidationError as error:
            erreurs = getattr(error, "message_dict", None)
            if erreurs:
                for champ, details in erreurs.items():
                    formulaire.add_error(
                        champ if champ in formulaire.fields else None,
                        details,
                    )
            else:
                formulaire.add_error(None, error.messages)
        else:
            messages.success(request, _("Le dossier de l’apprenant a été mis à jour."))
            return redirect("tableau_de_bord:apprenants")

    return render(
        request,
        "personnes/modifier_apprenant.html",
        {
            **contexte,
            "profil": profil,
            "formulaire": formulaire,
        },
    )
