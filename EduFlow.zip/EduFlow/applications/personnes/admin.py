from django.contrib import admin

from applications.personnes.models import Personne, ProfilApprenant, ProfilEnseignant

admin.site.register((Personne, ProfilApprenant, ProfilEnseignant))
