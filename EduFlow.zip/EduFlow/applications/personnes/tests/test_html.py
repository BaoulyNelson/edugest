"""Tests des parcours HTML de gestion des profils pédagogiques."""

import uuid

import pytest
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.organisations.models import (
    AdhesionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
)
from applications.organisations.services import provisionner_tenant
from applications.personnes.models import Personne, ProfilApprenant, ProfilEnseignant
from applications.referentiels.models import Institution

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email):
    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )


def _preparer_espace():
    proprietaire = _creer_utilisateur("profils-owner@example.org")
    tenant, _, _ = provisionner_tenant(
        createur=proprietaire,
        nom="Établissement des profils",
        cle_idempotence=uuid.uuid4(),
    )
    rendre_tenant_abonne(tenant, proprietaire)
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom="Établissement des profils",
        type_educatif="ecole",
        cree_par=proprietaire,
    )
    return proprietaire, tenant, institution


def test_manager_can_create_and_disable_teacher_profiles():
    proprietaire, tenant, institution = _preparer_espace()
    enseignant = _creer_utilisateur("teacher-profile@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=enseignant,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client = Client()
    client.force_login(proprietaire)
    url = reverse("personnes_web:enseignants")
    page = client.get(url)
    formulaire_creation = client.get(reverse("personnes_web:creer-enseignant"))

    creation = client.post(
        reverse("personnes_web:creer-enseignant"),
        {
            "cle_idempotence": str(
                formulaire_creation.context["formulaire"].initial["cle_idempotence"]
            ),
            "prenom": "Ari",
            "nom": "Enseignant",
            "courriel": "ARI@EXAMPLE.ORG",
            "telephone": "555-0101",
            "identifiant_externe": "teach-001",
            "compte": str(enseignant.pk),
        },
    )
    profil = ProfilEnseignant.objects.get(
        tenant=tenant,
        compte=enseignant,
    )
    assert page.status_code == 200
    assert "Ajouter un enseignant" in page.content.decode()
    assert 'name="prenom"' not in page.content.decode()
    assert formulaire_creation.status_code == 200
    assert creation.status_code == 302
    assert profil.personne.prenom == "Ari"
    assert profil.personne.courriel == "ari@example.org"
    assert profil.personne.identifiant_externe == "TEACH-001"
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="personnel.enseignant_cree",
        id_objet=str(profil.pk),
    ).exists()

    formulaire_modification = client.get(
        reverse("personnes_web:modifier-enseignant", args=(profil.pk,))
    )
    modification = client.post(
        reverse("personnes_web:modifier-enseignant", args=(profil.pk,)),
        {
            "cle_idempotence": str(profil.cle_idempotence),
            "prenom": "Ariane",
            "nom": "Enseignante",
            "courriel": "ariane@example.org",
            "telephone": "555-0102",
            "identifiant_externe": "teach-001",
            "compte": str(enseignant.pk),
        },
    )
    profil.personne.refresh_from_db()
    assert formulaire_modification.status_code == 200
    assert "Annuler" in formulaire_modification.content.decode()
    assert modification.status_code == 302
    assert profil.personne.prenom == "Ariane"
    assert profil.personne.nom == "Enseignante"

    desactivation = client.post(
        url,
        {
            "profil_id": str(profil.pk),
            "actif": "false",
        },
    )
    profil.refresh_from_db()
    assert desactivation.status_code == 302
    assert not profil.actif


def test_manager_can_edit_student_identity_and_duplicate_external_id_is_rejected():
    proprietaire, tenant, institution = _preparer_espace()
    personnes = [
        Personne.objects.create(
            cle_idempotence=uuid.uuid4(),
            tenant=tenant,
            institution=institution,
            cree_par=proprietaire,
            prenom=f"Élève {numero}",
            nom="Test",
            identifiant_externe=f"STUDENT-{numero}",
        )
        for numero in (1, 2)
    ]
    profils = [
        ProfilApprenant.objects.create(
            tenant=tenant,
            institution=institution,
            cree_par=proprietaire,
            personne=personne,
        )
        for personne in personnes
    ]
    client = Client()
    client.force_login(proprietaire)
    url = reverse("personnes_web:modifier-apprenant", args=(profils[0].pk,))

    page = client.get(url)
    assert page.status_code == 200
    assert "Élève 1" in page.content.decode()

    modifications = {
        "prenom": "Nadia",
        "nom": "Exemple",
        "date_naissance": "",
        "courriel": "nadia@example.org",
        "telephone": "555-0102",
        "identifiant_externe": "NADIA-001",
    }
    reponse = client.post(url, modifications)
    personnes[0].refresh_from_db()
    assert reponse.status_code == 302
    assert personnes[0].prenom == "Nadia"
    assert personnes[0].courriel == "nadia@example.org"

    modifications["identifiant_externe"] = personnes[1].identifiant_externe
    doublon = client.post(url, modifications)
    personnes[0].refresh_from_db()
    assert doublon.status_code == 200
    assert "déjà utilisé" in doublon.content.decode()
    assert personnes[0].identifiant_externe == "NADIA-001"


def test_student_profile_directory_includes_admitted_profiles_without_enrollment():
    proprietaire, tenant, institution = _preparer_espace()
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        prenom="Admis",
        nom="Sans inscription",
        identifiant_externe="ADM-001",
    )
    profil = ProfilApprenant.objects.create(
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        personne=personne,
    )
    client = Client()
    client.force_login(proprietaire)

    page = client.get(reverse("personnes_web:dossiers-apprenants"))
    resultat_recherche = client.get(
        reverse("personnes_web:dossiers-apprenants"),
        {"q": "ADM-001"},
    )

    assert page.status_code == 200
    assert "Admis Sans inscription" in page.content.decode()
    assert "Ouvrir le dossier" in page.content.decode()
    assert resultat_recherche.status_code == 200
    assert str(profil.pk) in resultat_recherche.content.decode()
