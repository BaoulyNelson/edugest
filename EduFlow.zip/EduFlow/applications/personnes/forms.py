"""Formulaires de gestion des profils et de liaison des comptes apprenants."""

import uuid

from django import forms
from django.contrib.auth import get_user_model
from django.db.models import Q

from applications.organisations.models import RoleAdhesion, StatutAdhesion
from applications.personnes.models import ProfilApprenant, ProfilEnseignant


class FormulaireProfilEnseignant(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    prenom = forms.CharField(max_length=100, label="Prénom")
    nom = forms.CharField(max_length=100, label="Nom")
    courriel = forms.EmailField(required=False, label="Courriel")
    telephone = forms.CharField(max_length=30, required=False, label="Téléphone")
    identifiant_externe = forms.CharField(
        max_length=80,
        required=False,
        label="Identifiant externe",
    )
    compte = forms.ModelChoiceField(
        queryset=get_user_model().objects.none(),
        required=False,
        empty_label="Aucun compte lié",
        label="Compte de connexion",
    )

    def __init__(self, *args, tenant, profil_actuel=None, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        comptes_deja_lies = ProfilEnseignant.objects.filter(
            tenant=tenant,
            compte__isnull=False,
        )
        if profil_actuel is not None:
            comptes_deja_lies = comptes_deja_lies.exclude(pk=profil_actuel.pk)
        comptes_deja_lies = comptes_deja_lies.values("compte_id")
        self.fields["compte"].queryset = (
            get_user_model()
            .objects.filter(
                adhesions_tenant__tenant=tenant,
                adhesions_tenant__role=RoleAdhesion.ENSEIGNANT,
                adhesions_tenant__statut=StatutAdhesion.ACTIVE,
            )
            .exclude(pk__in=comptes_deja_lies)
            .distinct()
            .order_by("email")
        )
        if profil_actuel is not None and profil_actuel.compte_id:
            self.fields["compte"].queryset = (
                get_user_model()
                .objects.filter(
                    Q(pk__in=self.fields["compte"].queryset.values("pk"))
                    | Q(pk=profil_actuel.compte_id)
                )
                .distinct()
                .order_by("email")
            )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class FormulaireActivationProfil(forms.Form):
    actif = forms.BooleanField(required=False)


class FormulaireProfilApprenant(forms.Form):
    prenom = forms.CharField(max_length=100, label="Prénom")
    nom = forms.CharField(max_length=100, label="Nom")
    date_naissance = forms.DateField(
        required=False,
        label="Date de naissance",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    courriel = forms.EmailField(required=False, label="Courriel")
    telephone = forms.CharField(max_length=30, required=False, label="Téléphone")
    identifiant_externe = forms.CharField(
        max_length=80,
        required=False,
        label="Identifiant externe",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class FormulaireLienCompteApprenant(forms.ModelForm):
    class Meta:
        model = ProfilApprenant
        fields = ("compte",)
        labels = {"compte": "Compte de l’apprenant"}

    def __init__(self, *args, tenant, **kwargs):
        super().__init__(*args, **kwargs)
        compte = self.instance.compte
        comptes_eligibles = get_user_model().objects.filter(
            adhesions_tenant__tenant=tenant,
            adhesions_tenant__statut=StatutAdhesion.ACTIVE,
            adhesions_tenant__role=RoleAdhesion.MEMBRE,
        )
        profils_deja_lies = ProfilApprenant.objects.filter(
            tenant=tenant,
            compte__isnull=False,
        ).exclude(pk=self.instance.pk)
        comptes_eligibles = comptes_eligibles.exclude(
            pk__in=profils_deja_lies.values("compte_id")
        )
        if compte is not None:
            comptes_eligibles = get_user_model().objects.filter(
                Q(pk__in=comptes_eligibles.values("pk")) | Q(pk=compte.pk)
            )
        self.fields["compte"].queryset = comptes_eligibles.distinct()
        self.fields["compte"].required = False
        self.fields["compte"].empty_label = "Aucun compte lié"
        self.fields["compte"].widget.attrs["class"] = "form-control"
