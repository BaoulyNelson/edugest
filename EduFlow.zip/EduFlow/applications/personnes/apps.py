"""Configuration des personnes et profils apprenants."""

from django.apps import AppConfig


class PersonnesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.personnes"
    label = "personnes"
    verbose_name = "Personnes et apprenants"
