"""Routes HTML de gestion des profils pédagogiques."""

from django.urls import path

from applications.personnes.views import (
    formulaire_profil_enseignant_html,
    modifier_profil_apprenant_html,
    profils_apprenants_html,
    profils_enseignants_html,
)

app_name = "personnes_web"

urlpatterns = [
    path(
        "espace/enseignants/creer/",
        formulaire_profil_enseignant_html,
        name="creer-enseignant",
    ),
    path(
        "espace/enseignants/<uuid:profil_id>/modifier/",
        formulaire_profil_enseignant_html,
        name="modifier-enseignant",
    ),
    path("espace/enseignants/", profils_enseignants_html, name="enseignants"),
    path("espace/dossiers-apprenants/", profils_apprenants_html, name="dossiers-apprenants"),
    path(
        "espace/apprenants/<uuid:profil_id>/modifier/",
        modifier_profil_apprenant_html,
        name="modifier-apprenant",
    ),
]
