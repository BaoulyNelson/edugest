"""Dossiers personnels et profils apprenants détenus par un tenant."""

import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q
from django.utils import timezone

from applications.organisations.models import (
    AdhesionTenant,
    StatutAdhesion,
    Tenant,
)
from applications.referentiels.models import Institution


class ObjetEducatifTenant(models.Model):
    """Propriété commune aux dossiers éducatifs tenant-scoped."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.PROTECT,
        related_name="%(class)ss",
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.PROTECT,
        related_name="%(class)ss",
    )
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="%(class)ss_crees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

    def clean(self):
        super().clean()
        if (
            self.tenant_id
            and self.institution_id
            and self.institution.tenant_id != self.tenant_id
        ):
            raise ValidationError(
                {"institution": "L’institution doit appartenir au tenant sélectionné."}
            )


class Personne(ObjetEducatifTenant):
    """Identité personnelle minimale, indépendante d’un compte de connexion."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    prenom = models.CharField(max_length=100)
    nom = models.CharField(max_length=100)
    date_naissance = models.DateField(null=True, blank=True)
    courriel = models.EmailField(blank=True)
    telephone = models.CharField(max_length=30, blank=True)
    identifiant_externe = models.CharField(max_length=80, blank=True)

    class Meta:
        ordering = ("nom", "prenom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "identifiant_externe"),
                condition=~Q(identifiant_externe=""),
                name="personne_tenant_identifiant_unique",
            ),
        ]
        indexes = [
            models.Index(fields=("tenant", "nom", "prenom"), name="personne_tenant_nom_idx"),
        ]
        verbose_name = "personne"
        verbose_name_plural = "personnes"

    def __str__(self) -> str:
        return f"{self.prenom} {self.nom}"

    def clean(self):
        super().clean()
        self.identifiant_externe = self.identifiant_externe.strip().upper()
        if self.date_naissance and self.date_naissance > timezone.localdate():
            raise ValidationError(
                {"date_naissance": "La date de naissance ne peut pas être future."}
            )


class ProfilApprenant(ObjetEducatifTenant):
    """Dossier scolaire durable créé après une admission acceptée."""

    compte = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="profils_apprenants",
    )
    personne = models.ForeignKey(
        Personne,
        on_delete=models.PROTECT,
        related_name="profils_apprenants",
    )

    class Meta:
        ordering = ("personne__nom", "personne__prenom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "personne"),
                name="apprenant_tenant_personne_unique",
            ),
            models.UniqueConstraint(
                fields=("tenant", "compte"),
                condition=Q(compte__isnull=False),
                name="apprenant_tenant_compte_unique",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "institution"),
                name="apprenant_tenant_inst_idx",
            ),
        ]
        verbose_name = "profil apprenant"
        verbose_name_plural = "profils apprenants"

    def __str__(self) -> str:
        return str(self.personne)

    def clean(self):
        super().clean()
        if self.personne_id and (
            self.personne.tenant_id != self.tenant_id
            or self.personne.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"personne": "La personne doit appartenir au même tenant et à la même institution."}
            )
        if self.compte_id and not AdhesionTenant.objects.filter(
            tenant_id=self.tenant_id,
            utilisateur_id=self.compte_id,
            statut=StatutAdhesion.ACTIVE,
        ).exists():
            raise ValidationError(
                {"compte": "Le compte doit être membre actif de l’établissement."}
            )


class ProfilEnseignant(ObjetEducatifTenant):
    """Profil pédagogique d’un enseignant, lié facultativement à un compte."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    personne = models.ForeignKey(
        Personne,
        on_delete=models.PROTECT,
        related_name="profils_enseignants",
    )
    compte = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="profils_enseignants",
    )
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("personne__nom", "personne__prenom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "personne"),
                name="enseignant_tenant_personne_unique",
            ),
            models.UniqueConstraint(
                fields=("tenant", "compte"),
                condition=Q(compte__isnull=False),
                name="enseignant_tenant_compte_unique",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "actif"),
                name="enseignant_tenant_actif_idx",
            ),
        ]
        verbose_name = "profil enseignant"
        verbose_name_plural = "profils enseignants"

    def __str__(self) -> str:
        return str(self.personne)

    def clean(self):
        super().clean()
        if self.personne_id and (
            self.personne.tenant_id != self.tenant_id
            or self.personne.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"personne": "La personne doit appartenir au même tenant et à la même institution."}
            )
