"""Transactions de création et de gestion des profils enseignants."""

import uuid

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from applications.organisations.models import (
    AdhesionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
    Tenant,
)
from applications.personnes.models import Personne, ProfilEnseignant
from applications.referentiels.models import Institution


class ConflitProfilEnseignant(Exception):
    """Un profil, une clé ou un identifiant externe est déjà utilisé."""


def creer_profil_enseignant(
    *,
    tenant: Tenant,
    institution: Institution,
    acteur,
    identite: dict,
    compte,
    cle_idempotence: uuid.UUID,
) -> tuple[ProfilEnseignant, bool]:
    identite = {
        "prenom": identite["prenom"].strip(),
        "nom": identite["nom"].strip(),
        "courriel": identite.get("courriel", "").strip().lower(),
        "telephone": identite.get("telephone", "").strip(),
        "identifiant_externe": identite.get("identifiant_externe", "").strip().upper(),
    }
    if institution.tenant_id != tenant.pk:
        raise ValidationError("L’institution ne correspond pas au tenant actif.")

    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = (
            ProfilEnseignant.objects.select_related("personne")
            .filter(cle_idempotence=cle_idempotence)
            .first()
        )
        if existant is not None:
            if (
                existant.tenant_id == tenant.pk
                and existant.institution_id == institution.pk
                and existant.cree_par_id == acteur.pk
                and existant.compte_id == getattr(compte, "pk", None)
                and all(
                    getattr(existant.personne, champ) == valeur
                    for champ, valeur in identite.items()
                )
            ):
                return existant, False
            raise ConflitProfilEnseignant
        if compte is not None and not AdhesionTenant.objects.filter(
            tenant=tenant,
            utilisateur=compte,
            role=RoleAdhesion.ENSEIGNANT,
            statut=StatutAdhesion.ACTIVE,
        ).exists():
            raise ValidationError(
                {
                    "compte": (
                        "Le compte doit avoir une adhésion enseignant active dans ce tenant."
                    )
                }
            )
        if compte is not None and ProfilEnseignant.objects.filter(
            tenant=tenant,
            compte=compte,
        ).exists():
            raise ConflitProfilEnseignant

        personne = Personne(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=uuid.uuid4(),
            **identite,
        )
        personne.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        if identite["identifiant_externe"] and Personne.objects.filter(
            tenant=tenant,
            identifiant_externe=identite["identifiant_externe"],
        ).exists():
            raise ConflitProfilEnseignant

        profil = ProfilEnseignant(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=cle_idempotence,
            personne=personne,
            compte=compte,
        )
        profil.full_clean(
            exclude=("cle_idempotence", "personne"),
            validate_unique=False,
            validate_constraints=False,
        )
        try:
            with transaction.atomic():
                personne.save(force_insert=True)
                profil.save(force_insert=True)
        except IntegrityError as error:
            if identite["identifiant_externe"] and Personne.objects.filter(
                tenant=tenant,
                identifiant_externe=identite["identifiant_externe"],
            ).exists():
                raise ConflitProfilEnseignant from error
            raise

        EvenementAudit.objects.create(
            tenant=tenant,
            acteur=acteur,
            action="personnel.enseignant_cree",
            type_objet="personnes.profilenseignant",
            id_objet=str(profil.pk),
            details={"champs": ["personne", "compte"]},
        )
        return profil, True


def modifier_profil_enseignant(
    *,
    profil: ProfilEnseignant,
    acteur,
    actif: bool,
) -> ProfilEnseignant:
    with transaction.atomic():
        profil = (
            ProfilEnseignant.objects.select_for_update()
            .select_related("tenant")
            .get(pk=profil.pk, tenant=profil.tenant)
        )
        if profil.actif != actif:
            profil.actif = actif
            profil.save(update_fields=("actif", "modifie_le"))
            EvenementAudit.objects.create(
                tenant=profil.tenant,
                acteur=acteur,
                action="personnel.enseignant_modifie",
                type_objet="personnes.profilenseignant",
                id_objet=str(profil.pk),
                details={"champs": ["actif"]},
            )
        return profil


def modifier_donnees_profil_enseignant(
    *,
    profil: ProfilEnseignant,
    acteur,
    identite: dict,
    compte,
) -> ProfilEnseignant:
    identite = {
            "prenom": identite["prenom"].strip(),
            "nom": identite["nom"].strip(),
            "courriel": identite.get("courriel", "").strip().lower(),
            "telephone": identite.get("telephone", "").strip(),
            "identifiant_externe": identite.get("identifiant_externe", "").strip().upper(),
    }
    with transaction.atomic():
            profil = (
                ProfilEnseignant.objects.select_for_update()
                .select_related("tenant", "personne")
                .get(pk=profil.pk, tenant=profil.tenant)
            )
            if compte is not None and not AdhesionTenant.objects.filter(
                tenant=profil.tenant,
                utilisateur=compte,
                role=RoleAdhesion.ENSEIGNANT,
                statut=StatutAdhesion.ACTIVE,
            ).exists():
                raise ValidationError(
                    {
                        "compte": (
                            "Le compte doit avoir une adhésion enseignant active dans ce tenant."
                        )
                    }
                )
            if compte is not None and ProfilEnseignant.objects.filter(
                tenant=profil.tenant,
                compte=compte,
            ).exclude(pk=profil.pk).exists():
                raise ConflitProfilEnseignant

            personne = Personne.objects.select_for_update().get(
                pk=profil.personne_id,
                tenant=profil.tenant,
                institution=profil.institution,
            )
            for champ, valeur in identite.items():
                setattr(personne, champ, valeur)
            personne.full_clean(
                exclude=("cle_idempotence",),
                validate_unique=False,
                validate_constraints=False,
            )
            if identite["identifiant_externe"] and Personne.objects.filter(
                tenant=profil.tenant,
                identifiant_externe=identite["identifiant_externe"],
            ).exclude(pk=personne.pk).exists():
                raise ConflitProfilEnseignant
            personne.save()

            champs_modifies = [
                champ
                for champ, valeur in identite.items()
                if getattr(profil.personne, champ) != valeur
            ]
            if profil.compte_id != getattr(compte, "pk", None):
                profil.compte = compte
                champs_modifies.append("compte")
            if champs_modifies:
                profil.save(update_fields=("compte", "modifie_le"))
                EvenementAudit.objects.create(
                    tenant=profil.tenant,
                    acteur=acteur,
                    action="personnel.enseignant_modifie",
                    type_objet="personnes.profilenseignant",
                    id_objet=str(profil.pk),
                    details={"champs": champs_modifies},
                )
            return profil
