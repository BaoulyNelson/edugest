from django.contrib import admin

from applications.pedagogie.models import (
    Devoir,
    PlanCours,
    QuestionQuiz,
    Quiz,
    RessourcePedagogique,
)


@admin.register(PlanCours)
class PlanCoursAdmin(admin.ModelAdmin):
    list_display = ("titre", "date", "affectation", "tenant", "cree_par")
    list_filter = ("date", "tenant")
    search_fields = ("titre", "objectifs", "affectation__cours__nom", "affectation__groupe__nom")
    readonly_fields = ("cree_le", "modifie_le")


@admin.register(Devoir)
class DevoirAdmin(admin.ModelAdmin):
    list_display = ("titre", "a_rendre_le", "affectation", "tenant", "cree_par")
    list_filter = ("a_rendre_le", "tenant")
    search_fields = ("titre", "consignes", "affectation__cours__nom", "affectation__groupe__nom")
    readonly_fields = ("cree_le", "modifie_le")


class QuestionQuizInline(admin.TabularInline):
    model = QuestionQuiz
    extra = 0


@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ("titre", "affectation", "tenant", "actif")
    list_filter = ("actif", "tenant")
    search_fields = ("titre", "description", "affectation__cours__nom")
    readonly_fields = ("cree_le", "modifie_le")
    inlines = (QuestionQuizInline,)


@admin.register(QuestionQuiz)
class QuestionQuizAdmin(admin.ModelAdmin):
    list_display = ("enonce", "quiz", "ordre", "tenant")
    list_filter = ("tenant",)
    search_fields = ("enonce", "quiz__titre")
    readonly_fields = ("cree_le", "modifie_le")


@admin.register(RessourcePedagogique)
class RessourcePedagogiqueAdmin(admin.ModelAdmin):
    list_display = ("titre", "tenant", "affectation", "cree_par", "cree_le")
    list_filter = ("tenant", "cree_le")
    search_fields = ("titre", "description", "affectation__cours__nom")
    readonly_fields = ("cree_le", "modifie_le")
