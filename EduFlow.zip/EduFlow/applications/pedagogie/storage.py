"""Stockage non exposé par la route publique des fichiers média."""

from pathlib import Path

from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.utils.deconstruct import deconstructible


@deconstructible
class PrivateRessourceStorage(FileSystemStorage):
    def __init__(self):
        super().__init__(location=Path(settings.BASE_DIR) / "private", base_url="")

    def url(self, name):
        raise ValueError("Les ressources privées doivent être servies par une vue autorisée.")
