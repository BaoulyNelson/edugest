"""Formulaires de création de contenus pédagogiques."""

from django import forms

from applications.pedagogie.models import Devoir, PlanCours, Quiz, RessourcePedagogique


class FormulairePedagogique(forms.ModelForm):
    def __init__(self, *args, affectations, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["affectation"].queryset = affectations
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"


class FormulairePlanCours(FormulairePedagogique):
    class Meta:
        model = PlanCours
        fields = ("affectation", "date", "titre", "objectifs", "contenu")
        labels = {
            "affectation": "Cours et groupe",
            "date": "Date du cours",
            "titre": "Titre du plan",
            "objectifs": "Objectifs pédagogiques",
            "contenu": "Déroulement et ressources",
        }
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}),
            "objectifs": forms.Textarea(attrs={"rows": 3}),
            "contenu": forms.Textarea(attrs={"rows": 5}),
        }


class FormulaireDevoir(FormulairePedagogique):
    class Meta:
        model = Devoir
        fields = ("affectation", "titre", "consignes", "publie_le", "a_rendre_le")
        labels = {
            "affectation": "Cours et groupe",
            "titre": "Titre du devoir",
            "consignes": "Consignes",
            "publie_le": "Date de publication",
            "a_rendre_le": "Date limite",
        }
        widgets = {
            "consignes": forms.Textarea(attrs={"rows": 5}),
            "publie_le": forms.DateInput(attrs={"type": "date"}),
            "a_rendre_le": forms.DateInput(attrs={"type": "date"}),
        }


class FormulaireQuiz(FormulairePedagogique):
    class Meta:
        model = Quiz
        fields = ("affectation", "titre", "description")
        labels = {
            "affectation": "Cours et groupe",
            "titre": "Titre du quiz",
            "description": "Description",
        }
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }


class FormulaireQuestionQuiz(forms.Form):
    enonce = forms.CharField(
        label="Question",
        max_length=500,
        widget=forms.TextInput(attrs={"class": "form-control"}),
    )
    options = forms.CharField(
        label="Réponses proposées (une par ligne, deux à six)",
        widget=forms.Textarea(attrs={"class": "form-control", "rows": 5}),
    )
    reponse_correcte = forms.IntegerField(
        label="Numéro de la bonne réponse",
        min_value=1,
        max_value=6,
        widget=forms.NumberInput(attrs={"class": "form-control", "min": 1, "max": 6}),
    )

    def clean_options(self):
        options = [option.strip() for option in self.cleaned_data["options"].splitlines()]
        options = [option for option in options if option]
        if not 2 <= len(options) <= 6:
            raise forms.ValidationError("Saisissez entre deux et six réponses.")
        if len({option.casefold() for option in options}) != len(options):
            raise forms.ValidationError("Chaque réponse proposée doit être unique.")
        return options

    def clean(self):
        cleaned_data = super().clean()
        options = cleaned_data.get("options")
        reponse_correcte = cleaned_data.get("reponse_correcte")
        if options and reponse_correcte and reponse_correcte > len(options):
            self.add_error(
                "reponse_correcte",
                "Le numéro doit correspondre à une réponse proposée.",
            )
        return cleaned_data


class FormulaireRessource(forms.ModelForm):
    def __init__(self, *args, affectations, autoriser_partage, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["affectation"].queryset = affectations
        self.fields["affectation"].required = not autoriser_partage
        self.fields["fichier"].widget.attrs["accept"] = ".pdf,.jpg,.jpeg,.png,.txt"
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"

    class Meta:
        model = RessourcePedagogique
        fields = ("affectation", "titre", "description", "fichier")
        labels = {
            "affectation": "Cours et groupe",
            "titre": "Titre de la ressource",
            "description": "Description",
            "fichier": "Fichier (PDF, JPG, PNG ou TXT · 10 Mo maximum)",
        }
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }
