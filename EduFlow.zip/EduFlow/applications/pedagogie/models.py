"""Plans de cours et devoirs associés aux affectations pédagogiques."""

import uuid
from pathlib import Path

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.emplois_temps.models import AffectationEnseignement
from applications.pedagogie.storage import PrivateRessourceStorage
from applications.personnes.models import ObjetEducatifTenant

EXTENSIONS_RESSOURCES_AUTORISEES = {".jpeg", ".jpg", ".pdf", ".png", ".txt"}
TAILLE_MAX_RESSOURCE = 10 * 1024 * 1024


def chemin_fichier_ressource(instance, nom_fichier):
    extension = Path(nom_fichier).suffix.lower()
    return f"pedagogie/{instance.tenant_id}/{uuid.uuid4().hex}{extension}"


def valider_fichier_ressource(fichier):
    extension = Path(fichier.name).suffix.lower()
    if extension not in EXTENSIONS_RESSOURCES_AUTORISEES:
        raise ValidationError("Format non pris en charge. Utilisez PDF, JPG, PNG ou TXT.")
    if fichier.size > TAILLE_MAX_RESSOURCE:
        raise ValidationError("Le fichier ne doit pas dépasser 10 Mo.")


class PlanCours(ObjetEducatifTenant):
    affectation = models.ForeignKey(
        AffectationEnseignement,
        on_delete=models.PROTECT,
        related_name="plans_cours",
    )
    date = models.DateField()
    titre = models.CharField(max_length=180)
    objectifs = models.TextField()
    contenu = models.TextField(blank=True)

    class Meta:
        ordering = ("date", "affectation__cours__nom", "titre")
        indexes = [
            models.Index(
                fields=("tenant", "date"),
                name="plan_cours_tenant_date_idx",
            ),
        ]
        verbose_name = "plan de cours"
        verbose_name_plural = "plans de cours"

    def __str__(self):
        return f"{self.date} — {self.titre}"

    def clean(self):
        super().clean()
        if self.affectation_id and (
            self.affectation.tenant_id != self.tenant_id
            or self.affectation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"affectation": "L’affectation doit appartenir au même établissement."}
            )
        if self.affectation_id and self.date and not (
            self.affectation.date_debut <= self.date <= self.affectation.date_fin
        ):
            raise ValidationError(
                {"date": "La date doit se situer pendant la période de l’affectation."}
            )


class Devoir(ObjetEducatifTenant):
    affectation = models.ForeignKey(
        AffectationEnseignement,
        on_delete=models.PROTECT,
        related_name="devoirs",
    )
    titre = models.CharField(max_length=180)
    consignes = models.TextField()
    publie_le = models.DateField()
    a_rendre_le = models.DateField()

    class Meta:
        ordering = ("a_rendre_le", "affectation__cours__nom", "titre")
        constraints = [
            models.CheckConstraint(
                condition=Q(a_rendre_le__gte=models.F("publie_le")),
                name="devoir_date_remise_valide",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "a_rendre_le"),
                name="devoir_tenant_remise_idx",
            ),
        ]
        verbose_name = "devoir"
        verbose_name_plural = "devoirs"

    def __str__(self):
        return self.titre

    def clean(self):
        super().clean()
        if self.affectation_id and (
            self.affectation.tenant_id != self.tenant_id
            or self.affectation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"affectation": "L’affectation doit appartenir au même établissement."}
            )
        if self.publie_le and self.a_rendre_le and self.a_rendre_le < self.publie_le:
            raise ValidationError(
                {"a_rendre_le": "La date de remise doit suivre la date de publication."}
            )
        if self.affectation_id and self.publie_le and self.a_rendre_le:
            if (
                self.publie_le < self.affectation.date_debut
                or self.a_rendre_le > self.affectation.date_fin
            ):
                raise ValidationError(
                    {"a_rendre_le": "Les dates du devoir doivent rester dans la période du cours."}
                )


class Quiz(ObjetEducatifTenant):
    affectation = models.ForeignKey(
        AffectationEnseignement,
        on_delete=models.PROTECT,
        related_name="quiz",
    )
    titre = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("titre", "id")
        indexes = [
            models.Index(fields=("tenant", "actif"), name="quiz_tenant_actif_idx"),
        ]
        verbose_name = "quiz"
        verbose_name_plural = "quiz"

    def __str__(self):
        return self.titre

    def clean(self):
        super().clean()
        if self.affectation_id and (
            self.affectation.tenant_id != self.tenant_id
            or self.affectation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"affectation": "L’affectation doit appartenir au même établissement."}
            )


class QuestionQuiz(ObjetEducatifTenant):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name="questions")
    ordre = models.PositiveSmallIntegerField()
    enonce = models.CharField(max_length=500)
    options = models.JSONField()
    reponse_correcte = models.PositiveSmallIntegerField()

    class Meta:
        ordering = ("ordre", "id")
        constraints = [
            models.UniqueConstraint(fields=("quiz", "ordre"), name="quiz_question_ordre_unique"),
        ]
        verbose_name = "question de quiz"
        verbose_name_plural = "questions de quiz"

    def __str__(self):
        return self.enonce

    def clean(self):
        super().clean()
        erreurs = {}
        if self.quiz_id and (
            self.quiz.tenant_id != self.tenant_id
            or self.quiz.institution_id != self.institution_id
        ):
            erreurs["quiz"] = "Le quiz doit appartenir au même établissement."
        if not isinstance(self.options, list) or not 2 <= len(self.options) <= 6:
            erreurs["options"] = "Une question doit proposer de deux à six réponses."
        elif not all(isinstance(option, str) and option.strip() for option in self.options):
            erreurs["options"] = "Chaque réponse doit contenir du texte."
        elif len({option.strip().casefold() for option in self.options}) != len(self.options):
            erreurs["options"] = "Les réponses proposées doivent être uniques."
        elif not 0 <= self.reponse_correcte < len(self.options):
            erreurs["reponse_correcte"] = "La réponse correcte doit correspondre à une option."
        if erreurs:
            raise ValidationError(erreurs)


class RessourcePedagogique(ObjetEducatifTenant):
    affectation = models.ForeignKey(
        AffectationEnseignement,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="ressources",
    )
    titre = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    fichier = models.FileField(
        upload_to=chemin_fichier_ressource,
        validators=[valider_fichier_ressource],
        storage=PrivateRessourceStorage(),
    )

    class Meta:
        ordering = ("titre", "id")
        indexes = [
            models.Index(fields=("tenant", "cree_le"), name="ressource_tenant_date_idx"),
        ]
        verbose_name = "ressource pédagogique"
        verbose_name_plural = "ressources pédagogiques"

    def __str__(self):
        return self.titre

    def clean(self):
        super().clean()
        if self.affectation_id and (
            self.affectation.tenant_id != self.tenant_id
            or self.affectation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"affectation": "L’affectation doit appartenir au même établissement."}
            )
