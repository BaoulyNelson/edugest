from django.apps import AppConfig


class PedagogieConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.pedagogie"
    label = "pedagogie"
    verbose_name = "Pédagogie"
