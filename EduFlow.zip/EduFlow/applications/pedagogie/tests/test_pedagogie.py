"""Tests de création et de cloisonnement des contenus pédagogiques."""

import uuid
from datetime import date, timedelta

import pytest
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.admissions.models import Candidature, StatutCandidature
from applications.emplois_temps.models import AffectationEnseignement
from applications.inscriptions.models import Inscription, StatutInscription
from applications.organisations.models import (
    AdhesionTenant,
    RoleAdhesion,
    StatutAdhesion,
    StatutTenant,
    Tenant,
)
from applications.pedagogie.models import (
    Devoir,
    PlanCours,
    QuestionQuiz,
    Quiz,
    RessourcePedagogique,
)
from applications.personnes.models import Personne, ProfilApprenant, ProfilEnseignant
from applications.referentiels.models import (
    AnneeAcademique,
    Cours,
    Groupe,
    Institution,
    Programme,
)

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email):
    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )


def _creer_gestionnaire(tenant, acteur, email):
    gestionnaire = _creer_utilisateur(email)
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=gestionnaire,
        role=RoleAdhesion.GESTIONNAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=acteur,
    )
    return gestionnaire


def _creer_affectation(nom, proprietaire):
    tenant = Tenant.objects.create(
        nom=nom,
        statut=StatutTenant.ACTIF,
        cle_idempotence=uuid.uuid4(),
        cree_par=proprietaire,
    )
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=f"Établissement {nom}",
        type_educatif="ecole",
        cree_par=proprietaire,
    )
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=proprietaire,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    rendre_tenant_abonne(tenant, proprietaire)
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        nom="2026-2027",
        debut=date(2026, 1, 1),
        fin=date(2026, 12, 31),
    )
    groupe = Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        annee_academique=annee,
        code=f"groupe-{tenant.pk.hex[:8]}",
        nom=f"Groupe {nom}",
    )
    cours = Cours.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        code=f"cours-{tenant.pk.hex[:8]}",
        nom=f"Cours {nom}",
    )
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        prenom="Professeur",
        nom=nom,
    )
    enseignant = ProfilEnseignant.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        personne=personne,
        compte=proprietaire,
    )
    affectation = AffectationEnseignement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=proprietaire,
        enseignant=enseignant,
        annee_academique=annee,
        groupe=groupe,
        cours=cours,
        date_debut=annee.debut,
        date_fin=annee.fin,
    )
    return tenant, affectation


def _activer_tenant(client, tenant):
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()


def _inscrire_apprenant(tenant, affectation, acteur, compte):
    identifiant = uuid.uuid4().hex[:8]
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=compte,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=acteur,
    )
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=acteur,
        prenom="Élève",
        nom=identifiant,
    )
    programme = Programme.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=acteur,
        code=f"programme-{identifiant}",
        nom=f"Programme {identifiant}",
    )
    candidature = Candidature.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=acteur,
        reference=f"CAND-{identifiant}",
        personne=personne,
        annee_academique=affectation.annee_academique,
        programme=programme,
        statut=StatutCandidature.SOUMISE,
    )
    apprenant = ProfilApprenant.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=acteur,
        personne=personne,
        compte=compte,
    )
    Inscription.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=acteur,
        candidature=candidature,
        apprenant=apprenant,
        annee_academique=affectation.annee_academique,
        programme=programme,
        groupe=affectation.groupe,
        statut=StatutInscription.ACTIVE,
        date_debut=affectation.date_debut,
    )
    return apprenant


def test_manager_can_create_plan_and_homework_for_active_tenant():
    proprietaire = _creer_utilisateur("pedagogie-owner@example.org")
    tenant, affectation = _creer_affectation("Cours actifs", proprietaire)
    gestionnaire = _creer_gestionnaire(
        tenant,
        proprietaire,
        "pedagogie-manager@example.org",
    )
    client = Client()
    client.force_login(gestionnaire)
    _activer_tenant(client, tenant)

    plan = client.post(
        reverse("pedagogie:plans"),
        {
            "affectation": str(affectation.pk),
            "date": "2026-04-15",
            "titre": "Les fractions",
            "objectifs": "Comparer deux fractions.",
            "contenu": "Exercices guidés.",
        },
    )
    devoir = client.post(
        reverse("pedagogie:devoirs"),
        {
            "affectation": str(affectation.pk),
            "titre": "Exercices sur les fractions",
            "consignes": "Résoudre les exercices 1 à 5.",
            "publie_le": "2026-04-15",
            "a_rendre_le": "2026-04-22",
        },
    )
    recherche = client.get(
        reverse("tableau_de_bord:recherche"),
        {"q": "fractions"},
    )

    assert plan.status_code == 302, plan.context["formulaire"].errors
    assert devoir.status_code == 302, devoir.context["formulaire"].errors
    assert recherche.status_code == 200
    assert "Les fractions" in recherche.content.decode()
    assert "Exercices sur les fractions" in recherche.content.decode()
    assert PlanCours.objects.get(tenant=tenant).affectation == affectation
    assert Devoir.objects.get(tenant=tenant).a_rendre_le == date(2026, 4, 22)


def test_owner_cannot_open_daily_pedagogical_management_pages():
    proprietaire = _creer_utilisateur("pedagogie-restricted-owner@example.org")
    tenant, _ = _creer_affectation("Activités réservées", proprietaire)
    client = Client()
    client.force_login(proprietaire)
    _activer_tenant(client, tenant)

    urls = (
        reverse("pedagogie:plans"),
        reverse("pedagogie:devoirs"),
        reverse("pedagogie:quiz"),
        reverse("pedagogie:quiz-detail", kwargs={"quiz_id": uuid.uuid4()}),
        reverse("pedagogie:bibliotheque"),
    )

    assert all(client.get(url).status_code == 403 for url in urls)


def test_teacher_only_sees_assigned_content_and_foreign_assignments_are_rejected():
    proprietaire = _creer_utilisateur("pedagogie-scope-owner@example.org")
    tenant, affectation = _creer_affectation("Cours privé", proprietaire)
    autre_proprietaire = _creer_utilisateur("pedagogie-foreign-owner@example.org")
    _, affectation_etrangere = _creer_affectation("Cours étranger", autre_proprietaire)
    PlanCours.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        affectation=affectation,
        date=date(2026, 2, 1),
        titre="Plan confidentiel",
        objectifs="Objectifs du groupe.",
    )
    enseignant_sans_affectation = _creer_utilisateur("pedagogie-no-assignment@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=enseignant_sans_affectation,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client = Client()
    client.force_login(enseignant_sans_affectation)
    _activer_tenant(client, tenant)

    page = client.get(reverse("pedagogie:plans"))
    recherche = client.get(
        reverse("tableau_de_bord:recherche"),
        {"q": "confidentiel"},
    )
    rejet = client.post(
        reverse("pedagogie:devoirs"),
        {
            "affectation": str(affectation_etrangere.pk),
            "titre": "Devoir hors tenant",
            "consignes": "Ne doit pas être enregistré.",
            "publie_le": "2026-04-15",
            "a_rendre_le": "2026-04-22",
        },
    )

    assert page.status_code == 200
    assert "Plan confidentiel" not in page.content.decode()
    assert "Aucun cours affecté" in page.content.decode()
    assert recherche.status_code == 200
    assert "Plan confidentiel" not in recherche.content.decode()
    assert rejet.status_code == 200
    assert not Devoir.objects.filter(titre="Devoir hors tenant").exists()


def test_quiz_creation_and_question_authoring_are_manual_and_tenant_scoped():
    proprietaire = _creer_utilisateur("quiz-owner@example.org")
    tenant, affectation = _creer_affectation("Quiz actif", proprietaire)
    autre_proprietaire = _creer_utilisateur("quiz-foreign-owner@example.org")
    _, affectation_etrangere = _creer_affectation(
        "Quiz étranger",
        autre_proprietaire,
    )
    gestionnaire = _creer_gestionnaire(
        tenant,
        proprietaire,
        "quiz-manager@example.org",
    )
    client = Client()
    client.force_login(gestionnaire)
    _activer_tenant(client, tenant)

    creation = client.post(
        reverse("pedagogie:quiz"),
        {
            "affectation": str(affectation.pk),
            "titre": "Quiz de fractions",
            "description": "Vérification des acquis.",
        },
    )
    quiz = Quiz.objects.get(tenant=tenant)
    question = client.post(
        reverse("pedagogie:quiz-detail", kwargs={"quiz_id": quiz.pk}),
        {
            "enonce": "Combien font un demi plus un demi ?",
            "options": "Un\nDeux\nTrois",
            "reponse_correcte": "1",
        },
    )
    contenu = client.get(reverse("pedagogie:quiz")).content.decode()
    resultats_recherche = client.get(
        reverse("tableau_de_bord:recherche"),
        {"q": "fractions"},
    ).content.decode()
    refus = client.post(
        reverse("pedagogie:quiz"),
        {
            "affectation": str(affectation_etrangere.pk),
            "titre": "Quiz hors tenant",
            "description": "",
        },
    )

    assert creation.status_code == 302
    assert question.status_code == 302
    assert QuestionQuiz.objects.get(quiz=quiz).reponse_correcte == 0
    assert "génération par IA externe est désactivée" in contenu
    assert "Quiz de fractions" in resultats_recherche
    assert refus.status_code == 200
    assert not Quiz.objects.filter(titre="Quiz hors tenant").exists()


def test_library_files_are_private_and_downloads_are_tenant_scoped():
    proprietaire = _creer_utilisateur("library-owner@example.org")
    tenant, affectation = _creer_affectation("Bibliothèque privée", proprietaire)
    autre_proprietaire = _creer_utilisateur("library-foreign-owner@example.org")
    autre_tenant, _ = _creer_affectation("Autre bibliothèque", autre_proprietaire)
    gestionnaire = _creer_gestionnaire(
        tenant,
        proprietaire,
        "library-manager@example.org",
    )
    autre_gestionnaire = _creer_gestionnaire(
        autre_tenant,
        autre_proprietaire,
        "library-other-manager@example.org",
    )
    client = Client()
    client.force_login(gestionnaire)
    _activer_tenant(client, tenant)

    upload = SimpleUploadedFile(
        "support.txt",
        b"Ressource reservee aux membres autorises.",
        content_type="text/plain",
    )
    creation = client.post(
        reverse("pedagogie:bibliotheque"),
        {
            "affectation": str(affectation.pk),
            "titre": "Support de cours",
            "description": "Notes de la séance.",
            "fichier": upload,
        },
    )
    ressource = RessourcePedagogique.objects.get(tenant=tenant)
    try:
        telechargement = client.get(
            reverse(
                "pedagogie:ressource-telecharger",
                kwargs={"ressource_id": ressource.pk},
            )
        )
        contenu = b"".join(telechargement.streaming_content)
        assert ressource.fichier.storage.location.endswith("\\private")
        with pytest.raises(ValueError):
            ressource.fichier.url
        recherche = client.get(
            reverse("tableau_de_bord:recherche"),
            {"q": "Support de cours"},
        )

        client.force_login(autre_gestionnaire)
        _activer_tenant(client, autre_tenant)
        refus = client.get(
            reverse(
                "pedagogie:ressource-telecharger",
                kwargs={"ressource_id": ressource.pk},
            )
        )

        assert creation.status_code == 302
        assert telechargement.status_code == 200
        assert "attachment" in telechargement["Content-Disposition"]
        assert telechargement["X-Content-Type-Options"] == "nosniff"
        assert contenu == b"Ressource reservee aux membres autorises."
        assert "Support de cours" in recherche.content.decode()
        assert refus.status_code == 404
    finally:
        ressource.fichier.delete(save=False)


def test_linked_learner_sees_only_own_active_group_content_and_can_read_library():
    proprietaire = _creer_utilisateur("learner-portal-owner@example.org")
    tenant, affectation = _creer_affectation("Cours de l’apprenant", proprietaire)
    compte = _creer_utilisateur("learner-portal-student@example.org")
    _inscrire_apprenant(tenant, affectation, proprietaire, compte)
    today = timezone.localdate()
    plan = PlanCours.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        affectation=affectation,
        date=date(2026, 6, 1),
        titre="Plan de mon groupe",
        objectifs="Objectifs de mon groupe.",
    )
    devoir = Devoir.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        affectation=affectation,
        titre="Devoir de mon groupe",
        consignes="À lire seulement.",
        publie_le=today,
        a_rendre_le=today + timedelta(days=7),
    )
    devoir_passe = Devoir.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        affectation=affectation,
        titre="Ancien devoir de mon groupe",
        consignes="À conserver dans l’historique.",
        publie_le=date(2026, 6, 1),
        a_rendre_le=date(2026, 6, 8),
    )
    autre_groupe = Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        annee_academique=affectation.annee_academique,
        code=f"groupe-autre-{tenant.pk.hex[:8]}",
        nom="Groupe non inscrit",
    )
    autre_cours = Cours.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        code=f"cours-autre-{tenant.pk.hex[:8]}",
        nom="Cours non inscrit",
    )
    autre_affectation = AffectationEnseignement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        enseignant=affectation.enseignant,
        annee_academique=affectation.annee_academique,
        groupe=autre_groupe,
        cours=autre_cours,
        date_debut=affectation.date_debut,
        date_fin=affectation.date_fin,
    )
    PlanCours.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        affectation=autre_affectation,
        date=date(2026, 6, 1),
        titre="Plan d’un autre groupe",
        objectifs="Confidentiel.",
    )
    upload = SimpleUploadedFile(
        "support.txt",
        b"Ressource pour le groupe.",
        content_type="text/plain",
    )
    ressource = RessourcePedagogique.objects.create(
        tenant=tenant,
        institution=tenant.institution,
        cree_par=proprietaire,
        affectation=affectation,
        titre="Support de mon cours",
        fichier=upload,
    )

    client = Client()
    client.force_login(compte)
    _activer_tenant(client, tenant)
    try:
        page = client.get(reverse("pedagogie:apprentissage"))
        bibliotheque = client.get(reverse("pedagogie:bibliotheque"))
        telechargement = client.get(
            reverse(
                "pedagogie:ressource-telecharger",
                kwargs={"ressource_id": ressource.pk},
            )
        )

        assert page.status_code == 200
        assert plan.titre in page.content.decode()
        assert devoir.titre in page.content.decode()
        assert devoir_passe.titre in page.content.decode()
        assert "Plan d’un autre groupe" not in page.content.decode()
        assert bibliotheque.status_code == 200
        assert "Support de mon cours" in bibliotheque.content.decode()
        assert "Ajouter à la bibliothèque" not in bibliotheque.content.decode()
        assert telechargement.status_code == 200
        assert b"".join(telechargement.streaming_content) == b"Ressource pour le groupe."
    finally:
        ressource.fichier.delete(save=False)


def test_member_without_linked_learner_profile_cannot_open_learner_portal():
    proprietaire = _creer_utilisateur("learner-unlinked-owner@example.org")
    tenant, _ = _creer_affectation("Cours sans profil", proprietaire)
    compte = _creer_utilisateur("learner-unlinked-student@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=compte,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client = Client()
    client.force_login(compte)
    _activer_tenant(client, tenant)

    response = client.get(reverse("pedagogie:apprentissage"))

    assert response.status_code == 403
