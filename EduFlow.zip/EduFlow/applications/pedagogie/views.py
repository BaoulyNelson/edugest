"""Vues HTML des plans de cours et des devoirs."""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Count, Max, Q
from django.http import FileResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template.defaultfilters import slugify
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods

from applications.emplois_temps.models import AffectationEnseignement
from applications.inscriptions.models import Inscription, StatutInscription
from applications.organisations.models import RoleAdhesion
from applications.pedagogie.forms import (
    FormulaireDevoir,
    FormulairePlanCours,
    FormulaireQuestionQuiz,
    FormulaireQuiz,
    FormulaireRessource,
)
from applications.pedagogie.models import (
    Devoir,
    PlanCours,
    QuestionQuiz,
    Quiz,
    RessourcePedagogique,
)
from applications.tableau_de_bord.views import _exiger_espace, _page_privee


def _affectations_autorisees(workspace, contexte, utilisateur):
    if (
        workspace.role == RoleAdhesion.PROPRIETAIRE
        and not utilisateur.is_superuser
    ):
        raise PermissionDenied(
            _(
                "La gestion pédagogique quotidienne est réservée aux enseignants "
                "et responsables pédagogiques."
            )
        )
    affectations = AffectationEnseignement.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        actif=True,
        enseignant__actif=True,
    )
    if contexte["role_enseignant"]:
        return affectations.filter(enseignant__compte=utilisateur)
    if contexte["role_gestion"]:
        return affectations
    raise PermissionDenied(_("Votre rôle ne permet pas de gérer les contenus pédagogiques."))


def _affectations_apprenant(workspace, contexte):
    profil = contexte["profil_apprenant"]
    if profil is None:
        raise PermissionDenied(_("Aucun dossier apprenant n’est lié à votre compte."))
    groupes = Inscription.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        apprenant=profil,
        statut=StatutInscription.ACTIVE,
        groupe__isnull=False,
    ).values("groupe_id")
    return AffectationEnseignement.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        groupe_id__in=groupes,
        actif=True,
        enseignant__actif=True,
    ).select_related("cours", "groupe", "annee_academique")


@login_required
@_page_privee
def apprentissage(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    affectations = _affectations_apprenant(workspace, contexte)
    plans = PlanCours.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        affectation__in=affectations,
    ).select_related("affectation__cours", "affectation__groupe")
    devoirs = Devoir.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        affectation__in=affectations,
    ).select_related("affectation__cours", "affectation__groupe")
    return render(
        request,
        "pedagogie/apprentissage.html",
        {
            **contexte,
            "affectations": affectations,
            "plans": plans,
            "devoirs": devoirs,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def plans_cours(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    affectations = _affectations_autorisees(workspace, contexte, request.user)
    formulaire = FormulairePlanCours(
        request.POST if request.method == "POST" else None,
        instance=PlanCours(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            cree_par=request.user,
        ),
        affectations=affectations,
    )
    if request.method == "POST" and formulaire.is_valid():
        plan = formulaire.save(commit=False)
        plan.tenant = workspace.tenant
        plan.institution = workspace.tenant.institution
        plan.cree_par = request.user
        plan.save()
        messages.success(request, _("Le plan de cours a été enregistré."))
        return redirect("pedagogie:plans")

    terme = request.GET.get("q", "").strip()[:100]
    plans = (
        PlanCours.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            affectation__in=affectations,
        )
        .select_related("affectation__cours", "affectation__groupe", "cree_par")
        .order_by("-date", "titre")
    )
    if terme:
        plans = plans.filter(
            Q(titre__icontains=terme)
            | Q(objectifs__icontains=terme)
            | Q(contenu__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
    return render(
        request,
        "pedagogie/plans.html",
        {
            **contexte,
            "formulaire": formulaire,
            "plans": plans,
            "terme": terme,
            "a_des_affectations": affectations.exists(),
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def devoirs(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    affectations = _affectations_autorisees(workspace, contexte, request.user)
    formulaire = FormulaireDevoir(
        request.POST if request.method == "POST" else None,
        instance=Devoir(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            cree_par=request.user,
        ),
        affectations=affectations,
    )
    if request.method == "POST" and formulaire.is_valid():
        devoir = formulaire.save(commit=False)
        devoir.tenant = workspace.tenant
        devoir.institution = workspace.tenant.institution
        devoir.cree_par = request.user
        devoir.save()
        messages.success(request, _("Le devoir a été enregistré."))
        return redirect("pedagogie:devoirs")

    terme = request.GET.get("q", "").strip()[:100]
    elements = (
        Devoir.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            affectation__in=affectations,
        )
        .select_related("affectation__cours", "affectation__groupe", "cree_par")
        .order_by("a_rendre_le", "titre")
    )
    if terme:
        elements = elements.filter(
            Q(titre__icontains=terme)
            | Q(consignes__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
    return render(
        request,
        "pedagogie/devoirs.html",
        {
            **contexte,
            "formulaire": formulaire,
            "devoirs": elements,
            "terme": terme,
            "a_des_affectations": affectations.exists(),
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def liste_quiz(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    affectations = _affectations_autorisees(workspace, contexte, request.user)
    formulaire = FormulaireQuiz(
        request.POST if request.method == "POST" else None,
        instance=Quiz(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            cree_par=request.user,
        ),
        affectations=affectations,
    )
    if request.method == "POST" and formulaire.is_valid():
        quiz = formulaire.save(commit=False)
        quiz.tenant = workspace.tenant
        quiz.institution = workspace.tenant.institution
        quiz.cree_par = request.user
        quiz.save()
        messages.success(
            request,
            _("Le quiz a été créé. Vous pouvez maintenant ajouter des questions."),
        )
        return redirect("pedagogie:quiz-detail", quiz_id=quiz.pk)

    terme = request.GET.get("q", "").strip()[:100]
    quiz = Quiz.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        affectation__in=affectations,
        actif=True,
    ).select_related("affectation__cours", "affectation__groupe")
    if terme:
        quiz = quiz.filter(
            Q(titre__icontains=terme)
            | Q(description__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
    quiz = quiz.annotate(nombre_questions=Count("questions")).order_by("titre")
    return render(
        request,
        "pedagogie/quiz_liste.html",
        {
            **contexte,
            "formulaire": formulaire,
            "quiz": quiz,
            "terme": terme,
            "a_des_affectations": affectations.exists(),
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_quiz(request, quiz_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    affectations = _affectations_autorisees(workspace, contexte, request.user)
    quiz = get_object_or_404(
        Quiz.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            affectation__in=affectations,
            actif=True,
        ).select_related("affectation__cours", "affectation__groupe"),
        pk=quiz_id,
    )
    formulaire = FormulaireQuestionQuiz(request.POST if request.method == "POST" else None)
    if request.method == "POST" and formulaire.is_valid():
        with transaction.atomic():
            quiz = Quiz.objects.select_for_update().get(pk=quiz.pk)
            dernier_ordre = quiz.questions.aggregate(dernier=Max("ordre"))["dernier"] or 0
            question = QuestionQuiz(
                tenant=workspace.tenant,
                institution=workspace.tenant.institution,
                cree_par=request.user,
                quiz=quiz,
                ordre=dernier_ordre + 1,
                enonce=formulaire.cleaned_data["enonce"],
                options=formulaire.cleaned_data["options"],
                reponse_correcte=formulaire.cleaned_data["reponse_correcte"] - 1,
            )
            question.full_clean()
            question.save()
        messages.success(request, _("La question a été ajoutée au quiz."))
        return redirect("pedagogie:quiz-detail", quiz_id=quiz.pk)

    return render(
        request,
        "pedagogie/quiz_detail.html",
        {
            **contexte,
            "quiz": quiz,
            "questions": quiz.questions.all(),
            "formulaire": formulaire,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def bibliotheque(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    apprenant = (
        not contexte["role_gestion"]
        and not contexte["role_enseignant"]
        and contexte["profil_apprenant"] is not None
    )
    if apprenant:
        if request.method == "POST":
            raise PermissionDenied(_("La bibliothèque est en lecture seule pour les apprenants."))
        affectations = _affectations_apprenant(workspace, contexte)
    else:
        affectations = _affectations_autorisees(workspace, contexte, request.user)
    autoriser_partage = contexte["role_gestion"]
    formulaire = None
    if not apprenant:
        formulaire = FormulaireRessource(
            request.POST if request.method == "POST" else None,
            request.FILES if request.method == "POST" else None,
            instance=RessourcePedagogique(
                tenant=workspace.tenant,
                institution=workspace.tenant.institution,
                cree_par=request.user,
            ),
            affectations=affectations,
            autoriser_partage=autoriser_partage,
        )
        if request.method == "POST" and formulaire.is_valid():
            ressource = formulaire.save(commit=False)
            ressource.tenant = workspace.tenant
            ressource.institution = workspace.tenant.institution
            ressource.cree_par = request.user
            ressource.save()
            messages.success(request, _("La ressource a été ajoutée à la bibliothèque."))
            return redirect("pedagogie:bibliotheque")

    ressources = (
        RessourcePedagogique.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        )
        .filter(Q(affectation__isnull=True) | Q(affectation__in=affectations))
        .select_related("affectation__cours", "affectation__groupe", "cree_par")
    )
    terme = request.GET.get("q", "").strip()[:100]
    if terme:
        ressources = ressources.filter(
            Q(titre__icontains=terme)
            | Q(description__icontains=terme)
            | Q(affectation__cours__nom__icontains=terme)
            | Q(affectation__groupe__nom__icontains=terme)
        )
    return render(
        request,
        "pedagogie/bibliotheque.html",
        {
            **contexte,
            "formulaire": formulaire,
            "ressources": ressources,
            "terme": terme,
            "a_des_affectations": affectations.exists(),
            "lecture_seule": apprenant,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET"])
def telecharger_ressource(request, ressource_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    if (
        not contexte["role_gestion"]
        and not contexte["role_enseignant"]
        and contexte["profil_apprenant"] is not None
    ):
        affectations = _affectations_apprenant(workspace, contexte)
    else:
        affectations = _affectations_autorisees(workspace, contexte, request.user)
    ressource = get_object_or_404(
        RessourcePedagogique.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ).filter(Q(affectation__isnull=True) | Q(affectation__in=affectations)),
        pk=ressource_id,
    )
    extension = ressource.fichier.name.rsplit(".", 1)[-1].lower()
    nom_fichier = f"{slugify(ressource.titre) or 'ressource'}.{extension}"
    response = FileResponse(
        ressource.fichier.open("rb"),
        as_attachment=True,
        filename=nom_fichier,
        content_type="application/octet-stream",
    )
    response["X-Content-Type-Options"] = "nosniff"
    return response
