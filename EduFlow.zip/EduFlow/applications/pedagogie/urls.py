"""Routes HTML des contenus pédagogiques."""

from django.urls import path

from applications.pedagogie.views import (
    apprentissage,
    bibliotheque,
    detail_quiz,
    devoirs,
    liste_quiz,
    plans_cours,
    telecharger_ressource,
)

app_name = "pedagogie"

urlpatterns = [
    path("espace/mes-cours/", apprentissage, name="apprentissage"),
    path("espace/plans-de-cours/", plans_cours, name="plans"),
    path("espace/devoirs/", devoirs, name="devoirs"),
    path("espace/quiz/", liste_quiz, name="quiz"),
    path("espace/quiz/<uuid:quiz_id>/", detail_quiz, name="quiz-detail"),
    path("espace/bibliotheque/", bibliotheque, name="bibliotheque"),
    path(
        "espace/bibliotheque/<uuid:ressource_id>/telecharger/",
        telecharger_ressource,
        name="ressource-telecharger",
    ),
]
