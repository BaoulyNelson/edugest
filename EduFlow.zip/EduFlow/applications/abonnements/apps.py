"""Configuration du catalogue SaaS, abonnements et droits d’usage."""

from django.apps import AppConfig


class AbonnementsConfig(AppConfig):
    """Application des offres et de leur facturation SaaS."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.abonnements"
    label = "abonnements"
    verbose_name = "Abonnements SaaS"
