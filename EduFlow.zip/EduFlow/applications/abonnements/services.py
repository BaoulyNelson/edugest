"""Workflows audités des offres SaaS, abonnements, paiements et entitlements."""

import calendar
import re
import uuid
from datetime import timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.core.exceptions import ValidationError
from django.db import IntegrityError, models, transaction
from django.db.models import Sum
from django.utils import timezone

from applications.abonnements.models import (
    Abonnement,
    DroitUsage,
    EnregistrementUsage,
    EvenementPaiement,
    PlanSaaS,
    StatutAbonnement,
    StatutEvenementPaiement,
    TypeEvenementPaiement,
)
from applications.organisations.models import EvenementAudit, StatutTenant, Tenant
from applications.organisations.services import transitionner_tenant


class ConflitIdempotenceAbonnement(Exception):
    """Une clé de reprise existante accompagne une opération différente."""


class AccesAbonnementRefuse(Exception):
    """Le tenant ne possède pas d’abonnement actif à la date courante."""


class DroitNonAccorde(Exception):
    """Le plan actif ne confère pas le module demandé."""


class QuotaDepasse(Exception):
    """L’usage demandé dépasserait le quota de la période d’abonnement."""


def _ajouter_mois(date_heure, nombre_mois):
    index_mois = date_heure.year * 12 + date_heure.month - 1 + nombre_mois
    annee, mois = divmod(index_mois, 12)
    mois += 1
    jour = min(date_heure.day, calendar.monthrange(annee, mois)[1])
    return date_heure.replace(year=annee, month=mois, day=jour)


def montant_attendu_abonnement(abonnement) -> Decimal:
    """Calcule le tarif de la période, avec prorata calendaire du dernier mois."""
    plan = abonnement.plan
    if plan.est_gratuit:
        raise ValidationError("Le plan gratuit ne nécessite pas de paiement.")
    if plan.prix_mensuel is None:
        raise ValidationError("Le tarif mensuel de ce plan doit être configuré.")

    debut = abonnement.commence_le
    fin = abonnement.termine_le
    mois_entiers = (fin.year - debut.year) * 12 + fin.month - debut.month
    while mois_entiers > 0 and _ajouter_mois(debut, mois_entiers) > fin:
        mois_entiers -= 1

    fin_mois_entiers = _ajouter_mois(debut, mois_entiers)
    mois_factures = Decimal(mois_entiers)
    if fin_mois_entiers < fin:
        fin_mois_suivant = _ajouter_mois(debut, mois_entiers + 1)
        duree_mois = Decimal(str((fin_mois_suivant - fin_mois_entiers).total_seconds()))
        duree_restante = Decimal(str((fin - fin_mois_entiers).total_seconds()))
        mois_factures += duree_restante / duree_mois

    return (plan.prix_mensuel * mois_factures).quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )


def _journaliser(
    *,
    action: str,
    objet: models.Model,
    acteur,
    tenant: Tenant | None,
    motif: str = "",
    details: dict | None = None,
) -> EvenementAudit:
    return EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=action,
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        motif=motif,
        details=details or {},
    )


def journaliser_lecture_operateur(*, acteur, action: str) -> EvenementAudit:
    """Trace les consultations opérateur transversales sans journaliser les données lues."""
    return EvenementAudit.objects.create(
        tenant=None,
        acteur=acteur,
        action=f"operateur.{action}.consulte",
        type_objet="abonnements.operateur",
        id_objet=action,
    )


def _droits_normalises(droits: list[dict]) -> dict[str, dict]:
    return {
        droit["code"]: {
            "actif": droit["actif"],
            "limite": droit["limite"],
            "unite": droit["unite"],
        }
        for droit in droits
    }


def sauvegarder_plan(
    *,
    acteur,
    code: str,
    nom: str,
    description: str,
    prix_mensuel: Decimal | None = None,
    devise: str = "HTG",
    actif: bool,
    droits: list[dict],
    cle_idempotence: uuid.UUID | None = None,
    plan_id: uuid.UUID | None = None,
) -> PlanSaaS:
    """Crée ou modifie un plan et met à jour les droits fournis transactionnellement."""
    droits_demandes = _droits_normalises(droits)
    with transaction.atomic():
        if plan_id is None and cle_idempotence is not None:
            plan = PlanSaaS.objects.filter(cle_idempotence=cle_idempotence).first()
            if plan is not None:
                droits_existants = {
                    droit.code: {
                        "actif": droit.actif,
                        "limite": droit.limite,
                        "unite": droit.unite,
                    }
                    for droit in plan.droits.all()
                }
                if (
                    plan.code != code
                    or plan.nom != nom
                    or plan.description != description
                    or plan.prix_mensuel != prix_mensuel
                    or plan.devise != devise
                    or plan.actif != actif
                    or droits_existants != droits_demandes
                ):
                    raise ConflitIdempotenceAbonnement
                return plan

        cree = plan_id is None
        if cree:
            if cle_idempotence is None:
                raise ValidationError("Une clé d’idempotence est obligatoire.")
            plan = PlanSaaS(
                cle_idempotence=cle_idempotence,
                cree_par=acteur,
            )
        else:
            plan = PlanSaaS.objects.select_for_update().get(pk=plan_id)

        ancien = {
            "code": plan.code,
            "nom": plan.nom,
            "description": plan.description,
            "prix_mensuel": str(plan.prix_mensuel) if plan.prix_mensuel is not None else None,
            "devise": plan.devise,
            "actif": plan.actif,
        }
        plan.code = code
        plan.nom = nom
        plan.description = description
        plan.prix_mensuel = prix_mensuel
        plan.devise = devise
        plan.actif = actif
        try:
            with transaction.atomic():
                plan.save()
        except IntegrityError as error:
            if cree:
                existant = PlanSaaS.objects.filter(cle_idempotence=cle_idempotence).first()
                if existant is not None:
                    droits_existants = {
                        droit.code: {
                            "actif": droit.actif,
                            "limite": droit.limite,
                            "unite": droit.unite,
                        }
                        for droit in existant.droits.all()
                    }
                    if (
                        existant.code == code
                        and existant.nom == nom
                        and existant.description == description
                        and existant.prix_mensuel == prix_mensuel
                        and existant.devise == devise
                        and existant.actif == actif
                        and droits_existants == droits_demandes
                    ):
                        return existant
                    raise ConflitIdempotenceAbonnement from error
            raise ValidationError({"code": "Ce code de plan existe déjà."}) from error

        for code_droit, valeurs in droits_demandes.items():
            DroitUsage.objects.update_or_create(
                plan=plan,
                code=code_droit,
                defaults=valeurs,
            )

        _journaliser(
            action="plan.cree" if cree else "plan.modifie",
            objet=plan,
            acteur=acteur,
            tenant=None,
            details={
                "ancien": ancien,
                "nouveau": {
                    "code": code,
                    "nom": nom,
                    "description": description,
                    "prix_mensuel": str(prix_mensuel) if prix_mensuel is not None else None,
                    "prix_annuel": str(prix_mensuel * 12) if prix_mensuel is not None else None,
                    "devise": devise,
                    "actif": actif,
                    "droits_fournis": sorted(droits_demandes),
                },
            },
        )
        return plan


def creer_abonnement(
    *,
    tenant: Tenant,
    plan: PlanSaaS,
    commence_le,
    termine_le,
    acteur,
    cle_idempotence: uuid.UUID,
) -> Abonnement:
    """Prépare une période en attente ; aucun tenant n’accède avant paiement confirmé."""
    if plan.est_gratuit:
        raise ValidationError(
            "Le plan gratuit s’active via le parcours d’inscription, sans paiement."
        )
    if termine_le <= commence_le:
        raise ValidationError("La fin d’abonnement doit suivre son début.")
    if timezone.is_naive(commence_le) or timezone.is_naive(termine_le):
        raise ValidationError("Les dates d’abonnement doivent inclure un fuseau horaire.")

    with transaction.atomic():
        existant = Abonnement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.tenant_id != tenant.pk
                or existant.plan_id != plan.pk
                or existant.commence_le != commence_le
                or existant.termine_le != termine_le
            ):
                raise ConflitIdempotenceAbonnement
            return existant

        tenant = Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = Abonnement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.tenant_id != tenant.pk
                or existant.plan_id != plan.pk
                or existant.commence_le != commence_le
                or existant.termine_le != termine_le
            ):
                raise ConflitIdempotenceAbonnement
            return existant
        if termine_le <= timezone.now():
            raise ValidationError("La période d’abonnement ne peut pas être déjà échue.")
        if tenant.statut in (StatutTenant.SORTIE, StatutTenant.ARCHIVE):
            raise ValidationError("Un tenant en sortie ou archivé ne peut pas être réabonné.")
        plan = PlanSaaS.objects.select_for_update().get(pk=plan.pk)
        if not plan.actif:
            raise ValidationError("Ce plan n’est pas disponible pour un nouvel abonnement.")
        if plan.est_gratuit:
            raise ValidationError(
                "Le plan gratuit s’active via le parcours d’inscription, sans paiement."
            )
        if plan.prix_mensuel is None:
            raise ValidationError("Le tarif mensuel du plan doit être configuré.")

        abonnement_existant = (
            Abonnement.objects.select_for_update()
            .filter(
                tenant=tenant,
                statut__in=(StatutAbonnement.EN_ATTENTE, StatutAbonnement.ACTIF),
            )
            .first()
        )
        if abonnement_existant:
            if abonnement_existant.termine_le <= timezone.now():
                abonnement_existant.statut = StatutAbonnement.EXPIRE
                abonnement_existant.save(update_fields=("statut", "modifie_le"))
                _journaliser(
                    action="abonnement.expire",
                    objet=abonnement_existant,
                    acteur=acteur,
                    tenant=tenant,
                    motif="Fin de période contractuelle atteinte.",
                )
            else:
                raise ValidationError("Un abonnement en attente ou actif existe déjà.")

        try:
            with transaction.atomic():
                abonnement = Abonnement.objects.create(
                    cle_idempotence=cle_idempotence,
                    tenant=tenant,
                    plan=plan,
                    statut=StatutAbonnement.EN_ATTENTE,
                    commence_le=commence_le,
                    termine_le=termine_le,
                    cree_par=acteur,
                )
        except IntegrityError as error:
            existant = Abonnement.objects.filter(cle_idempotence=cle_idempotence).first()
            if existant is not None:
                if (
                    existant.tenant_id == tenant.pk
                    and existant.plan_id == plan.pk
                    and existant.commence_le == commence_le
                    and existant.termine_le == termine_le
                ):
                    return existant
                raise ConflitIdempotenceAbonnement from error
            raise ValidationError("Un abonnement en attente ou actif existe déjà.") from error
        _journaliser(
            action="abonnement.cree",
            objet=abonnement,
            acteur=acteur,
            tenant=tenant,
            details={
                "plan": plan.code,
                "commence_le": commence_le.isoformat(),
                "termine_le": termine_le.isoformat(),
            },
        )
        return abonnement


def modifier_abonnement(
    abonnement_id: uuid.UUID,
    *,
    plan: PlanSaaS,
    commence_le,
    termine_le,
    acteur,
) -> Abonnement:
    """Modifie un contrat en attente uniquement avant tout enregistrement de paiement."""
    if termine_le <= commence_le:
        raise ValidationError("La fin d’abonnement doit suivre son début.")
    if timezone.is_naive(commence_le) or timezone.is_naive(termine_le):
        raise ValidationError("Les dates d’abonnement doivent inclure un fuseau horaire.")

    with transaction.atomic():
        abonnement = Abonnement.objects.select_for_update().get(pk=abonnement_id)
        maintenant = timezone.now()
        if abonnement.statut != StatutAbonnement.EN_ATTENTE:
            raise ValidationError("Seul un abonnement en attente peut être modifié.")
        if termine_le <= maintenant:
            raise ValidationError("La période d’abonnement ne peut pas être déjà échue.")
        if EvenementPaiement.objects.filter(
            abonnement=abonnement,
            type_evenement=TypeEvenementPaiement.PAIEMENT,
        ).exists():
            raise ValidationError(
                "Un abonnement avec un paiement enregistré ne peut pas être modifié."
            )
        plan = PlanSaaS.objects.select_for_update().get(pk=plan.pk)
        if plan.est_gratuit:
            raise ValidationError(
                "Le plan gratuit s’active via le parcours d’inscription, sans paiement."
            )
        if plan.pk != abonnement.plan_id and not plan.actif:
            raise ValidationError("Le nouveau plan n’est pas disponible.")

        ancien = {
            "plan": abonnement.plan.code,
            "commence_le": abonnement.commence_le.isoformat(),
            "termine_le": abonnement.termine_le.isoformat(),
        }
        abonnement.plan = plan
        abonnement.commence_le = commence_le
        abonnement.termine_le = termine_le
        abonnement.save(update_fields=("plan", "commence_le", "termine_le", "modifie_le"))
        _journaliser(
            action="abonnement.modifie",
            objet=abonnement,
            acteur=acteur,
            tenant=abonnement.tenant,
            details={
                "ancien": ancien,
                "nouveau": {
                    "plan": plan.code,
                    "commence_le": commence_le.isoformat(),
                    "termine_le": termine_le.isoformat(),
                },
            },
        )
        return abonnement


def creer_abonnement_gratuit(
    *,
    tenant: Tenant,
    plan: PlanSaaS,
    cree_par,
) -> Abonnement:
    """Active sept jours d’accès gratuit, sans créer de faux événement de paiement."""
    if not plan.est_gratuit:
        raise ValidationError("Seul le plan explicitement gratuit peut être activé ainsi.")

    cle_idempotence = uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"eduflow:inscription-gratuite:{tenant.pk}",
    )
    with transaction.atomic():
        tenant = Tenant.objects.select_for_update().get(pk=tenant.pk)
        plan = PlanSaaS.objects.select_for_update().get(pk=plan.pk)
        if not plan.actif or not plan.est_gratuit:
            raise ValidationError("Le plan gratuit n’est plus disponible.")
        if tenant.statut not in (StatutTenant.PROVISIONNEMENT, StatutTenant.ACTIF):
            raise ValidationError(
                "Le tenant doit être en provisionnement ou en reprise d’activation."
            )

        existant = Abonnement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.tenant_id != tenant.pk
                or existant.plan_id != plan.pk
                or existant.statut != StatutAbonnement.ACTIF
                or existant.termine_le <= timezone.now()
            ):
                raise ValidationError("Un abonnement gratuit existe déjà, mais n’est plus actif.")
            return existant

        maintenant = timezone.now()
        abonnement = Abonnement.objects.create(
            cle_idempotence=cle_idempotence,
            tenant=tenant,
            plan=plan,
            statut=StatutAbonnement.ACTIF,
            commence_le=maintenant,
            termine_le=maintenant + timedelta(days=7),
            cree_par=cree_par,
        )
        _journaliser(
            action="abonnement.gratuit_active",
            objet=abonnement,
            acteur=None,
            tenant=tenant,
            motif="Activation automatique du plan gratuit pour sept jours.",
            details={"plan": plan.code, "duree_jours": 7},
        )
        return abonnement


def enregistrer_paiement(
    *,
    abonnement: Abonnement,
    montant: Decimal,
    devise: str,
    reference: str,
    acteur,
    cle_idempotence: uuid.UUID,
) -> EvenementPaiement:
    """Enregistre un paiement manuel sans activer l’abonnement avant confirmation."""
    if montant <= 0:
        raise ValidationError("Le montant du paiement doit être positif.")
    if not re.fullmatch(r"[A-Z]{3}", devise):
        raise ValidationError("La devise doit être un code de 3 lettres majuscules.")
    if len(reference) > 200:
        raise ValidationError("La référence dépasse 200 caractères.")
    with transaction.atomic():
        existant = EvenementPaiement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.abonnement_id != abonnement.pk
                or existant.type_evenement != TypeEvenementPaiement.PAIEMENT
                or existant.montant != montant
                or existant.devise != devise
                or existant.reference != reference
            ):
                raise ConflitIdempotenceAbonnement
            return existant

        abonnement = Abonnement.objects.select_for_update().get(pk=abonnement.pk)
        existant = EvenementPaiement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.abonnement_id == abonnement.pk
                and existant.type_evenement == TypeEvenementPaiement.PAIEMENT
                and existant.montant == montant
                and existant.devise == devise
                and existant.reference == reference
            ):
                return existant
            raise ConflitIdempotenceAbonnement
        if abonnement.statut != StatutAbonnement.EN_ATTENTE:
            raise ValidationError(
                "Un paiement ne peut être rattaché qu’à un abonnement en attente."
            )
        plan = PlanSaaS.objects.select_for_update().get(pk=abonnement.plan_id)
        if plan.est_gratuit:
            raise ValidationError("Un plan gratuit ne nécessite pas de paiement.")
        if plan.devise != devise:
            raise ValidationError("La devise du paiement doit correspondre à celle du plan.")
        montant_attendu = montant_attendu_abonnement(abonnement)
        if montant != montant_attendu:
            raise ValidationError(
                f"Montant incorrect : le total attendu est de {montant_attendu:.2f} "
                f"{plan.devise} pour la période choisie."
            )
        try:
            with transaction.atomic():
                evenement = EvenementPaiement.objects.create(
                    cle_idempotence=cle_idempotence,
                    abonnement=abonnement,
                    type_evenement=TypeEvenementPaiement.PAIEMENT,
                    montant=montant,
                    devise=devise,
                    reference=reference,
                    enregistre_par=acteur,
                )
        except IntegrityError as error:
            existant = EvenementPaiement.objects.filter(cle_idempotence=cle_idempotence).first()
            if existant is not None:
                if (
                    existant.abonnement_id == abonnement.pk
                    and existant.type_evenement == TypeEvenementPaiement.PAIEMENT
                    and existant.montant == montant
                    and existant.devise == devise
                    and existant.reference == reference
                ):
                    return existant
                raise ConflitIdempotenceAbonnement from error
            raise
        _journaliser(
            action="paiement.enregistre",
            objet=evenement,
            acteur=acteur,
            tenant=abonnement.tenant,
            details={"montant": str(montant), "devise": devise},
        )
        return evenement


def enregistrer_remboursement(
    *,
    paiement_origine: EvenementPaiement,
    montant: Decimal,
    reference: str,
    acteur,
    cle_idempotence: uuid.UUID,
) -> EvenementPaiement:
    """Enregistre un remboursement manuel partiel ou total avec plafond cumulatif."""
    if montant <= 0:
        raise ValidationError("Le montant du remboursement doit être positif.")
    if len(reference) > 200:
        raise ValidationError("La référence dépasse 200 caractères.")
    with transaction.atomic():
        existant = EvenementPaiement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.type_evenement != TypeEvenementPaiement.REMBOURSEMENT
                or existant.paiement_origine_id != paiement_origine.pk
                or existant.montant != montant
                or existant.reference != reference
            ):
                raise ConflitIdempotenceAbonnement
            return existant

        paiement_origine = (
            EvenementPaiement.objects.select_for_update()
            .select_related("abonnement")
            .get(pk=paiement_origine.pk)
        )
        existant = EvenementPaiement.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.type_evenement == TypeEvenementPaiement.REMBOURSEMENT
                and existant.paiement_origine_id == paiement_origine.pk
                and existant.montant == montant
                and existant.reference == reference
            ):
                return existant
            raise ConflitIdempotenceAbonnement
        if (
            paiement_origine.type_evenement != TypeEvenementPaiement.PAIEMENT
            or paiement_origine.statut != StatutEvenementPaiement.CONFIRME
        ):
            raise ValidationError("Seul un paiement confirmé peut être remboursé.")
        montant_reserve = EvenementPaiement.objects.filter(
            paiement_origine=paiement_origine,
        ).exclude(statut=StatutEvenementPaiement.REJETE).aggregate(total=Sum("montant"))[
            "total"
        ] or Decimal("0")
        if montant_reserve + montant > paiement_origine.montant:
            raise ValidationError("Le total des remboursements dépasse le paiement d’origine.")

        try:
            with transaction.atomic():
                evenement = EvenementPaiement.objects.create(
                    cle_idempotence=cle_idempotence,
                    abonnement=paiement_origine.abonnement,
                    type_evenement=TypeEvenementPaiement.REMBOURSEMENT,
                    paiement_origine=paiement_origine,
                    montant=montant,
                    devise=paiement_origine.devise,
                    reference=reference,
                    enregistre_par=acteur,
                )
        except IntegrityError as error:
            existant = EvenementPaiement.objects.filter(cle_idempotence=cle_idempotence).first()
            if existant is not None:
                if (
                    existant.type_evenement == TypeEvenementPaiement.REMBOURSEMENT
                    and existant.paiement_origine_id == paiement_origine.pk
                    and existant.montant == montant
                    and existant.reference == reference
                ):
                    return existant
                raise ConflitIdempotenceAbonnement from error
            raise
        _journaliser(
            action="remboursement.enregistre",
            objet=evenement,
            acteur=acteur,
            tenant=paiement_origine.abonnement.tenant,
            details={
                "paiement_origine": str(paiement_origine.pk),
                "montant": str(montant),
                "devise": evenement.devise,
            },
        )
        return evenement


def decider_evenement_paiement(
    evenement_id: uuid.UUID,
    *,
    acteur,
    confirmer: bool,
    motif: str = "",
) -> EvenementPaiement:
    """Confirme ou rejette un paiement/remboursement et active le contrat payé."""
    nouveau_statut = (
        StatutEvenementPaiement.CONFIRME if confirmer else StatutEvenementPaiement.REJETE
    )
    if not confirmer and not motif.strip():
        raise ValidationError("Un motif est obligatoire pour rejeter un événement financier.")

    with transaction.atomic():
        evenement = (
            EvenementPaiement.objects.select_for_update(of=("self",))
            .select_related("abonnement", "paiement_origine")
            .get(pk=evenement_id)
        )
        if evenement.statut == nouveau_statut:
            return evenement
        if evenement.statut != StatutEvenementPaiement.ENREGISTRE:
            raise ValidationError("Cet événement financier a déjà reçu une décision différente.")

        abonnement = Abonnement.objects.select_for_update().get(pk=evenement.abonnement_id)
        if confirmer and evenement.type_evenement == TypeEvenementPaiement.PAIEMENT:
            maintenant = timezone.now()
            if abonnement.statut != StatutAbonnement.EN_ATTENTE:
                raise ValidationError("L’abonnement n’est plus en attente de paiement.")
            if abonnement.termine_le <= maintenant:
                raise ValidationError("La période d’abonnement est échue.")
            montant_attendu = montant_attendu_abonnement(abonnement)
            if (
                evenement.devise != abonnement.plan.devise
                or evenement.montant != montant_attendu
            ):
                raise ValidationError(
                    f"Le paiement ne correspond pas au tarif actuel du plan "
                    f"({montant_attendu:.2f} {abonnement.plan.devise})."
                )
            abonnement.statut = StatutAbonnement.ACTIF
            abonnement.save(update_fields=("statut", "modifie_le"))
            _journaliser(
                action="abonnement.active",
                objet=abonnement,
                acteur=acteur,
                tenant=abonnement.tenant,
                motif="Paiement manuel confirmé.",
                details={"evenement_paiement": str(evenement.pk)},
            )
            tenant = Tenant.objects.get(pk=abonnement.tenant_id)
            if tenant.statut in (
                StatutTenant.PROVISIONNEMENT,
                StatutTenant.RESTREINT,
            ):
                transitionner_tenant(
                    abonnement.tenant_id,
                    StatutTenant.ACTIF,
                    acteur=acteur,
                    motif="Abonnement activé après confirmation du paiement.",
                )
        elif confirmer and evenement.type_evenement == TypeEvenementPaiement.REMBOURSEMENT:
            if (
                evenement.paiement_origine is None
                or evenement.paiement_origine.statut != StatutEvenementPaiement.CONFIRME
            ):
                raise ValidationError("Le paiement d’origine n’est plus confirmé.")

        evenement.statut = nouveau_statut
        evenement.decide_par = acteur
        evenement.decide_le = timezone.now()
        evenement.motif_decision = motif.strip()
        evenement.save(update_fields=("statut", "decide_par", "decide_le", "motif_decision"))
        _journaliser(
            action=("evenement_paiement.confirme" if confirmer else "evenement_paiement.rejete"),
            objet=evenement,
            acteur=acteur,
            tenant=abonnement.tenant,
            motif=motif,
            details={"type": evenement.type_evenement},
        )
        return evenement


def annuler_abonnement(
    abonnement_id: uuid.UUID,
    *,
    acteur,
    motif: str,
) -> Abonnement:
    """Annule immédiatement un abonnement ; aucun accès n’est accordé ensuite."""
    if not motif.strip():
        raise ValidationError("Un motif est obligatoire pour annuler un abonnement.")
    with transaction.atomic():
        abonnement = Abonnement.objects.select_for_update().get(pk=abonnement_id)
        if abonnement.statut == StatutAbonnement.ANNULE:
            return abonnement
        if abonnement.statut not in (
            StatutAbonnement.EN_ATTENTE,
            StatutAbonnement.ACTIF,
        ):
            raise ValidationError("Seul un abonnement en attente ou actif peut être annulé.")
        abonnement.statut = StatutAbonnement.ANNULE
        abonnement.annule_par = acteur
        abonnement.annule_le = timezone.now()
        abonnement.save(update_fields=("statut", "annule_par", "annule_le", "modifie_le"))
        _journaliser(
            action="abonnement.annule",
            objet=abonnement,
            acteur=acteur,
            tenant=abonnement.tenant,
            motif=motif.strip(),
        )
        return abonnement


def expirer_abonnements_echus(*, limite: int = 500) -> int:
    """Marque les abonnements arrivés à échéance ; le contrôle d’accès vérifie aussi la date."""
    if limite < 1:
        raise ValidationError("La limite doit être positive.")
    identifiants = list(
        Abonnement.objects.filter(
            statut__in=(StatutAbonnement.EN_ATTENTE, StatutAbonnement.ACTIF),
            termine_le__lte=timezone.now(),
        )
        .order_by("termine_le", "pk")
        .values_list("pk", flat=True)[:limite]
    )
    expires = 0
    for abonnement_id in identifiants:
        with transaction.atomic():
            abonnement = (
                Abonnement.objects.select_for_update()
                .select_related("tenant", "plan")
                .filter(
                    pk=abonnement_id,
                    statut__in=(StatutAbonnement.EN_ATTENTE, StatutAbonnement.ACTIF),
                    termine_le__lte=timezone.now(),
                )
                .first()
            )
            if abonnement is None:
                continue
            abonnement.statut = StatutAbonnement.EXPIRE
            abonnement.save(update_fields=("statut", "modifie_le"))
            _journaliser(
                action="abonnement.expire",
                objet=abonnement,
                acteur=None,
                tenant=abonnement.tenant,
                motif="Fin de période contractuelle atteinte.",
            )
            if (
                abonnement.plan.est_gratuit
                and abonnement.tenant.statut == StatutTenant.ACTIF
                and abonnement_actif_pour_tenant(abonnement.tenant) is None
            ):
                transitionner_tenant(
                    abonnement.tenant_id,
                    StatutTenant.RESTREINT,
                    acteur=None,
                    motif="La période d’accès gratuit de sept jours est terminée.",
                )
            expires += 1
    return expires


def abonnement_actif_pour_tenant(tenant: Tenant) -> Abonnement | None:
    """Retourne le contrat actif dans sa période, sans créer de période de grâce."""
    return (
        Abonnement.objects.select_related("plan")
        .filter(
            tenant=tenant,
            statut=StatutAbonnement.ACTIF,
            commence_le__lte=timezone.now(),
            termine_le__gt=timezone.now(),
        )
        .first()
    )


def verifier_droit(tenant: Tenant, code: str) -> DroitUsage:
    """Refuse par défaut les tenants sans contrat ou droit explicitement actif."""
    abonnement = abonnement_actif_pour_tenant(tenant)
    if abonnement is None:
        raise AccesAbonnementRefuse
    droit = DroitUsage.objects.filter(
        plan=abonnement.plan,
        code=code,
        actif=True,
    ).first()
    if droit is None:
        raise DroitNonAccorde
    return droit


def enregistrer_usage(
    *,
    tenant: Tenant,
    code_droit: str,
    quantite: int,
    cle_idempotence: uuid.UUID,
    acteur=None,
) -> EnregistrementUsage:
    """Mesure l’usage du droit pendant toute la période de l’abonnement."""
    if isinstance(quantite, bool) or not isinstance(quantite, int) or quantite < 1:
        raise ValidationError("La quantité d’usage doit être positive.")
    with transaction.atomic():
        abonnement = abonnement_actif_pour_tenant(tenant)
        if abonnement is None:
            raise AccesAbonnementRefuse
        abonnement = Abonnement.objects.select_for_update().get(pk=abonnement.pk)
        maintenant = timezone.now()
        if not (
            abonnement.statut == StatutAbonnement.ACTIF
            and abonnement.commence_le <= maintenant < abonnement.termine_le
        ):
            raise AccesAbonnementRefuse
        existant = EnregistrementUsage.objects.filter(cle_idempotence=cle_idempotence).first()
        if existant is not None:
            if (
                existant.tenant_id == tenant.pk
                and existant.abonnement_id == abonnement.pk
                and existant.droit.code == code_droit
                and existant.quantite == quantite
            ):
                return existant
            raise ConflitIdempotenceAbonnement
        droit = (
            DroitUsage.objects.select_for_update()
            .filter(
                plan=abonnement.plan,
                code=code_droit,
                actif=True,
            )
            .first()
        )
        if droit is None:
            raise DroitNonAccorde

        if droit.limite is not None:
            consommation = (
                EnregistrementUsage.objects.filter(
                    abonnement=abonnement,
                    droit=droit,
                ).aggregate(total=Sum("quantite"))["total"]
                or 0
            )
            if consommation + quantite > droit.limite:
                raise QuotaDepasse

        try:
            usage = EnregistrementUsage.objects.create(
                cle_idempotence=cle_idempotence,
                tenant=tenant,
                abonnement=abonnement,
                droit=droit,
                quantite=quantite,
                cree_par=acteur,
            )
        except IntegrityError as error:
            raise ConflitIdempotenceAbonnement from error
        _journaliser(
            action="usage.enregistre",
            objet=usage,
            acteur=acteur,
            tenant=tenant,
            details={"droit": droit.code, "quantite": quantite},
        )
        return usage
