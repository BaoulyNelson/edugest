from django.contrib import admin

from applications.abonnements.models import (
    Abonnement,
    DroitUsage,
    EnregistrementUsage,
    EvenementPaiement,
    PlanSaaS,
)

admin.site.register((PlanSaaS, DroitUsage, Abonnement, EvenementPaiement, EnregistrementUsage))
