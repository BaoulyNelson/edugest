"""Vues Django classiques de l’administration opérateur des abonnements SaaS."""

import uuid
from decimal import Decimal
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.db.models import Exists, OuterRef, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_GET, require_http_methods

from applications.abonnements.access import utilisateur_peut_gerer_abonnements_saas
from applications.abonnements.forms import (
    AnnulationAbonnementForm,
    CreationAbonnementForm,
    DecisionEvenementPaiementForm,
    DroitUsageFormSet,
    ModifierAbonnementForm,
    PaiementManuelForm,
    PlanSaaSForm,
    RemboursementManuelForm,
)
from applications.abonnements.models import (
    Abonnement,
    EvenementPaiement,
    PlanSaaS,
    StatutAbonnement,
    StatutEvenementPaiement,
    TypeEvenementPaiement,
)
from applications.abonnements.services import (
    ConflitIdempotenceAbonnement,
    annuler_abonnement,
    creer_abonnement,
    decider_evenement_paiement,
    enregistrer_paiement,
    enregistrer_remboursement,
    journaliser_lecture_operateur,
    modifier_abonnement,
    sauvegarder_plan,
)
from applications.organisations.models import Tenant


def operateur_saas_requis(view):
    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not utilisateur_peut_gerer_abonnements_saas(request.user):
            raise PermissionDenied
        response = view(request, *args, **kwargs)
        response.headers["Cache-Control"] = "private, no-store"
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
        return response

    return wrapper


def _contexte_page(active):
    return {
        "administration_saas": True,
        "sous_navigation_saas": active,
    }


def _droits_formset(formset):
    return [
        {
            "code": valeurs["code"],
            "actif": valeurs["actif"],
            "limite": valeurs["limite"],
            "unite": valeurs["unite"],
        }
        for valeurs in formset.cleaned_data
        if valeurs and valeurs.get("code")
    ]


def _ajouter_erreur_formulaire(form, erreur):
    if hasattr(erreur, "message_dict"):
        for champ, erreurs in erreur.message_dict.items():
            form.add_error(champ if champ in form.fields else None, erreurs)
    else:
        form.add_error(None, erreur.messages)


def _avec_indicateur_paiement(abonnements):
    return abonnements.annotate(
        paiement_enregistre=Exists(
            EvenementPaiement.objects.filter(
                abonnement_id=OuterRef("pk"),
                type_evenement=TypeEvenementPaiement.PAIEMENT,
            )
        )
    )


@operateur_saas_requis
@require_GET
def plans_saas(request):
    journaliser_lecture_operateur(acteur=request.user, action="plans")
    terme = request.GET.get("q", "").strip()[:100]
    plans = PlanSaaS.objects.prefetch_related("droits").order_by("code")
    if terme:
        plans = plans.filter(
            Q(code__icontains=terme)
            | Q(nom__icontains=terme)
            | Q(description__icontains=terme)
        )
    return render(
        request,
        "abonnements/plans.html",
        {
            **_contexte_page("plans"),
            "page": Paginator(plans, 25).get_page(request.GET.get("page")),
            "terme": terme,
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def creer_plan_saas(request):
    plan = PlanSaaS()
    form = PlanSaaSForm(request.POST or None, instance=plan)
    formset = DroitUsageFormSet(request.POST or None, instance=plan, prefix="droits")
    if request.method == "POST" and form.is_valid() and formset.is_valid():
        valeurs = form.cleaned_data
        try:
            plan = sauvegarder_plan(
                acteur=request.user,
                code=valeurs["code"],
                nom=valeurs["nom"],
                description=valeurs["description"],
                prix_mensuel=valeurs["prix_mensuel"],
                devise=valeurs["devise"],
                actif=valeurs["actif"],
                droits=_droits_formset(formset),
                cle_idempotence=uuid.uuid4(),
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        except ConflitIdempotenceAbonnement:
            form.add_error(
                None,
                "Cette opération entre en conflit avec une autre création. Réessayez.",
            )
        else:
            messages.success(request, f"Le plan « {plan.nom} » a été créé.")
            return redirect("administration_saas:plans")

    return render(
        request,
        "abonnements/plan_form.html",
        {
            **_contexte_page("plans"),
            "form": form,
            "formset": formset,
            "titre_page": "Créer un plan",
            "texte_action": "Créer le plan",
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def modifier_plan_saas(request, plan_id):
    plan = get_object_or_404(PlanSaaS, pk=plan_id)
    form = PlanSaaSForm(request.POST or None, instance=plan)
    formset = DroitUsageFormSet(
        request.POST or None,
        instance=plan,
        prefix="droits",
    )
    if request.method == "POST" and form.is_valid() and formset.is_valid():
        valeurs = form.cleaned_data
        try:
            plan = sauvegarder_plan(
                acteur=request.user,
                plan_id=plan.pk,
                code=valeurs["code"],
                nom=valeurs["nom"],
                description=valeurs["description"],
                prix_mensuel=valeurs["prix_mensuel"],
                devise=valeurs["devise"],
                actif=valeurs["actif"],
                droits=_droits_formset(formset),
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        except ConflitIdempotenceAbonnement:
            form.add_error(
                None,
                "Cette modification entre en conflit avec une autre opération. Réessayez.",
            )
        else:
            messages.success(request, f"Le plan « {plan.nom} » a été mis à jour.")
            return redirect("administration_saas:plans")

    return render(
        request,
        "abonnements/plan_form.html",
        {
            **_contexte_page("plans"),
            "form": form,
            "formset": formset,
            "titre_page": f"Modifier {plan.nom}",
            "texte_action": "Enregistrer les modifications",
            "plan": plan,
        },
    )


@operateur_saas_requis
@require_GET
def etablissements_saas(request):
    journaliser_lecture_operateur(acteur=request.user, action="tenants")
    terme = request.GET.get("q", "").strip()[:100]
    tenants = Tenant.objects.order_by("nom", "id")
    if terme:
        tenants = tenants.filter(nom__icontains=terme)
    page = Paginator(tenants, 25).get_page(request.GET.get("page"))
    etablissements = list(page.object_list)
    page.object_list = etablissements
    abonnements = _avec_indicateur_paiement(
        Abonnement.objects.filter(
            tenant_id__in=[tenant.pk for tenant in etablissements],
            statut__in=(StatutAbonnement.EN_ATTENTE, StatutAbonnement.ACTIF),
        ).select_related("plan")
    ).order_by("tenant_id", "-cree_le")
    maintenant = timezone.now()
    abonnement_par_tenant = {}
    for abonnement in abonnements:
        if abonnement.termine_le > maintenant:
            abonnement_par_tenant.setdefault(abonnement.tenant_id, abonnement)
    for tenant in etablissements:
        abonnement = abonnement_par_tenant.get(tenant.pk)
        tenant.abonnement_saas = abonnement
        tenant.abonnement_modifiable = bool(
            abonnement
            and abonnement.statut == StatutAbonnement.EN_ATTENTE
            and not abonnement.paiement_enregistre
        )
    return render(
        request,
        "abonnements/etablissements.html",
        {
            **_contexte_page("etablissements"),
            "page": page,
            "terme": terme,
        },
    )


@operateur_saas_requis
@require_GET
def abonnements_saas(request):
    journaliser_lecture_operateur(acteur=request.user, action="abonnements")
    terme = request.GET.get("q", "").strip()[:100]
    statut = request.GET.get("statut", "").strip()
    maintenant = timezone.now()
    abonnements = _avec_indicateur_paiement(
        Abonnement.objects.select_related("tenant", "plan")
    ).order_by("-cree_le")
    if terme:
        abonnements = abonnements.filter(
            Q(tenant__nom__icontains=terme)
            | Q(plan__nom__icontains=terme)
            | Q(plan__code__icontains=terme)
        )
    if statut in StatutAbonnement.values:
        if statut == StatutAbonnement.EXPIRE:
            abonnements = abonnements.filter(
                Q(statut=StatutAbonnement.EXPIRE)
                | Q(
                    statut__in=(
                        StatutAbonnement.EN_ATTENTE,
                        StatutAbonnement.ACTIF,
                    ),
                    termine_le__lte=maintenant,
                )
            )
        elif statut == StatutAbonnement.ACTIF:
            abonnements = abonnements.filter(
                statut=StatutAbonnement.ACTIF,
                commence_le__lte=maintenant,
                termine_le__gt=maintenant,
            )
        else:
            abonnements = abonnements.filter(statut=statut)
    page = Paginator(abonnements, 25).get_page(request.GET.get("page"))
    for abonnement in page:
        statut_effectif = abonnement.statut
        if (
            statut_effectif in (StatutAbonnement.ACTIF, StatutAbonnement.EN_ATTENTE)
            and abonnement.termine_le <= maintenant
        ):
            statut_effectif = StatutAbonnement.EXPIRE
        abonnement.statut_effectif = statut_effectif
        abonnement.anomalie_plan_gratuit = (
            abonnement.statut == StatutAbonnement.EN_ATTENTE
            and abonnement.plan.est_gratuit
            and not abonnement.paiement_enregistre
        )
        abonnement.statut_effectif_libelle = (
            "À corriger : plan gratuit sans paiement"
            if abonnement.anomalie_plan_gratuit
            else StatutAbonnement(statut_effectif).label
        )
        abonnement.peut_modifier = (
            abonnement.statut == StatutAbonnement.EN_ATTENTE
            and not abonnement.paiement_enregistre
            and abonnement.termine_le > maintenant
        )
    return render(
        request,
        "abonnements/abonnements.html",
        {
            **_contexte_page("abonnements"),
            "page": page,
            "terme": terme,
            "statut_selectionne": statut,
            "statuts": StatutAbonnement.choices,
            "peut_annuler": (
                StatutAbonnement.EN_ATTENTE,
                StatutAbonnement.ACTIF,
            ),
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def creer_abonnement_saas(request):
    form = CreationAbonnementForm(
        request.POST or None,
        initial={"tenant": request.GET.get("tenant", "")},
    )
    if request.method == "POST" and form.is_valid():
        try:
            abonnement = creer_abonnement(
                tenant=form.cleaned_data["tenant"],
                plan=form.cleaned_data["plan"],
                commence_le=form.cleaned_data["commence_le"],
                termine_le=form.cleaned_data["termine_le"],
                acteur=request.user,
                cle_idempotence=uuid.uuid4(),
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        except ConflitIdempotenceAbonnement:
            form.add_error(
                None,
                "Cette création entre en conflit avec une autre opération. Réessayez.",
            )
        else:
            messages.success(
                request,
                f"L’abonnement de « {abonnement.tenant.nom} » est en attente de paiement.",
            )
            return redirect("administration_saas:abonnements")

    return render(
        request,
        "abonnements/abonnement_form.html",
        {
            **_contexte_page("abonnements"),
            "form": form,
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def modifier_abonnement_saas(request, abonnement_id):
    abonnement = get_object_or_404(
        Abonnement.objects.select_related("tenant", "plan"),
        pk=abonnement_id,
    )
    paiement_enregistre = EvenementPaiement.objects.filter(
        abonnement=abonnement,
        type_evenement=TypeEvenementPaiement.PAIEMENT,
    ).exists()
    if (
        abonnement.statut != StatutAbonnement.EN_ATTENTE
        or paiement_enregistre
        or abonnement.termine_le <= timezone.now()
    ):
        raise Http404("Cet abonnement ne peut plus être modifié.")

    form = ModifierAbonnementForm(
        request.POST or None,
        abonnement=abonnement,
        initial={
            "plan": "" if abonnement.plan.est_gratuit else abonnement.plan_id,
            "commence_le": abonnement.commence_le,
            "termine_le": abonnement.termine_le,
        },
    )
    if request.method == "POST" and form.is_valid():
        try:
            abonnement = modifier_abonnement(
                abonnement.pk,
                plan=form.cleaned_data["plan"],
                commence_le=form.cleaned_data["commence_le"],
                termine_le=form.cleaned_data["termine_le"],
                acteur=request.user,
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        else:
            messages.success(
                request,
                f"L’abonnement de « {abonnement.tenant.nom} » a été modifié.",
            )
            return redirect("administration_saas:abonnements")

    return render(
        request,
        "abonnements/abonnement_form.html",
        {
            **_contexte_page("abonnements"),
            "form": form,
            "abonnement": abonnement,
            "modification": True,
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def annuler_abonnement_saas(request, abonnement_id):
    abonnement = get_object_or_404(
        Abonnement.objects.select_related("tenant", "plan"),
        pk=abonnement_id,
    )
    form = AnnulationAbonnementForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            abonnement = annuler_abonnement(
                abonnement.pk,
                acteur=request.user,
                motif=form.cleaned_data["motif"],
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        else:
            messages.success(request, f"L’abonnement de « {abonnement.tenant.nom} » a été annulé.")
            return redirect("administration_saas:abonnements")

    return render(
        request,
        "abonnements/abonnement_annulation.html",
        {
            **_contexte_page("abonnements"),
            "abonnement": abonnement,
            "form": form,
        },
    )


@operateur_saas_requis
@require_GET
def paiements_saas(request):
    journaliser_lecture_operateur(acteur=request.user, action="paiements")
    terme = request.GET.get("q", "").strip()[:100]
    statut = request.GET.get("statut", "").strip()
    type_evenement = request.GET.get("type", "").strip()
    evenements = EvenementPaiement.objects.select_related(
        "abonnement__tenant",
        "abonnement__plan",
        "paiement_origine",
        "enregistre_par",
        "decide_par",
    ).prefetch_related("remboursements")
    if terme:
        filtre = (
            Q(reference__icontains=terme)
            | Q(devise__icontains=terme)
            | Q(abonnement__tenant__nom__icontains=terme)
            | Q(abonnement__plan__nom__icontains=terme)
            | Q(abonnement__plan__code__icontains=terme)
        )
        try:
            identifiant = uuid.UUID(terme)
        except ValueError:
            pass
        else:
            filtre |= Q(pk=identifiant) | Q(abonnement_id=identifiant)
        evenements = evenements.filter(filtre)
    if statut in StatutEvenementPaiement.values:
        evenements = evenements.filter(statut=statut)
    if type_evenement in TypeEvenementPaiement.values:
        evenements = evenements.filter(type_evenement=type_evenement)
    page = Paginator(evenements, 25).get_page(request.GET.get("page"))
    for evenement in page:
        remboursements_reserves = sum(
            (
                remboursement.montant
                for remboursement in evenement.remboursements.all()
                if remboursement.statut != StatutEvenementPaiement.REJETE
            ),
            Decimal("0"),
        )
        evenement.montant_remboursable = max(
            Decimal("0"),
            evenement.montant - remboursements_reserves,
        )
    return render(
        request,
        "abonnements/paiements.html",
        {
            **_contexte_page("paiements"),
            "page": page,
            "terme": terme,
            "statut_selectionne": statut,
            "type_selectionne": type_evenement,
            "statuts": StatutEvenementPaiement.choices,
            "types_evenement": TypeEvenementPaiement.choices,
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def enregistrer_paiement_saas(request):
    form = PaiementManuelForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        abonnement = form.cleaned_data["abonnement"]
        try:
            enregistrer_paiement(
                abonnement=abonnement,
                montant=form.cleaned_data["montant"],
                devise=abonnement.plan.devise,
                reference=form.cleaned_data["reference"],
                acteur=request.user,
                cle_idempotence=uuid.uuid4(),
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        except ConflitIdempotenceAbonnement:
            form.add_error(
                None,
                "Cette opération entre en conflit avec une autre création. Réessayez.",
            )
        else:
            messages.success(
                request,
                "Le paiement a été enregistré et attend une décision opérateur.",
            )
            return redirect("administration_saas:paiements")

    return render(
        request,
        "abonnements/paiement_form.html",
        {
            **_contexte_page("paiements"),
            "form": form,
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def enregistrer_remboursement_saas(request, paiement_id):
    paiement_origine = get_object_or_404(
        EvenementPaiement.objects.select_related(
            "abonnement__tenant",
            "abonnement__plan",
        ),
        pk=paiement_id,
        type_evenement=TypeEvenementPaiement.PAIEMENT,
        statut=StatutEvenementPaiement.CONFIRME,
    )
    form = RemboursementManuelForm(
        request.POST or None,
        paiement_origine=paiement_origine,
    )
    if request.method == "POST" and form.is_valid():
        try:
            enregistrer_remboursement(
                paiement_origine=paiement_origine,
                montant=form.cleaned_data["montant"],
                reference=form.cleaned_data["reference"],
                acteur=request.user,
                cle_idempotence=uuid.uuid4(),
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        except ConflitIdempotenceAbonnement:
            form.add_error(
                None,
                "Cette opération entre en conflit avec une autre création. Réessayez.",
            )
        else:
            messages.success(
                request,
                "Le remboursement a été enregistré et attend une décision opérateur.",
            )
            return redirect("administration_saas:paiements")

    return render(
        request,
        "abonnements/remboursement_form.html",
        {
            **_contexte_page("paiements"),
            "form": form,
            "paiement": paiement_origine,
        },
    )


@operateur_saas_requis
@require_http_methods(["GET", "POST"])
def decider_evenement_paiement_saas(request, evenement_id, decision):
    if decision not in ("confirmer", "rejeter"):
        raise Http404
    evenement = get_object_or_404(
        EvenementPaiement.objects.select_related(
            "abonnement__tenant",
            "abonnement__plan",
            "paiement_origine",
        ),
        pk=evenement_id,
    )
    confirmer = decision == "confirmer"
    form = DecisionEvenementPaiementForm(
        request.POST or None,
        confirmer=confirmer,
    )
    if request.method == "POST" and form.is_valid():
        try:
            decider_evenement_paiement(
                evenement.pk,
                acteur=request.user,
                confirmer=confirmer,
                motif=form.cleaned_data.get("motif", ""),
            )
        except ValidationError as erreur:
            _ajouter_erreur_formulaire(form, erreur)
        else:
            action = "confirmé" if confirmer else "rejeté"
            messages.success(request, f"L’événement financier a été {action}.")
            return redirect("administration_saas:paiements")

    return render(
        request,
        "abonnements/paiement_decision.html",
        {
            **_contexte_page("paiements"),
            "form": form,
            "evenement": evenement,
            "confirmer": confirmer,
        },
    )
