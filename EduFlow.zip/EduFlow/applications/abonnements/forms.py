"""Formulaires Django du catalogue SaaS opérateur."""

from datetime import timedelta
from decimal import Decimal

from django import forms
from django.db.models import Sum
from django.forms import inlineformset_factory
from django.utils import timezone

from applications.abonnements.models import (
    Abonnement,
    DroitUsage,
    EvenementPaiement,
    PlanSaaS,
    StatutAbonnement,
    StatutEvenementPaiement,
)
from applications.abonnements.services import montant_attendu_abonnement
from applications.organisations.models import StatutTenant, Tenant


class PlanSaaSForm(forms.ModelForm):
    class Meta:
        model = PlanSaaS
        fields = (
            "code",
            "nom",
            "description",
            "prix_mensuel",
            "devise",
            "actif",
        )
        widgets = {
            "code": forms.TextInput(
                attrs={"autocomplete": "off", "placeholder": "ex. essentiel"}
            ),
            "nom": forms.TextInput(attrs={"placeholder": "Nom de l’offre"}),
            "description": forms.Textarea(
                attrs={"rows": 3, "placeholder": "Description présentée aux établissements"}
            ),
            "prix_mensuel": forms.NumberInput(attrs={"min": "0.01", "step": "0.01"}),
            "devise": forms.TextInput(
                attrs={"minlength": "3", "maxlength": "3", "placeholder": "HTG"}
            ),
        }
        labels = {
            "code": "Code unique",
            "nom": "Nom du plan",
            "description": "Description",
            "prix_mensuel": "Prix mensuel",
            "devise": "Devise",
            "actif": "Disponible pour les nouveaux abonnements",
        }
        help_texts = {
            "prix_mensuel": "Le tarif annuel affiché correspond à douze mensualités, sans remise.",
            "devise": "Trois lettres majuscules, par exemple HTG ou USD.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")
        self.fields["actif"].widget.attrs["class"] = "saas-checkbox-input"


class DroitUsageForm(forms.ModelForm):
    class Meta:
        model = DroitUsage
        fields = ("code", "actif", "limite", "unite")
        widgets = {
            "code": forms.TextInput(attrs={"placeholder": "ex. apprenants"}),
            "limite": forms.NumberInput(attrs={"min": "1", "placeholder": "Sans limite"}),
            "unite": forms.TextInput(attrs={"placeholder": "ex. apprenants"}),
        }
        labels = {
            "code": "Code du droit",
            "actif": "Activé",
            "limite": "Quota",
            "unite": "Unité",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")
        self.fields["actif"].widget.attrs["class"] = "saas-checkbox-input"


class CreationAbonnementForm(forms.Form):
    tenant = forms.ModelChoiceField(
        queryset=Tenant.objects.exclude(
            statut__in=(StatutTenant.SORTIE, StatutTenant.ARCHIVE)
        ),
        label="Établissement",
        empty_label="Sélectionner un établissement",
    )
    plan = forms.ModelChoiceField(
        queryset=PlanSaaS.objects.filter(actif=True, prix_mensuel__isnull=False),
        label="Plan actif",
        empty_label="Sélectionner un plan",
    )
    commence_le = forms.DateTimeField(
        label="Début de la période",
        input_formats=("%Y-%m-%dT%H:%M",),
        widget=forms.DateTimeInput(
            format="%Y-%m-%dT%H:%M",
            attrs={"type": "datetime-local"},
        ),
    )
    termine_le = forms.DateTimeField(
        label="Fin de la période",
        input_formats=("%Y-%m-%dT%H:%M",),
        widget=forms.DateTimeInput(
            format="%Y-%m-%dT%H:%M",
            attrs={"type": "datetime-local"},
        ),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        now = timezone.localtime()
        self.initial.setdefault("commence_le", now)
        self.initial.setdefault("termine_le", now + timedelta(days=365))
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get("commence_le")
        end = cleaned_data.get("termine_le")
        if start and end:
            if end <= start:
                self.add_error("termine_le", "La fin doit suivre le début de la période.")
            if end <= timezone.now():
                self.add_error(
                    "termine_le",
                    "La période d’abonnement ne peut pas être déjà échue.",
                )
        return cleaned_data


class ModifierAbonnementForm(CreationAbonnementForm):
    def __init__(self, *args, abonnement, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields.pop("tenant")
        if abonnement.plan.est_gratuit:
            self.fields["plan"].help_text = (
                f"Le contrat actuel utilise « {abonnement.plan.nom} ». "
                "Un plan gratuit ne peut pas rester en attente de paiement ; "
                "choisissez un plan payant pour corriger ce contrat."
            )
        if not abonnement.plan.est_gratuit and not abonnement.plan.actif:
            self.fields["plan"].queryset = (
                self.fields["plan"].queryset
                | PlanSaaS.objects.filter(pk=abonnement.plan_id)
            )


class AnnulationAbonnementForm(forms.Form):
    motif = forms.CharField(
        label="Motif obligatoire",
        max_length=500,
        widget=forms.Textarea(
            attrs={
                "rows": 4,
                "class": "saas-input",
                "placeholder": "Expliquez la raison de l’annulation",
            }
        ),
    )

    def clean_motif(self):
        motif = self.cleaned_data["motif"].strip()
        if not motif:
            raise forms.ValidationError("Un motif est obligatoire pour annuler le contrat.")
        return motif


class AbonnementEnAttenteField(forms.ModelChoiceField):
    def label_from_instance(self, abonnement):
        montant_attendu = montant_attendu_abonnement(abonnement)
        return (
            f"{abonnement.tenant.nom} · {abonnement.plan.nom} · "
            f"{abonnement.termine_le:%d/%m/%Y} · "
            f"Total : {montant_attendu:.2f} {abonnement.plan.devise}"
        )


class PaiementManuelForm(forms.Form):
    abonnement = AbonnementEnAttenteField(
        queryset=Abonnement.objects.none(),
        label="Abonnement en attente",
        empty_label="Sélectionner un abonnement",
    )
    montant = forms.DecimalField(
        label="Montant reçu",
        max_digits=12,
        decimal_places=2,
        min_value=Decimal("0.01"),
        help_text="Saisissez le montant total indiqué dans le choix de l’abonnement.",
        widget=forms.NumberInput(
            attrs={"class": "saas-input", "min": "0.01", "step": "0.01"}
        ),
    )
    reference = forms.CharField(
        label="Référence du règlement (facultative)",
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={"class": "saas-input"}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["abonnement"].queryset = (
            Abonnement.objects.filter(statut=StatutAbonnement.EN_ATTENTE)
            .filter(plan__prix_mensuel__isnull=False)
            .select_related("tenant", "plan")
            .order_by("tenant__nom", "cree_le")
        )
        self.fields["abonnement"].widget.attrs["class"] = "saas-input"

    def clean(self):
        cleaned_data = super().clean()
        abonnement = cleaned_data.get("abonnement")
        montant = cleaned_data.get("montant")
        if abonnement is not None and montant is not None:
            montant_attendu = montant_attendu_abonnement(abonnement)
            if montant != montant_attendu:
                self.add_error(
                    "montant",
                    f"Le montant total attendu est de {montant_attendu:.2f} "
                    f"{abonnement.plan.devise} pour la période choisie.",
                )
        return cleaned_data


class RemboursementManuelForm(forms.Form):
    montant = forms.DecimalField(
        label="Montant remboursé",
        max_digits=12,
        decimal_places=2,
        min_value=Decimal("0.01"),
        widget=forms.NumberInput(
            attrs={"class": "saas-input", "min": "0.01", "step": "0.01"}
        ),
    )
    reference = forms.CharField(
        label="Référence du remboursement (facultative)",
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={"class": "saas-input"}),
    )

    def __init__(self, *args, paiement_origine, **kwargs):
        self.paiement_origine = paiement_origine
        super().__init__(*args, **kwargs)

    def clean_montant(self):
        montant = self.cleaned_data["montant"]
        remboursements_reserves = (
            EvenementPaiement.objects.filter(paiement_origine=self.paiement_origine)
            .exclude(statut=StatutEvenementPaiement.REJETE)
            .aggregate(total=Sum("montant"))["total"]
            or Decimal("0")
        )
        montant_restant = self.paiement_origine.montant - remboursements_reserves
        if montant > montant_restant:
            raise forms.ValidationError(
                f"Le montant dépasse le solde remboursable ({montant_restant:.2f} "
                f"{self.paiement_origine.devise})."
            )
        return montant


class DecisionEvenementPaiementForm(forms.Form):
    confirmation = forms.ChoiceField(
        choices=(("oui", "Oui"),),
        initial="oui",
        widget=forms.HiddenInput,
    )
    motif = forms.CharField(
        label="Motif du rejet",
        max_length=500,
        required=False,
        widget=forms.Textarea(
            attrs={"rows": 4, "class": "saas-input"}
        ),
    )

    def __init__(self, *args, confirmer, **kwargs):
        self.confirmer = confirmer
        super().__init__(*args, **kwargs)
        if confirmer:
            self.fields.pop("motif")

    def clean_motif(self):
        motif = self.cleaned_data.get("motif", "").strip()
        if not self.confirmer and not motif:
            raise forms.ValidationError(
                "Un motif est obligatoire pour rejeter un événement financier."
            )
        return motif


DroitUsageFormSet = inlineformset_factory(
    PlanSaaS,
    DroitUsage,
    form=DroitUsageForm,
    extra=2,
    can_delete=False,
)
