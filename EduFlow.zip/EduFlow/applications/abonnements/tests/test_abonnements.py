"""Tests de cycle de vie, paiement manuel, quotas et séparation opérateur."""

import uuid
from datetime import timedelta
from decimal import Decimal

import pytest
from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone

from applications.abonnements.models import (
    Abonnement,
    DroitUsage,
    EnregistrementUsage,
    EvenementPaiement,
    PlanSaaS,
    StatutAbonnement,
    TypeEvenementPaiement,
)
from applications.abonnements.services import (
    AccesAbonnementRefuse,
    ConflitIdempotenceAbonnement,
    DroitNonAccorde,
    QuotaDepasse,
    abonnement_actif_pour_tenant,
    annuler_abonnement,
    creer_abonnement,
    creer_abonnement_gratuit,
    decider_evenement_paiement,
    enregistrer_paiement,
    enregistrer_remboursement,
    enregistrer_usage,
    expirer_abonnements_echus,
    montant_attendu_abonnement,
    verifier_droit,
)
from applications.organisations.access import resoudre_adhesion_active
from applications.organisations.models import EvenementAudit, StatutTenant, Tenant
from applications.organisations.services import provisionner_tenant, transitionner_tenant

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email: str, *, staff: bool = False):
    from django.contrib.auth import get_user_model
    from django.contrib.auth.models import Permission

    utilisateur = get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        is_staff=staff,
    )
    if staff:
        permission = Permission.objects.get(
            codename="gerer_abonnements_saas",
            content_type__app_label="abonnements",
        )
        utilisateur.user_permissions.add(permission)
    return utilisateur


def _creer_tenant(proprietaire, nom="École Alpha"):
    tenant, _, _ = provisionner_tenant(
        createur=proprietaire,
        nom=nom,
        cle_idempotence=uuid.uuid4(),
    )
    return tenant


def _creer_plan(acteur, *, code=None):
    code = code or f"plan-{uuid.uuid4().hex[:12]}"
    return PlanSaaS.objects.create(
        cle_idempotence=uuid.uuid4(),
        code=code,
        nom="Plan configurable",
        prix_mensuel=None if code.casefold() == "gratuit" else Decimal("100.00"),
        actif=True,
        cree_par=acteur,
    )


def _preparer_abonnement(tenant, acteur, *, duree=30):
    plan = _creer_plan(acteur)
    maintenant = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=maintenant - timedelta(minutes=1),
        termine_le=maintenant + timedelta(days=duree),
        acteur=acteur,
        cle_idempotence=uuid.uuid4(),
    )
    paiement = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="MANUEL-001",
        acteur=acteur,
        cle_idempotence=uuid.uuid4(),
    )
    decider_evenement_paiement(paiement.pk, acteur=acteur, confirmer=True)
    return abonnement, paiement




def test_subscription_requires_confirmed_manual_payment_and_cancellation_blocks_access():
    staff = _creer_utilisateur("operator@example.org", staff=True)
    owner = _creer_utilisateur("owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(staff)
    maintenant = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=maintenant - timedelta(minutes=1),
        termine_le=maintenant + timedelta(days=30),
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )

    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    assert abonnement_actif_pour_tenant(tenant) is None
    with pytest.raises(AccesAbonnementRefuse):
        verifier_droit(tenant, "academics")

    paiement = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="TRANSFERT-42",
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )
    assert abonnement_actif_pour_tenant(tenant) is None
    abonnement = Abonnement.objects.get(pk=abonnement.pk)
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE

    decider_evenement_paiement(paiement.pk, acteur=staff, confirmer=True)
    assert abonnement_actif_pour_tenant(tenant).pk == abonnement.pk
    annuler_abonnement(abonnement.pk, acteur=staff, motif="Fin immédiate demandée.")
    assert abonnement_actif_pour_tenant(tenant) is None
    abonnement.refresh_from_db()
    assert abonnement.statut == StatutAbonnement.ANNULE
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="abonnement.annule",
    ).exists()




def test_payment_replay_is_idempotent_and_conflicting_reuse_is_rejected():
    staff = _creer_utilisateur("operator@example.org", staff=True)
    owner = _creer_utilisateur("owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(staff)
    maintenant = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=maintenant - timedelta(minutes=1),
        termine_le=maintenant + timedelta(days=30),
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )
    cle = uuid.uuid4()
    paiement = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="REF-1",
        acteur=staff,
        cle_idempotence=cle,
    )
    replay = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="REF-1",
        acteur=staff,
        cle_idempotence=cle,
    )
    assert replay.pk == paiement.pk
    with pytest.raises(ConflitIdempotenceAbonnement):
        enregistrer_paiement(
            abonnement=abonnement,
            montant=Decimal("99.00"),
            devise="HTG",
            reference="REF-1",
            acteur=staff,
            cle_idempotence=cle,
        )
    assert EvenementPaiement.objects.filter(abonnement=abonnement).count() == 1


def test_payment_must_match_the_plan_price_for_the_contract_period():
    staff = _creer_utilisateur("amount-validation-operator@example.org", staff=True)
    owner = _creer_utilisateur("amount-validation-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(staff)
    debut = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=debut,
        termine_le=debut + timedelta(days=30),
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )

    assert montant_attendu_abonnement(abonnement) == Decimal("100.00")
    with pytest.raises(ValidationError, match="Montant incorrect"):
        enregistrer_paiement(
            abonnement=abonnement,
            montant=Decimal("99.99"),
            devise=plan.devise,
            reference="MONTANT-INCORRECT",
            acteur=staff,
            cle_idempotence=uuid.uuid4(),
        )

    assert not EvenementPaiement.objects.filter(abonnement=abonnement).exists()


def test_payment_total_for_twelve_months_is_twelve_monthly_prices():
    staff = _creer_utilisateur("annual-amount-operator@example.org", staff=True)
    owner = _creer_utilisateur("annual-amount-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(staff)
    debut = timezone.now()
    fin = debut.replace(year=debut.year + 1)
    abonnement = Abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=debut,
        termine_le=fin,
    )

    assert montant_attendu_abonnement(abonnement) == Decimal("1200.00")


def test_incorrect_legacy_payment_cannot_activate_a_subscription():
    staff = _creer_utilisateur("amount-confirm-operator@example.org", staff=True)
    owner = _creer_utilisateur("amount-confirm-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(staff)
    debut = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=debut,
        termine_le=debut + timedelta(days=30),
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )
    paiement = EvenementPaiement.objects.create(
        cle_idempotence=uuid.uuid4(),
        abonnement=abonnement,
        type_evenement="paiement",
        montant=Decimal("99.99"),
        devise=plan.devise,
        reference="ANCIEN-MONTANT",
        enregistre_par=staff,
    )

    with pytest.raises(ValidationError, match="ne correspond pas au tarif actuel"):
        decider_evenement_paiement(paiement.pk, acteur=staff, confirmer=True)

    abonnement.refresh_from_db()
    paiement.refresh_from_db()
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    assert paiement.statut == "enregistre"
    assert abonnement_actif_pour_tenant(tenant) is None


def test_rejected_payment_requires_reason_and_keeps_subscription_blocked():
    staff = _creer_utilisateur("operator@example.org", staff=True)
    owner = _creer_utilisateur("owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(staff)
    maintenant = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=maintenant - timedelta(minutes=1),
        termine_le=maintenant + timedelta(days=30),
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )
    paiement = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="REF-REJETE",
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )

    with pytest.raises(ValidationError, match="motif est obligatoire"):
        decider_evenement_paiement(
            paiement.pk,
            acteur=staff,
            confirmer=False,
        )
    decider_evenement_paiement(
        paiement.pk,
        acteur=staff,
        confirmer=False,
        motif="Justificatif insuffisant.",
    )

    paiement.refresh_from_db()
    abonnement.refresh_from_db()
    assert paiement.statut == "rejete"
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    assert abonnement_actif_pour_tenant(tenant) is None






def test_refunds_are_audited_partial_and_cannot_exceed_confirmed_payment():
    staff = _creer_utilisateur("operator@example.org", staff=True)
    owner = _creer_utilisateur("owner@example.org")
    tenant = _creer_tenant(owner)
    abonnement, paiement = _preparer_abonnement(tenant, staff)

    remboursement = enregistrer_remboursement(
        paiement_origine=paiement,
        montant=Decimal("40.00"),
        reference="REMBOURSEMENT-1",
        acteur=staff,
        cle_idempotence=uuid.uuid4(),
    )
    assert remboursement.type_evenement == TypeEvenementPaiement.REMBOURSEMENT
    assert remboursement.paiement_origine_id == paiement.pk
    decider_evenement_paiement(remboursement.pk, acteur=staff, confirmer=True)
    with pytest.raises(ValidationError, match="dépasse"):
        enregistrer_remboursement(
            paiement_origine=paiement,
            montant=Decimal("60.01"),
            reference="REMBOURSEMENT-2",
            acteur=staff,
            cle_idempotence=uuid.uuid4(),
        )
    assert abonnement_actif_pour_tenant(tenant).pk == abonnement.pk
    assert (
        EvenementAudit.objects.filter(
            tenant=tenant,
            action="remboursement.enregistre",
        ).count()
        == 1
    )


def test_usage_is_plan_scoped_tenant_scoped_and_limited_per_subscription_period():
    staff = _creer_utilisateur("operator@example.org", staff=True)
    owner_a = _creer_utilisateur("a@example.org")
    owner_b = _creer_utilisateur("b@example.org")
    tenant_a = _creer_tenant(owner_a, "Alpha")
    tenant_b = _creer_tenant(owner_b, "Beta")
    abonnement, _ = _preparer_abonnement(tenant_a, staff)
    droit = DroitUsage.objects.create(
        plan=abonnement.plan,
        code="learners",
        actif=True,
        limite=3,
        unite="apprenants",
    )

    usage = enregistrer_usage(
        tenant=tenant_a,
        code_droit="learners",
        quantite=2,
        cle_idempotence=uuid.uuid4(),
        acteur=owner_a,
    )
    replay = enregistrer_usage(
        tenant=tenant_a,
        code_droit="learners",
        quantite=2,
        cle_idempotence=usage.cle_idempotence,
        acteur=owner_a,
    )
    assert replay.pk == usage.pk
    with pytest.raises(QuotaDepasse):
        enregistrer_usage(
            tenant=tenant_a,
            code_droit="learners",
            quantite=2,
            cle_idempotence=uuid.uuid4(),
            acteur=owner_a,
        )
    with pytest.raises(AccesAbonnementRefuse):
        enregistrer_usage(
            tenant=tenant_b,
            code_droit="learners",
            quantite=1,
            cle_idempotence=uuid.uuid4(),
            acteur=owner_b,
        )
    assert EnregistrementUsage.objects.filter(tenant=tenant_a, droit=droit).count() == 1
    with pytest.raises(DroitNonAccorde):
        verifier_droit(tenant_a, "finance")


def test_expired_subscription_is_denied_without_grace_and_expiry_is_audited():
    staff = _creer_utilisateur("operator@example.org", staff=True)
    owner = _creer_utilisateur("owner@example.org")
    tenant = _creer_tenant(owner)
    abonnement, _ = _preparer_abonnement(tenant, staff)
    abonnement.termine_le = timezone.now() - timedelta(seconds=1)
    abonnement.save(update_fields=("termine_le",))

    assert abonnement_actif_pour_tenant(tenant) is None
    assert expirer_abonnements_echus() == 1
    assert expirer_abonnements_echus() == 0
    abonnement.refresh_from_db()
    assert abonnement.statut == StatutAbonnement.EXPIRE
    assert (
        EvenementAudit.objects.filter(
            tenant=tenant,
            action="abonnement.expire",
        ).count()
        == 1
    )


def test_paid_subscription_workflow_rejects_the_free_plan():
    owner = _creer_utilisateur("free-pending-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(owner, code="Gratuit")
    debut = timezone.now()

    with pytest.raises(ValidationError, match="Le plan gratuit s’active"):
        creer_abonnement(
            tenant=tenant,
            plan=plan,
            commence_le=debut,
            termine_le=debut + timedelta(days=30),
            acteur=owner,
            cle_idempotence=uuid.uuid4(),
        )

    assert not Abonnement.objects.filter(tenant=tenant).exists()


def test_free_pending_subscription_cannot_receive_a_payment():
    operator = _creer_utilisateur("free-payment-operator@example.org", staff=True)
    owner = _creer_utilisateur("free-payment-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan(owner, code="Gratuit")
    abonnement = Abonnement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        plan=plan,
        statut=StatutAbonnement.EN_ATTENTE,
        commence_le=timezone.now(),
        termine_le=timezone.now() + timedelta(days=30),
        cree_par=operator,
    )

    with pytest.raises(ValidationError, match="Un plan gratuit ne nécessite pas"):
        enregistrer_paiement(
            abonnement=abonnement,
            montant=Decimal("10.00"),
            devise="HTG",
            reference="",
            acteur=operator,
            cle_idempotence=uuid.uuid4(),
        )

    assert not EvenementPaiement.objects.filter(abonnement=abonnement).exists()


def test_free_subscription_can_resume_for_an_already_active_tenant():
    owner = _creer_utilisateur("free-active-owner@example.org")
    tenant = Tenant.objects.create(
        nom="Free active tenant",
        statut=StatutTenant.ACTIF,
        cle_idempotence=uuid.uuid4(),
        cree_par=owner,
    )
    plan = _creer_plan(owner, code="Gratuit")
    plan.nom = "Plan Gratuit"
    plan.save(update_fields=("nom",))

    abonnement = creer_abonnement_gratuit(
        tenant=tenant,
        plan=plan,
        cree_par=owner,
    )

    assert abonnement.statut == StatutAbonnement.ACTIF
    assert abonnement.plan == plan
    assert abonnement.termine_le - abonnement.commence_le == timedelta(days=7)
    assert not abonnement.evenements_paiement.exists()


def test_free_subscription_expires_after_seven_days_and_restricts_tenant():
    owner = _creer_utilisateur("free-owner@example.org")
    tenant = Tenant.objects.create(
        nom="Free trial tenant",
        statut=StatutTenant.PROVISIONNEMENT,
        cle_idempotence=uuid.uuid4(),
        cree_par=owner,
    )
    plan = _creer_plan(owner, code="Gratuit")
    plan.nom = "Plan Gratuit"
    plan.save(update_fields=("nom",))
    abonnement = creer_abonnement_gratuit(
        tenant=tenant,
        plan=plan,
        cree_par=owner,
    )
    assert abonnement.termine_le - abonnement.commence_le == timedelta(days=7)
    transitionner_tenant(
        tenant.pk,
        StatutTenant.ACTIF,
        acteur=None,
        motif="Activation automatique du plan gratuit.",
    )
    maintenant = timezone.now()
    abonnement.commence_le = maintenant - timedelta(days=7, seconds=1)
    abonnement.termine_le = maintenant - timedelta(seconds=1)
    abonnement.save(update_fields=("commence_le", "termine_le"))
    assert expirer_abonnements_echus() == 1
    abonnement.refresh_from_db()
    tenant.refresh_from_db()

    assert abonnement.statut == StatutAbonnement.EXPIRE
    assert tenant.statut == StatutTenant.RESTREINT
    assert abonnement_actif_pour_tenant(tenant) is None
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="tenant.statut_modifie",
        details__nouveau_statut=StatutTenant.RESTREINT,
    ).exists()

    plan_payant = _creer_plan(owner, code="paid-after-free")
    debut = timezone.now()
    abonnement_payant = creer_abonnement(
        tenant=tenant,
        plan=plan_payant,
        commence_le=debut,
        termine_le=debut + timedelta(days=30),
        acteur=owner,
        cle_idempotence=uuid.uuid4(),
    )
    paiement = enregistrer_paiement(
        abonnement=abonnement_payant,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="REPRISE-APRES-GRATUIT",
        acteur=owner,
        cle_idempotence=uuid.uuid4(),
    )
    decider_evenement_paiement(paiement.pk, acteur=owner, confirmer=True)
    tenant.refresh_from_db()
    assert tenant.statut == StatutTenant.ACTIF


def test_tenant_context_is_blocked_until_subscription_is_paid():
    owner = _creer_utilisateur("owner@example.org")
    tenant = _creer_tenant(owner)
    from applications.organisations.models import AdhesionTenant

    with pytest.raises(PermissionDenied):
        resoudre_adhesion_active(owner, str(tenant.pk))
    assert AdhesionTenant.objects.filter(tenant=tenant, utilisateur=owner).exists()
