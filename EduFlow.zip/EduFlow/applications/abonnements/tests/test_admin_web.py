"""Tests de session, permissions et protection CSRF du portail opérateur."""

import uuid
from datetime import timedelta
from decimal import Decimal

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.models import (
    Abonnement,
    EvenementPaiement,
    PlanSaaS,
    StatutAbonnement,
    StatutEvenementPaiement,
    TypeEvenementPaiement,
)
from applications.abonnements.services import (
    abonnement_actif_pour_tenant,
    decider_evenement_paiement,
    enregistrer_paiement,
)
from applications.organisations.models import EvenementAudit
from applications.organisations.services import provisionner_tenant

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email, *, operateur=False, staff=False):
    utilisateur = get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        is_staff=staff or operateur,
        email_verifie_le=timezone.now(),
    )
    if operateur:
        permission = Permission.objects.get(
            codename="gerer_abonnements_saas",
            content_type__app_label="abonnements",
        )
        utilisateur.user_permissions.add(permission)
    return utilisateur


@pytest.mark.parametrize(
    ("name", "screen"),
    (
        ("administration_saas:plans", "plans"),
        ("administration_saas:etablissements", "etablissements"),
        ("administration_saas:abonnements", "abonnements"),
        ("administration_saas:paiements", "paiements"),
    ),
)
def test_operator_pages_require_permission_and_render_no_store(name, screen):
    owner = _creer_utilisateur(f"{screen}-owner@example.org")
    staff_without_permission = _creer_utilisateur(
        f"{screen}-staff@example.org",
        staff=True,
    )
    operator = _creer_utilisateur(
        f"{screen}-operator@example.org",
        operateur=True,
    )
    url = reverse(name)

    anonymous_response = Client().get(url)
    owner_client = Client()
    owner_client.force_login(owner)
    owner_response = owner_client.get(url)
    staff_client = Client()
    staff_client.force_login(staff_without_permission)
    staff_response = staff_client.get(url)
    operator_client = Client()
    operator_client.force_login(operator)
    operator_response = operator_client.get(url)

    assert anonymous_response.status_code == 302
    assert anonymous_response["Location"].startswith("/connexion/?next=")
    assert owner_response.status_code == 403
    assert staff_response.status_code == 403
    assert operator_response.status_code == 200
    assert operator_response["Cache-Control"] == "private, no-store"
    assert operator_response["X-Robots-Tag"] == "noindex, nofollow"
    if screen == "plans":
        contenu = operator_response.content.decode()
        assert "Plans d’abonnement" in contenu
        assert "abonnements-admin.js" not in contenu
        assert reverse("administration_saas:creer-plan") in contenu
        assert '<a class="mobile-nav-item active"' in contenu
        assert '<summary class="mobile-nav-item active"' not in contenu
        assert '<th scope="col">Actions</th>' in contenu
    elif screen == "etablissements":
        assert "Établissements" in operator_response.content.decode()
        assert "abonnements-admin.js" not in operator_response.content.decode()
    elif screen == "abonnements":
        assert "Nouvel abonnement" in operator_response.content.decode()
        assert "abonnements-admin.js" not in operator_response.content.decode()
    elif screen == "paiements":
        assert "Paiements" in operator_response.content.decode()
        assert "abonnements-admin.js" not in operator_response.content.decode()
    else:
        assert "abonnements-admin.js" not in operator_response.content.decode()


def _creer_plan_actif(operator, *, code="plan-actif", prix_mensuel="100.00"):
    return PlanSaaS.objects.create(
        cle_idempotence=uuid.uuid4(),
        code=code,
        nom="Plan actif",
        prix_mensuel=(
            None if code.casefold() == "gratuit" else Decimal(prix_mensuel)
        ),
        actif=True,
        cree_par=operator,
    )


def _creer_tenant(owner, nom="Institut Démo"):
    tenant, _, _ = provisionner_tenant(
        createur=owner,
        nom=nom,
        cle_idempotence=uuid.uuid4(),
    )
    return tenant


def _dates_formulaire():
    debut = timezone.localtime() + timedelta(days=1)
    fin = debut + timedelta(days=30)
    return debut.strftime("%Y-%m-%dT%H:%M"), fin.strftime("%Y-%m-%dT%H:%M")


def _creer_abonnement_attente(operator, tenant, plan):
    maintenant = timezone.now()
    return Abonnement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        plan=plan,
        statut=StatutAbonnement.EN_ATTENTE,
        commence_le=maintenant,
        termine_le=maintenant + timedelta(days=30),
        cree_par=operator,
    )


def _creer_paiement_enregistre(operator, tenant, plan, *, montant="100.00"):
    abonnement = _creer_abonnement_attente(operator, tenant, plan)
    evenement = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal(montant),
        devise=plan.devise,
        reference="RECU-TEST",
        acteur=operator,
        cle_idempotence=uuid.uuid4(),
    )
    return abonnement, evenement


def test_operator_can_create_pending_subscription_without_granting_access():
    operator = _creer_utilisateur("subscription-form-operator@example.org", operateur=True)
    owner = _creer_utilisateur("subscription-form-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator)
    client = Client(enforce_csrf_checks=True)
    client.force_login(operator)
    url = reverse("administration_saas:creer-abonnement")
    page = client.get(url)
    csrf_token = client.cookies["csrftoken"].value
    debut, fin = _dates_formulaire()
    payload = {
        "tenant": str(tenant.pk),
        "plan": str(plan.pk),
        "commence_le": debut,
        "termine_le": fin,
    }

    without_csrf = client.post(url, payload)
    response = client.post(url, payload, HTTP_X_CSRFTOKEN=csrf_token)

    assert page.status_code == 200
    assert "name=\"tenant\"" in page.content.decode()
    assert without_csrf.status_code == 403
    assert response.status_code == 302
    abonnement = Abonnement.objects.get(tenant=tenant)
    assert abonnement.plan == plan
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    assert abonnement_actif_pour_tenant(tenant) is None
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="abonnement.cree",
        id_objet=str(abonnement.pk),
    ).exists()


def test_payment_registration_subscription_select_uses_full_width_input_style():
    operator = _creer_utilisateur("payment-form-operator@example.org", operateur=True)
    owner = _creer_utilisateur("payment-form-owner@example.org")
    plan = _creer_plan_actif(operator, code="paid-payment-form")
    tenant = _creer_tenant(owner)
    _creer_abonnement_attente(operator, tenant, plan)
    tenant_gratuit = _creer_tenant(owner, "Institut gratuit en attente")
    plan_gratuit = _creer_plan_actif(operator, code="gratuit")
    _creer_abonnement_attente(operator, tenant_gratuit, plan_gratuit)
    client = Client()
    client.force_login(operator)

    response = client.get(reverse("administration_saas:enregistrer-paiement"))
    contenu = response.content.decode()

    assert response.status_code == 200
    assert 'name="abonnement" class="saas-input"' in contenu
    assert tenant.nom in contenu
    assert tenant_gratuit.nom not in contenu


def test_operator_cannot_create_a_pending_subscription_for_the_free_plan():
    operator = _creer_utilisateur("free-subscription-operator@example.org", operateur=True)
    owner = _creer_utilisateur("free-subscription-owner@example.org")
    tenant = _creer_tenant(owner)
    free_plan = _creer_plan_actif(operator, code="gratuit")
    client = Client()
    client.force_login(operator)
    url = reverse("administration_saas:creer-abonnement")
    debut, fin = _dates_formulaire()

    page = client.get(url)
    response = client.post(
        url,
        {
            "tenant": str(tenant.pk),
            "plan": str(free_plan.pk),
            "commence_le": debut,
            "termine_le": fin,
        },
    )

    assert str(free_plan.pk) not in page.content.decode()
    assert response.status_code == 200
    assert not Abonnement.objects.filter(tenant=tenant).exists()


def test_existing_free_pending_contract_is_flagged_and_can_be_reassigned():
    operator = _creer_utilisateur("legacy-free-operator@example.org", operateur=True)
    owner = _creer_utilisateur("legacy-free-owner@example.org")
    tenant = _creer_tenant(owner)
    free_plan = _creer_plan_actif(operator, code="gratuit")
    paid_plan = _creer_plan_actif(operator, code="plan-payant")
    abonnement = _creer_abonnement_attente(operator, tenant, free_plan)
    client = Client()
    client.force_login(operator)

    listing = client.get(reverse("administration_saas:abonnements"))
    editor = client.get(
        reverse("administration_saas:modifier-abonnement", args=(abonnement.pk,)),
    )

    assert "À corriger : plan gratuit sans paiement" in listing.content.decode()
    assert str(paid_plan.pk) in editor.content.decode()
    assert str(free_plan.pk) not in editor.content.decode()
    assert "Le contrat actuel utilise « Plan actif »." in editor.content.decode()
    assert "choisissez un plan payant" in editor.content.decode()


def test_operator_subscription_form_rejects_invalid_period_and_existing_contract():
    operator = _creer_utilisateur("subscription-invalid-operator@example.org", operateur=True)
    owner = _creer_utilisateur("subscription-invalid-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator)
    client = Client()
    client.force_login(operator)
    url = reverse("administration_saas:creer-abonnement")
    debut, fin = _dates_formulaire()
    payload = {
        "tenant": str(tenant.pk),
        "plan": str(plan.pk),
        "commence_le": fin,
        "termine_le": debut,
    }

    invalid_period = client.post(url, payload)

    assert invalid_period.status_code == 200
    assert "La fin doit suivre le début de la période." in invalid_period.content.decode()
    payload["commence_le"] = (timezone.localtime() - timedelta(days=2)).strftime(
        "%Y-%m-%dT%H:%M"
    )
    payload["termine_le"] = (timezone.localtime() - timedelta(days=1)).strftime(
        "%Y-%m-%dT%H:%M"
    )
    expired_period = client.post(url, payload)

    assert expired_period.status_code == 200
    assert "La période d’abonnement ne peut pas être déjà échue." in expired_period.content.decode()
    payload["commence_le"] = debut
    payload["termine_le"] = fin
    Abonnement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        plan=plan,
        statut=StatutAbonnement.EN_ATTENTE,
        commence_le=timezone.now(),
        termine_le=timezone.now() + timedelta(days=30),
        cree_par=operator,
    )

    existing_contract = client.post(url, payload)

    assert existing_contract.status_code == 200
    assert "Un abonnement en attente ou actif existe déjà." in existing_contract.content.decode()
    assert Abonnement.objects.filter(tenant=tenant).count() == 1


def test_operator_subscription_list_searches_and_audits_consultation():
    operator = _creer_utilisateur("subscription-search-operator@example.org", operateur=True)
    owner = _creer_utilisateur("subscription-search-owner@example.org")
    plan = _creer_plan_actif(operator)
    tenant_a = _creer_tenant(owner, "Institut Horizon")
    tenant_b = _creer_tenant(owner, "Campus Boréal")
    for tenant in (tenant_a, tenant_b):
        Abonnement.objects.create(
            cle_idempotence=uuid.uuid4(),
            tenant=tenant,
            plan=plan,
            statut=StatutAbonnement.EN_ATTENTE,
            commence_le=timezone.now(),
            termine_le=timezone.now() + timedelta(days=30),
            cree_par=operator,
        )
    client = Client()
    client.force_login(operator)

    response = client.get(reverse("administration_saas:abonnements"), {"q": "Horizon"})

    contenu = response.content.decode()
    assert response.status_code == 200
    assert "Institut Horizon" in contenu
    assert "Campus Boréal" not in contenu
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="operateur.abonnements.consulte",
    ).exists()


def test_active_subscription_filter_matches_open_contracts_only():
    operator = _creer_utilisateur("active-filter-operator@example.org", operateur=True)
    owner = _creer_utilisateur("active-filter-owner@example.org")
    plan = _creer_plan_actif(operator, code="active-filter-plan")
    actif = _creer_tenant(owner, "Institut Actif")
    en_attente = _creer_tenant(owner, "Institut En attente")
    expire = _creer_tenant(owner, "Institut Échu")
    futur = _creer_tenant(owner, "Institut Futur")
    maintenant = timezone.now()
    abonnement_actif = _creer_abonnement_attente(operator, actif, plan)
    abonnement_actif.statut = StatutAbonnement.ACTIF
    abonnement_actif.save(update_fields=("statut",))
    abonnement_expire = _creer_abonnement_attente(operator, expire, plan)
    abonnement_expire.statut = StatutAbonnement.ACTIF
    abonnement_expire.commence_le = maintenant - timedelta(days=31)
    abonnement_expire.termine_le = maintenant - timedelta(seconds=1)
    abonnement_expire.save(update_fields=("statut", "commence_le", "termine_le"))
    abonnement_futur = _creer_abonnement_attente(operator, futur, plan)
    abonnement_futur.statut = StatutAbonnement.ACTIF
    abonnement_futur.commence_le = maintenant + timedelta(days=1)
    abonnement_futur.save(update_fields=("statut", "commence_le"))
    _creer_abonnement_attente(operator, en_attente, plan)
    client = Client()
    client.force_login(operator)

    response = client.get(
        reverse("administration_saas:abonnements"),
        {"statut": StatutAbonnement.ACTIF},
    )
    content = response.content.decode()

    assert response.status_code == 200
    assert "Institut Actif" in content
    assert "Institut En attente" not in content
    assert "Institut Échu" not in content
    assert "Institut Futur" not in content
    assert response.context["page"].paginator.count == 1
    assert response.context["statut_selectionne"] == StatutAbonnement.ACTIF


def test_operator_can_cancel_pending_subscription_with_audited_reason():
    operator = _creer_utilisateur("subscription-cancel-operator@example.org", operateur=True)
    owner = _creer_utilisateur("subscription-cancel-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator)
    abonnement = Abonnement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        plan=plan,
        statut=StatutAbonnement.EN_ATTENTE,
        commence_le=timezone.now(),
        termine_le=timezone.now() + timedelta(days=30),
        cree_par=operator,
    )
    client = Client()
    client.force_login(operator)
    url = reverse("administration_saas:annuler-abonnement", args=(abonnement.pk,))

    page = client.get(url)
    invalid = client.post(url, {"motif": "   "})
    response = client.post(url, {"motif": "Contrat créé par erreur."})

    assert page.status_code == 200
    assert invalid.status_code == 200
    assert response.status_code == 302
    abonnement.refresh_from_db()
    assert abonnement.statut == StatutAbonnement.ANNULE
    assert abonnement.annule_par == operator
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="abonnement.annule",
        motif="Contrat créé par erreur.",
        id_objet=str(abonnement.pk),
    ).exists()


def test_operator_can_record_payment_without_activating_subscription():
    operator = _creer_utilisateur("payment-form-operator@example.org", operateur=True)
    owner = _creer_utilisateur("payment-form-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator, code="payment-plan", prix_mensuel="2500.00")
    abonnement = _creer_abonnement_attente(operator, tenant, plan)
    client = Client(enforce_csrf_checks=True)
    client.force_login(operator)
    url = reverse("administration_saas:enregistrer-paiement")
    page = client.get(url)
    csrf_token = client.cookies["csrftoken"].value
    payload = {
        "abonnement": str(abonnement.pk),
        "montant": "2500.00",
        "reference": "RECU-2026-001",
    }

    without_csrf = client.post(url, payload)
    response = client.post(url, payload, HTTP_X_CSRFTOKEN=csrf_token)

    assert page.status_code == 200
    assert "name=\"abonnement\"" in page.content.decode()
    assert without_csrf.status_code == 403
    assert response.status_code == 302
    evenement = EvenementPaiement.objects.get(abonnement=abonnement)
    assert evenement.type_evenement == TypeEvenementPaiement.PAIEMENT
    assert evenement.statut == StatutEvenementPaiement.ENREGISTRE
    assert evenement.devise == plan.devise
    assert evenement.reference == "RECU-2026-001"
    abonnement.refresh_from_db()
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    assert abonnement_actif_pour_tenant(tenant) is None
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="paiement.enregistre",
        id_objet=str(evenement.pk),
    ).exists()


def test_payment_form_rejects_amount_different_from_subscription_total():
    operator = _creer_utilisateur("payment-amount-operator@example.org", operateur=True)
    owner = _creer_utilisateur("payment-amount-owner@example.org")
    plan = _creer_plan_actif(
        operator,
        code="payment-amount-plan",
        prix_mensuel="2500.00",
    )
    tenant = _creer_tenant(owner)
    abonnement = _creer_abonnement_attente(operator, tenant, plan)
    client = Client()
    client.force_login(operator)
    url = reverse("administration_saas:enregistrer-paiement")
    montant_attendu = "2500.00"

    response = client.post(
        url,
        {
            "abonnement": str(abonnement.pk),
            "montant": "2499.99",
            "reference": "RECU-INCORRECT",
        },
    )

    assert response.status_code == 200
    assert f"Le montant total attendu est de {montant_attendu} HTG" in (
        response.content.decode()
    )
    assert not EvenementPaiement.objects.filter(abonnement=abonnement).exists()


def test_operator_can_confirm_payment_after_explicit_confirmation_page():
    operator = _creer_utilisateur("payment-confirm-operator@example.org", operateur=True)
    owner = _creer_utilisateur("payment-confirm-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator, code="payment-confirm-plan")
    abonnement, paiement = _creer_paiement_enregistre(operator, tenant, plan)
    client = Client()
    client.force_login(operator)
    url = reverse(
        "administration_saas:decider-paiement",
        args=(paiement.pk, "confirmer"),
    )

    page = client.get(url)
    response = client.post(url, {"confirmation": "oui"})

    assert page.status_code == 200
    assert "activera l’abonnement" in page.content.decode()
    assert response.status_code == 302
    paiement.refresh_from_db()
    abonnement.refresh_from_db()
    assert paiement.statut == StatutEvenementPaiement.CONFIRME
    assert paiement.decide_par == operator
    assert abonnement.statut == StatutAbonnement.ACTIF
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="evenement_paiement.confirme",
        id_objet=str(paiement.pk),
    ).exists()


def test_operator_must_give_reason_to_reject_payment():
    operator = _creer_utilisateur("payment-reject-operator@example.org", operateur=True)
    owner = _creer_utilisateur("payment-reject-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator, code="payment-reject-plan")
    abonnement, paiement = _creer_paiement_enregistre(operator, tenant, plan)
    client = Client()
    client.force_login(operator)
    url = reverse(
        "administration_saas:decider-paiement",
        args=(paiement.pk, "rejeter"),
    )

    invalid = client.post(url, {"confirmation": "oui", "motif": "   "})
    response = client.post(
        url,
        {"confirmation": "oui", "motif": "Preuve de paiement invalide."},
    )

    assert invalid.status_code == 200
    assert "Un motif est obligatoire" in invalid.content.decode()
    assert response.status_code == 302
    paiement.refresh_from_db()
    abonnement.refresh_from_db()
    assert paiement.statut == StatutEvenementPaiement.REJETE
    assert paiement.motif_decision == "Preuve de paiement invalide."
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    assert abonnement_actif_pour_tenant(tenant) is None


def test_operator_can_record_partial_refund_and_cannot_exceed_remaining_amount():
    operator = _creer_utilisateur("refund-form-operator@example.org", operateur=True)
    owner = _creer_utilisateur("refund-form-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator, code="refund-plan")
    abonnement, paiement = _creer_paiement_enregistre(operator, tenant, plan)
    decider_evenement_paiement(paiement.pk, acteur=operator, confirmer=True)
    client = Client()
    client.force_login(operator)
    url = reverse(
        "administration_saas:enregistrer-remboursement",
        args=(paiement.pk,),
    )

    page = client.get(url)
    excessive = client.post(url, {"montant": "100.01", "reference": ""})
    response = client.post(
        url,
        {"montant": "40.00", "reference": "REM-TEST-1"},
    )

    assert page.status_code == 200
    assert excessive.status_code == 200
    assert "dépasse le solde remboursable" in excessive.content.decode()
    assert response.status_code == 302
    remboursement = EvenementPaiement.objects.get(
        paiement_origine=paiement,
        type_evenement=TypeEvenementPaiement.REMBOURSEMENT,
    )
    assert remboursement.montant == Decimal("40.00")
    assert remboursement.statut == StatutEvenementPaiement.ENREGISTRE
    assert remboursement.devise == paiement.devise
    abonnement.refresh_from_db()
    assert abonnement.statut == StatutAbonnement.ACTIF
    historique = client.get(
        reverse("administration_saas:paiements"),
        {"type": TypeEvenementPaiement.PAIEMENT},
    )
    contenu = historique.content.decode()
    assert historique.status_code == 200
    assert "RECU-TEST" in contenu
    assert "Rembourser" in contenu
    assert "60,00 HTG" in contenu or "60.00 HTG" in contenu
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="operateur.paiements.consulte",
    ).exists()


def test_operator_can_create_a_plan_with_django_forms_and_audit():
    operator = _creer_utilisateur("plans-form-operator@example.org", operateur=True)
    client = Client(enforce_csrf_checks=True)
    client.force_login(operator)

    page = client.get(reverse("administration_saas:creer-plan"))
    csrf_token = client.cookies["csrftoken"].value
    payload = {
        "code": "formulaire",
        "nom": "Offre Formulaire",
        "description": "Plan créé depuis le formulaire Django.",
        "prix_mensuel": "2500.00",
        "devise": "HTG",
        "actif": "on",
        "droits-TOTAL_FORMS": "2",
        "droits-INITIAL_FORMS": "0",
        "droits-MIN_NUM_FORMS": "0",
        "droits-MAX_NUM_FORMS": "1000",
        "droits-0-code": "apprenants",
        "droits-0-actif": "on",
        "droits-0-limite": "250",
        "droits-0-unite": "apprenants",
        "droits-1-code": "",
        "droits-1-limite": "",
        "droits-1-unite": "",
    }

    without_csrf = client.post(reverse("administration_saas:creer-plan"), payload)
    response = client.post(
        reverse("administration_saas:creer-plan"),
        payload,
        HTTP_X_CSRFTOKEN=csrf_token,
    )

    assert page.status_code == 200
    assert "name=\"droits-TOTAL_FORMS\"" in page.content.decode()
    assert without_csrf.status_code == 403
    assert response.status_code == 302
    plan = PlanSaaS.objects.get(code="formulaire")
    assert plan.cree_par == operator
    assert plan.prix_annuel == 30000
    assert plan.droits.get(code="apprenants").limite == 250
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="plan.cree",
        id_objet=str(plan.pk),
    ).exists()


def test_operator_can_edit_plan_without_deleting_omitted_rights():
    operator = _creer_utilisateur("plans-edit-operator@example.org", operateur=True)
    plan = PlanSaaS.objects.create(
        cle_idempotence=uuid.uuid4(),
        code="offre-existante",
        nom="Offre existante",
        actif=False,
        cree_par=operator,
    )
    apprenants = plan.droits.create(
        code="apprenants",
        actif=True,
        limite=100,
        unite="apprenants",
    )
    campus = plan.droits.create(
        code="campus",
        actif=True,
        limite=2,
        unite="campus",
    )
    client = Client()
    client.force_login(operator)
    url = reverse("administration_saas:modifier-plan", args=(plan.pk,))
    page = client.get(url)
    payload = {
        "code": plan.code,
        "nom": "Offre mise à jour",
        "description": "",
        "prix_mensuel": "",
        "devise": "HTG",
        "droits-TOTAL_FORMS": "4",
        "droits-INITIAL_FORMS": "2",
        "droits-MIN_NUM_FORMS": "0",
        "droits-MAX_NUM_FORMS": "1000",
        "droits-0-id": str(apprenants.pk),
        "droits-0-code": "apprenants",
        "droits-0-limite": "100",
        "droits-0-unite": "apprenants",
        "droits-1-id": str(campus.pk),
        "droits-1-code": "campus",
        "droits-1-actif": "on",
        "droits-1-limite": "2",
        "droits-1-unite": "campus",
        "droits-2-code": "",
        "droits-2-limite": "",
        "droits-2-unite": "",
        "droits-3-code": "",
        "droits-3-limite": "",
        "droits-3-unite": "",
    }

    response = client.post(url, payload)

    assert page.status_code == 200
    assert response.status_code == 302
    plan.refresh_from_db()
    apprenants.refresh_from_db()
    campus.refresh_from_db()
    assert plan.nom == "Offre mise à jour"
    assert apprenants.actif is False
    assert campus.actif is True
    assert plan.droits.count() == 2


def test_operator_tenant_directory_searches_and_audits_consultation():
    operator = _creer_utilisateur("tenant-list-operator@example.org", operateur=True)
    owner = _creer_utilisateur("tenant-list-owner@example.org")
    tenant_a, _, _ = provisionner_tenant(
        createur=owner,
        nom="Institut Horizon",
        cle_idempotence=uuid.uuid4(),
    )
    tenant_b, _, _ = provisionner_tenant(
        createur=owner,
        nom="Campus Boréal",
        cle_idempotence=uuid.uuid4(),
    )
    client = Client()
    client.force_login(operator)

    response = client.get(
        reverse("administration_saas:etablissements"),
        {"q": "Horizon"},
    )
    forbidden = Client().get(reverse("administration_saas:etablissements"))

    assert response.status_code == 200
    content = response.content.decode()
    assert "Institut Horizon" in content
    assert "Campus Boréal" not in content
    assert f"?tenant={tenant_a.pk}" in content
    assert forbidden.status_code == 302
    assert EvenementAudit.objects.filter(
        acteur=operator,
        action="operateur.tenants.consulte",
    ).count() == 1


def test_tenant_directory_offers_create_modify_or_view_based_on_subscription():
    operator = _creer_utilisateur("tenant-actions-operator@example.org", operateur=True)
    owner = _creer_utilisateur("tenant-actions-owner@example.org")
    plan = _creer_plan_actif(operator)
    sans_abonnement = _creer_tenant(owner, "Institut Sans contrat")
    en_attente = _creer_tenant(owner, "Institut En attente")
    actif = _creer_tenant(owner, "Institut Actif")
    paiement_en_attente = _creer_tenant(owner, "Institut Paiement")
    abonnement_en_attente = _creer_abonnement_attente(operator, en_attente, plan)
    abonnement_actif = _creer_abonnement_attente(operator, actif, plan)
    abonnement_actif.statut = StatutAbonnement.ACTIF
    abonnement_actif.save(update_fields=("statut",))
    abonnement_paye, _ = _creer_paiement_enregistre(
        operator,
        paiement_en_attente,
        plan,
    )
    client = Client()
    client.force_login(operator)

    response = client.get(reverse("administration_saas:etablissements"))
    contenu = response.content.decode()

    assert response.status_code == 200
    assert (
        f'href="{reverse("administration_saas:creer-abonnement")}?tenant={sans_abonnement.pk}"'
        in contenu
    )
    url_modification = reverse(
        "administration_saas:modifier-abonnement",
        args=(abonnement_en_attente.pk,),
    )
    assert f'href="{url_modification}"' in contenu
    assert (
        f'href="{reverse("administration_saas:abonnements")}?q=Institut%20Actif"'
        in contenu
    )
    assert (
        f'href="{reverse("administration_saas:abonnements")}?q=Institut%20Paiement"'
        in contenu
    )
    assert f"modifier-abonnement/{abonnement_paye.pk}/" not in contenu


def test_operator_can_modify_pending_subscription_without_payment():
    operator = _creer_utilisateur("subscription-edit-operator@example.org", operateur=True)
    owner = _creer_utilisateur("subscription-edit-owner@example.org")
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator)
    nouveau_plan = _creer_plan_actif(operator, code="nouveau-plan")
    abonnement = _creer_abonnement_attente(operator, tenant, plan)
    client = Client()
    client.force_login(operator)
    url = reverse("administration_saas:modifier-abonnement", args=(abonnement.pk,))
    debut, fin = _dates_formulaire()

    page = client.get(url)
    response = client.post(
        url,
        {
            "plan": str(nouveau_plan.pk),
            "commence_le": debut,
            "termine_le": fin,
        },
    )

    assert page.status_code == 200
    assert "Modifier l’abonnement" in page.content.decode()
    assert response.status_code == 302
    abonnement.refresh_from_db()
    assert abonnement.plan == nouveau_plan
    assert abonnement.statut == StatutAbonnement.EN_ATTENTE
    evenement = EvenementAudit.objects.get(
        acteur=operator,
        action="abonnement.modifie",
        id_objet=str(abonnement.pk),
    )
    assert evenement.details["ancien"]["plan"] == plan.code
    assert evenement.details["nouveau"]["plan"] == nouveau_plan.code


@pytest.mark.parametrize("avec_paiement", (False, True))
def test_paid_or_active_subscription_cannot_be_modified(avec_paiement):
    operator = _creer_utilisateur(
        f"subscription-locked-operator-{avec_paiement}@example.org",
        operateur=True,
    )
    owner = _creer_utilisateur(
        f"subscription-locked-owner-{avec_paiement}@example.org",
    )
    tenant = _creer_tenant(owner)
    plan = _creer_plan_actif(operator)
    if avec_paiement:
        abonnement, _ = _creer_paiement_enregistre(operator, tenant, plan)
    else:
        abonnement = _creer_abonnement_attente(operator, tenant, plan)
        abonnement.statut = StatutAbonnement.ACTIF
        abonnement.save(update_fields=("statut",))
    client = Client()
    client.force_login(operator)

    response = client.get(
        reverse("administration_saas:modifier-abonnement", args=(abonnement.pk,)),
    )

    assert response.status_code == 404


def test_operator_subscription_form_uses_selected_tenant_from_query_string():
    operator = _creer_utilisateur("csrf-operator@example.org", operateur=True)
    owner = _creer_utilisateur("preselected-tenant-owner@example.org")
    tenant = _creer_tenant(owner, "Institut préselectionné")
    client = Client()
    client.force_login(operator)

    response = client.get(
        reverse("administration_saas:creer-abonnement"),
        {"tenant": str(tenant.pk)},
    )

    assert response.status_code == 200
    assert f'value="{tenant.pk}" selected' in response.content.decode()
