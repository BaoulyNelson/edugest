"""Factories de tests pour les contrats tenant actifs."""

import uuid
from datetime import timedelta

from django.utils import timezone

from applications.abonnements.models import Abonnement, PlanSaaS


def rendre_tenant_abonne(tenant, acteur):
    """Crée un contrat actif fixture sans prix ni droits implicites."""
    plan = PlanSaaS.objects.create(
        cle_idempotence=uuid.uuid4(),
        code=f"test-{uuid.uuid4().hex[:12]}",
        nom="Plan de test",
        actif=True,
        cree_par=acteur,
    )
    maintenant = timezone.now()
    return Abonnement.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        plan=plan,
        statut="actif",
        commence_le=maintenant - timedelta(days=1),
        termine_le=maintenant + timedelta(days=30),
        cree_par=acteur,
    )
