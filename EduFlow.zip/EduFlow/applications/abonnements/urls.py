"""Routes Django classiques de l’administration SaaS."""

from django.urls import path

from applications.abonnements import views

app_name = "administration_saas"

urlpatterns = [
    path("plans/", views.plans_saas, name="plans"),
    path("plans/creer/", views.creer_plan_saas, name="creer-plan"),
    path("plans/<uuid:plan_id>/modifier/", views.modifier_plan_saas, name="modifier-plan"),
    path("etablissements/", views.etablissements_saas, name="etablissements"),
    path("abonnements/", views.abonnements_saas, name="abonnements"),
    path("abonnements/creer/", views.creer_abonnement_saas, name="creer-abonnement"),
    path(
        "abonnements/<uuid:abonnement_id>/modifier/",
        views.modifier_abonnement_saas,
        name="modifier-abonnement",
    ),
    path(
        "abonnements/<uuid:abonnement_id>/annuler/",
        views.annuler_abonnement_saas,
        name="annuler-abonnement",
    ),
    path("paiements/", views.paiements_saas, name="paiements"),
    path("paiements/enregistrer/", views.enregistrer_paiement_saas, name="enregistrer-paiement"),
    path(
        "paiements/<uuid:paiement_id>/rembourser/",
        views.enregistrer_remboursement_saas,
        name="enregistrer-remboursement",
    ),
    path(
        "paiements/<uuid:evenement_id>/<str:decision>/",
        views.decider_evenement_paiement_saas,
        name="decider-paiement",
    ),
]
