"""Vérification Django de l’accès au portail opérateur SaaS."""


def utilisateur_peut_gerer_abonnements_saas(utilisateur) -> bool:
    """Vérifie le droit Django nécessaire à la gestion des abonnements SaaS."""
    return bool(
        utilisateur
        and utilisateur.is_authenticated
        and utilisateur.is_staff
        and utilisateur.has_perm("abonnements.gerer_abonnements_saas")
    )
