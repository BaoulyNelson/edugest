"""Modèles opérateur SaaS et mesures d’usage tenant-scoped."""

import uuid

from django.conf import settings
from django.core.validators import MinValueValidator, RegexValidator
from django.db import models
from django.db.models import Q

from applications.organisations.models import Tenant


class StatutAbonnement(models.TextChoices):
    EN_ATTENTE = "en_attente", "En attente de paiement"
    ACTIF = "actif", "Actif"
    ANNULE = "annule", "Annulé"
    EXPIRE = "expire", "Expiré"


class TypeEvenementPaiement(models.TextChoices):
    PAIEMENT = "paiement", "Paiement"
    REMBOURSEMENT = "remboursement", "Remboursement"


class StatutEvenementPaiement(models.TextChoices):
    ENREGISTRE = "enregistre", "Enregistré"
    CONFIRME = "confirme", "Confirmé"
    REJETE = "rejete", "Rejeté"


class PlanSaaS(models.Model):
    """Offre opérateur avec tarif explicite et entitlements configurés."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    code = models.SlugField(max_length=80, unique=True)
    nom = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    prix_mensuel = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0.01)],
    )
    devise = models.CharField(
        max_length=3,
        default="HTG",
        validators=[
            RegexValidator(
                r"^[A-Z]{3}$",
                "La devise doit utiliser trois lettres majuscules.",
            )
        ],
    )
    actif = models.BooleanField(default=False)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="plans_saas_crees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("code",)
        verbose_name = "plan SaaS"
        verbose_name_plural = "plans SaaS"
        permissions = [
            ("gerer_abonnements_saas", "Peut gérer les abonnements SaaS"),
        ]

    def __str__(self) -> str:
        return f"{self.nom} ({self.code})"

    @property
    def prix_annuel(self):
        """Retourne douze mensualités sans remise ni prix annuel implicite."""
        if self.prix_mensuel is None:
            return None
        return self.prix_mensuel * 12

    @property
    def est_gratuit(self) -> bool:
        """Le plan gratuit est explicitement nommé et sans tarif configuré."""
        return self.code.casefold() == "gratuit" and self.prix_mensuel is None


class DroitUsage(models.Model):
    """Module ou quota configurable d’un plan, sans valeur métier par défaut."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    plan = models.ForeignKey(PlanSaaS, on_delete=models.CASCADE, related_name="droits")
    code = models.SlugField(max_length=100)
    actif = models.BooleanField(default=False)
    limite = models.PositiveIntegerField(null=True, blank=True)
    unite = models.CharField(max_length=50)

    class Meta:
        ordering = ("code",)
        constraints = [
            models.UniqueConstraint(fields=("plan", "code"), name="droit_plan_code_unique"),
            models.CheckConstraint(
                condition=Q(limite__isnull=True) | Q(limite__gt=0),
                name="droit_limite_positive",
            ),
        ]
        verbose_name = "droit d’usage"
        verbose_name_plural = "droits d’usage"

    def __str__(self) -> str:
        return f"{self.plan.code}:{self.code}"


class Abonnement(models.Model):
    """Contrat commercial d’un tenant, distinct de son statut opérationnel."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.PROTECT,
        related_name="abonnements_saas",
    )
    plan = models.ForeignKey(
        PlanSaaS,
        on_delete=models.PROTECT,
        related_name="abonnements",
    )
    statut = models.CharField(
        max_length=12,
        choices=StatutAbonnement.choices,
        default=StatutAbonnement.EN_ATTENTE,
    )
    commence_le = models.DateTimeField()
    termine_le = models.DateTimeField()
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="abonnements_saas_crees",
    )
    annule_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="abonnements_saas_annules",
    )
    annule_le = models.DateTimeField(null=True, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-cree_le",)
        constraints = [
            models.CheckConstraint(
                condition=Q(statut__in=StatutAbonnement.values),
                name="abonnement_statut_valide",
            ),
            models.CheckConstraint(
                condition=Q(termine_le__gt=models.F("commence_le")),
                name="abonnement_periode_valide",
            ),
            models.UniqueConstraint(
                fields=("tenant",),
                condition=Q(statut__in=(StatutAbonnement.EN_ATTENTE, StatutAbonnement.ACTIF)),
                name="tenant_un_abonnement_en_cours",
            ),
        ]
        indexes = [
            models.Index(fields=("tenant", "statut"), name="abonnement_tenant_statut_idx"),
            models.Index(fields=("statut", "termine_le"), name="abonnement_statut_fin_idx"),
        ]
        verbose_name = "abonnement SaaS"
        verbose_name_plural = "abonnements SaaS"

    def __str__(self) -> str:
        return f"{self.tenant_id} — {self.plan.code} ({self.statut})"


class EvenementPaiement(models.Model):
    """Événement manuel immuable de paiement ou remboursement, sans donnée de carte."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    abonnement = models.ForeignKey(
        Abonnement,
        on_delete=models.PROTECT,
        related_name="evenements_paiement",
    )
    type_evenement = models.CharField(max_length=16, choices=TypeEvenementPaiement.choices)
    statut = models.CharField(
        max_length=12,
        choices=StatutEvenementPaiement.choices,
        default=StatutEvenementPaiement.ENREGISTRE,
    )
    paiement_origine = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="remboursements",
    )
    montant = models.DecimalField(max_digits=12, decimal_places=2)
    devise = models.CharField(
        max_length=3,
        validators=[
            RegexValidator(
                r"^[A-Z]{3}$",
                "La devise doit être un code de 3 lettres majuscules.",
            )
        ],
    )
    reference = models.CharField(max_length=200, blank=True)
    motif_decision = models.CharField(max_length=500, blank=True)
    enregistre_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="evenements_paiement_saas_enregistres",
    )
    decide_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="evenements_paiement_saas_decides",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    decide_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-cree_le",)
        constraints = [
            models.CheckConstraint(
                condition=Q(type_evenement__in=TypeEvenementPaiement.values),
                name="paiement_type_valide",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutEvenementPaiement.values),
                name="paiement_statut_valide",
            ),
            models.CheckConstraint(
                condition=Q(montant__gt=0),
                name="paiement_montant_positif",
            ),
            models.CheckConstraint(
                condition=(
                    Q(type_evenement=TypeEvenementPaiement.PAIEMENT, paiement_origine__isnull=True)
                    | Q(
                        type_evenement=TypeEvenementPaiement.REMBOURSEMENT,
                        paiement_origine__isnull=False,
                    )
                ),
                name="paiement_origine_selon_type",
            ),
        ]
        indexes = [
            models.Index(fields=("abonnement", "statut"), name="paiement_abonnement_statut_idx"),
        ]
        verbose_name = "événement de paiement SaaS"
        verbose_name_plural = "événements de paiement SaaS"

    def __str__(self) -> str:
        return f"{self.type_evenement} {self.montant} {self.devise} ({self.statut})"


class EnregistrementUsage(models.Model):
    """Usage mesuré pour un droit durant la période contractuelle d’un abonnement."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.PROTECT,
        related_name="usages_saas",
    )
    abonnement = models.ForeignKey(
        Abonnement,
        on_delete=models.PROTECT,
        related_name="usages",
    )
    droit = models.ForeignKey(
        DroitUsage,
        on_delete=models.PROTECT,
        related_name="usages",
    )
    quantite = models.PositiveIntegerField()
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="usages_saas_enregistres",
    )
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-cree_le",)
        constraints = [
            models.CheckConstraint(
                condition=Q(quantite__gt=0),
                name="usage_quantite_positive",
            ),
        ]
        indexes = [
            models.Index(
                fields=("abonnement", "droit", "cree_le"),
                name="usage_abonnement_droit_idx",
            ),
            models.Index(fields=("tenant", "cree_le"), name="usage_tenant_created_idx"),
        ]
        verbose_name = "enregistrement d’usage"
        verbose_name_plural = "enregistrements d’usage"

    def __str__(self) -> str:
        return f"{self.tenant_id}:{self.droit.code} +{self.quantite}"
