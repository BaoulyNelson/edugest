"""Commande planifiable d’expiration des abonnements SaaS échus."""

from django.core.management.base import BaseCommand

from applications.abonnements.services import expirer_abonnements_echus


class Command(BaseCommand):
    help = "Marque les abonnements SaaS dont la période contractuelle est échue."

    def add_arguments(self, parser):
        parser.add_argument("--limite", type=int, default=500)

    def handle(self, *args, **options):
        expires = expirer_abonnements_echus(limite=options["limite"])
        self.stdout.write(
            self.style.SUCCESS(
                f"{expires} abonnement(s) marqué(s) expiré(s); "
                "les tenants sans abonnement actif sont restreints."
            )
        )
