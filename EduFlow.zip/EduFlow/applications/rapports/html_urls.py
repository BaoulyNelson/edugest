"""Routes HTML du module des rapports."""

from django.urls import path

from applications.rapports.views import rapports_html

app_name = "rapports_web"

urlpatterns = [path("", rapports_html, name="accueil")]
