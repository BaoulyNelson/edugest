"""Tests des rapports HTML tenant-scoped et audités."""

from uuid import uuid4

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.emplois_temps.tests.factories import (
    _creer_affectation,
    _creer_inscription,
    _preparer_tenant,
)
from applications.evaluations.models import Evaluation, NoteEvaluation, StatutEvaluation
from applications.organisations.models import EvenementAudit
from applications.pedagogie.models import Devoir, Quiz

pytestmark = pytest.mark.django_db


def _client_web(utilisateur, tenant):
    utilisateur.email_verifie_le = timezone.now()
    utilisateur.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(utilisateur)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    return client


def test_html_reports_use_tenant_scoped_filters_and_audit_reads():
    contexte = _preparer_tenant("report-html")
    _creer_inscription(contexte)
    client = _client_web(contexte["proprietaire"], contexte["tenant"])
    url = reverse("rapports_web:accueil")

    effectifs = client.get(
        url,
        {
            "rapport": "effectifs",
            "annee_academique": str(contexte["annee"].pk),
        },
    )
    presences = client.get(
        url,
        {
            "rapport": "presences",
            "date_debut": "2026-09-01",
            "date_fin": "2026-09-30",
        },
    )
    plage_invalide = client.get(
        url,
        {
            "rapport": "presences",
            "date_debut": "2026-10-01",
            "date_fin": "2026-09-01",
        },
    )

    assert effectifs.status_code == 200
    assert "1 inscription" in effectifs.content.decode()
    assert presences.status_code == 200
    assert "Aucune présence enregistrée" in presences.content.decode()
    assert plage_invalide.status_code == 200
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="rapport.effectifs.consulte",
    ).exists()
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="rapport.presences.consulte",
    ).exists()


def test_reports_are_not_available_to_teachers():
    contexte = _preparer_tenant("report-permissions")
    client = _client_web(contexte["enseignant"]["compte"], contexte["tenant"])

    response = client.get(reverse("rapports_web:accueil"))

    assert response.status_code == 403


def test_owner_gets_global_counts_and_published_results_by_assignment():
    contexte = _preparer_tenant("report-pedagogical")
    affectation = _creer_affectation(contexte)
    inscription = _creer_inscription(contexte)
    evaluation = Evaluation.objects.create(
        cle_idempotence=uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        affectation=affectation,
        titre="Évaluation globale",
        date_evaluation="2026-09-10",
        note_maximale="20",
        coefficient="1",
        statut=StatutEvaluation.PUBLIEE,
    )
    NoteEvaluation.objects.create(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        evaluation=evaluation,
        inscription=inscription,
        note="15",
    )
    Quiz.objects.create(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        affectation=affectation,
        titre="Quiz de révision",
    )
    Devoir.objects.create(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        affectation=affectation,
        titre="Devoir de révision",
        consignes="Exercices à faire.",
        publie_le="2026-09-10",
        a_rendre_le="2026-09-17",
    )
    client = _client_web(contexte["proprietaire"], contexte["tenant"])

    response = client.get(reverse("rapports_web:accueil"))

    assert response.status_code == 200
    assert response.context["total_evaluations"] == 1
    assert response.context["total_quiz"] == 1
    assert response.context["total_devoirs"] == 1
    ligne = response.context["activites_pedagogiques"][0]
    assert ligne["evaluations_publiees"] == 1
    assert ligne["notes"] == 1
    assert float(ligne["moyenne"]) == 75
    assert "Activités pédagogiques globales" in response.content.decode()
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="rapport.pedagogique.consulte",
    ).exists()
