"""Formulaires HTML de génération des rapports éducatifs."""

from datetime import timedelta

from django import forms
from django.core.exceptions import ValidationError

from applications.referentiels.models import AnneeAcademique


class RapportEffectifsForm(forms.Form):
    annee_academique = forms.ModelChoiceField(
        queryset=AnneeAcademique.objects.none(),
        label="Année académique",
    )

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["annee_academique"].queryset = AnneeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
        )
        self.fields["annee_academique"].widget.attrs["class"] = "saas-input"


class RapportPresencesForm(forms.Form):
    date_debut = forms.DateField(
        label="Du",
        widget=forms.DateInput(
            attrs={"type": "date", "class": "saas-input"},
            format="%Y-%m-%d",
        ),
    )
    date_fin = forms.DateField(
        label="Au",
        widget=forms.DateInput(
            attrs={"type": "date", "class": "saas-input"},
            format="%Y-%m-%d",
        ),
    )

    def clean(self):
        cleaned_data = super().clean()
        debut = cleaned_data.get("date_debut")
        fin = cleaned_data.get("date_fin")
        if debut and fin:
            if fin < debut:
                self.add_error("date_fin", "La fin doit être égale ou postérieure au début.")
            elif fin - debut > timedelta(days=365):
                raise ValidationError("La période ne peut pas dépasser 366 jours inclusifs.")
        return cleaned_data
