from decimal import Decimal

from django.db.models import Avg, Count, DecimalField, ExpressionWrapper, F, Q, Value

from applications.emplois_temps.models import AffectationEnseignement
from applications.evaluations.models import Evaluation, StatutEvaluation
from applications.inscriptions.models import Inscription
from applications.organisations.models import EvenementAudit
from applications.pedagogie.models import Devoir, Quiz
from applications.presences.models import Presence


def agreger_effectifs(*, tenant, institution, annee):
    return list(
        Inscription.objects.filter(
            tenant=tenant,
            institution=institution,
            annee_academique=annee,
            annee_academique__tenant=tenant,
            annee_academique__institution=institution,
            programme__tenant=tenant,
            programme__institution=institution,
            apprenant__tenant=tenant,
            apprenant__institution=institution,
            apprenant__personne__tenant=tenant,
            apprenant__personne__institution=institution,
            candidature__tenant=tenant,
            candidature__institution=institution,
        )
        .filter(
            Q(groupe__isnull=True)
            | Q(groupe__tenant=tenant, groupe__institution=institution)
        )
        .values(
            "programme_id",
            "programme__code",
            "programme__nom",
            "groupe_id",
            "groupe__code",
            "groupe__nom",
            "statut",
        )
        .annotate(nombre_inscriptions=Count("pk"))
        .order_by(
            "programme__nom",
            "groupe__nom",
            "statut",
        )
    )


def agreger_presences(*, tenant, institution, date_debut, date_fin):
    return list(
        Presence.objects.filter(
            tenant=tenant,
            institution=institution,
            seance__tenant=tenant,
            seance__institution=institution,
            seance__date__range=(date_debut, date_fin),
            seance__creneau__tenant=tenant,
            seance__creneau__institution=institution,
            seance__creneau__affectation__tenant=tenant,
            seance__creneau__affectation__institution=institution,
            seance__creneau__affectation__groupe_id=F("groupe_id"),
            inscription__tenant=tenant,
            inscription__institution=institution,
            inscription__apprenant__tenant=tenant,
            inscription__apprenant__institution=institution,
            inscription__apprenant__personne__tenant=tenant,
            inscription__apprenant__personne__institution=institution,
            inscription__groupe_id=F("groupe_id"),
            groupe__tenant=tenant,
            groupe__institution=institution,
        )
        .values("groupe_id", "groupe__code", "groupe__nom", "statut")
        .annotate(nombre_presences_enregistrees=Count("pk"))
        .order_by("groupe__nom", "statut")
    )


def agreger_activites_pedagogiques(*, tenant, institution):
    filtres_tenant = {
        "tenant": tenant,
        "institution": institution,
        "affectation__tenant": tenant,
        "affectation__institution": institution,
    }
    moyenne_pourcentage = ExpressionWrapper(
        F("notes__note") * Value(Decimal("100.00")) / F("note_maximale"),
        output_field=DecimalField(max_digits=12, decimal_places=4),
    )
    evaluations = {
        ligne["affectation_id"]: ligne
        for ligne in Evaluation.objects.filter(**filtres_tenant)
        .values("affectation_id")
        .annotate(
            nombre=Count("pk", distinct=True),
            publiees=Count(
                "pk",
                filter=Q(statut=StatutEvaluation.PUBLIEE),
                distinct=True,
            ),
            nombre_notes=Count(
                "notes__pk",
                filter=Q(
                    statut=StatutEvaluation.PUBLIEE,
                    notes__tenant=tenant,
                    notes__institution=institution,
                    notes__note__isnull=False,
                ),
                distinct=True,
            ),
            moyenne=Avg(
                moyenne_pourcentage,
                filter=Q(
                    statut=StatutEvaluation.PUBLIEE,
                    notes__tenant=tenant,
                    notes__institution=institution,
                    notes__note__isnull=False,
                ),
            ),
        )
    }
    quiz = {
        ligne["affectation_id"]: ligne["nombre"]
        for ligne in Quiz.objects.filter(**filtres_tenant)
        .values("affectation_id")
        .annotate(nombre=Count("pk"))
    }
    devoirs = {
        ligne["affectation_id"]: ligne["nombre"]
        for ligne in Devoir.objects.filter(**filtres_tenant)
        .values("affectation_id")
        .annotate(nombre=Count("pk"))
    }
    affectations_ids = set(evaluations) | set(quiz) | set(devoirs)
    affectations = (
        AffectationEnseignement.objects.filter(
            pk__in=affectations_ids,
            tenant=tenant,
            institution=institution,
        )
        .select_related("enseignant__personne", "cours", "groupe", "annee_academique")
        .order_by("annee_academique__nom", "groupe__nom", "cours__nom")
    )
    return [
        {
            "enseignant": str(affectation.enseignant.personne),
            "cours": affectation.cours.nom,
            "groupe": affectation.groupe.nom,
            "annee_academique": affectation.annee_academique.nom,
            "evaluations": evaluations.get(affectation.pk, {}).get("nombre", 0),
            "evaluations_publiees": evaluations.get(affectation.pk, {}).get(
                "publiees",
                0,
            ),
            "quiz": quiz.get(affectation.pk, 0),
            "devoirs": devoirs.get(affectation.pk, 0),
            "notes": evaluations.get(affectation.pk, {}).get("nombre_notes", 0),
            "moyenne": evaluations.get(affectation.pk, {}).get("moyenne"),
        }
        for affectation in affectations
    ]


def auditer_consultation_rapport(*, tenant, acteur, nom, identifiant, filtres):
    EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=f"rapport.{nom}.consulte",
        type_objet=f"rapports.{nom}",
        id_objet=str(identifiant),
        details=filtres,
    )
