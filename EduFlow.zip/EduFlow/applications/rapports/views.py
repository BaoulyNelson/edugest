"""Rapports HTML tenant-scoped et audités."""

from datetime import timedelta

from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.decorators.http import require_GET

from applications.rapports.forms import RapportEffectifsForm, RapportPresencesForm
from applications.rapports.services import (
    agreger_activites_pedagogiques,
    agreger_effectifs,
    agreger_presences,
    auditer_consultation_rapport,
)
from applications.referentiels.views import _exiger_gestion
from applications.tableau_de_bord.views import _page_privee


@login_required
@_page_privee
@require_GET
def rapports_html(request):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    institution = workspace.tenant.institution
    with timezone.override(institution.fuseau_horaire):
        today = timezone.localdate()
    effectifs_form = RapportEffectifsForm(
        request.GET if request.GET.get("rapport") == "effectifs" else None,
        initial={"annee_academique": request.GET.get("annee_academique")},
        tenant=workspace.tenant,
        institution=institution,
    )
    presences_form = RapportPresencesForm(
        request.GET if request.GET.get("rapport") == "presences" else None,
        initial={
            "date_debut": today - timedelta(days=30),
            "date_fin": today,
        },
    )
    effectifs = []
    presences = []
    total_effectifs = 0
    total_presences = 0
    activites_pedagogiques = agreger_activites_pedagogiques(
        tenant=workspace.tenant,
        institution=institution,
    )
    total_evaluations = sum(ligne["evaluations"] for ligne in activites_pedagogiques)
    total_quiz = sum(ligne["quiz"] for ligne in activites_pedagogiques)
    total_devoirs = sum(ligne["devoirs"] for ligne in activites_pedagogiques)
    auditer_consultation_rapport(
        tenant=workspace.tenant,
        acteur=request.user,
        nom="pedagogique",
        identifiant=workspace.tenant.pk,
        filtres={
            "evaluations": total_evaluations,
            "quiz": total_quiz,
            "devoirs": total_devoirs,
        },
    )

    if effectifs_form.is_bound and effectifs_form.is_valid():
        annee = effectifs_form.cleaned_data["annee_academique"]
        effectifs = agreger_effectifs(
            tenant=workspace.tenant,
            institution=institution,
            annee=annee,
        )
        total_effectifs = sum(ligne["nombre_inscriptions"] for ligne in effectifs)
        auditer_consultation_rapport(
            tenant=workspace.tenant,
            acteur=request.user,
            nom="effectifs",
            identifiant=annee.pk,
            filtres={"annee_academique": str(annee.pk)},
        )

    if presences_form.is_bound and presences_form.is_valid():
        debut = presences_form.cleaned_data["date_debut"]
        fin = presences_form.cleaned_data["date_fin"]
        presences = agreger_presences(
            tenant=workspace.tenant,
            institution=institution,
            date_debut=debut,
            date_fin=fin,
        )
        total_presences = sum(
            ligne["nombre_presences_enregistrees"] for ligne in presences
        )
        auditer_consultation_rapport(
            tenant=workspace.tenant,
            acteur=request.user,
            nom="presences",
            identifiant=f"{debut}:{fin}",
            filtres={
                "date_debut": debut.isoformat(),
                "date_fin": fin.isoformat(),
            },
        )

    return render(
        request,
        "rapports/accueil.html",
        {
            **contexte,
            "effectifs_form": effectifs_form,
            "presences_form": presences_form,
            "effectifs": effectifs,
            "presences": presences,
            "total_effectifs": total_effectifs,
            "total_presences": total_presences,
            "activites_pedagogiques": activites_pedagogiques,
            "total_evaluations": total_evaluations,
            "total_quiz": total_quiz,
            "total_devoirs": total_devoirs,
        },
    )
