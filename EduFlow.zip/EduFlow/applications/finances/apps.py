"""Configuration des finances scolaires."""

from django.apps import AppConfig


class FinancesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.finances"
    label = "finances"
    verbose_name = "Finances de l’établissement"
