"""Formulaires HTML des barèmes, factures et paiements scolaires."""

import uuid
from decimal import Decimal

from django import forms
from django.db.models import Sum
from django.forms import formset_factory

from applications.finances.models import (
    AllocationPaiement,
    BaremeFrais,
    Facture,
    ModePaiement,
    StatutFacture,
)
from applications.finances.services import situation_factures
from applications.inscriptions.models import Inscription, StatutInscription
from applications.referentiels.models import AnneeAcademique, Programme


class BaremeCreationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    annee_academique = forms.ModelChoiceField(
        queryset=AnneeAcademique.objects.none(),
        label="Année académique",
    )
    programme = forms.ModelChoiceField(
        queryset=Programme.objects.none(),
        label="Programme",
    )
    code = forms.SlugField(max_length=50, label="Code")
    nom = forms.CharField(max_length=160, label="Nom du barème")
    devise = forms.ChoiceField(label="Devise")
    actif = forms.BooleanField(initial=True, required=False, label="Actif")

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["annee_academique"].queryset = AnneeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
        )
        self.fields["programme"].queryset = Programme.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        devises = [institution.devise_principale, *institution.devises_secondaires]
        self.fields["devise"].choices = [(devise, devise) for devise in devises]
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class LigneBaremeForm(forms.Form):
    libelle = forms.CharField(max_length=200, label="Poste de frais")
    montant = forms.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=0.01,
        label="Montant",
        widget=forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
    )
    ordre = forms.IntegerField(min_value=0, required=False, label="Ordre")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


LigneBaremeFormSet = formset_factory(
    LigneBaremeForm,
    extra=2,
    min_num=1,
    max_num=20,
    validate_min=True,
    validate_max=True,
    can_delete=True,
)


class FactureCreationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    inscription = forms.ModelChoiceField(
        queryset=Inscription.objects.none(),
        label="Inscription",
    )
    bareme = forms.ModelChoiceField(
        queryset=BaremeFrais.objects.none(),
        label="Barème de frais",
    )
    date_echeance = forms.DateField(
        label="Date d’échéance",
        widget=forms.DateInput(attrs={"type": "date"}),
    )

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["inscription"].queryset = Inscription.objects.filter(
            tenant=tenant,
            institution=institution,
            statut=StatutInscription.ACTIVE,
        ).select_related("apprenant__personne", "annee_academique", "programme")
        self.fields["inscription"].label_from_instance = lambda item: (
            f"{item.apprenant.personne} — {item.programme.nom} · "
            f"{item.annee_academique.nom}"
        )
        self.fields["bareme"].queryset = BaremeFrais.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        inscription = cleaned_data.get("inscription")
        bareme = cleaned_data.get("bareme")
        if inscription and bareme and (
            inscription.annee_academique_id != bareme.annee_academique_id
            or inscription.programme_id != bareme.programme_id
        ):
            self.add_error("bareme", "Le barème ne correspond pas au programme et à l’année.")
        return cleaned_data


class PaiementCreationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    facture = forms.ModelChoiceField(queryset=Facture.objects.none(), label="Facture")
    montant = forms.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=0.01,
        label="Montant reçu",
        widget=forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
    )
    date_paiement = forms.DateField(
        label="Date du paiement",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    mode = forms.ChoiceField(choices=ModePaiement.choices, label="Mode de paiement")
    autre_mode = forms.CharField(max_length=80, required=False, label="Préciser le mode")
    reference = forms.CharField(max_length=120, required=False, label="Référence")

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["facture"].queryset = Facture.objects.filter(
            tenant=tenant,
            institution=institution,
            statut__in=(StatutFacture.EMISE, StatutFacture.PARTIELLE),
        ).select_related("inscription__apprenant__personne")
        self.fields["facture"].label_from_instance = lambda item: (
            f"{item.numero} — {item.inscription.apprenant.personne} ({item.devise})"
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        facture = cleaned_data.get("facture")
        montant = cleaned_data.get("montant")
        if facture and montant:
            situation = situation_factures(tenant=facture.tenant, factures=[facture])[
                facture.pk
            ]
            solde = situation["total"] - situation["paye"]
            if montant > solde:
                self.add_error("montant", f"Le montant dépasse le solde de {solde}.")
        if cleaned_data.get("mode") == ModePaiement.AUTRE and not cleaned_data.get(
            "autre_mode", ""
        ).strip():
            self.add_error("autre_mode", "Précisez le mode de paiement.")
        return cleaned_data


class FiltrePaiementsForm(forms.Form):
    date_debut = forms.DateField(
        label="Du",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    date_fin = forms.DateField(
        label="Au",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    devise = forms.ChoiceField(label="Devise", required=False)

    def __init__(self, *args, institution, **kwargs):
        super().__init__(*args, **kwargs)
        devises = [institution.devise_principale, *institution.devises_secondaires]
        self.fields["devise"].choices = [("", "Toutes les devises")] + [
            (devise, devise) for devise in devises
        ]
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        debut = cleaned_data.get("date_debut")
        fin = cleaned_data.get("date_fin")
        if debut and fin and debut > fin:
            self.add_error("date_fin", "La date de fin doit suivre la date de début.")
        return cleaned_data


class RemboursementCreationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    allocation = forms.ModelChoiceField(
        queryset=AllocationPaiement.objects.none(),
        label="Facture concernée",
    )
    montant = forms.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=0.01,
        label="Montant à rembourser",
        widget=forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
    )
    date_remboursement = forms.DateField(
        label="Date du remboursement",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    mode = forms.ChoiceField(choices=ModePaiement.choices, label="Mode de remboursement")
    autre_mode = forms.CharField(max_length=80, required=False, label="Préciser le mode")
    reference = forms.CharField(max_length=120, required=False, label="Référence")
    motif = forms.CharField(max_length=250, label="Motif")

    def __init__(self, *args, tenant, institution, paiement, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["allocation"].queryset = AllocationPaiement.objects.filter(
            tenant=tenant,
            institution=institution,
            paiement=paiement,
        ).select_related("facture__inscription__apprenant__personne")
        self.fields["allocation"].label_from_instance = lambda allocation: (
            f"{allocation.facture.numero} — "
            f"{allocation.facture.inscription.apprenant.personne}"
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean(self):
        cleaned_data = super().clean()
        allocation = cleaned_data.get("allocation")
        montant = cleaned_data.get("montant")
        if allocation and montant:
            rembourse = allocation.remboursements.aggregate(
                total=Sum("montant")
            )["total"] or Decimal("0.00")
            restant = allocation.montant - rembourse
            if montant > restant:
                self.add_error(
                    "montant",
                    f"Le remboursement dépasse le solde de {restant}.",
                )
        if cleaned_data.get("mode") == ModePaiement.AUTRE and not cleaned_data.get(
            "autre_mode", ""
        ).strip():
            self.add_error("autre_mode", "Précisez le mode de remboursement.")
        return cleaned_data


class AnnulerFactureForm(forms.Form):
    motif = forms.CharField(
        label="Motif d’annulation",
        max_length=250,
        widget=forms.Textarea(attrs={"rows": 3, "class": "saas-input"}),
    )


class ModifierFactureForm(forms.Form):
    date_echeance = forms.DateField(
        label="Date d’échéance",
        widget=forms.DateInput(attrs={"type": "date", "class": "saas-input"}),
    )


class LigneFactureForm(forms.Form):
    libelle = forms.CharField(max_length=200, label="Poste de frais")
    montant = forms.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=0.01,
        label="Montant",
        widget=forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
    )
    ordre = forms.IntegerField(min_value=0, required=False, label="Ordre")


LigneFactureFormSet = formset_factory(
    LigneFactureForm,
    extra=2,
    min_num=1,
    max_num=20,
    validate_min=True,
    validate_max=True,
    can_delete=True,
)
