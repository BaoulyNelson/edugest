"""Barèmes, factures et opérations financières tenant-scoped."""

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.inscriptions.models import Inscription
from applications.personnes.models import ObjetEducatifTenant
from applications.referentiels.models import AnneeAcademique, Programme


class StatutFacture(models.TextChoices):
    BROUILLON = "brouillon", "Brouillon"
    EMISE = "emise", "Émise"
    PARTIELLE = "partielle", "Partiellement payée"
    PAYEE = "payee", "Payée"
    ANNULEE = "annulee", "Annulée"


class ModePaiement(models.TextChoices):
    ESPECES = "especes", "Espèces"
    VIREMENT = "virement", "Virement"
    CHEQUE = "cheque", "Chèque"
    AUTRE = "autre", "Autre"


class BaremeFrais(ObjetEducatifTenant):
    """Barème versionné applicable à un programme et une année académique."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    annee_academique = models.ForeignKey(
        AnneeAcademique,
        on_delete=models.PROTECT,
        related_name="baremes_frais",
    )
    programme = models.ForeignKey(
        Programme,
        on_delete=models.PROTECT,
        related_name="baremes_frais",
    )
    code = models.SlugField(max_length=50)
    nom = models.CharField(max_length=160)
    devise = models.CharField(max_length=3)
    actif = models.BooleanField(default=True)

    class Meta:
        ordering = ("annee_academique__debut", "programme__nom", "code")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "code"),
                name="bareme_tenant_code_unique",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "annee_academique", "actif"),
                name="bareme_tenant_annee_idx",
            ),
        ]
        verbose_name = "barème de frais"
        verbose_name_plural = "barèmes de frais"

    def __str__(self) -> str:
        return f"{self.nom} ({self.code})"

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("annee_academique", self.annee_academique if self.annee_academique_id else None),
            ("programme", self.programme if self.programme_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if self.devise and self.institution_id:
            devises_autorisees = {
                self.institution.devise_principale,
                *self.institution.devises_secondaires,
            }
            if self.devise not in devises_autorisees:
                erreurs["devise"] = (
                    "La devise doit être configurée dans les paramètres de l’institution."
                )
        if erreurs:
            raise ValidationError(erreurs)


class LigneBaremeFrais(ObjetEducatifTenant):
    """Montant d’un poste de frais dans un barème."""

    bareme = models.ForeignKey(
        BaremeFrais,
        on_delete=models.CASCADE,
        related_name="lignes",
    )
    libelle = models.CharField(max_length=200)
    montant = models.DecimalField(max_digits=12, decimal_places=2)
    ordre = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ("ordre", "id")
        constraints = [
            models.CheckConstraint(
                condition=Q(montant__gt=0),
                name="ligne_bareme_montant_positif",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "bareme", "ordre"),
                name="ligne_bareme_tenant_idx",
            ),
        ]
        verbose_name = "ligne de barème"
        verbose_name_plural = "lignes de barème"

    def __str__(self) -> str:
        return f"{self.libelle} — {self.montant}"

    def clean(self):
        super().clean()
        if self.bareme_id and (
            self.bareme.tenant_id != self.tenant_id
            or self.bareme.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"bareme": "Le barème doit appartenir au même tenant."}
            )
        if self.montant is not None and self.montant <= 0:
            raise ValidationError({"montant": "Le montant doit être supérieur à zéro."})


class Facture(ObjetEducatifTenant):
    """Facture brouillon ou document émis pour une inscription."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    bareme = models.ForeignKey(
        BaremeFrais,
        on_delete=models.PROTECT,
        related_name="factures",
    )
    inscription = models.ForeignKey(
        Inscription,
        on_delete=models.PROTECT,
        related_name="factures",
    )
    numero = models.CharField(max_length=32, blank=True)
    annee_sequence = models.PositiveSmallIntegerField(null=True, blank=True)
    sequence = models.PositiveIntegerField(null=True, blank=True)
    devise = models.CharField(max_length=3)
    date_echeance = models.DateField()
    date_emission = models.DateField(null=True, blank=True)
    statut = models.CharField(
        max_length=12,
        choices=StatutFacture.choices,
        default=StatutFacture.BROUILLON,
    )
    motif_annulation = models.CharField(max_length=250, blank=True)
    annulee_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-date_emission", "-cree_le")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "numero"),
                condition=~Q(numero=""),
                name="facture_tenant_numero_unique",
            ),
            models.UniqueConstraint(
                fields=("tenant", "annee_sequence", "sequence"),
                condition=Q(sequence__isnull=False),
                name="facture_tenant_sequence_unique",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutFacture.values),
                name="facture_statut_valide",
            ),
            models.CheckConstraint(
                condition=(
                    Q(
                        statut=StatutFacture.BROUILLON,
                        numero="",
                        sequence__isnull=True,
                        date_emission__isnull=True,
                    )
                    | Q(
                        statut__in=(
                            StatutFacture.EMISE,
                            StatutFacture.PARTIELLE,
                            StatutFacture.PAYEE,
                            StatutFacture.ANNULEE,
                        ),
                        numero__gt="",
                        sequence__gte=1,
                        annee_sequence__gte=1,
                        date_emission__isnull=False,
                    )
                ),
                name="facture_emission_coherente",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "statut", "date_echeance"),
                name="facture_tenant_statut_idx",
            ),
            models.Index(
                fields=("tenant", "inscription", "date_emission"),
                name="facture_tenant_insc_idx",
            ),
        ]
        verbose_name = "facture scolaire"
        verbose_name_plural = "factures scolaires"

    def __str__(self) -> str:
        return self.numero or f"Brouillon — {self.inscription_id}"

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("bareme", self.bareme if self.bareme_id else None),
            ("inscription", self.inscription if self.inscription_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if self.bareme_id and self.inscription_id:
            if (
                self.bareme.annee_academique_id
                != self.inscription.annee_academique_id
                or self.bareme.programme_id != self.inscription.programme_id
            ):
                erreurs["bareme"] = (
                    "Le barème doit correspondre au programme et à l’année de l’inscription."
                )
        if self.devise and self.bareme_id and self.devise != self.bareme.devise:
            erreurs["devise"] = "La devise de la facture doit être celle du barème."
        if erreurs:
            raise ValidationError(erreurs)


class LigneFacture(ObjetEducatifTenant):
    """Copie immuable après émission d’un poste de facture."""

    facture = models.ForeignKey(
        Facture,
        on_delete=models.CASCADE,
        related_name="lignes",
    )
    libelle = models.CharField(max_length=200)
    montant = models.DecimalField(max_digits=12, decimal_places=2)
    ordre = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ("ordre", "id")
        constraints = [
            models.CheckConstraint(
                condition=Q(montant__gt=0),
                name="ligne_facture_montant_positif",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "facture", "ordre"),
                name="ligne_facture_tenant_idx",
            ),
        ]
        verbose_name = "ligne de facture"
        verbose_name_plural = "lignes de facture"

    def __str__(self) -> str:
        return f"{self.libelle} — {self.montant}"

    def clean(self):
        super().clean()
        if self.facture_id and (
            self.facture.tenant_id != self.tenant_id
            or self.facture.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"facture": "La facture doit appartenir au même tenant."}
            )
        if self.montant is not None and self.montant <= 0:
            raise ValidationError({"montant": "Le montant doit être supérieur à zéro."})


class Paiement(ObjetEducatifTenant):
    """Encaissement manuel confirmé à sa saisie."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    montant = models.DecimalField(max_digits=12, decimal_places=2)
    devise = models.CharField(max_length=3)
    date_paiement = models.DateField()
    mode = models.CharField(max_length=12, choices=ModePaiement.choices)
    autre_mode = models.CharField(max_length=80, blank=True)
    reference = models.CharField(max_length=120, blank=True)
    confirme_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-date_paiement", "-cree_le")
        constraints = [
            models.CheckConstraint(
                condition=Q(montant__gt=0),
                name="fin_paiement_montant_pos",
            ),
            models.CheckConstraint(
                condition=Q(mode__in=ModePaiement.values),
                name="paiement_mode_valide",
            ),
            models.CheckConstraint(
                condition=(
                    ~Q(mode=ModePaiement.AUTRE)
                    | ~Q(autre_mode="")
                ),
                name="paiement_autre_mode_libelle",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "date_paiement"),
                name="paiement_tenant_date_idx",
            ),
        ]
        verbose_name = "paiement scolaire"
        verbose_name_plural = "paiements scolaires"

    def __str__(self) -> str:
        return f"{self.montant} {self.devise} — {self.date_paiement}"

    def clean(self):
        super().clean()
        if self.montant is not None and self.montant <= 0:
            raise ValidationError({"montant": "Le montant doit être supérieur à zéro."})
        if self.mode == ModePaiement.AUTRE and not self.autre_mode.strip():
            raise ValidationError(
                {"autre_mode": "Précisez le mode de paiement lorsque « Autre » est choisi."}
            )


class AllocationPaiement(ObjetEducatifTenant):
    """Part d’un paiement imputée à une facture de même devise."""

    paiement = models.ForeignKey(
        Paiement,
        on_delete=models.PROTECT,
        related_name="allocations",
    )
    facture = models.ForeignKey(
        Facture,
        on_delete=models.PROTECT,
        related_name="allocations",
    )
    montant = models.DecimalField(max_digits=12, decimal_places=2)

    class Meta:
        ordering = ("cree_le", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "paiement", "facture"),
                name="allocation_paiement_facture_unique",
            ),
            models.CheckConstraint(
                condition=Q(montant__gt=0),
                name="allocation_montant_positif",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "facture"),
                name="allocation_tenant_fact_idx",
            ),
        ]
        verbose_name = "allocation de paiement"
        verbose_name_plural = "allocations de paiement"

    def __str__(self) -> str:
        return f"{self.montant} — {self.facture}"

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("paiement", self.paiement if self.paiement_id else None),
            ("facture", self.facture if self.facture_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = "La référence doit appartenir au même tenant."
        if self.paiement_id and self.facture_id:
            if self.paiement.devise != self.facture.devise:
                erreurs["facture"] = (
                    "La devise de l’allocation doit correspondre au paiement."
                )
        if self.montant is not None and self.montant <= 0:
            erreurs["montant"] = "Le montant doit être supérieur à zéro."
        if erreurs:
            raise ValidationError(erreurs)


class RemboursementPaiement(ObjetEducatifTenant):
    """Remboursement manuel effectué et lié à une allocation précise."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    allocation = models.ForeignKey(
        AllocationPaiement,
        on_delete=models.PROTECT,
        related_name="remboursements",
    )
    montant = models.DecimalField(max_digits=12, decimal_places=2)
    date_remboursement = models.DateField()
    mode = models.CharField(max_length=12, choices=ModePaiement.choices)
    autre_mode = models.CharField(max_length=80, blank=True)
    reference = models.CharField(max_length=120, blank=True)
    motif = models.CharField(max_length=250)
    rembourse_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-date_remboursement", "-cree_le")
        constraints = [
            models.CheckConstraint(
                condition=Q(montant__gt=0),
                name="remboursement_montant_positif",
            ),
            models.CheckConstraint(
                condition=Q(mode__in=ModePaiement.values),
                name="remboursement_mode_valide",
            ),
            models.CheckConstraint(
                condition=(~Q(mode=ModePaiement.AUTRE) | ~Q(autre_mode="")),
                name="remboursement_autre_mode_libelle",
            ),
            models.CheckConstraint(
                condition=~Q(motif=""),
                name="remboursement_motif_requis",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "allocation", "date_remboursement"),
                name="remb_tenant_alloc_date_idx",
            ),
        ]
        verbose_name = "remboursement scolaire"
        verbose_name_plural = "remboursements scolaires"

    def __str__(self) -> str:
        return f"{self.montant} — {self.allocation_id}"

    def clean(self):
        super().clean()
        if self.allocation_id and (
            self.allocation.tenant_id != self.tenant_id
            or self.allocation.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"allocation": "L’allocation doit appartenir au même tenant."}
            )
        if self.montant is not None and self.montant <= 0:
            raise ValidationError({"montant": "Le montant doit être supérieur à zéro."})
        if not self.motif.strip():
            raise ValidationError({"motif": "Un motif est obligatoire."})
        if self.mode == ModePaiement.AUTRE and not self.autre_mode.strip():
            raise ValidationError(
                {"autre_mode": "Précisez le mode de remboursement lorsque « Autre » est choisi."}
            )


class RecuPaiement(ObjetEducatifTenant):
    """Instantané immuable du reçu d’un paiement confirmé."""

    paiement = models.OneToOneField(
        Paiement,
        on_delete=models.PROTECT,
        related_name="recu",
    )
    instantane = models.JSONField()
    emis_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-emis_le",)
        verbose_name = "reçu de paiement"
        verbose_name_plural = "reçus de paiement"

    def __str__(self) -> str:
        return f"Reçu — {self.paiement_id}"

    def clean(self):
        super().clean()
        if self.paiement_id and (
            self.paiement.tenant_id != self.tenant_id
            or self.paiement.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"paiement": "Le paiement doit appartenir au même tenant."}
            )
