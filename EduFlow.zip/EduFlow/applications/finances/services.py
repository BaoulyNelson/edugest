"""Transactions métier des barèmes, factures, paiements et remboursements."""

import uuid
from collections import defaultdict
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Sum
from django.utils import timezone

from applications.finances.models import (
    AllocationPaiement,
    BaremeFrais,
    Facture,
    LigneBaremeFrais,
    LigneFacture,
    Paiement,
    RecuPaiement,
    RemboursementPaiement,
    StatutFacture,
)
from applications.inscriptions.models import Inscription
from applications.organisations.models import EvenementAudit, Tenant


class ConflitIdempotenceFinance(Exception):
    """Une clé idempotente est réutilisée avec une autre opération."""


def _auditer(*, tenant, acteur, objet, action: str, champs: list[str], motif: str = ""):
    EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=f"finances.{action}",
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        motif=motif,
        details={"champs": sorted(champs)},
    )


def _meme_bareme(existant, *, institution, acteur, valeurs, lignes) -> bool:
    lignes_existantes = list(
        existant.lignes.order_by("ordre", "libelle").values_list(
            "libelle",
            "montant",
            "ordre",
        )
    )
    lignes_candidates = sorted(
        [
            (ligne["libelle"], ligne["montant"], ligne.get("ordre", 0))
            for ligne in lignes
        ],
        key=lambda ligne: (ligne[2], ligne[0]),
    )
    return (
        existant.institution_id == institution.pk
        and existant.cree_par_id == acteur.pk
        and existant.annee_academique_id == valeurs["annee_academique"].pk
        and existant.programme_id == valeurs["programme"].pk
        and existant.code == valeurs["code"]
        and existant.nom == valeurs["nom"]
        and existant.devise == valeurs["devise"]
        and existant.actif == valeurs["actif"]
        and lignes_existantes == lignes_candidates
    )


def creer_bareme(
    *,
    tenant,
    institution,
    acteur,
    valeurs: dict,
    lignes: list[dict],
    cle_idempotence: uuid.UUID,
) -> tuple[BaremeFrais, bool]:
    bareme = BaremeFrais(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        cle_idempotence=cle_idempotence,
        **valeurs,
    )
    bareme.full_clean(
        exclude=("cle_idempotence",),
        validate_unique=False,
        validate_constraints=False,
    )
    if not lignes:
        raise ValidationError({"lignes": "Un barème doit contenir au moins une ligne."})
    for ligne in lignes:
        objet = LigneBaremeFrais(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            bareme=bareme,
            **ligne,
        )
        objet.full_clean(
            exclude=("bareme",),
            validate_unique=False,
            validate_constraints=False,
        )

    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = BaremeFrais.objects.filter(
            cle_idempotence=cle_idempotence
        ).first()
        if existant:
            if _meme_bareme(
                existant,
                institution=institution,
                acteur=acteur,
                valeurs=valeurs,
                lignes=lignes,
            ):
                return existant, False
            raise ConflitIdempotenceFinance
        try:
            with transaction.atomic():
                bareme.save(force_insert=True)
                LigneBaremeFrais.objects.bulk_create(
                    [
                        LigneBaremeFrais(
                            tenant=tenant,
                            institution=institution,
                            cree_par=acteur,
                            bareme=bareme,
                            **ligne,
                        )
                        for ligne in lignes
                    ]
                )
        except IntegrityError as error:
            existant = BaremeFrais.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existant and _meme_bareme(
                existant,
                institution=institution,
                acteur=acteur,
                valeurs=valeurs,
                lignes=lignes,
            ):
                return existant, False
            raise ConflitIdempotenceFinance from error
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=bareme,
            action="bareme_cree",
            champs=["annee_academique", "programme", "devise", "lignes"],
        )
        return bareme, True


def modifier_bareme(
    *,
    bareme_id,
    tenant,
    institution,
    acteur,
    valeurs: dict,
    lignes: list[dict] | None = None,
) -> BaremeFrais:
    with transaction.atomic():
        bareme = BaremeFrais.objects.select_for_update().get(
            pk=bareme_id,
            tenant=tenant,
            institution=institution,
        )
        for champ, valeur in valeurs.items():
            setattr(bareme, champ, valeur)
        bareme.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        if lignes is not None:
            if not lignes:
                raise ValidationError(
                    {"lignes": "Un barème doit contenir au moins une ligne."}
                )
            for ligne in lignes:
                objet = LigneBaremeFrais(
                    tenant=tenant,
                    institution=institution,
                    cree_par=acteur,
                    bareme=bareme,
                    **ligne,
                )
                objet.full_clean(validate_unique=False, validate_constraints=False)
            bareme.lignes.all().delete()
            LigneBaremeFrais.objects.bulk_create(
                [
                    LigneBaremeFrais(
                        tenant=tenant,
                        institution=institution,
                        cree_par=acteur,
                        bareme=bareme,
                        **ligne,
                    )
                    for ligne in lignes
                ]
            )
        bareme.save(update_fields=(*valeurs.keys(), "modifie_le"))
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=bareme,
            action="bareme_modifie",
            champs=[*valeurs, *(["lignes"] if lignes is not None else [])],
        )
        return bareme


def desactiver_bareme(*, bareme_id, tenant, institution, acteur) -> BaremeFrais:
    with transaction.atomic():
        bareme = BaremeFrais.objects.select_for_update().get(
            pk=bareme_id,
            tenant=tenant,
            institution=institution,
        )
        if bareme.actif:
            bareme.actif = False
            bareme.save(update_fields=("actif", "modifie_le"))
            _auditer(
                tenant=tenant,
                acteur=acteur,
                objet=bareme,
                action="bareme_desactive",
                champs=["actif"],
            )
        return bareme


def _correspond_facture(
    facture,
    *,
    tenant,
    institution,
    acteur,
    inscription,
    bareme,
    date_echeance,
):
    return (
        facture.tenant_id == tenant.pk
        and facture.institution_id == institution.pk
        and facture.cree_par_id == acteur.pk
        and facture.inscription_id == inscription.pk
        and facture.bareme_id == bareme.pk
        and facture.date_echeance == date_echeance
    )


def creer_facture(
    *,
    tenant,
    institution,
    acteur,
    inscription_id,
    bareme_id,
    date_echeance,
    cle_idempotence: uuid.UUID,
) -> tuple[Facture, bool]:
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        inscription = Inscription.objects.select_for_update(of=("self",)).get(
            pk=inscription_id,
            tenant=tenant,
            institution=institution,
        )
        bareme = BaremeFrais.objects.select_for_update().get(
            pk=bareme_id,
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        existante = Facture.objects.filter(
            cle_idempotence=cle_idempotence
        ).first()
        if existante:
            if _correspond_facture(
                existante,
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                inscription=inscription,
                bareme=bareme,
                date_echeance=date_echeance,
            ):
                return existante, False
            raise ConflitIdempotenceFinance
        facture = Facture(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=cle_idempotence,
            bareme=bareme,
            inscription=inscription,
            devise=bareme.devise,
            date_echeance=date_echeance,
        )
        facture.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        lignes_bareme = list(bareme.lignes.order_by("ordre", "id"))
        if not lignes_bareme:
            raise ValidationError({"bareme": "Le barème ne contient aucune ligne."})
        try:
            with transaction.atomic():
                facture.save(force_insert=True)
                LigneFacture.objects.bulk_create(
                    [
                        LigneFacture(
                            tenant=tenant,
                            institution=institution,
                            cree_par=acteur,
                            facture=facture,
                            libelle=ligne.libelle,
                            montant=ligne.montant,
                            ordre=ligne.ordre,
                        )
                        for ligne in lignes_bareme
                    ]
                )
        except IntegrityError as error:
            existante = Facture.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existante and _correspond_facture(
                existante,
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                inscription=inscription,
                bareme=bareme,
                date_echeance=date_echeance,
            ):
                return existante, False
            raise ConflitIdempotenceFinance from error
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=facture,
            action="facture_brouillon_creee",
            champs=["bareme", "inscription", "date_echeance"],
        )
        return facture, True


def total_facture(facture: Facture) -> Decimal:
    return facture.lignes.aggregate(total=Sum("montant"))["total"] or Decimal("0.00")


def situation_factures(*, tenant, factures) -> dict:
    facture_ids = [facture.pk for facture in factures]
    totaux = LigneFacture.objects.filter(
        tenant=tenant,
        facture_id__in=facture_ids,
    ).values("facture_id").annotate(total=Sum("montant"))
    allocations = AllocationPaiement.objects.filter(
        tenant=tenant,
        facture_id__in=facture_ids,
    ).values("facture_id").annotate(total=Sum("montant"))
    remboursements = RemboursementPaiement.objects.filter(
        tenant=tenant,
        allocation__facture_id__in=facture_ids,
    ).values("allocation__facture_id").annotate(total=Sum("montant"))
    alloues = {ligne["facture_id"]: ligne["total"] for ligne in allocations}
    rembourses = {
        ligne["allocation__facture_id"]: ligne["total"] for ligne in remboursements
    }
    totaux_par_facture = {
        ligne["facture_id"]: ligne["total"] for ligne in totaux
    }
    return {
        facture.pk: {
            "total": totaux_par_facture.get(facture.pk, Decimal("0.00")),
            "paye": alloues.get(facture.pk, Decimal("0.00"))
            - rembourses.get(facture.pk, Decimal("0.00")),
        }
        for facture in factures
    }


def _actualiser_statut_facture(*, facture, acteur):
    if facture.statut in (StatutFacture.BROUILLON, StatutFacture.ANNULEE):
        return
    situation = situation_factures(
        tenant=facture.tenant,
        factures=[facture],
    )[facture.pk]
    if situation["paye"] >= situation["total"]:
        statut = StatutFacture.PAYEE
    elif situation["paye"] > 0:
        statut = StatutFacture.PARTIELLE
    else:
        statut = StatutFacture.EMISE
    if facture.statut != statut:
        facture.statut = statut
        facture.save(update_fields=("statut", "modifie_le"))
        _auditer(
            tenant=facture.tenant,
            acteur=acteur,
            objet=facture,
            action="statut_facture_actualise",
            champs=["statut"],
        )


def modifier_brouillon_facture(
    *,
    facture_id,
    tenant,
    institution,
    acteur,
    date_echeance,
    lignes: list[dict] | None = None,
) -> Facture:
    if lignes is not None and not lignes:
        raise ValidationError({"lignes": "Une facture doit contenir au moins une ligne."})
    with transaction.atomic():
        facture = Facture.objects.select_for_update().get(
            pk=facture_id,
            tenant=tenant,
            institution=institution,
            statut=StatutFacture.BROUILLON,
        )
        if lignes is not None:
            for ligne in lignes:
                objet = LigneFacture(
                    tenant=tenant,
                    institution=institution,
                    cree_par=acteur,
                    facture=facture,
                    **ligne,
                )
                objet.full_clean(validate_unique=False, validate_constraints=False)
        facture.date_echeance = date_echeance
        facture.save(update_fields=("date_echeance", "modifie_le"))
        if lignes is not None:
            facture.lignes.all().delete()
            LigneFacture.objects.bulk_create(
                [
                    LigneFacture(
                        tenant=tenant,
                        institution=institution,
                        cree_par=acteur,
                        facture=facture,
                        **ligne,
                    )
                    for ligne in lignes
                ]
            )
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=facture,
            action="facture_brouillon_modifiee",
            champs=["date_echeance", "lignes"],
        )
        return facture


def supprimer_brouillon_facture(*, facture_id, tenant, institution, acteur) -> None:
    with transaction.atomic():
        facture = Facture.objects.select_for_update().get(
            pk=facture_id,
            tenant=tenant,
            institution=institution,
            statut=StatutFacture.BROUILLON,
        )
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=facture,
            action="facture_brouillon_supprimee",
            champs=["facture"],
        )
        facture.delete()


def emettre_facture(*, facture_id, tenant, institution, acteur) -> tuple[Facture, bool]:
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        facture = Facture.objects.select_for_update().get(
            pk=facture_id,
            tenant=tenant,
            institution=institution,
        )
        if facture.statut != StatutFacture.BROUILLON:
            return facture, False
        if not facture.lignes.exists() or total_facture(facture) <= 0:
            raise ValidationError("Une facture doit avoir un total positif avant émission.")
        date_emission = timezone.localdate()
        annee = date_emission.year
        dernier = (
            Facture.objects.filter(
                tenant=tenant,
                annee_sequence=annee,
            )
            .order_by("-sequence")
            .values_list("sequence", flat=True)
            .first()
        )
        sequence = (dernier or 0) + 1
        facture.annee_sequence = annee
        facture.sequence = sequence
        facture.numero = f"EF-{annee}-{sequence:06d}"
        facture.date_emission = date_emission
        facture.statut = StatutFacture.EMISE
        facture.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        try:
            facture.save(
                update_fields=(
                    "annee_sequence",
                    "sequence",
                    "numero",
                    "date_emission",
                    "statut",
                    "modifie_le",
                )
            )
        except IntegrityError as error:
            raise ConflitIdempotenceFinance from error
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=facture,
            action="facture_emise",
            champs=["numero", "date_emission", "statut"],
        )
        return facture, True


def annuler_facture(
    *,
    facture_id,
    tenant,
    institution,
    acteur,
    motif: str,
) -> tuple[Facture, bool]:
    motif = motif.strip()
    if not motif:
        raise ValidationError({"motif": "Un motif d’annulation est obligatoire."})
    with transaction.atomic():
        facture = Facture.objects.select_for_update().get(
            pk=facture_id,
            tenant=tenant,
            institution=institution,
        )
        if facture.statut == StatutFacture.ANNULEE:
            return facture, False
        if facture.statut == StatutFacture.BROUILLON:
            raise ValidationError(
                "Un brouillon peut être supprimé; seule une facture émise peut être annulée."
            )
        if facture.allocations.exists():
            raise ValidationError(
                "Une facture ayant reçu une allocation ne peut pas être annulée."
            )
        facture.statut = StatutFacture.ANNULEE
        facture.motif_annulation = motif
        facture.annulee_le = timezone.now()
        facture.save(
            update_fields=("statut", "motif_annulation", "annulee_le", "modifie_le")
        )
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=facture,
            action="facture_annulee",
            champs=["statut", "annulee_le"],
            motif=motif,
        )
        return facture, True


def _normaliser_allocations(allocations):
    normalisees = sorted(
        (
            str(allocation["facture"].pk),
            allocation["montant"],
        )
        for allocation in allocations
    )
    return normalisees


def _meme_paiement(
    paiement,
    *,
    tenant,
    institution,
    acteur,
    montant,
    devise,
    date_paiement,
    mode,
    autre_mode,
    reference,
    allocations,
):
    return (
        paiement.tenant_id == tenant.pk
        and paiement.institution_id == institution.pk
        and paiement.cree_par_id == acteur.pk
        and paiement.montant == montant
        and paiement.devise == devise
        and paiement.date_paiement == date_paiement
        and paiement.mode == mode
        and paiement.autre_mode == autre_mode
        and paiement.reference == reference
        and _normaliser_allocations(
            [
                {"facture": allocation.facture, "montant": allocation.montant}
                for allocation in paiement.allocations.select_related("facture")
            ]
        )
        == allocations
    )


def creer_paiement(
    *,
    tenant,
    institution,
    acteur,
    montant: Decimal,
    devise: str,
    date_paiement,
    mode: str,
    autre_mode: str,
    reference: str,
    allocations: list[dict],
    cle_idempotence: uuid.UUID,
) -> tuple[Paiement, bool]:
    if montant <= 0:
        raise ValidationError({"montant": "Le paiement doit être supérieur à zéro."})
    if not allocations:
        raise ValidationError(
            {"allocations": "Un paiement doit être affecté à au moins une facture."}
        )
    total_allocations = sum(
        (allocation["montant"] for allocation in allocations),
        Decimal("0.00"),
    )
    if total_allocations != montant:
        raise ValidationError(
            {"allocations": "Le total alloué doit être égal au montant du paiement."}
        )
    identifiants = [allocation["facture"].pk for allocation in allocations]
    if len(identifiants) != len(set(identifiants)):
        raise ValidationError(
            {"allocations": "Une facture ne peut apparaître qu’une seule fois."}
        )
    paiement = Paiement(
        tenant=tenant,
        institution=institution,
        cree_par=acteur,
        cle_idempotence=cle_idempotence,
        montant=montant,
        devise=devise,
        date_paiement=date_paiement,
        mode=mode,
        autre_mode=autre_mode,
        reference=reference,
    )
    paiement.full_clean(
        exclude=("cle_idempotence",),
        validate_unique=False,
        validate_constraints=False,
    )
    normalisees = _normaliser_allocations(allocations)

    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = Paiement.objects.filter(
            cle_idempotence=cle_idempotence
        ).first()
        if existant:
            if _meme_paiement(
                existant,
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                montant=montant,
                devise=devise,
                date_paiement=date_paiement,
                mode=mode,
                autre_mode=autre_mode,
                reference=reference,
                allocations=normalisees,
            ):
                return existant, False
            raise ConflitIdempotenceFinance

        factures = list(
            Facture.objects.select_for_update()
            .filter(
                tenant=tenant,
                institution=institution,
                pk__in=identifiants,
            )
            .select_related("inscription__apprenant__personne")
            .order_by("pk")
        )
        par_id = {facture.pk: facture for facture in factures}
        if len(par_id) != len(identifiants):
            raise ValidationError(
                {"allocations": "Une facture n’existe pas dans le tenant actif."}
            )
        sommes = situation_factures(tenant=tenant, factures=factures)
        for allocation in allocations:
            facture = par_id[allocation["facture"].pk]
            if facture.statut not in (
                StatutFacture.EMISE,
                StatutFacture.PARTIELLE,
            ):
                raise ValidationError(
                    {"allocations": "Seules les factures émises et impayées sont recevables."}
                )
            if facture.devise != devise:
                raise ValidationError(
                    {"devise": "Le paiement et toutes ses factures doivent avoir la même devise."}
                )
            if allocation["montant"] <= 0:
                raise ValidationError(
                    {"allocations": "Chaque allocation doit être supérieure à zéro."}
                )
            if allocation["montant"] > (
                sommes[facture.pk]["total"] - sommes[facture.pk]["paye"]
            ):
                raise ValidationError(
                    {"allocations": "Une allocation ne peut pas dépasser le solde de la facture."}
                )

        try:
            with transaction.atomic():
                paiement.save(force_insert=True)
                allocations_creees = []
                for allocation in allocations:
                    facture = par_id[allocation["facture"].pk]
                    objet = AllocationPaiement(
                        tenant=tenant,
                        institution=institution,
                        cree_par=acteur,
                        paiement=paiement,
                        facture=facture,
                        montant=allocation["montant"],
                    )
                    objet.full_clean(
                        validate_unique=False,
                        validate_constraints=False,
                    )
                    objet.save(force_insert=True)
                    allocations_creees.append(objet)
                reçu_instantane = {
                    "numero": str(paiement.pk),
                    "date_paiement": date_paiement.isoformat(),
                    "montant": str(montant),
                    "devise": devise,
                    "mode": (
                        autre_mode.strip()
                        if mode == "autre"
                        else paiement.get_mode_display()
                    ),
                    "reference": reference,
                    "payeur": acteur.get_full_name() or acteur.email,
                    "allocations": [
                        {
                            "facture": facture.numero,
                            "montant": str(allocation["montant"]),
                            "apprenant": str(facture.inscription.apprenant.personne),
                        }
                        for allocation in allocations
                        for facture in [par_id[allocation["facture"].pk]]
                    ],
                }
                recu = RecuPaiement(
                    tenant=tenant,
                    institution=institution,
                    cree_par=acteur,
                    paiement=paiement,
                    instantane=reçu_instantane,
                )
                recu.full_clean(validate_unique=False, validate_constraints=False)
                recu.save(force_insert=True)
        except IntegrityError as error:
            existant = Paiement.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existant and _meme_paiement(
                existant,
                tenant=tenant,
                institution=institution,
                acteur=acteur,
                montant=montant,
                devise=devise,
                date_paiement=date_paiement,
                mode=mode,
                autre_mode=autre_mode,
                reference=reference,
                allocations=normalisees,
            ):
                return existant, False
            raise ConflitIdempotenceFinance from error
        for facture in factures:
            _actualiser_statut_facture(facture=facture, acteur=acteur)
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=paiement,
            action="paiement_confirme",
            champs=["montant", "devise", "date_paiement", "allocations"],
        )
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=recu,
            action="recu_emis",
            champs=["paiement"],
        )
        return paiement, True


def creer_remboursement(
    *,
    tenant,
    institution,
    acteur,
    cle_idempotence: uuid.UUID,
    allocation_id,
    montant: Decimal,
    date_remboursement,
    mode: str,
    autre_mode: str,
    reference: str,
    motif: str,
) -> tuple[RemboursementPaiement, bool]:
    motif = motif.strip()
    if montant <= 0:
        raise ValidationError({"montant": "Le remboursement doit être supérieur à zéro."})
    if not motif:
        raise ValidationError({"motif": "Un motif de remboursement est obligatoire."})
    with transaction.atomic():
        Tenant.objects.select_for_update().get(pk=tenant.pk)
        existant = RemboursementPaiement.objects.filter(
            cle_idempotence=cle_idempotence
        ).first()
        if existant:
            if (
                existant.tenant_id == tenant.pk
                and existant.institution_id == institution.pk
                and existant.cree_par_id == acteur.pk
                and existant.allocation_id == allocation_id
                and existant.montant == montant
                and existant.date_remboursement == date_remboursement
                and existant.mode == mode
                and existant.autre_mode == autre_mode
                and existant.reference == reference
                and existant.motif == motif
            ):
                return existant, False
            raise ConflitIdempotenceFinance
        allocation = (
            AllocationPaiement.objects.select_for_update()
            .select_related("facture")
            .get(
                pk=allocation_id,
                tenant=tenant,
                institution=institution,
            )
        )
        facture = Facture.objects.select_for_update().get(
            pk=allocation.facture_id,
            tenant=tenant,
            institution=institution,
        )
        deja_rembourse = allocation.remboursements.aggregate(
            total=Sum("montant")
        )["total"] or Decimal("0.00")
        restant = allocation.montant - deja_rembourse
        if montant > restant:
            raise ValidationError(
                {"montant": "Le remboursement dépasse le montant net de cette allocation."}
            )
        remboursement = RemboursementPaiement(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=cle_idempotence,
            allocation=allocation,
            montant=montant,
            date_remboursement=date_remboursement,
            mode=mode,
            autre_mode=autre_mode,
            reference=reference,
            motif=motif,
        )
        remboursement.full_clean(
            validate_unique=False,
            validate_constraints=False,
        )
        try:
            with transaction.atomic():
                remboursement.save(force_insert=True)
        except IntegrityError as error:
            existant = RemboursementPaiement.objects.filter(
                cle_idempotence=cle_idempotence
            ).first()
            if existant and (
                existant.tenant_id == tenant.pk
                and existant.institution_id == institution.pk
                and existant.cree_par_id == acteur.pk
                and existant.allocation_id == allocation.pk
                and existant.montant == montant
                and existant.date_remboursement == date_remboursement
                and existant.mode == mode
                and existant.autre_mode == autre_mode
                and existant.reference == reference
                and existant.motif == motif
            ):
                return existant, False
            raise ConflitIdempotenceFinance from error
        _actualiser_statut_facture(facture=facture, acteur=acteur)
        _auditer(
            tenant=tenant,
            acteur=acteur,
            objet=remboursement,
            action="remboursement_confirme",
            champs=["allocation", "montant", "date_remboursement", "mode"],
            motif=motif,
        )
        return remboursement, True


def lignes_factures(*, tenant, factures):
    par_facture = defaultdict(list)
    for ligne in LigneFacture.objects.filter(
        tenant=tenant,
        facture_id__in=[facture.pk for facture in factures],
    ).order_by("ordre", "id"):
        par_facture[ligne.facture_id].append(ligne)
    return par_facture
