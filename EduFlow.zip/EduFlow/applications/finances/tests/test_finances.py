"""Tests des parcours HTML de facturation et des reçus."""

import uuid
from datetime import date
from decimal import Decimal

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.emplois_temps.tests.factories import (
    _creer_inscription,
    _preparer_tenant,
)
from applications.finances.models import (
    BaremeFrais,
    Facture,
    Paiement,
    RecuPaiement,
    RemboursementPaiement,
    StatutFacture,
)
from applications.finances.services import (
    creer_bareme,
    creer_facture,
    creer_paiement,
    emettre_facture,
)
from applications.organisations.models import EvenementAudit

pytestmark = pytest.mark.django_db


def _client_web(utilisateur, tenant):
    utilisateur.email_verifie_le = timezone.now()
    utilisateur.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(utilisateur)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    return client


def _creer_bareme(contexte, *, code=None):
    bareme, _ = creer_bareme(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        acteur=contexte["proprietaire"],
        valeurs={
            "annee_academique": contexte["annee"],
            "programme": contexte["programme"],
            "code": code or f"frais-{contexte['tenant'].pk.hex[:8]}",
            "nom": "Frais scolaires",
            "devise": "HTG",
            "actif": True,
        },
        lignes=[{"libelle": "Scolarité", "montant": Decimal("300.00"), "ordre": 0}],
        cle_idempotence=uuid.uuid4(),
    )
    return bareme


def _creer_facture(contexte, inscription, bareme):
    facture, _ = creer_facture(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        acteur=contexte["proprietaire"],
        inscription_id=inscription.pk,
        bareme_id=bareme.pk,
        date_echeance=date(2027, 6, 30),
        cle_idempotence=uuid.uuid4(),
    )
    return facture


def test_html_finance_workflow_creates_bareme_invoice_payment_and_receipt():
    contexte = _preparer_tenant("finance-html")
    inscription = _creer_inscription(contexte)
    client = _client_web(contexte["proprietaire"], contexte["tenant"])
    url = reverse("finances_web:accueil")
    page = client.get(url)
    lignes = page.context["formset_lignes"]

    creation_bareme = client.post(
        url,
        {
            "action": "bareme",
            "cle_idempotence": str(
                page.context["formulaire_bareme"].initial["cle_idempotence"]
            ),
            "annee_academique": str(contexte["annee"].pk),
            "programme": str(contexte["programme"].pk),
            "code": "frais-annuels",
            "nom": "Frais annuels",
            "devise": "HTG",
            "actif": "on",
            "lignes-TOTAL_FORMS": str(lignes.total_form_count()),
            "lignes-INITIAL_FORMS": "0",
            "lignes-MIN_NUM_FORMS": "1",
            "lignes-MAX_NUM_FORMS": "20",
            "lignes-0-libelle": "Scolarité",
            "lignes-0-montant": "300.00",
            "lignes-0-ordre": "0",
            "lignes-1-libelle": "",
            "lignes-1-montant": "",
            "lignes-1-ordre": "",
        },
    )
    assert creation_bareme.status_code == 302, (
        creation_bareme.context["formulaire_bareme"].errors,
        creation_bareme.context["formset_lignes"].errors,
        creation_bareme.context["formset_lignes"].non_form_errors(),
    )
    bareme = BaremeFrais.objects.get(tenant=contexte["tenant"])
    bareme_url = reverse("finances_web:detail-bareme", args=(bareme.pk,))
    page_bareme = client.get(bareme_url)
    lignes_bareme = page_bareme.context["formset_lignes"]
    maj_bareme = client.post(
        bareme_url,
        {
            "action": "modifier",
            "cle_idempotence": str(
                page_bareme.context["formulaire"].initial["cle_idempotence"]
            ),
            "annee_academique": str(contexte["annee"].pk),
            "programme": str(contexte["programme"].pk),
            "code": bareme.code,
            "nom": "Frais annuels mis à jour",
            "devise": "HTG",
            "actif": "on",
            "lignes-TOTAL_FORMS": str(lignes_bareme.total_form_count()),
            "lignes-INITIAL_FORMS": str(lignes_bareme.initial_form_count()),
            "lignes-MIN_NUM_FORMS": "1",
            "lignes-MAX_NUM_FORMS": "20",
            "lignes-0-libelle": "Scolarité",
            "lignes-0-montant": "300.00",
            "lignes-0-ordre": "0",
            "lignes-1-libelle": "",
            "lignes-1-montant": "",
            "lignes-1-ordre": "",
            "lignes-2-libelle": "",
            "lignes-2-montant": "",
            "lignes-2-ordre": "",
        },
    )
    assert maj_bareme.status_code == 302
    bareme.refresh_from_db()
    assert bareme.nom == "Frais annuels mis à jour"

    facture_page = client.get(url)
    creation_facture = client.post(
        url,
        {
            "action": "facture",
            "cle_idempotence": str(
                facture_page.context["formulaire_facture"].initial["cle_idempotence"]
            ),
            "inscription": str(inscription.pk),
            "bareme": str(bareme.pk),
            "date_echeance": "2027-06-30",
        },
    )
    assert creation_facture.status_code == 302
    facture = Facture.objects.get(tenant=contexte["tenant"])
    assert facture.statut == StatutFacture.BROUILLON
    emission = client.post(
        reverse("finances_web:emettre-facture", args=(facture.pk,)),
    )
    assert emission.status_code == 302
    paiement_page = client.get(url)
    paiement = client.post(
        url,
        {
            "action": "paiement",
            "cle_idempotence": str(
                paiement_page.context["formulaire_paiement"].initial["cle_idempotence"]
            ),
            "facture": str(facture.pk),
            "montant": "300.00",
            "date_paiement": "2026-10-01",
            "mode": "especes",
            "autre_mode": "",
            "reference": "REC-HTML-1",
        },
    )

    assert paiement.status_code == 302
    facture.refresh_from_db()
    assert facture.statut == StatutFacture.PAYEE
    assert Paiement.objects.filter(tenant=contexte["tenant"]).count() == 1
    assert RecuPaiement.objects.filter(tenant=contexte["tenant"]).count() == 1
    desactivation = client.post(bareme_url, {"action": "desactiver"})
    assert desactivation.status_code == 302
    bareme.refresh_from_db()
    assert not bareme.actif


def test_html_invoice_cancellation_refund_and_receipt_are_tenant_scoped():
    contexte = _preparer_tenant("finance-html-operations")
    autre_contexte = _preparer_tenant("finance-html-other")
    inscription = _creer_inscription(contexte)
    bareme = _creer_bareme(contexte)
    client = _client_web(contexte["proprietaire"], contexte["tenant"])

    brouillon = _creer_facture(contexte, inscription, bareme)
    brouillon_url = reverse("finances_web:detail-facture", args=(brouillon.pk,))
    page_brouillon = client.get(brouillon_url)
    lignes = page_brouillon.context["formset_lignes"]
    modification = {
        "action": "modifier",
        "date_echeance": "2027-05-30",
        "lignes-TOTAL_FORMS": str(lignes.total_form_count()),
        "lignes-INITIAL_FORMS": str(lignes.initial_form_count()),
        "lignes-MIN_NUM_FORMS": "1",
        "lignes-MAX_NUM_FORMS": "20",
    }
    for index in range(lignes.total_form_count()):
        prefix = f"lignes-{index}-"
        modification.update(
            {
                f"{prefix}libelle": "Scolarité ajustée" if index == 0 else "",
                f"{prefix}montant": "320.00" if index == 0 else "",
                f"{prefix}ordre": "0" if index == 0 else "",
            }
        )
    maj = client.post(brouillon_url, modification)
    assert maj.status_code == 302
    brouillon.refresh_from_db()
    assert brouillon.date_echeance == date(2027, 5, 30)
    assert brouillon.lignes.get().libelle == "Scolarité ajustée"

    suppression = client.post(brouillon_url, {"action": "supprimer"})
    assert suppression.status_code == 302
    assert not Facture.objects.filter(pk=brouillon.pk).exists()

    a_annuler = _creer_facture(contexte, inscription, bareme)
    emettre_facture(
        facture_id=a_annuler.pk,
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        acteur=contexte["proprietaire"],
    )
    annulation = client.post(
        reverse("finances_web:detail-facture", args=(a_annuler.pk,)),
        {
            "action": "annuler",
            "motif": "Facture créée en double après vérification.",
        },
    )
    assert annulation.status_code == 302
    a_annuler.refresh_from_db()
    assert a_annuler.statut == StatutFacture.ANNULEE

    a_payer = _creer_facture(contexte, inscription, bareme)
    emettre_facture(
        facture_id=a_payer.pk,
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        acteur=contexte["proprietaire"],
    )
    paiement, _ = creer_paiement(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        acteur=contexte["proprietaire"],
        montant=Decimal("300.00"),
        devise="HTG",
        date_paiement=date(2026, 10, 1),
        mode="especes",
        autre_mode="",
        reference="REC-HTML-2",
        allocations=[{"facture": a_payer, "montant": Decimal("300.00")}],
        cle_idempotence=uuid.uuid4(),
    )
    paiement_url = reverse("finances_web:detail-paiement", args=(paiement.pk,))
    page_paiement = client.get(paiement_url)
    remboursement = client.post(
        paiement_url,
        {
            "action": "rembourser",
            "cle_idempotence": str(
                page_paiement.context["formulaire"].initial["cle_idempotence"]
            ),
            "allocation": str(paiement.allocations.get().pk),
            "montant": "25.00",
            "date_remboursement": "2026-10-02",
            "mode": "especes",
            "autre_mode": "",
            "reference": "",
            "motif": "Remboursement partiel accepté.",
        },
    )
    recu = client.get(
        reverse("finances_web:imprimer-recu", args=(paiement.pk,))
    )
    autre_client = _client_web(autre_contexte["proprietaire"], autre_contexte["tenant"])
    fuite = autre_client.get(paiement_url)

    assert page_paiement.status_code == 200
    assert remboursement.status_code == 302
    assert RemboursementPaiement.objects.filter(
        allocation__paiement=paiement,
    ).count() == 1
    assert recu.status_code == 200
    assert recu["Cache-Control"] == "private, no-store"
    assert b"Re\xc3\xa7u de paiement" in recu.content
    assert fuite.status_code == 404
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="finances.facture_annulee",
        id_objet=str(a_annuler.pk),
    ).exists()
