"""Routes HTML du module financier."""

from django.urls import path

from applications.finances.views import (
    detail_bareme_web,
    detail_facture_web,
    detail_paiement_web,
    emettre_facture_web,
    gestion_finances,
    imprimer_recu_web,
)

app_name = "finances_web"

urlpatterns = [
    path("", gestion_finances, name="accueil"),
    path("baremes/<uuid:bareme_id>/", detail_bareme_web, name="detail-bareme"),
    path(
        "factures/<uuid:facture_id>/emettre/",
        emettre_facture_web,
        name="emettre-facture",
    ),
    path("factures/<uuid:facture_id>/", detail_facture_web, name="detail-facture"),
    path("paiements/<uuid:paiement_id>/", detail_paiement_web, name="detail-paiement"),
    path(
        "paiements/<uuid:paiement_id>/recu/",
        imprimer_recu_web,
        name="imprimer-recu",
    ),
]
