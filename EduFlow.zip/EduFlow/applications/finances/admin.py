from django.contrib import admin

from applications.finances.models import (
    AllocationPaiement,
    BaremeFrais,
    Facture,
    LigneBaremeFrais,
    LigneFacture,
    Paiement,
    RecuPaiement,
    RemboursementPaiement,
)

admin.site.register(
    (
        BaremeFrais,
        LigneBaremeFrais,
        Facture,
        LigneFacture,
        Paiement,
        AllocationPaiement,
        RemboursementPaiement,
        RecuPaiement,
    )
)
