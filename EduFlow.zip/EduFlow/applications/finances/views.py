"""Vues HTML des barèmes, factures et paiements scolaires."""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods, require_POST

from applications.finances.forms import (
    AnnulerFactureForm,
    BaremeCreationForm,
    FactureCreationForm,
    FiltrePaiementsForm,
    LigneBaremeFormSet,
    LigneFactureFormSet,
    ModifierFactureForm,
    PaiementCreationForm,
    RemboursementCreationForm,
)
from applications.finances.models import (
    AllocationPaiement,
    BaremeFrais,
    Facture,
    Paiement,
    RecuPaiement,
    StatutFacture,
)
from applications.finances.services import (
    ConflitIdempotenceFinance,
    annuler_facture,
    creer_bareme,
    creer_facture,
    creer_paiement,
    creer_remboursement,
    desactiver_bareme,
    emettre_facture,
    modifier_bareme,
    modifier_brouillon_facture,
    situation_factures,
    supprimer_brouillon_facture,
)
from applications.referentiels.views import _exiger_gestion
from applications.tableau_de_bord.views import _page_privee


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def gestion_finances(request):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    tenant = workspace.tenant
    institution = tenant.institution
    action = request.POST.get("action") if request.method == "POST" else ""
    formulaires = _creer_formulaires(request, action, tenant, institution)
    if request.method == "POST":
        response = _traiter_action(request, workspace, formulaires, action)
        if response is not None:
            return response

    factures = Facture.objects.filter(
        tenant=tenant,
        institution=institution,
    ).select_related(
        "inscription__apprenant__personne",
        "bareme",
    )
    statut = request.GET.get("statut", "")
    if statut in StatutFacture.values:
        factures = factures.filter(statut=statut)
    terme = request.GET.get("q", "").strip()
    if terme:
        factures = factures.filter(
            numero__icontains=terme,
        ) | factures.filter(
            inscription__apprenant__personne__nom__icontains=terme,
        ) | factures.filter(
            inscription__apprenant__personne__prenom__icontains=terme,
        )
    factures = list(factures.order_by("-cree_le")[:50])
    situations = situation_factures(tenant=tenant, factures=factures)
    for facture in factures:
        facture.situation = situations[facture.pk]
    formulaire_filtre_paiements = FiltrePaiementsForm(
        request.GET,
        institution=institution,
    )
    paiements = Paiement.objects.filter(
        tenant=tenant,
        institution=institution,
    ).select_related("recu")
    if formulaire_filtre_paiements.is_valid():
        dates = formulaire_filtre_paiements.cleaned_data
        if dates["date_debut"]:
            paiements = paiements.filter(date_paiement__gte=dates["date_debut"])
        if dates["date_fin"]:
            paiements = paiements.filter(date_paiement__lte=dates["date_fin"])
        if dates["devise"]:
            paiements = paiements.filter(devise=dates["devise"])

    return render(
        request,
        "finances/gestion.html",
        {
            **contexte,
            **formulaires,
            "baremes": BaremeFrais.objects.filter(
                tenant=tenant,
                institution=institution,
            ).prefetch_related("lignes"),
            "factures": factures,
            "statuts_facture": StatutFacture.choices,
            "statut_selectionne": statut if statut in StatutFacture.values else "",
            "terme": terme,
            "formulaire_filtre_paiements": formulaire_filtre_paiements,
            "paiements": paiements.order_by("-date_paiement", "-cree_le")[:50],
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_bareme_web(request, bareme_id):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    tenant = workspace.tenant
    institution = tenant.institution
    bareme = get_object_or_404(
        BaremeFrais.objects.prefetch_related("lignes"),
        pk=bareme_id,
        tenant=tenant,
        institution=institution,
    )
    action = request.POST.get("action", "")
    lignes_initiales = list(
        bareme.lignes.order_by("ordre", "id").values("libelle", "montant", "ordre")
    )
    formulaire = BaremeCreationForm(
        request.POST if action == "modifier" else None,
        tenant=tenant,
        institution=institution,
        initial={
            "annee_academique": bareme.annee_academique_id,
            "programme": bareme.programme_id,
            "code": bareme.code,
            "nom": bareme.nom,
            "devise": bareme.devise,
            "actif": bareme.actif,
        },
    )
    formset_lignes = LigneBaremeFormSet(
        request.POST if action == "modifier" else None,
        initial=lignes_initiales,
        prefix="lignes",
    )
    if request.method == "POST":
        if action == "modifier":
            if formulaire.is_valid() and formset_lignes.is_valid():
                lignes = [
                    {
                        "libelle": ligne.cleaned_data["libelle"],
                        "montant": ligne.cleaned_data["montant"],
                        "ordre": ligne.cleaned_data.get("ordre") or 0,
                    }
                    for ligne in formset_lignes.forms
                    if (ligne.initial or ligne.has_changed())
                    and ligne.cleaned_data
                    and not ligne.cleaned_data.get("DELETE")
                ]
                valeurs = {
                    key: value
                    for key, value in formulaire.cleaned_data.items()
                    if key != "cle_idempotence"
                }
                try:
                    bareme = modifier_bareme(
                        bareme_id=bareme.pk,
                        tenant=tenant,
                        institution=institution,
                        acteur=request.user,
                        valeurs=valeurs,
                        lignes=lignes,
                    )
                except ValidationError as error:
                    _ajouter_erreur(formulaire, error)
                else:
                    messages.success(request, _("Le barème a été modifié."))
                    return redirect("finances_web:detail-bareme", bareme_id=bareme.pk)
        elif action == "desactiver":
            try:
                desactiver_bareme(
                    bareme_id=bareme.pk,
                    tenant=tenant,
                    institution=institution,
                    acteur=request.user,
                )
            except BaremeFrais.DoesNotExist:
                messages.error(request, _("Ce barème n’existe plus."))
            else:
                messages.success(request, _("Le barème a été désactivé."))
                return redirect("finances_web:detail-bareme", bareme_id=bareme.pk)
        elif action:
            messages.error(request, _("Action de barème inconnue."))
    return render(
        request,
        "finances/bareme_detail.html",
        {
            **contexte,
            "bareme": bareme,
            "formulaire": formulaire,
            "formset_lignes": formset_lignes,
        },
    )


def _creer_formulaires(request, action, tenant, institution):
    bind_bareme = request.POST if action == "bareme" else None
    bind_facture = request.POST if action == "facture" else None
    bind_paiement = request.POST if action == "paiement" else None
    return {
        "formulaire_bareme": BaremeCreationForm(
            bind_bareme,
            tenant=tenant,
            institution=institution,
        ),
        "formset_lignes": LigneBaremeFormSet(
            bind_bareme,
            prefix="lignes",
        ),
        "formulaire_facture": FactureCreationForm(
            bind_facture,
            tenant=tenant,
            institution=institution,
        ),
        "formulaire_paiement": PaiementCreationForm(
            bind_paiement,
            tenant=tenant,
            institution=institution,
        ),
    }


def _traiter_action(request, workspace, formulaires, action):
    tenant = workspace.tenant
    institution = tenant.institution
    if action == "bareme":
        formulaire = formulaires["formulaire_bareme"]
        formset = formulaires["formset_lignes"]
        if formulaire.is_valid() and formset.is_valid():
            lignes = [
                {
                    "libelle": ligne.cleaned_data["libelle"],
                    "montant": ligne.cleaned_data["montant"],
                    "ordre": ligne.cleaned_data.get("ordre") or 0,
                }
                for ligne in formset.forms
                if ligne.cleaned_data
                and not ligne.cleaned_data.get("DELETE")
                and ligne.has_changed()
            ]
            try:
                bareme, cree = creer_bareme(
                    tenant=tenant,
                    institution=institution,
                    acteur=request.user,
                    valeurs={
                        key: value
                        for key, value in formulaire.cleaned_data.items()
                        if key != "cle_idempotence"
                    },
                    lignes=lignes,
                    cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
                )
            except ConflitIdempotenceFinance:
                formulaire.add_error(
                    None,
                    _("Cette création entre en conflit avec un barème existant."),
                )
            except ValidationError as error:
                _ajouter_erreur(formulaire, error)
            else:
                if cree:
                    messages.success(
                        request,
                        _("Le barème %(nom)s a été créé.") % {"nom": bareme.nom},
                    )
                return redirect("finances_web:accueil")
    elif action == "facture":
        formulaire = formulaires["formulaire_facture"]
        if formulaire.is_valid():
            try:
                facture, cree = creer_facture(
                    tenant=tenant,
                    institution=institution,
                    acteur=request.user,
                    inscription_id=formulaire.cleaned_data["inscription"].pk,
                    bareme_id=formulaire.cleaned_data["bareme"].pk,
                    date_echeance=formulaire.cleaned_data["date_echeance"],
                    cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
                )
            except ConflitIdempotenceFinance:
                formulaire.add_error(
                    None,
                    _("Cette création entre en conflit avec une facture existante."),
                )
            except ValidationError as error:
                _ajouter_erreur(formulaire, error)
            else:
                if cree:
                    messages.success(request, _("La facture brouillon a été créée."))
                return redirect("finances_web:accueil")
    elif action == "paiement":
        formulaire = formulaires["formulaire_paiement"]
        if formulaire.is_valid():
            valeurs = formulaire.cleaned_data
            facture = valeurs["facture"]
            try:
                paiement, cree = creer_paiement(
                    tenant=tenant,
                    institution=institution,
                    acteur=request.user,
                    montant=valeurs["montant"],
                    devise=facture.devise,
                    date_paiement=valeurs["date_paiement"],
                    mode=valeurs["mode"],
                    autre_mode=valeurs["autre_mode"],
                    reference=valeurs["reference"],
                    allocations=[{"facture": facture, "montant": valeurs["montant"]}],
                    cle_idempotence=valeurs["cle_idempotence"],
                )
            except ConflitIdempotenceFinance:
                formulaire.add_error(
                    None,
                    _("Ce paiement entre en conflit avec une opération existante."),
                )
            except ValidationError as error:
                _ajouter_erreur(formulaire, error)
            else:
                if cree:
                    messages.success(
                        request,
                        _("Paiement de %(montant)s %(devise)s enregistré avec reçu.")
                        % {"montant": paiement.montant, "devise": paiement.devise},
                    )
                return redirect("finances_web:accueil")
    elif action:
        messages.error(request, _("Action financière inconnue."))
    return None


@login_required
@_page_privee
@require_POST
def emettre_facture_web(request, facture_id):
    workspace = _exiger_gestion(request)[0]
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    facture = get_object_or_404(
        Facture.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ),
        pk=facture_id,
    )
    try:
        emettre_facture(
            facture_id=facture.pk,
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            acteur=request.user,
        )
    except ConflitIdempotenceFinance:
        messages.error(request, _("La numérotation de la facture est en conflit. Réessayez."))
    except ValidationError as error:
        messages.error(request, " ".join(error.messages))
    else:
        messages.success(request, _("La facture a été émise."))
    return redirect("finances_web:accueil")


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_facture_web(request, facture_id):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    tenant = workspace.tenant
    facture = get_object_or_404(
        Facture.objects.select_related(
            "inscription__apprenant__personne",
            "bareme",
        ).prefetch_related("lignes", "allocations"),
        pk=facture_id,
        tenant=tenant,
        institution=tenant.institution,
    )
    action = request.POST.get("action", "")
    lignes_initiales = list(
        facture.lignes.order_by("ordre", "id").values("libelle", "montant", "ordre")
    )
    formulaire = ModifierFactureForm(
        request.POST if action == "modifier" else None,
        initial={"date_echeance": facture.date_echeance},
    )
    formset_lignes = LigneFactureFormSet(
        request.POST if action == "modifier" else None,
        initial=lignes_initiales,
        prefix="lignes",
    )
    formulaire_annulation = AnnulerFactureForm(
        request.POST if action == "annuler" else None,
    )
    if request.method == "POST":
        if action == "modifier":
            if formulaire.is_valid() and formset_lignes.is_valid():
                lignes = [
                    {
                        "libelle": ligne.cleaned_data["libelle"],
                        "montant": ligne.cleaned_data["montant"],
                        "ordre": ligne.cleaned_data.get("ordre") or 0,
                    }
                    for ligne in formset_lignes.forms
                    if (ligne.initial or ligne.has_changed())
                    and ligne.cleaned_data
                    and not ligne.cleaned_data.get("DELETE")
                ]
                try:
                    modifier_brouillon_facture(
                        facture_id=facture.pk,
                        tenant=tenant,
                        institution=tenant.institution,
                        acteur=request.user,
                        date_echeance=formulaire.cleaned_data["date_echeance"],
                        lignes=lignes,
                    )
                except ValidationError as error:
                    _ajouter_erreur(formulaire, error)
                else:
                    messages.success(request, _("Le brouillon de facture a été modifié."))
                    return redirect("finances_web:detail-facture", facture_id=facture.pk)
        elif action == "supprimer":
            try:
                supprimer_brouillon_facture(
                    facture_id=facture.pk,
                    tenant=tenant,
                    institution=tenant.institution,
                    acteur=request.user,
                )
            except ValidationError as error:
                messages.error(request, " ".join(error.messages))
            else:
                messages.success(request, _("Le brouillon de facture a été supprimé."))
                return redirect("finances_web:accueil")
        elif action == "annuler" and formulaire_annulation.is_valid():
            try:
                annuler_facture(
                    facture_id=facture.pk,
                    tenant=tenant,
                    institution=tenant.institution,
                    acteur=request.user,
                    motif=formulaire_annulation.cleaned_data["motif"],
                )
            except ValidationError as error:
                _ajouter_erreur(formulaire_annulation, error)
            else:
                messages.success(request, _("La facture a été annulée."))
                return redirect("finances_web:detail-facture", facture_id=facture.pk)
        elif action not in {"modifier", "supprimer", "annuler"}:
            messages.error(request, _("Action de facture inconnue."))

    situation = situation_factures(tenant=tenant, factures=[facture])[facture.pk]
    return render(
        request,
        "finances/facture_detail.html",
        {
            **contexte,
            "facture": facture,
            "lignes": facture.lignes.all(),
            "situation": situation,
            "solde": situation["total"] - situation["paye"],
            "formulaire": formulaire,
            "formset_lignes": formset_lignes,
            "formulaire_annulation": formulaire_annulation,
            "peut_annuler": (
                facture.statut not in (StatutFacture.BROUILLON, StatutFacture.ANNULEE)
                and not facture.allocations.exists()
            ),
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_paiement_web(request, paiement_id):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    tenant = workspace.tenant
    paiement = get_object_or_404(
        Paiement.objects.select_related("recu"),
        pk=paiement_id,
        tenant=tenant,
        institution=tenant.institution,
    )
    formulaire = RemboursementCreationForm(
        request.POST if request.POST.get("action") == "rembourser" else None,
        tenant=tenant,
        institution=tenant.institution,
        paiement=paiement,
    )
    if request.method == "POST":
        if request.POST.get("action") != "rembourser":
            formulaire.add_error(None, _("Action de paiement inconnue."))
        elif formulaire.is_valid():
            valeurs = formulaire.cleaned_data
            try:
                remboursement, cree = creer_remboursement(
                    tenant=tenant,
                    institution=paiement.institution,
                    acteur=request.user,
                    cle_idempotence=valeurs["cle_idempotence"],
                    allocation_id=valeurs["allocation"].pk,
                    montant=valeurs["montant"],
                    date_remboursement=valeurs["date_remboursement"],
                    mode=valeurs["mode"],
                    autre_mode=valeurs["autre_mode"],
                    reference=valeurs["reference"],
                    motif=valeurs["motif"],
                )
            except ConflitIdempotenceFinance:
                formulaire.add_error(
                    None,
                    _("Ce remboursement entre en conflit avec une opération existante."),
                )
            except ValidationError as error:
                _ajouter_erreur(formulaire, error)
            else:
                if cree:
                    messages.success(request, _("Le remboursement a été enregistré."))
                return redirect("finances_web:detail-paiement", paiement_id=paiement.pk)

    allocations = AllocationPaiement.objects.filter(
        tenant=tenant,
        institution=paiement.institution,
        paiement=paiement,
    ).select_related(
        "facture__inscription__apprenant__personne",
    ).prefetch_related("remboursements")
    for allocation in allocations:
        remboursements = list(allocation.remboursements.all())
        allocation.remboursements_liste = remboursements
        allocation.montant_rembourse = sum(
            (remboursement.montant for remboursement in remboursements),
            start=0,
        )
        allocation.solde_remboursable = allocation.montant - allocation.montant_rembourse
    recu = RecuPaiement.objects.filter(
        tenant=tenant,
        institution=paiement.institution,
        paiement=paiement,
    ).first()
    return render(
        request,
        "finances/paiement_detail.html",
        {
            **contexte,
            "paiement": paiement,
            "allocations": allocations,
            "formulaire": formulaire,
            "recu": recu,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET"])
def imprimer_recu_web(request, paiement_id):
    workspace, _ = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    paiement = get_object_or_404(
        Paiement.objects.filter(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
        ),
        pk=paiement_id,
    )
    recu = get_object_or_404(
        RecuPaiement.objects.filter(
            tenant=workspace.tenant,
            institution=paiement.institution,
            paiement=paiement,
        )
    )
    response = render(
        request,
        "finances/recu_paiement.html",
        {"recu": recu, "instantane": recu.instantane},
    )
    response.headers["Cache-Control"] = "private, no-store"
    response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return response


def _ajouter_erreur(formulaire, error):
    erreurs = getattr(error, "message_dict", None)
    if erreurs:
        for champ, messages_erreur in erreurs.items():
            formulaire.add_error(
                champ if champ in formulaire.fields else None,
                messages_erreur,
            )
    else:
        formulaire.add_error(None, error.messages)
