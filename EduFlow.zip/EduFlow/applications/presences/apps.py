"""Configuration du suivi des présences."""

from django.apps import AppConfig


class PresencesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.presences"
    label = "presences"
    verbose_name = "Présences"
