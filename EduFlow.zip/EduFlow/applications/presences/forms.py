"""Formulaires HTML de saisie des feuilles de présence."""

from django import forms
from django.core.exceptions import ValidationError
from django.forms import BaseFormSet, formset_factory

from applications.presences.models import StatutPresence


class FiltreDatePresenceForm(forms.Form):
    date = forms.DateField(
        label="Date des séances",
        widget=forms.DateInput(format="%Y-%m-%d", attrs={"type": "date"}),
    )


class PresenceFeuilleForm(forms.Form):
    inscription_id = forms.UUIDField(widget=forms.HiddenInput)
    statut = forms.ChoiceField(
        label="Présence",
        choices=(("", "Non renseignée"), *StatutPresence.choices),
        required=False,
    )
    motif_correction = forms.CharField(
        label="Motif de correction",
        max_length=250,
        required=False,
        widget=forms.TextInput(
            attrs={"placeholder": "Obligatoire si vous changez un statut déjà saisi"}
        ),
    )


class PresenceFeuilleBaseFormSet(BaseFormSet):
    def __init__(self, *args, inscription_ids=(), **kwargs):
        self.inscription_ids = set(inscription_ids)
        super().__init__(*args, **kwargs)

    def clean(self):
        super().clean()
        if any(self.errors):
            return

        submitted_ids = [
            form.cleaned_data["inscription_id"]
            for form in self.forms
            if "inscription_id" in form.cleaned_data
        ]
        if len(submitted_ids) != len(self.inscription_ids) or set(
            submitted_ids
        ) != self.inscription_ids:
            raise ValidationError(
                "La liste des apprenants a changé. Rechargez la feuille avant de l’enregistrer."
            )


PresenceFeuilleFormSet = formset_factory(
    PresenceFeuilleForm,
    formset=PresenceFeuilleBaseFormSet,
    extra=0,
)
