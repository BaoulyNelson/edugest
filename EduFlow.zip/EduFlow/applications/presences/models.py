"""Présences par séance et historique des corrections."""

import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.emplois_temps.models import Seance
from applications.inscriptions.models import Inscription
from applications.personnes.models import ObjetEducatifTenant
from applications.referentiels.models import Groupe, Institution


class StatutPresence(models.TextChoices):
    PRESENTE = "presente", "Présente"
    RETARD = "retard", "En retard"
    ABSENTE = "absente", "Absente"
    JUSTIFIEE = "justifiee", "Absence justifiée"


class TypeHistoriquePresence(models.TextChoices):
    SAISIE = "saisie", "Saisie initiale"
    CORRECTION = "correction", "Correction"


class Presence(ObjetEducatifTenant):
    """État de présence d’une inscription à une séance, unique par séance."""

    seance = models.ForeignKey(
        Seance,
        on_delete=models.PROTECT,
        related_name="presences",
    )
    inscription = models.ForeignKey(
        Inscription,
        on_delete=models.PROTECT,
        related_name="presences",
    )
    groupe = models.ForeignKey(
        Groupe,
        on_delete=models.PROTECT,
        related_name="presences",
    )
    statut = models.CharField(max_length=10, choices=StatutPresence.choices)

    class Meta:
        ordering = ("inscription__apprenant__personne__nom", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "seance", "inscription"),
                name="presence_seance_inscription_unique",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutPresence.values),
                name="presence_statut_valide",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "seance", "statut"),
                name="presence_tenant_seance_idx",
            ),
        ]
        verbose_name = "présence"
        verbose_name_plural = "présences"

    def __str__(self) -> str:
        return f"{self.inscription} — {self.seance.date} — {self.get_statut_display()}"

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("seance", self.seance if self.seance_id else None),
            ("inscription", self.inscription if self.inscription_id else None),
            ("groupe", self.groupe if self.groupe_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if self.seance_id and self.groupe_id:
            if self.seance.creneau.affectation.groupe_id != self.groupe_id:
                erreurs["groupe"] = "Le groupe doit correspondre au groupe de la séance."
        if self.inscription_id and self.seance_id:
            inscription = self.inscription
            if inscription.groupe_id != self.groupe_id:
                erreurs["inscription"] = "L’inscription doit appartenir au groupe de la séance."
            if inscription.date_debut > self.seance.date or (
                inscription.date_fin and inscription.date_fin < self.seance.date
            ):
                erreurs["inscription"] = (
                    "L’inscription doit couvrir la date de la séance."
                )
        if erreurs:
            raise ValidationError(erreurs)


class HistoriquePresence(models.Model):
    """Trace de présence sans copie des données personnelles de l’apprenant."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        "organisations.Tenant",
        on_delete=models.PROTECT,
        related_name="historiques_presence",
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.PROTECT,
        related_name="historiques_presence",
    )
    presence = models.ForeignKey(
        Presence,
        on_delete=models.PROTECT,
        related_name="historique",
    )
    acteur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="historiques_presence_crees",
    )
    type_operation = models.CharField(
        max_length=10,
        choices=TypeHistoriquePresence.choices,
    )
    avant = models.JSONField(default=dict, blank=True)
    apres = models.JSONField(default=dict)
    motif_correction = models.CharField(max_length=250, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("cree_le", "id")
        indexes = [
            models.Index(fields=("tenant", "presence", "cree_le"), name="hist_presence_date_idx"),
        ]
        verbose_name = "historique de présence"
        verbose_name_plural = "historiques de présence"

    def __str__(self) -> str:
        return f"{self.type_operation} — {self.presence_id}"

    @property
    def ancien_statut_display(self) -> str:
        statut = self.avant.get("statut", "")
        return dict(StatutPresence.choices).get(statut, statut)

    @property
    def nouveau_statut_display(self) -> str:
        statut = self.apres.get("statut", "")
        return dict(StatutPresence.choices).get(statut, statut)

    def clean(self):
        super().clean()
        if self.presence_id and (
            self.presence.tenant_id != self.tenant_id
            or self.presence.institution_id != self.institution_id
        ):
            raise ValidationError(
                {"presence": "La présence doit appartenir au même tenant et à la même institution."}
            )
        if (
            self.type_operation == TypeHistoriquePresence.CORRECTION
            and not self.motif_correction.strip()
        ):
            raise ValidationError(
                {"motif_correction": "Un motif est obligatoire pour corriger une présence."}
            )
