from django.contrib import admin

from applications.presences.models import HistoriquePresence, Presence

admin.site.register((Presence, HistoriquePresence))
