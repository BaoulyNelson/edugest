"""Transactions de saisie et de correction des présences."""

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from applications.emplois_temps.models import Seance, StatutSeance
from applications.inscriptions.models import Inscription, StatutInscription
from applications.organisations.models import EvenementAudit
from applications.presences.models import (
    HistoriquePresence,
    Presence,
    TypeHistoriquePresence,
)


def enregistrer_presence(
    *,
    tenant,
    institution,
    seance_id,
    inscription_id,
    acteur,
    statut: str,
    motif_correction: str = "",
) -> tuple[Presence, bool]:
    with transaction.atomic():
        seance = (
            Seance.objects.select_for_update()
            .select_related("creneau__affectation")
            .get(pk=seance_id, tenant=tenant, institution=institution)
        )
        if seance.statut == StatutSeance.ANNULEE:
            raise ValidationError("Une séance annulée ne peut pas recevoir de présence.")

        inscription = (
            Inscription.objects.select_for_update(of=("self",))
            .select_related("apprenant", "groupe")
            .get(
                pk=inscription_id,
                tenant=tenant,
                institution=institution,
            )
        )
        groupe_id = seance.creneau.affectation.groupe_id
        if inscription.groupe_id != groupe_id:
            raise ValidationError(
                {"inscription": "L’inscription ne relève pas du groupe de cette séance."}
            )
        if inscription.statut != StatutInscription.ACTIVE:
            raise ValidationError(
                {"inscription": "Seule une inscription active peut recevoir une présence."}
            )
        if inscription.date_debut > seance.date or (
            inscription.date_fin and inscription.date_fin < seance.date
        ):
            raise ValidationError(
                {"inscription": "L’inscription ne couvre pas la date de cette séance."}
            )

        presence = (
            Presence.objects.select_for_update()
            .filter(
                tenant=tenant,
                seance=seance,
                inscription=inscription,
            )
            .first()
        )
        if presence is not None:
            if presence.statut == statut:
                return presence, False
            motif = motif_correction.strip()
            if not motif:
                raise ValidationError(
                    {"motif_correction": "Un motif est obligatoire pour corriger une présence."}
                )
            avant = {"statut": presence.statut}
            presence.statut = statut
            presence.save(update_fields=("statut", "modifie_le"))
            _historiser(
                presence=presence,
                acteur=acteur,
                type_operation=TypeHistoriquePresence.CORRECTION,
                avant=avant,
                apres={"statut": statut},
                motif_correction=motif,
            )
            _auditer(presence=presence, acteur=acteur, action="presence_corrigee")
            return presence, False

        presence = Presence(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            seance=seance,
            inscription=inscription,
            groupe_id=groupe_id,
            statut=statut,
        )
        presence.full_clean(validate_unique=False, validate_constraints=False)
        try:
            with transaction.atomic():
                presence.save(force_insert=True)
        except IntegrityError:
            presence = Presence.objects.get(
                tenant=tenant,
                seance=seance,
                inscription=inscription,
            )
            if presence.statut == statut:
                return presence, False
            raise
        _historiser(
            presence=presence,
            acteur=acteur,
            type_operation=TypeHistoriquePresence.SAISIE,
            avant={},
            apres={"statut": statut},
        )
        _auditer(presence=presence, acteur=acteur, action="presence_saisie")
        return presence, True


def _historiser(
    *,
    presence: Presence,
    acteur,
    type_operation: str,
    avant: dict,
    apres: dict,
    motif_correction: str = "",
) -> None:
    HistoriquePresence.objects.create(
        tenant=presence.tenant,
        institution=presence.institution,
        presence=presence,
        acteur=acteur,
        type_operation=type_operation,
        avant=avant,
        apres=apres,
        motif_correction=motif_correction,
    )


def _auditer(*, presence: Presence, acteur, action: str) -> None:
    EvenementAudit.objects.create(
        tenant=presence.tenant,
        acteur=acteur,
        action=f"presence.{action}",
        type_objet="presences.presence",
        id_objet=str(presence.pk),
        details={"champs": ["statut"]},
    )
