from django.contrib import admin

from applications.notifications.models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("titre", "destinataire", "tenant", "categorie", "cree_le", "lue_le")
    list_filter = ("categorie", "lue_le")
    search_fields = ("titre", "message", "destinataire__email", "tenant__nom")
    readonly_fields = ("cree_le",)
