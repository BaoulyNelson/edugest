"""Création contrôlée des notifications tenant-scoped."""

from applications.notifications.models import CategorieNotification, Notification
from applications.organisations.models import (
    AdhesionTenant,
    RoleAdhesion,
    StatutAdhesion,
    Tenant,
)
from applications.referentiels.models import Institution

ROLES_GESTION = {
    RoleAdhesion.PROPRIETAIRE,
    RoleAdhesion.ADMINISTRATEUR,
    RoleAdhesion.GESTIONNAIRE,
}


def creer_notification(
    *,
    tenant: Tenant,
    institution: Institution,
    destinataire,
    titre: str,
    message: str = "",
    url: str = "",
    categorie: str = CategorieNotification.SYSTEME,
    cree_par=None,
) -> Notification:
    notification = Notification(
        tenant=tenant,
        institution=institution,
        destinataire=destinataire,
        cree_par=cree_par,
        categorie=categorie,
        titre=titre,
        message=message,
        url=url,
    )
    notification.full_clean()
    notification.save(force_insert=True)
    return notification


def notifier_gestionnaires(
    *,
    tenant: Tenant,
    institution: Institution,
    titre: str,
    message: str = "",
    url: str = "",
    categorie: str = CategorieNotification.SYSTEME,
    cree_par=None,
) -> list[Notification]:
    destinataires = AdhesionTenant.objects.filter(
        tenant=tenant,
        statut=StatutAdhesion.ACTIVE,
        role__in=ROLES_GESTION,
    ).select_related("utilisateur")
    if cree_par is not None:
        destinataires = destinataires.exclude(utilisateur=cree_par)

    return [
        creer_notification(
            tenant=tenant,
            institution=institution,
            destinataire=adhesion.utilisateur,
            titre=titre,
            message=message,
            url=url,
            categorie=categorie,
            cree_par=cree_par,
        )
        for adhesion in destinataires
    ]
