import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from applications.organisations.models import (
    AdhesionTenant,
    StatutAdhesion,
    Tenant,
)
from applications.referentiels.models import Institution


class CategorieNotification(models.TextChoices):
    SYSTEME = "systeme", "Système"
    MESSAGE = "message", "Message"
    COURS = "cours", "Cours"
    DEVOIR = "devoir", "Devoir"
    EVALUATION = "evaluation", "Évaluation"
    ADMISSION = "admission", "Admission"


class Notification(models.Model):
    """Notification privée d’un utilisateur dans un établissement."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.CASCADE,
        related_name="notifications",
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name="notifications",
    )
    destinataire = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="notifications_recues",
    )
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="notifications_creees",
    )
    categorie = models.CharField(
        max_length=16,
        choices=CategorieNotification.choices,
        default=CategorieNotification.SYSTEME,
    )
    titre = models.CharField(max_length=160)
    message = models.CharField(max_length=500, blank=True)
    url = models.CharField(max_length=500, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)
    lue_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-cree_le", "-id")
        indexes = [
            models.Index(
                fields=("tenant", "destinataire", "lue_le", "cree_le"),
                name="notif_tenant_user_read_idx",
            ),
        ]
        verbose_name = "notification"
        verbose_name_plural = "notifications"

    def __str__(self):
        return f"{self.titre} — {self.destinataire}"

    def clean(self):
        super().clean()
        erreurs = {}
        if self.tenant_id and self.institution_id:
            if self.institution.tenant_id != self.tenant_id:
                erreurs["institution"] = "L’établissement doit appartenir au tenant."
        if self.destinataire_id and self.tenant_id:
            if not AdhesionTenant.objects.filter(
                tenant_id=self.tenant_id,
                utilisateur_id=self.destinataire_id,
                statut=StatutAdhesion.ACTIVE,
            ).exists():
                erreurs["destinataire"] = (
                    "Le destinataire doit avoir une adhésion active à l’établissement."
                )
        if self.url and (
            not self.url.startswith("/")
            or self.url.startswith("//")
            or "\\" in self.url
            or any(character in self.url for character in "\r\n")
        ):
            erreurs["url"] = "La destination doit être un chemin interne sûr."
        if erreurs:
            raise ValidationError(erreurs)

# Create your models here.
