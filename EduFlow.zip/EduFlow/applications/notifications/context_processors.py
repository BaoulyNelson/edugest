"""Contexte partagé du compteur de notifications non lues."""

from applications.notifications.models import Notification
from applications.organisations.access import adhesion_active_de_session


def compteur_notifications(request):
    adhesion = adhesion_active_de_session(request)
    if adhesion is None:
        return {"notifications_non_lues": 0}

    nombre = Notification.objects.filter(
        tenant=adhesion.tenant,
        destinataire=request.user,
        lue_le__isnull=True,
    ).count()
    return {"notifications_non_lues": nombre}
