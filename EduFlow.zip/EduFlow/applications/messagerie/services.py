"""Opérations métier transactionnelles de la messagerie interne."""

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.urls import reverse

from applications.messagerie.models import (
    Conversation,
    Message,
    ParticipantConversation,
)
from applications.notifications.models import CategorieNotification
from applications.notifications.services import creer_notification
from applications.organisations.models import AdhesionTenant, StatutAdhesion, Tenant
from applications.referentiels.models import Institution


def creer_ou_recuperer_conversation(
    *,
    tenant: Tenant,
    institution: Institution,
    premier_participant,
    second_participant,
) -> tuple[Conversation, bool]:
    if premier_participant.pk == second_participant.pk:
        raise ValidationError("Une conversation doit réunir deux personnes différentes.")
    if institution.tenant_id != tenant.pk:
        raise ValidationError("L’établissement doit appartenir au tenant sélectionné.")

    participant_ids = sorted(
        (str(premier_participant.pk), str(second_participant.pk))
    )
    cle_unique = f"{tenant.pk}:{participant_ids[0]}:{participant_ids[1]}"
    membres_actifs = AdhesionTenant.objects.filter(
        tenant=tenant,
        utilisateur_id__in=(premier_participant.pk, second_participant.pk),
        statut=StatutAdhesion.ACTIVE,
    ).values_list("utilisateur_id", flat=True)
    if len(set(membres_actifs)) != 2:
        raise PermissionDenied("Les deux personnes doivent être membres actifs du tenant.")

    with transaction.atomic():
        conversation, creee = Conversation.objects.get_or_create(
            cle_unique=cle_unique,
            defaults={
                "tenant": tenant,
                "institution": institution,
                "cree_par": premier_participant,
            },
        )
        if creee:
            ParticipantConversation.objects.bulk_create(
                [
                    ParticipantConversation(
                        conversation=conversation,
                        utilisateur=premier_participant,
                    ),
                    ParticipantConversation(
                        conversation=conversation,
                        utilisateur=second_participant,
                    ),
                ]
            )
    return conversation, creee


def envoyer_message(
    *,
    conversation: Conversation,
    expediteur,
    contenu: str,
) -> Message:
    texte = contenu.strip()
    if not texte:
        raise ValidationError({"contenu": "Le message ne peut pas être vide."})
    if len(texte) > 2000:
        raise ValidationError({"contenu": "Le message ne peut pas dépasser 2 000 caractères."})

    with transaction.atomic():
        participants = list(
            ParticipantConversation.objects.select_for_update()
            .filter(conversation=conversation)
            .select_related("utilisateur")
        )
        participant_ids = {participant.utilisateur_id for participant in participants}
        if expediteur.pk not in participant_ids:
            raise PermissionDenied("Vous ne participez pas à cette conversation.")
        if len(participants) != 2:
            raise ValidationError("La conversation doit avoir exactement deux participants.")
        if AdhesionTenant.objects.filter(
            tenant=conversation.tenant,
            utilisateur_id__in=participant_ids,
            statut=StatutAdhesion.ACTIVE,
        ).count() != 2:
            raise PermissionDenied("Les deux personnes doivent rester membres actifs du tenant.")

        message = Message(
            conversation=conversation,
            expediteur=expediteur,
            contenu=texte,
        )
        message.full_clean()
        message.save(force_insert=True)

        destinataire = next(
            participant.utilisateur
            for participant in participants
            if participant.utilisateur_id != expediteur.pk
        )
        creer_notification(
            tenant=conversation.tenant,
            institution=conversation.institution,
            destinataire=destinataire,
            cree_par=expediteur,
            categorie=CategorieNotification.MESSAGE,
            titre="Nouveau message",
            message=f"{expediteur.get_full_name() or expediteur.email} vous a écrit.",
            url=reverse(
                "messagerie:conversation",
                kwargs={"conversation_id": conversation.pk},
            ),
        )
    return message
