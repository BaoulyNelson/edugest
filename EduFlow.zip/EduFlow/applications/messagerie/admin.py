from django.contrib import admin

from applications.messagerie.models import (
    Conversation,
    Message,
    ParticipantConversation,
)


class ParticipantConversationInline(admin.TabularInline):
    model = ParticipantConversation
    extra = 0


class MessageInline(admin.TabularInline):
    model = Message
    extra = 0
    readonly_fields = ("cree_le",)


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ("conversation", "expediteur", "cree_le")
    search_fields = ("contenu", "expediteur__email", "conversation__tenant__nom")
    readonly_fields = ("cree_le",)


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ("id", "tenant", "cree_par", "cree_le")
    search_fields = ("tenant__nom", "cree_par__email", "messages__contenu")
    readonly_fields = ("cree_le",)
    inlines = (ParticipantConversationInline, MessageInline)


@admin.register(ParticipantConversation)
class ParticipantConversationAdmin(admin.ModelAdmin):
    list_display = ("conversation", "utilisateur", "dernier_lu_le")
    search_fields = ("utilisateur__email", "conversation__tenant__nom")
