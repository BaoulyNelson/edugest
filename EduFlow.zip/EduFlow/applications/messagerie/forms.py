"""Formulaires de la messagerie interne."""

from django import forms
from django.contrib.auth import get_user_model

from applications.organisations.models import StatutAdhesion, Tenant


class UtilisateurConversationField(forms.ModelChoiceField):
    def label_from_instance(self, utilisateur):
        return utilisateur.get_full_name() or utilisateur.email


class NouvelleConversationForm(forms.Form):
    destinataire = UtilisateurConversationField(
        queryset=get_user_model().objects.none(),
        label="Destinataire",
        empty_label="Choisir un membre",
    )

    def __init__(self, *args, tenant: Tenant, utilisateur, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["destinataire"].queryset = (
            get_user_model()
            .objects.filter(
                adhesions_tenant__tenant=tenant,
                adhesions_tenant__statut=StatutAdhesion.ACTIVE,
            )
            .exclude(pk=utilisateur.pk)
            .order_by("last_name", "first_name", "email")
            .distinct()
        )


class MessageForm(forms.Form):
    contenu = forms.CharField(
        label="Votre message",
        min_length=1,
        max_length=2000,
        strip=True,
        widget=forms.Textarea(
            attrs={
                "rows": 3,
                "placeholder": "Écrire un message…",
            }
        ),
    )
