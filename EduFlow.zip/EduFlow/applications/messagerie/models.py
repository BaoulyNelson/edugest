import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from applications.organisations.models import AdhesionTenant, StatutAdhesion, Tenant
from applications.referentiels.models import Institution


class Conversation(models.Model):
    """Conversation privée entre deux membres du même établissement."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.CASCADE,
        related_name="conversations",
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name="conversations",
    )
    cle_unique = models.CharField(max_length=300, unique=True)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="conversations_creees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-cree_le",)
        verbose_name = "conversation"
        verbose_name_plural = "conversations"

    def __str__(self):
        return f"Conversation {self.pk}"

    def clean(self):
        super().clean()
        if (
            self.tenant_id
            and self.institution_id
            and self.institution.tenant_id != self.tenant_id
        ):
            raise ValidationError(
                {"institution": "L’établissement doit appartenir au tenant."}
            )


class ParticipantConversation(models.Model):
    conversation = models.ForeignKey(
        Conversation,
        on_delete=models.CASCADE,
        related_name="participants",
    )
    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="participations_conversations",
    )
    dernier_lu_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=("conversation", "utilisateur"),
                name="conversation_participant_unique",
            ),
        ]
        verbose_name = "participant à une conversation"
        verbose_name_plural = "participants aux conversations"

    def __str__(self):
        return f"{self.utilisateur} — {self.conversation}"

    def clean(self):
        super().clean()
        if self.conversation_id and self.utilisateur_id:
            if not AdhesionTenant.objects.filter(
                tenant_id=self.conversation.tenant_id,
                utilisateur_id=self.utilisateur_id,
                statut=StatutAdhesion.ACTIVE,
            ).exists():
                raise ValidationError(
                    {"utilisateur": "Le participant doit être membre actif du tenant."}
                )


class Message(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    conversation = models.ForeignKey(
        Conversation,
        on_delete=models.CASCADE,
        related_name="messages",
    )
    expediteur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="messages_envoyes",
    )
    contenu = models.CharField(max_length=2000)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("cree_le", "id")
        indexes = [
            models.Index(
                fields=("conversation", "cree_le"),
                name="message_conversation_date_idx",
            ),
        ]
        verbose_name = "message"
        verbose_name_plural = "messages"

    def __str__(self):
        return f"Message de {self.expediteur}"

    def clean(self):
        super().clean()
        if self.conversation_id and self.expediteur_id:
            if not ParticipantConversation.objects.filter(
                conversation_id=self.conversation_id,
                utilisateur_id=self.expediteur_id,
            ).exists():
                raise ValidationError(
                    {"expediteur": "L’expéditeur doit participer à la conversation."}
                )
