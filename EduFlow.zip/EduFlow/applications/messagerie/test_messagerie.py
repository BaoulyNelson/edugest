"""Tests de la messagerie interne et de l’isolation des conversations."""

import uuid

import pytest
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.messagerie.models import Conversation, Message
from applications.notifications.models import Notification
from applications.organisations.models import (
    AdhesionTenant,
    RoleAdhesion,
    StatutAdhesion,
    StatutTenant,
    Tenant,
)
from applications.referentiels.models import Institution

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email):
    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )


def _creer_tenant(nom, proprietaire):
    tenant = Tenant.objects.create(
        nom=nom,
        statut=StatutTenant.ACTIF,
        cle_idempotence=uuid.uuid4(),
        cree_par=proprietaire,
    )
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=f"Établissement {nom}",
        type_educatif="ecole",
        cree_par=proprietaire,
    )
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=proprietaire,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    rendre_tenant_abonne(tenant, proprietaire)
    return tenant, institution


def _activer_tenant(client, tenant):
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()


def test_messages_are_private_and_generate_a_readable_notification():
    proprietaire = _creer_utilisateur("messagerie-owner@example.org")
    tenant, _ = _creer_tenant("Messagerie", proprietaire)
    destinataire = _creer_utilisateur("messagerie-destinataire@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=destinataire,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client = Client()
    client.force_login(proprietaire)
    _activer_tenant(client, tenant)

    creation = client.post(
        reverse("messagerie:nouveau"),
        {"destinataire": destinataire.pk},
    )
    conversation = Conversation.objects.get(tenant=tenant)
    envoi = client.post(
        reverse(
            "messagerie:conversation",
            kwargs={"conversation_id": conversation.pk},
        ),
        {"contenu": "Bonjour, bienvenue dans l’équipe."},
    )

    assert creation.status_code == 302
    assert creation["Location"] == reverse(
        "messagerie:conversation",
        kwargs={"conversation_id": conversation.pk},
    )
    assert envoi.status_code == 302
    assert Message.objects.filter(
        conversation=conversation,
        expediteur=proprietaire,
        contenu="Bonjour, bienvenue dans l’équipe.",
    ).exists()
    notification = Notification.objects.get(
        tenant=tenant,
        destinataire=destinataire,
        categorie="message",
    )
    assert notification.url == reverse(
        "messagerie:conversation",
        kwargs={"conversation_id": conversation.pk},
    )

    client.force_login(destinataire)
    liste = client.get(reverse("messagerie:liste"))
    assert liste.status_code == 200
    assert liste.context["messages_non_lus"] == 1
    assert "1 message non lu" in liste.content.decode()

    detail = client.get(
        reverse(
            "messagerie:conversation",
            kwargs={"conversation_id": conversation.pk},
        )
    )
    assert detail.status_code == 200
    assert "Bonjour, bienvenue dans l’équipe." in detail.content.decode()
    assert detail.context["messages_non_lus"] == 0


def test_conversation_is_not_visible_to_other_tenant_members_or_nonparticipants():
    proprietaire = _creer_utilisateur("messagerie-private-owner@example.org")
    tenant, _ = _creer_tenant("Messagerie privée", proprietaire)
    autre_tenant, _ = _creer_tenant("Autre espace", proprietaire)
    destinataire = _creer_utilisateur("messagerie-private-destinataire@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=destinataire,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    from applications.messagerie.services import creer_ou_recuperer_conversation

    conversation, _ = creer_ou_recuperer_conversation(
        tenant=tenant,
        institution=tenant.institution,
        premier_participant=proprietaire,
        second_participant=destinataire,
    )
    client = Client()
    autre_membre = _creer_utilisateur("messagerie-private-autre@example.org")
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=autre_membre,
        role=RoleAdhesion.ENSEIGNANT,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    client.force_login(autre_membre)
    _activer_tenant(client, tenant)
    non_participant = client.get(
        reverse(
            "messagerie:conversation",
            kwargs={"conversation_id": conversation.pk},
        )
    )

    client.force_login(proprietaire)
    _activer_tenant(client, autre_tenant)

    response = client.get(
        reverse(
            "messagerie:conversation",
            kwargs={"conversation_id": conversation.pk},
        )
    )

    assert non_participant.status_code == 404
    assert response.status_code == 404
