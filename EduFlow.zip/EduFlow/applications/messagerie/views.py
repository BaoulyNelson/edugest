"""Vues HTML de la messagerie tenant-scoped."""

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import OuterRef, Prefetch, Subquery
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from applications.messagerie.forms import MessageForm, NouvelleConversationForm
from applications.messagerie.models import (
    Message,
    ParticipantConversation,
)
from applications.messagerie.services import (
    creer_ou_recuperer_conversation,
    envoyer_message,
)
from applications.tableau_de_bord.views import _exiger_espace, _page_privee


@login_required
@_page_privee
@require_http_methods(["GET"])
def liste_conversations(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    dernier_message = Message.objects.filter(
        conversation_id=OuterRef("conversation_id")
    ).order_by("-cree_le", "-id")
    participations = (
        ParticipantConversation.objects.filter(
            conversation__tenant=workspace.tenant,
            conversation__institution=workspace.tenant.institution,
            utilisateur=request.user,
        )
        .annotate(
            dernier_message_le=Subquery(dernier_message.values("cree_le")[:1]),
            dernier_message_contenu=Subquery(dernier_message.values("contenu")[:1]),
        )
        .select_related("conversation")
        .prefetch_related(
            Prefetch(
                "conversation__participants",
                queryset=ParticipantConversation.objects.select_related("utilisateur"),
                to_attr="participants_prefetch",
            )
        )
        .order_by("-dernier_message_le", "-conversation__cree_le")
    )
    for participation in participations:
        autres = [
            participant
            for participant in participation.conversation.participants_prefetch
            if participant.utilisateur_id != request.user.pk
        ]
        if len(autres) != 1:
            raise PermissionDenied("La conversation n’a pas deux participants valides.")
        participation.autre_participant = autres[0]

    return render(
        request,
        "messagerie/liste.html",
        {
            **contexte,
            "participations": participations,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def nouvelle_conversation(request):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    formulaire = NouvelleConversationForm(
        request.POST if request.method == "POST" else None,
        tenant=workspace.tenant,
        utilisateur=request.user,
    )
    if request.method == "POST" and formulaire.is_valid():
        conversation, _ = creer_ou_recuperer_conversation(
            tenant=workspace.tenant,
            institution=workspace.tenant.institution,
            premier_participant=request.user,
            second_participant=formulaire.cleaned_data["destinataire"],
        )
        return redirect(
            "messagerie:conversation",
            conversation_id=conversation.pk,
        )

    return render(
        request,
        "messagerie/nouvelle_conversation.html",
        {
            **contexte,
            "formulaire": formulaire,
            "a_des_destinataires": formulaire.fields["destinataire"].queryset.exists(),
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_conversation(request, conversation_id):
    workspace, contexte = _exiger_espace(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")

    participation = get_object_or_404(
        ParticipantConversation.objects.select_related(
            "conversation",
            "conversation__tenant",
            "conversation__institution",
        ).filter(
            conversation__tenant=workspace.tenant,
            conversation__institution=workspace.tenant.institution,
            conversation_id=conversation_id,
            utilisateur=request.user,
        )
    )
    autres = list(
        participation.conversation.participants.select_related("utilisateur").exclude(
            utilisateur=request.user
        )
    )
    if len(autres) != 1:
        raise PermissionDenied("La conversation n’a pas deux participants valides.")
    autre_participant = autres[0]

    formulaire = MessageForm(
        request.POST if request.method == "POST" else None
    )
    if request.method == "POST" and formulaire.is_valid():
        envoyer_message(
            conversation=participation.conversation,
            expediteur=request.user,
            contenu=formulaire.cleaned_data["contenu"],
        )
        return redirect(
            "messagerie:conversation",
            conversation_id=participation.conversation_id,
        )

    participation.dernier_lu_le = timezone.now()
    participation.save(update_fields=("dernier_lu_le",))
    derniers_messages = list(
        Message.objects.filter(conversation=participation.conversation)
        .select_related("expediteur")
        .order_by("-cree_le", "-id")[:100]
    )
    derniers_messages.reverse()

    return render(
        request,
        "messagerie/conversation.html",
        {
            **contexte,
            "participation": participation,
            "autre_participant": autre_participant,
            "messages_conversation": derniers_messages,
            "formulaire": formulaire,
        },
    )
