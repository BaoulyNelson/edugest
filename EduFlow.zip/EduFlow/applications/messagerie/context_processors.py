"""Contexte partagé du compteur de messages non lus."""

from django.db.models import Count, F, Q

from applications.messagerie.models import ParticipantConversation
from applications.organisations.access import adhesion_active_de_session


def compteur_messages(request):
    adhesion = adhesion_active_de_session(request)
    if adhesion is None:
        return {"messages_non_lus": 0}

    non_lus_par_conversation = (
        ParticipantConversation.objects.filter(
            conversation__tenant=adhesion.tenant,
            utilisateur=request.user,
        )
        .annotate(
            nombre=Count(
                "conversation__messages",
                filter=(
                    Q(dernier_lu_le__isnull=True)
                    | Q(conversation__messages__cree_le__gt=F("dernier_lu_le"))
                )
                & ~Q(conversation__messages__expediteur=request.user),
                distinct=True,
            )
        )
        .values_list("nombre", flat=True)
    )
    return {
        "messages_non_lus": sum(non_lus_par_conversation),
    }
