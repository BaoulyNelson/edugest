"""Routes HTML de la messagerie."""

from django.urls import path

from applications.messagerie.views import (
    detail_conversation,
    liste_conversations,
    nouvelle_conversation,
)

app_name = "messagerie"

urlpatterns = [
    path("espace/messages/", liste_conversations, name="liste"),
    path("espace/messages/nouveau/", nouvelle_conversation, name="nouveau"),
    path(
        "espace/messages/<uuid:conversation_id>/",
        detail_conversation,
        name="conversation",
    ),
]
