"""Tests des parcours HTML d’admission et d’inscription."""

import uuid

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.admissions.models import Candidature, StatutCandidature
from applications.emplois_temps.tests.factories import _preparer_tenant
from applications.inscriptions.models import HistoriqueInscription, Inscription, StatutInscription
from applications.organisations.models import EvenementAudit
from applications.personnes.models import ProfilApprenant

pytestmark = pytest.mark.django_db


def _client_web(utilisateur, tenant):
    utilisateur.email_verifie_le = timezone.now()
    utilisateur.save(update_fields=("email_verifie_le",))
    client = Client()
    client.force_login(utilisateur)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()
    return client


def test_admission_form_updates_draft_and_creates_learner_on_acceptance():
    contexte = _preparer_tenant("admission-web")
    client = _client_web(contexte["proprietaire"], contexte["tenant"])
    create_url = reverse("tableau_de_bord:creer-candidature")

    page = client.get(create_url)
    creation = client.post(
        create_url,
        {
            "cle_idempotence": str(page.context["form"].initial["cle_idempotence"]),
            "prenom": "Mika",
            "nom": "Apprenant",
            "date_naissance": "",
            "courriel": "mika@example.org",
            "telephone": "",
            "identifiant_externe": "eleve-001",
            "annee_academique": str(contexte["annee"].pk),
            "programme": str(contexte["programme"].pk),
        },
    )
    candidature = Candidature.objects.get(tenant=contexte["tenant"])
    detail_url = reverse(
        "tableau_de_bord:detail-candidature",
        args=(candidature.pk,),
    )
    detail = client.get(detail_url)
    modification = client.post(
        detail_url,
        {
            "prenom": "Mikaël",
            "nom": "Apprenant",
            "date_naissance": "",
            "courriel": "mikael@example.org",
            "telephone": "",
            "identifiant_externe": "eleve-001",
            "annee_academique": str(contexte["annee"].pk),
            "programme": str(contexte["programme"].pk),
        },
    )
    transitions = []
    for statut in (
        StatutCandidature.SOUMISE,
        StatutCandidature.EN_EXAMEN,
        StatutCandidature.ADMISE,
    ):
        response = client.post(
            reverse(
                "tableau_de_bord:transition-candidature",
                args=(candidature.pk, statut),
            ),
            {"confirmation": "oui"},
        )
        transitions.append(response)

    candidature.refresh_from_db()
    assert page.status_code == 200
    assert creation.status_code == 302
    assert detail.status_code == 200
    assert modification.status_code == 302
    assert all(response.status_code == 302 for response in transitions)
    assert candidature.personne.prenom == "Mikaël"
    assert candidature.statut == StatutCandidature.ADMISE
    assert ProfilApprenant.objects.filter(
        tenant=contexte["tenant"],
        personne=candidature.personne,
    ).exists()
    assert EvenementAudit.objects.filter(
        tenant=contexte["tenant"],
        action="admission.candidature_transitionnee",
        id_objet=str(candidature.pk),
    ).exists()


def test_admitted_candidate_can_be_enrolled_and_status_history_is_kept():
    contexte = _preparer_tenant("enrollment-web")
    client = _client_web(contexte["proprietaire"], contexte["tenant"])
    candidature = Candidature.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        reference="ADM-WEB-001",
        personne=contexte["profil"].personne,
        annee_academique=contexte["annee"],
        programme=contexte["programme"],
        statut=StatutCandidature.ADMISE,
        decidee_par=contexte["proprietaire"],
        decidee_le=timezone.now(),
    )
    ProfilApprenant.objects.create(
        tenant=contexte["tenant"],
        institution=contexte["institution"],
        cree_par=contexte["proprietaire"],
        personne=candidature.personne,
    )
    url = reverse("inscriptions_web:gestion")
    page = client.get(url)
    creation = client.post(
        url,
        {
            "cle_idempotence": str(uuid.uuid4()),
            "candidature": str(candidature.pk),
            "groupe": str(contexte["groupe"].pk),
            "date_debut": "2026-09-01",
        },
    )
    assert creation.status_code == 302, creation.context["form"].errors
    inscription = Inscription.objects.get(candidature=candidature)
    detail_url = reverse("inscriptions_web:detail", args=(inscription.pk,))
    detail = client.get(detail_url)
    changement = client.post(
        detail_url,
        {
            "action": "statut",
            "statut": StatutInscription.INTERROMPUE,
            "date_effet": "2026-10-01",
        },
    )

    inscription.refresh_from_db()
    assert page.status_code == 200
    assert creation.status_code == 302
    assert detail.status_code == 200
    assert changement.status_code == 302
    assert inscription.statut == StatutInscription.INTERROMPUE
    assert HistoriqueInscription.objects.filter(
        inscription=inscription,
        type_operation="statut",
        date_effet="2026-10-01",
    ).exists()
