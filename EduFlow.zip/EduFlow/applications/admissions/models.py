"""Candidatures tenant-scoped et décisions d’admission."""

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.personnes.models import ObjetEducatifTenant, Personne
from applications.referentiels.models import AnneeAcademique, Programme


class StatutCandidature(models.TextChoices):
    BROUILLON = "brouillon", "Brouillon"
    SOUMISE = "soumise", "Soumise"
    EN_EXAMEN = "en_examen", "À l’étude"
    ADMISE = "admise", "Admise"
    REFUSEE = "refusee", "Refusée"
    RETIREE = "retiree", "Retirée"


class Candidature(ObjetEducatifTenant):
    """Demande d’admission liée à une personne et à un parcours ciblé."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    reference = models.CharField(max_length=40)
    personne = models.ForeignKey(
        Personne,
        on_delete=models.PROTECT,
        related_name="candidatures",
    )
    annee_academique = models.ForeignKey(
        AnneeAcademique,
        on_delete=models.PROTECT,
        related_name="candidatures",
    )
    programme = models.ForeignKey(
        Programme,
        on_delete=models.PROTECT,
        related_name="candidatures",
    )
    statut = models.CharField(
        max_length=12,
        choices=StatutCandidature.choices,
        default=StatutCandidature.BROUILLON,
    )
    decidee_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="candidatures_decidees",
    )
    decidee_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-cree_le", "reference")
        constraints = [
            models.UniqueConstraint(
                fields=("tenant", "reference"),
                name="candidature_tenant_reference_unique",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutCandidature.values),
                name="candidature_statut_valide",
            ),
            models.CheckConstraint(
                condition=(
                    Q(
                        statut__in=(StatutCandidature.ADMISE, StatutCandidature.REFUSEE),
                        decidee_par__isnull=False,
                        decidee_le__isnull=False,
                    )
                    | (
                        ~Q(statut__in=(StatutCandidature.ADMISE, StatutCandidature.REFUSEE))
                        & Q(decidee_par__isnull=True, decidee_le__isnull=True)
                    )
                ),
                name="candidature_decision_coherente",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "statut", "cree_le"),
                name="candidature_tenant_statut_idx",
            ),
        ]
        verbose_name = "candidature"
        verbose_name_plural = "candidatures"

    def __str__(self) -> str:
        return self.reference

    def clean(self):
        super().clean()
        erreurs = {}
        for champ, objet in (
            ("personne", self.personne if self.personne_id else None),
            ("annee_academique", self.annee_academique if self.annee_academique_id else None),
            ("programme", self.programme if self.programme_id else None),
        ):
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if erreurs:
            raise ValidationError(erreurs)
