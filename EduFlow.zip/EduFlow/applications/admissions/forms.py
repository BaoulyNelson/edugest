"""Formulaires Django pour le traitement des candidatures."""

import uuid

from django import forms

from applications.admissions.models import StatutCandidature
from applications.admissions.services import TRANSITIONS_CANDIDATURE
from applications.referentiels.models import AnneeAcademique, Programme


class CandidatureCreationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    prenom = forms.CharField(max_length=100, label="Prénom")
    nom = forms.CharField(max_length=100, label="Nom")
    date_naissance = forms.DateField(
        required=False,
        label="Date de naissance",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    courriel = forms.EmailField(required=False, label="Adresse e-mail")
    telephone = forms.CharField(max_length=30, required=False, label="Téléphone")
    identifiant_externe = forms.CharField(
        max_length=80,
        required=False,
        label="Identifiant externe",
        help_text="Facultatif ; il doit être unique dans cet établissement.",
    )
    annee_academique = forms.ModelChoiceField(
        queryset=AnneeAcademique.objects.none(),
        label="Année académique",
        empty_label="Sélectionner une année",
    )
    programme = forms.ModelChoiceField(
        queryset=Programme.objects.none(),
        label="Programme",
        empty_label="Sélectionner un programme",
    )

    def __init__(self, *args, tenant, institution, **kwargs):
        initial = kwargs.pop("initial", {})
        initial.setdefault("cle_idempotence", uuid.uuid4())
        super().__init__(*args, initial=initial, **kwargs)
        self.tenant = tenant
        self.institution = institution
        self.fields["annee_academique"].queryset = AnneeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
        )
        self.fields["programme"].queryset = Programme.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean_cle_idempotence(self):
        return self.cleaned_data["cle_idempotence"]

    def identite(self):
        return {
            champ: self.cleaned_data[champ]
            for champ in (
                "prenom",
                "nom",
                "date_naissance",
                "courriel",
                "telephone",
                "identifiant_externe",
            )
        }


class CandidatureModificationForm(forms.Form):
    prenom = forms.CharField(max_length=100, label="Prénom")
    nom = forms.CharField(max_length=100, label="Nom")
    date_naissance = forms.DateField(
        required=False,
        label="Date de naissance",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    courriel = forms.EmailField(required=False, label="Adresse e-mail")
    telephone = forms.CharField(max_length=30, required=False, label="Téléphone")
    identifiant_externe = forms.CharField(
        max_length=80,
        required=False,
        label="Identifiant externe",
        help_text="Facultatif ; il doit être unique dans cet établissement.",
    )
    annee_academique = forms.ModelChoiceField(
        queryset=AnneeAcademique.objects.none(),
        label="Année académique",
    )
    programme = forms.ModelChoiceField(
        queryset=Programme.objects.none(),
        label="Programme",
    )

    def __init__(self, *args, tenant, institution, candidature, **kwargs):
        initial = {
            "prenom": candidature.personne.prenom,
            "nom": candidature.personne.nom,
            "date_naissance": candidature.personne.date_naissance,
            "courriel": candidature.personne.courriel,
            "telephone": candidature.personne.telephone,
            "identifiant_externe": candidature.personne.identifiant_externe,
            "annee_academique": candidature.annee_academique_id,
            "programme": candidature.programme_id,
        }
        initial.update(kwargs.pop("initial", {}))
        super().__init__(*args, initial=initial, **kwargs)
        self.fields["annee_academique"].queryset = AnneeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
        )
        self.fields["programme"].queryset = Programme.objects.filter(
            tenant=tenant,
            institution=institution,
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class CandidatureImportForm(forms.Form):
    fichier_csv = forms.FileField(
        label="Fichier CSV",
        help_text=(
            "UTF-8, maximum 1 Mio et 500 lignes. "
            "Colonnes : prenom, nom, date_naissance, courriel, telephone, "
            "identifiant_externe. La date doit suivre le format AAAA-MM-JJ."
        ),
    )
    annee_academique = forms.ModelChoiceField(
        queryset=AnneeAcademique.objects.none(),
        label="Année académique",
        empty_label="Sélectionner une année",
    )
    programme = forms.ModelChoiceField(
        queryset=Programme.objects.none(),
        label="Programme",
        empty_label="Sélectionner un programme",
    )

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["annee_academique"].queryset = AnneeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
        )
        self.fields["programme"].queryset = Programme.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean_fichier_csv(self):
        fichier = self.cleaned_data["fichier_csv"]
        if fichier.size > 1024 * 1024:
            raise forms.ValidationError("Le fichier ne peut pas dépasser 1 Mio.")
        return fichier


class CandidatureImportRowForm(forms.Form):
    prenom = forms.CharField(max_length=100)
    nom = forms.CharField(max_length=100)
    date_naissance = forms.DateField(
        required=False,
        input_formats=("%Y-%m-%d",),
    )
    courriel = forms.EmailField(required=False)
    telephone = forms.CharField(max_length=30, required=False)
    identifiant_externe = forms.CharField(max_length=80, required=False)


class TransitionCandidatureForm(forms.Form):
    confirmation = forms.ChoiceField(
        choices=(("oui", "Confirmer"),),
        initial="oui",
        widget=forms.HiddenInput,
    )


LIBELLES_TRANSITION_CANDIDATURE = {
    StatutCandidature.SOUMISE: "Soumettre",
    StatutCandidature.EN_EXAMEN: "Mettre à l’étude",
    StatutCandidature.ADMISE: "Admettre",
    StatutCandidature.REFUSEE: "Refuser",
    StatutCandidature.RETIREE: "Retirer",
}

ORDRE_TRANSITIONS_CANDIDATURE = (
    StatutCandidature.SOUMISE,
    StatutCandidature.EN_EXAMEN,
    StatutCandidature.ADMISE,
    StatutCandidature.REFUSEE,
    StatutCandidature.RETIREE,
)

TRANSITIONS_CANDIDATURE_WEB = {
    statut: tuple(
        (cible, LIBELLES_TRANSITION_CANDIDATURE[cible])
        for cible in ORDRE_TRANSITIONS_CANDIDATURE
        if cible in cibles
    )
    for statut, cibles in TRANSITIONS_CANDIDATURE.items()
}
