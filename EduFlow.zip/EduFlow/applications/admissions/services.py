"""Transactions métier des candidatures et décisions d’admission."""

import uuid

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.utils import timezone

from applications.admissions.models import Candidature, StatutCandidature
from applications.notifications.models import CategorieNotification
from applications.notifications.services import notifier_gestionnaires
from applications.organisations.models import EvenementAudit, Tenant
from applications.personnes.models import Personne, ProfilApprenant
from applications.referentiels.models import Institution


class ConflitIdempotenceAdmission(Exception):
    """Une clé d’idempotence de candidature a été réutilisée incohéremment."""


class ConflitIdentifiantExterneAdmission(Exception):
    """Un identifiant externe est déjà utilisé dans le tenant."""


TRANSITIONS_CANDIDATURE = {
    StatutCandidature.BROUILLON: {
        StatutCandidature.SOUMISE,
        StatutCandidature.RETIREE,
    },
    StatutCandidature.SOUMISE: {
        StatutCandidature.EN_EXAMEN,
        StatutCandidature.RETIREE,
    },
    StatutCandidature.EN_EXAMEN: {
        StatutCandidature.ADMISE,
        StatutCandidature.REFUSEE,
        StatutCandidature.RETIREE,
    },
    StatutCandidature.ADMISE: {StatutCandidature.RETIREE},
    StatutCandidature.REFUSEE: set(),
    StatutCandidature.RETIREE: set(),
}


def _journaliser(*, tenant: Tenant, acteur, objet, action: str, champs: list[str]):
    return EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=f"admission.{action}",
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        details={"champs": sorted(champs)},
    )


def _normaliser_identite(identite: dict) -> dict:
    donnees = dict(identite)
    if "identifiant_externe" in donnees:
        donnees["identifiant_externe"] = donnees["identifiant_externe"].strip().upper()
    if "courriel" in donnees:
        donnees["courriel"] = donnees["courriel"].strip().lower()
    if "telephone" in donnees:
        donnees["telephone"] = donnees["telephone"].strip()
    return donnees


def _sauvegarder_personne_modifiee(personne: Personne) -> None:
    try:
        with transaction.atomic():
            personne.save()
    except IntegrityError as error:
        doublon = (
            personne.identifiant_externe
            and Personne.objects.filter(
                tenant_id=personne.tenant_id,
                identifiant_externe=personne.identifiant_externe,
            )
            .exclude(pk=personne.pk)
            .exists()
        )
        if doublon:
            raise ConflitIdentifiantExterneAdmission from error
        raise


def creer_candidature(
    *,
    tenant: Tenant,
    institution: Institution,
    acteur,
    identite: dict,
    annee_academique,
    programme,
    cle_idempotence: uuid.UUID,
) -> tuple[Candidature, bool]:
    identite = _normaliser_identite(identite)
    identite = {
        "prenom": identite["prenom"],
        "nom": identite["nom"],
        "date_naissance": identite.get("date_naissance"),
        "courriel": identite.get("courriel", ""),
        "telephone": identite.get("telephone", ""),
        "identifiant_externe": identite.get("identifiant_externe", ""),
    }
    if (
        institution.tenant_id != tenant.pk
        or annee_academique.tenant_id != tenant.pk
        or annee_academique.institution_id != institution.pk
        or programme.tenant_id != tenant.pk
        or programme.institution_id != institution.pk
    ):
        raise ValidationError("Les références doivent appartenir au tenant actif.")

    with transaction.atomic():
        existant = (
            Candidature.objects.select_for_update()
            .select_related("personne", "annee_academique", "programme")
            .filter(cle_idempotence=cle_idempotence)
            .first()
        )
        if existant is not None:
            if not _correspond(existant, identite, annee_academique, programme, acteur):
                raise ConflitIdempotenceAdmission
            return existant, False

        personne = Personne(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=uuid.uuid4(),
            **identite,
        )
        personne.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        candidature = Candidature(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=cle_idempotence,
            reference=f"ADM-{uuid.uuid4().hex.upper()}",
            personne=personne,
            annee_academique=annee_academique,
            programme=programme,
        )
        candidature.full_clean(
            exclude=("cle_idempotence", "personne"),
            validate_unique=False,
            validate_constraints=False,
        )
        try:
            with transaction.atomic():
                personne.save(force_insert=True)
                candidature.save(force_insert=True)
        except IntegrityError as error:
            existant = (
                Candidature.objects.select_related("personne", "annee_academique", "programme")
                .filter(cle_idempotence=cle_idempotence)
                .first()
            )
            if existant is not None and _correspond(
                existant,
                identite,
                annee_academique,
                programme,
                acteur,
            ):
                return existant, False
            if identite["identifiant_externe"] and Personne.objects.filter(
                tenant_id=tenant.pk,
                identifiant_externe=identite["identifiant_externe"],
            ).exists():
                raise ConflitIdentifiantExterneAdmission from error
            raise ConflitIdempotenceAdmission from error

        _journaliser(
            tenant=tenant,
            acteur=acteur,
            objet=candidature,
            action="candidature_creee",
            champs=[*identite, "annee_academique", "programme"],
        )
        return candidature, True


def _correspond(candidature, identite, annee_academique, programme, acteur) -> bool:
    return (
        candidature.cree_par_id == acteur.pk
        and candidature.annee_academique_id == annee_academique.pk
        and candidature.programme_id == programme.pk
        and all(
            getattr(candidature.personne, champ) == valeur
            for champ, valeur in identite.items()
        )
    )


def modifier_candidature_brouillon(
    *,
    candidature_id,
    tenant: Tenant,
    acteur,
    modifications: dict,
) -> Candidature:
    modifications = dict(modifications)
    champs_personne = {
        champ: valeur
        for champ, valeur in modifications.items()
        if champ
        in {
            "prenom",
            "nom",
            "date_naissance",
            "courriel",
            "telephone",
            "identifiant_externe",
        }
    }
    champs_candidature = {
        champ: valeur
        for champ, valeur in modifications.items()
        if champ in {"annee_academique", "programme"}
    }
    champs_personne = _normaliser_identite(champs_personne)

    with transaction.atomic():
        candidature = (
            Candidature.objects.select_for_update()
            .select_related("personne", "annee_academique", "programme")
            .get(pk=candidature_id, tenant=tenant)
        )
        if candidature.statut != StatutCandidature.BROUILLON:
            raise ValidationError("Seule une candidature brouillon peut être modifiée.")
        for champ, valeur in champs_personne.items():
            setattr(candidature.personne, champ, valeur)
        for champ, valeur in champs_candidature.items():
            setattr(candidature, champ, valeur)
        candidature.personne.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        candidature.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        if (
            candidature.personne.identifiant_externe
            and Personne.objects.filter(
                tenant=tenant,
                identifiant_externe=candidature.personne.identifiant_externe,
            )
            .exclude(pk=candidature.personne_id)
            .exists()
        ):
            raise ConflitIdentifiantExterneAdmission
        _sauvegarder_personne_modifiee(candidature.personne)
        candidature.save()
        _journaliser(
            tenant=tenant,
            acteur=acteur,
            objet=candidature,
            action="candidature_modifiee",
            champs=list(modifications),
        )
        return candidature


def modifier_profil_apprenant(
    *,
    profil_id,
    tenant: Tenant,
    acteur,
    modifications: dict,
) -> ProfilApprenant:
    modifications = _normaliser_identite(modifications)
    with transaction.atomic():
        profil = (
            ProfilApprenant.objects.select_for_update()
            .select_related("personne")
            .get(pk=profil_id, tenant=tenant)
        )
        for champ, valeur in modifications.items():
            setattr(profil.personne, champ, valeur)
        profil.personne.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        if (
            profil.personne.identifiant_externe
            and Personne.objects.filter(
                tenant=tenant,
                identifiant_externe=profil.personne.identifiant_externe,
            )
            .exclude(pk=profil.personne_id)
            .exists()
        ):
            raise ConflitIdentifiantExterneAdmission
        _sauvegarder_personne_modifiee(profil.personne)
        _journaliser(
            tenant=tenant,
            acteur=acteur,
            objet=profil,
            action="profil_apprenant_modifie",
            champs=list(modifications),
        )
        return profil


def transitionner_candidature(
    *,
    candidature_id,
    tenant: Tenant,
    acteur,
    nouveau_statut: str,
) -> Candidature:
    with transaction.atomic():
        candidature = (
            Candidature.objects.select_for_update()
            .select_related("personne", "institution")
            .get(pk=candidature_id, tenant=tenant)
        )
        if nouveau_statut == candidature.statut:
            return candidature
        if nouveau_statut not in TRANSITIONS_CANDIDATURE[candidature.statut]:
            raise ValidationError("Cette transition de candidature n’est pas autorisée.")

        if nouveau_statut == StatutCandidature.ADMISE:
            profil, cree = ProfilApprenant.objects.get_or_create(
                tenant=candidature.tenant,
                personne=candidature.personne,
                defaults={
                    "institution": candidature.institution,
                    "cree_par": acteur,
                },
            )
            if not cree and profil.institution_id != candidature.institution_id:
                raise ValidationError("Le profil apprenant appartient à une autre institution.")
            if cree:
                _journaliser(
                    tenant=tenant,
                    acteur=acteur,
                    objet=profil,
                    action="profil_apprenant_cree",
                    champs=["personne"],
                )
            candidature.decidee_par = acteur
            candidature.decidee_le = timezone.now()
        elif nouveau_statut == StatutCandidature.REFUSEE:
            candidature.decidee_par = acteur
            candidature.decidee_le = timezone.now()
        candidature.statut = nouveau_statut
        candidature.save(update_fields=("statut", "decidee_par", "decidee_le", "modifie_le"))
        _journaliser(
            tenant=tenant,
            acteur=acteur,
            objet=candidature,
            action="candidature_transitionnee",
            champs=["statut"],
        )
        if nouveau_statut == StatutCandidature.SOUMISE:
            notifier_gestionnaires(
                tenant=tenant,
                institution=candidature.institution,
                titre="Nouvelle candidature à traiter",
                message=(
                    f"{candidature.personne} · {candidature.reference}"
                ),
                url="/espace/candidatures/",
                categorie=CategorieNotification.ADMISSION,
                cree_par=acteur,
            )
        return candidature
