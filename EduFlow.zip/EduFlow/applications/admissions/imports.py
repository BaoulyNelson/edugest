"""Import CSV borné des candidatures via les services métier."""

import csv
import hashlib
import io
import uuid
from collections import Counter

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models.functions import Upper

from applications.admissions.forms import CandidatureImportRowForm
from applications.admissions.models import Candidature
from applications.admissions.services import (
    ConflitIdempotenceAdmission,
    ConflitIdentifiantExterneAdmission,
    creer_candidature,
)
from applications.organisations.models import EvenementAudit
from applications.personnes.models import Personne

ENTETES_CSV = (
    "prenom",
    "nom",
    "date_naissance",
    "courriel",
    "telephone",
    "identifiant_externe",
)
MAX_LIGNES_CSV = 500
ESPACE_NOM_IDEMPOTENCE = uuid.UUID("da27270d-9774-44fc-bfe7-663bb9c39d64")


class ErreurImportCandidatures(Exception):
    """Le fichier est invalide ou au moins une candidature ne peut être importée."""

    def __init__(self, erreurs):
        self.erreurs = erreurs
        super().__init__("Le fichier CSV contient des erreurs.")


def _lire_lignes(contenu):
    try:
        texte = contenu.decode("utf-8-sig")
    except UnicodeDecodeError as erreur:
        raise ErreurImportCandidatures(
            ["Le fichier doit être encodé en UTF-8."]
        ) from erreur

    lecteur = csv.DictReader(io.StringIO(texte, newline=""))
    entetes = lecteur.fieldnames or []
    if len(entetes) != len(set(entetes)):
        raise ErreurImportCandidatures(["Le fichier contient des colonnes en double."])
    manquantes = {"prenom", "nom"} - set(entetes)
    inconnues = set(entetes) - set(ENTETES_CSV)
    if manquantes or inconnues:
        details = []
        if manquantes:
            details.append(f"Colonnes obligatoires manquantes : {', '.join(sorted(manquantes))}.")
        if inconnues:
            details.append(f"Colonnes inconnues : {', '.join(sorted(inconnues))}.")
        raise ErreurImportCandidatures(details)

    lignes = []
    erreurs = []
    for numero, ligne in enumerate(lecteur, start=2):
        if ligne is None:
            continue
        if None in ligne:
            erreurs.append(f"Ligne {numero} : trop de valeurs pour les colonnes déclarées.")
            continue
        if all(not (valeur or "").strip() for valeur in ligne.values()):
            continue
        donnees = {
            entete: (ligne.get(entete) or "").strip()
            for entete in ENTETES_CSV
        }
        formulaire = CandidatureImportRowForm(donnees)
        if not formulaire.is_valid():
            erreurs.append(
                f"Ligne {numero} : "
                + " ".join(
                    f"{champ} : {', '.join(messages)}"
                    for champ, messages in formulaire.errors.items()
                )
            )
            continue
        lignes.append((numero, formulaire.cleaned_data))
        if len(lignes) > MAX_LIGNES_CSV:
            raise ErreurImportCandidatures(
                [f"Le fichier ne peut pas contenir plus de {MAX_LIGNES_CSV} lignes."]
            )
    if not lignes and not erreurs:
        erreurs.append("Le fichier ne contient aucune candidature.")
    if erreurs:
        raise ErreurImportCandidatures(erreurs)
    return lignes


def importer_candidatures_csv(
    *,
    contenu,
    tenant,
    institution,
    acteur,
    annee_academique,
    programme,
):
    lignes = _lire_lignes(contenu)
    empreinte = hashlib.sha256(contenu).hexdigest()
    cles_idempotence = {
        numero: uuid.uuid5(
            ESPACE_NOM_IDEMPOTENCE,
            f"{tenant.pk}:{acteur.pk}:{empreinte}:{numero}",
        )
        for numero, _ in lignes
    }
    identifiants = [
        donnees["identifiant_externe"].strip().upper()
        for _, donnees in lignes
        if donnees["identifiant_externe"].strip()
    ]
    doublons_fichier = {
        identifiant
        for identifiant, nombre in Counter(identifiants).items()
        if nombre > 1
    }
    if doublons_fichier:
        raise ErreurImportCandidatures(
            [
                "Identifiants externes répétés dans le fichier : "
                + ", ".join(sorted(doublons_fichier))
                + "."
            ]
        )

    candidatures_existantes = dict(
        Candidature.objects.filter(
            tenant=tenant,
            cle_idempotence__in=cles_idempotence.values(),
        ).values_list("cle_idempotence", "personne__identifiant_externe")
    )
    identifiants_reprises = {
        identifiant.strip().upper()
        for identifiant in candidatures_existantes.values()
        if identifiant
    }
    identifiants_existants = set(
        Personne.objects.filter(tenant=tenant)
        .exclude(identifiant_externe="")
        .annotate(identifiant_normalise=Upper("identifiant_externe"))
        .filter(identifiant_normalise__in=identifiants)
        .values_list("identifiant_normalise", flat=True)
    ) - identifiants_reprises
    if identifiants_existants:
        raise ErreurImportCandidatures(
            [
                "Identifiants externes déjà utilisés dans cet établissement : "
                + ", ".join(sorted(identifiants_existants))
                + "."
            ]
        )

    creees = 0
    reprises = 0
    try:
        with transaction.atomic():
            for numero, identite in lignes:
                try:
                    _, creee = creer_candidature(
                        tenant=tenant,
                        institution=institution,
                        acteur=acteur,
                        identite=identite,
                        annee_academique=annee_academique,
                        programme=programme,
                        cle_idempotence=cles_idempotence[numero],
                    )
                except (
                    ConflitIdempotenceAdmission,
                    ConflitIdentifiantExterneAdmission,
                    ValidationError,
                ) as erreur:
                    raise ErreurImportCandidatures(
                        [f"Ligne {numero} : la candidature ne peut pas être créée."]
                    ) from erreur
                creees += int(creee)
                reprises += int(not creee)

            EvenementAudit.objects.create(
                tenant=tenant,
                acteur=acteur,
                action="admission.candidatures_importees",
                type_objet=Candidature._meta.label_lower,
                id_objet="csv",
                details={
                    "lignes": len(lignes),
                    "candidatures_creees": creees,
                    "candidatures_reprises": reprises,
                    "format": "csv",
                },
            )
    except ErreurImportCandidatures:
        raise

    return {
        "lignes": len(lignes),
        "creees": creees,
        "reprises": reprises,
    }
