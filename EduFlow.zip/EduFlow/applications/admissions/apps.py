"""Configuration du processus d’admission."""

from django.apps import AppConfig


class AdmissionsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.admissions"
    label = "admissions"
    verbose_name = "Admissions"
