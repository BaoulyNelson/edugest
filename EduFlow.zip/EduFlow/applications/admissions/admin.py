from django.contrib import admin

from applications.admissions.models import Candidature

admin.site.register(Candidature)
