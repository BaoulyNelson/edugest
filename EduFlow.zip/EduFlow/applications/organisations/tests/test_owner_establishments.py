"""Tests de visibilité et d’isolation des établissements du propriétaire."""

import io
import uuid

import pytest
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client
from django.urls import reverse
from django.utils import timezone
from PIL import Image

from applications.abonnements.models import PlanSaaS
from applications.organisations.models import (
    AdhesionTenant,
    DemandeInscriptionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
    StatutDemandeInscription,
    StatutTenant,
    Tenant,
)
from applications.referentiels.models import Institution

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email):
    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )


def _creer_etablissement(proprietaire, nom):
    tenant = Tenant.objects.create(
        nom=nom,
        statut=StatutTenant.ACTIF,
        cle_idempotence=uuid.uuid4(),
        cree_par=proprietaire,
    )
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=f"École {nom}",
        type_educatif="ecole_classique",
        cree_par=proprietaire,
    )
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=proprietaire,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    return tenant, institution


def _image_png(nom):
    contenu = io.BytesIO()
    Image.new("RGB", (2, 2), color="blue").save(contenu, format="PNG")
    return SimpleUploadedFile(nom, contenu.getvalue(), content_type="image/png")


def test_owner_lists_all_owned_establishments_and_pending_signup_but_not_foreign_tenants():
    proprietaire = _creer_utilisateur("owner-establishments@example.org")
    tenant_1, institution_1 = _creer_etablissement(proprietaire, "Alpha")
    tenant_2, _ = _creer_etablissement(proprietaire, "Beta")
    tenant_etranger, _ = _creer_etablissement(
        _creer_utilisateur("other-owner-establishments@example.org"),
        "Étranger",
    )
    plan = PlanSaaS.objects.create(
        cle_idempotence=uuid.uuid4(),
        code="starter-owner-list",
        nom="Starter",
        prix_mensuel="2500.00",
        devise="HTG",
        actif=True,
        cree_par=proprietaire,
    )
    tenant_en_attente = Tenant.objects.create(
        nom="Demande en préparation",
        statut=StatutTenant.DEMANDE,
        cle_idempotence=uuid.uuid4(),
        cree_par=proprietaire,
    )
    DemandeInscriptionTenant.objects.create(
        tenant=tenant_en_attente,
        compte=proprietaire,
        plan=plan,
        type_educatif="ecole_classique",
        pays="HT",
        telephone="+509 3700 0000",
        effectif_apprenants=100,
        statut=StatutDemandeInscription.EN_ATTENTE,
        empreinte_jeton=uuid.uuid4().hex + uuid.uuid4().hex,
        jeton_expire_le=timezone.now(),
        email_verifie_le=timezone.now(),
    )

    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant_1.pk)
    session.save()

    response = client.get(reverse("parcours_tenant:mes-etablissements"))

    contenu = response.content.decode()
    assert response.status_code == 200
    assert response["Referrer-Policy"] == "same-origin"
    assert response.context["nombre_etablissements"] == 3
    assert "École Alpha" in contenu
    assert "École Beta" in contenu
    assert "Demande en préparation" in contenu
    assert "Étranger" not in contenu
    assert response.context["nombre_en_preparation"] == 1
    assert str(tenant_1.pk) in contenu
    assert str(tenant_2.pk) in contenu
    assert str(tenant_etranger.pk) not in contenu
    assert institution_1.nom in contenu
    assert f'href="{reverse("parcours_tenant:mes-etablissements")}"' in contenu
    assert f'href="{reverse("parcours_tenant:inscription")}"' in contenu
    assert "sidebar-tenant" in contenu


def test_owner_can_open_only_their_own_establishment_profile():
    proprietaire = _creer_utilisateur("owner-profile@example.org")
    tenant, institution = _creer_etablissement(proprietaire, "Profil")
    autre_proprietaire = _creer_utilisateur("other-owner-profile@example.org")
    tenant_etranger, _ = _creer_etablissement(autre_proprietaire, "Privé")
    client = Client()
    client.force_login(proprietaire)

    profil = client.get(reverse("parcours_tenant:profil-etablissement", args=(tenant.pk,)))
    refuse = client.get(reverse("parcours_tenant:profil-etablissement", args=(tenant_etranger.pk,)))

    assert profil.status_code == 200
    assert institution.nom in profil.content.decode()
    assert "Informations générales" in profil.content.decode()
    assert "Enregistrer les modifications" in profil.content.decode()
    assert "Complétude" in profil.content.decode()
    assert "Configuration académique" in profil.content.decode()
    assert institution.slug in profil.content.decode()
    assert f'href="{reverse("parcours_tenant:mes-etablissements")}"' in profil.content.decode()
    assert refuse.status_code == 404


def test_active_owner_can_edit_establishment_from_its_profile():
    proprietaire = _creer_utilisateur("owner-edit-profile@example.org")
    tenant, institution = _creer_etablissement(proprietaire, "À modifier")
    client = Client()
    client.force_login(proprietaire)
    url = reverse("parcours_tenant:profil-etablissement", args=(tenant.pk,))

    page = client.get(url)
    response = client.post(
        url,
        {
            "nom": "École mise à jour",
            "type_educatif": "universite",
            "pays": "HT",
            "langue": "fr",
            "devise_principale": "HTG",
            "couleur_principale": "#2563EB",
            "devises_secondaires": "USD, CAD",
            "fuseau_horaire": "America/Port-au-Prince",
            "format_date": "YYYY-MM-DD",
            "indicatif_telephonique": "+509",
        },
    )

    assert page.status_code == 200
    assert "Informations générales" in page.content.decode()
    assert "Enregistrer les modifications" in page.content.decode()
    assert response.status_code == 302
    assert response["Location"] == url
    institution.refresh_from_db()
    assert institution.nom == "École mise à jour"
    assert institution.type_educatif == "universite"
    assert institution.format_date == "YYYY-MM-DD"
    assert institution.devises_secondaires == ["USD", "CAD"]
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        acteur=proprietaire,
        action="referentiel.modifie",
        type_objet="referentiels.institution",
        id_objet=str(institution.pk),
    ).exists()


def test_owner_can_save_profile_fields_and_images(tmp_path, settings):
    proprietaire = _creer_utilisateur("owner-full-profile@example.org")
    tenant, institution = _creer_etablissement(proprietaire, "Profil complet")
    client = Client()
    client.force_login(proprietaire)
    url = reverse("parcours_tenant:profil-etablissement", args=(tenant.pk,))
    settings.MEDIA_ROOT = tmp_path

    response = client.post(
        url,
        {
            "nom": "École des sciences",
            "nom_court": "EDS",
            "type_educatif": "ecole_classique",
            "code_officiel": "MENFP-042",
            "annee_fondation": "1998",
            "responsable": "Marie Jean",
            "slogan": "Apprendre pour demain",
            "pays": "HT",
            "adresse": "12, rue des Écoles",
            "departement": "Ouest",
            "commune": "Port-au-Prince",
            "telephone": "+509 3700 0000",
            "email_officiel": "contact@ecole.example",
            "site_web": "https://ecole.example",
            "couleur_principale": "#336699",
            "langue": "fr",
            "devise_principale": "HTG",
            "devises_secondaires": "USD",
            "fuseau_horaire": "America/Port-au-Prince",
            "format_date": "DD/MM/YYYY",
            "indicatif_telephonique": "+509",
            "logo": _image_png("logo.png"),
            "banniere": _image_png("banniere.png"),
            "signature": _image_png("signature.png"),
        },
    )

    assert response.status_code == 302
    institution.refresh_from_db()
    assert institution.nom_court == "EDS"
    assert institution.code_officiel == "MENFP-042"
    assert institution.annee_fondation == 1998
    assert institution.responsable == "Marie Jean"
    assert institution.adresse == "12, rue des Écoles"
    assert institution.departement == "Ouest"
    assert institution.commune == "Port-au-Prince"
    assert institution.email_officiel == "contact@ecole.example"
    assert institution.site_web == "https://ecole.example"
    assert institution.couleur_principale == "#336699"
    assert institution.logo.name.startswith(f"institutions/{tenant.pk}/logos/")
    assert institution.banniere.name.startswith(f"institutions/{tenant.pk}/bannieres/")
    assert institution.signature.name.startswith(f"institutions/{tenant.pk}/signatures/")
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        acteur=proprietaire,
        action="referentiel.modifie",
        details__champs__contains=["logo", "banniere", "signature"],
    ).exists()


def test_owner_cannot_save_invalid_image_or_future_founding_year():
    proprietaire = _creer_utilisateur("owner-invalid-profile@example.org")
    tenant, institution = _creer_etablissement(proprietaire, "Profil invalide")
    client = Client()
    client.force_login(proprietaire)
    url = reverse("parcours_tenant:profil-etablissement", args=(tenant.pk,))

    response = client.post(
        url,
        {
            "nom": "Profil invalide",
            "nom_court": "",
            "type_educatif": "ecole_classique",
            "code_officiel": "",
            "annee_fondation": str(timezone.localdate().year + 1),
            "responsable": "",
            "slogan": "",
            "pays": "HT",
            "adresse": "",
            "departement": "",
            "commune": "",
            "telephone": "",
            "email_officiel": "",
            "site_web": "",
            "couleur_principale": "#2563EB",
            "langue": "fr",
            "devise_principale": "HTG",
            "devises_secondaires": "",
            "fuseau_horaire": "America/Port-au-Prince",
            "format_date": "DD/MM/YYYY",
            "indicatif_telephonique": "+509",
            "logo": SimpleUploadedFile(
                "pas-une-image.png",
                b"not an image",
                content_type="image/png",
            ),
        },
    )

    assert response.status_code == 200
    assert response.context["formulaire"].errors["logo"]
    assert response.context["formulaire"].errors["annee_fondation"]
    institution.refresh_from_db()
    assert institution.nom == "École Profil invalide"
    assert not institution.logo


def test_account_without_owned_establishments_sees_empty_owner_page():
    utilisateur = _creer_utilisateur("empty-owner@example.org")
    client = Client()
    client.force_login(utilisateur)

    response = client.get(reverse("parcours_tenant:mes-etablissements"))

    assert response.status_code == 200
    assert response.context["nombre_etablissements"] == 0
    assert "Aucun établissement pour le moment" in response.content.decode()


def test_owner_without_active_subscription_can_reach_establishment_directory():
    proprietaire = _creer_utilisateur("owner-without-subscription@example.org")
    tenant, _ = _creer_etablissement(proprietaire, "Sans abonnement")
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()

    dashboard = client.get(reverse("tableau_de_bord:accueil"))

    contenu = dashboard.content.decode()
    assert dashboard.status_code == 200
    assert dashboard.context["workspace_accessible"] is False
    assert f'href="{reverse("parcours_tenant:mes-etablissements")}"' in contenu
    assert "Mes établissements" in contenu
