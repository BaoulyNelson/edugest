"""Tests des invitations à usage unique et des permissions RBAC."""

import re
from datetime import timedelta
from smtplib import SMTPException
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse

import pytest
from django.core import mail
from django.core.exceptions import ValidationError
from django.test import Client, override_settings
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.organisations.models import (
    AdhesionTenant,
    InvitationTenant,
    RoleAdhesion,
    StatutInvitation,
)
from applications.organisations.services import (
    accepter_invitation,
    creer_invitation,
    provisionner_tenant,
    transitionner_tenant,
)

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email: str):
    from django.contrib.auth import get_user_model

    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )


def _creer_tenant(proprietaire):
    import uuid

    return provisionner_tenant(
        createur=proprietaire,
        nom="École Alpha",
        cle_idempotence=uuid.uuid4(),
    )


@override_settings(
    MAILERS={"default": {"BACKEND": "django.core.mail.backends.locmem.EmailBackend"}},
    DEFAULT_FROM_EMAIL="EduFlow <noreply@example.org>",
    EDUFLOW_BASE_URL="http://testserver",
)
def test_owner_can_invite_and_email_contains_single_use_token():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire)
    rendre_tenant_abonne(tenant, proprietaire)
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()

    response = client.post(
        reverse("parcours_tenant:equipe"),
        {
            "action": "inviter",
            "email": "NOUVEAU@EXAMPLE.ORG",
            "role": RoleAdhesion.ENSEIGNANT,
        },
    )

    assert response.status_code == 302
    assert len(mail.outbox) == 1
    url = re.search(r"https?://\S+", mail.outbox[0].body).group()
    token = parse_qs(urlparse(url).query)["jeton"][0]
    invitation = InvitationTenant.objects.get(email="nouveau@example.org")
    assert invitation.empreinte_jeton != token
    assert invitation.statut == StatutInvitation.EN_ATTENTE
    assert client.get("/api/v1/tenants/invitations/").status_code == 404


def test_member_cannot_manage_team_or_view_another_tenant():
    proprietaire_a = _creer_utilisateur("owner-a@example.org")
    proprietaire_b = _creer_utilisateur("owner-b@example.org")
    membre_a = _creer_utilisateur("member-a@example.org")
    tenant_a, _, _ = _creer_tenant(proprietaire_a)
    tenant_b, _, _ = _creer_tenant(proprietaire_b)
    rendre_tenant_abonne(tenant_a, proprietaire_a)
    rendre_tenant_abonne(tenant_b, proprietaire_b)
    adhesion = AdhesionTenant.objects.create(
        tenant=tenant_a,
        utilisateur=membre_a,
        role=RoleAdhesion.MEMBRE,
        statut="active",
        cree_par=proprietaire_a,
    )
    client = Client()
    client.force_login(membre_a)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant_a.pk)
    session.save()

    acces_refuse = client.get(reverse("parcours_tenant:equipe"))
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant_b.pk)
    session.save()
    autre_tenant = client.get(reverse("parcours_tenant:equipe"))

    assert acces_refuse.status_code == 403
    assert autre_tenant.status_code == 404
    assert adhesion.pk is not None


@override_settings(
    MAILERS={"default": {"BACKEND": "django.core.mail.backends.locmem.EmailBackend"}},
    DEFAULT_FROM_EMAIL="EduFlow <noreply@example.org>",
    EDUFLOW_BASE_URL="http://testserver",
)
def test_invitation_link_creates_verified_account_and_active_membership():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire)
    invitation, token = creer_invitation(
        tenant=tenant,
        invite_par=proprietaire,
        email="apprenant@example.org",
        role=RoleAdhesion.ENSEIGNANT,
    )
    accept_url = f"{reverse('parcours_tenant:accepter-invitation')}?jeton={token}"
    client = Client(enforce_csrf_checks=True)

    page = client.get(accept_url)
    assert "Rejoindre" in page.content.decode()
    assert "invitation-form" in page.content.decode()
    assert 'name="robots" content="noindex, nofollow"' in page.content.decode()
    assert "/static/js/password-toggle.js" in page.content.decode()
    assert "/static/css/password-toggle.css" in page.content.decode()
    csrf_token = re.search(
        r'name="csrfmiddlewaretoken" value="([^"]+)"',
        page.content.decode(),
    ).group(1)
    response = client.post(
        reverse("parcours_tenant:accepter-invitation"),
        {
            "jeton": token,
            "mot_de_passe": "mot-de-passe-solide",
            "confirmation_mot_de_passe": "ne-correspond-pas",
        },
        HTTP_X_CSRFTOKEN=csrf_token,
    )
    assert response.status_code == 400
    assert b"ne correspondent pas" in response.content

    response = client.post(
        reverse("parcours_tenant:accepter-invitation"),
        {
            "jeton": token,
            "mot_de_passe": "mot-de-passe-solide",
            "confirmation_mot_de_passe": "mot-de-passe-solide",
            "csrfmiddlewaretoken": csrf_token,
        },
        HTTP_X_CSRFTOKEN=csrf_token,
    )

    from django.contrib.auth import get_user_model

    compte = get_user_model().objects.get(email="apprenant@example.org")
    adhesion = AdhesionTenant.objects.get(tenant=tenant, utilisateur=compte)
    invitation.refresh_from_db()
    assert page.status_code == 200
    assert response.status_code == 200
    assert "no-store" in response["Cache-Control"]
    assert invitation.statut == StatutInvitation.ACCEPTEE
    assert compte.email_verifie_le is not None
    assert compte.check_password("mot-de-passe-solide")
    assert adhesion.role == RoleAdhesion.ENSEIGNANT


def test_invitation_token_cannot_be_reused():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire)
    invitation, token = creer_invitation(
        tenant=tenant,
        invite_par=proprietaire,
        email="apprenant@example.org",
        role=RoleAdhesion.MEMBRE,
    )

    compte, created = accepter_invitation(jeton=token, mot_de_passe="mot-de-passe-solide")
    meme_compte, reused = accepter_invitation(jeton=token)
    invitation.refresh_from_db()

    assert created is True
    assert reused is False
    assert meme_compte.pk == compte.pk
    assert invitation.statut == StatutInvitation.ACCEPTEE


def test_invitation_get_requires_token_and_post_requires_csrf():
    client = Client(enforce_csrf_checks=True)

    response = client.post(
        reverse("parcours_tenant:accepter-invitation"),
        {"jeton": "invalid"},
    )

    assert response.status_code == 403


def test_expired_invitation_is_marked_expired_when_accepted():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire)
    invitation, token = creer_invitation(
        tenant=tenant,
        invite_par=proprietaire,
        email="apprenant@example.org",
        role=RoleAdhesion.MEMBRE,
    )
    invitation.expire_le = timezone.now() - timedelta(seconds=1)
    invitation.save(update_fields=("expire_le",))

    with pytest.raises(ValidationError, match="invalide ou expirée"):
        accepter_invitation(jeton=token)

    invitation.refresh_from_db()
    assert invitation.statut == StatutInvitation.EXPIREE


def test_invitation_cannot_be_accepted_after_tenant_suspension():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire)
    invitation, token = creer_invitation(
        tenant=tenant,
        invite_par=proprietaire,
        email="apprenant@example.org",
        role=RoleAdhesion.MEMBRE,
    )
    transitionner_tenant(
        tenant.pk,
        "suspendu",
        acteur=proprietaire,
        motif="Incident.",
    )

    with pytest.raises(ValidationError, match="n’accepte plus"):
        accepter_invitation(jeton=token, mot_de_passe="mot-de-passe-solide")

    invitation.refresh_from_db()
    assert invitation.statut == StatutInvitation.EN_ATTENTE


@override_settings(
    MAILERS={"default": {"BACKEND": "django.core.mail.backends.locmem.EmailBackend"}},
    DEFAULT_FROM_EMAIL="EduFlow <noreply@example.org>",
    EDUFLOW_BASE_URL="http://testserver",
)
def test_email_delivery_failure_revokes_invitation_and_returns_service_error():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire)
    rendre_tenant_abonne(tenant, proprietaire)
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant.pk)
    session.save()

    with patch(
        "applications.organisations.views.send_mail",
        side_effect=SMTPException("SMTP indisponible"),
    ):
        response = client.post(
            reverse("parcours_tenant:equipe"),
            {
                "action": "inviter",
                "email": "nouveau@example.org",
                "role": RoleAdhesion.MEMBRE,
            },
        )

    invitation = InvitationTenant.objects.get(email="nouveau@example.org")
    assert response.status_code == 200
    assert "n’a pas pu être distribué" in response.content.decode()
    assert invitation.statut == StatutInvitation.REVOQUEE
