"""Tests du site public et du parcours de demande d’inscription tenant."""

import re
import uuid
from datetime import timedelta
from decimal import Decimal
from urllib.parse import urlparse

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core import mail
from django.core.exceptions import ValidationError
from django.test import Client, override_settings
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.models import DroitUsage
from applications.abonnements.services import (
    abonnement_actif_pour_tenant,
    creer_abonnement,
    decider_evenement_paiement,
    enregistrer_paiement,
)
from applications.organisations.models import (
    AdhesionTenant,
    DemandeInscriptionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
    StatutDemandeInscription,
    StatutTenant,
    Tenant,
)
from applications.organisations.services import (
    creer_demande_inscription_tenant,
    traiter_demande_inscription_tenant,
    transitionner_tenant,
    verifier_email_demande_inscription,
)
from applications.referentiels.models import Institution

pytestmark = pytest.mark.django_db

MOT_DE_PASSE = "T3nant-P@ssphrase-Solide-83!"
MAILERS_LOCAL = {"default": {"BACKEND": "django.core.mail.backends.locmem.EmailBackend"}}


def _creer_utilisateur(email="operateur@example.org"):
    return get_user_model().objects.create_superuser(email, "Mot-de-passe-admin-solide-82!")


def _creer_plan(
    acteur,
    *,
    code="essentiel",
    nom="Forfait Essentiel",
    actif=True,
    prix_mensuel=None,
):
    from applications.abonnements.models import PlanSaaS

    plan = PlanSaaS.objects.create(
        cle_idempotence=uuid.uuid4(),
        code=code,
        nom=nom,
        description="Pour les besoins essentiels de votre établissement.",
        actif=actif,
        prix_mensuel=(
            None
            if code.casefold() == "gratuit" and prix_mensuel is None
            else prix_mensuel or Decimal("100.00")
        ),
        devise="HTG",
        cree_par=acteur,
    )
    DroitUsage.objects.create(
        plan=plan,
        code="apprenants",
        actif=True,
        limite=250,
        unite="apprenants",
    )
    DroitUsage.objects.create(
        plan=plan,
        code="multi-campus",
        actif=False,
        limite=None,
        unite="campus",
    )
    return plan


def _donnees_inscription(plan, **overrides):
    donnees = {
        "nom_etablissement": "Institut Horizon",
        "type_educatif": "ecole_professionnelle",
        "pays": "ht",
        "email": "direction@instituthorizon.ht",
        "prenom_responsable": "Mireille",
        "nom_responsable": "Jean",
        "telephone": "+509 3700 0000",
        "effectif_apprenants": 800,
        "plan": str(plan.pk),
        "mot_de_passe": MOT_DE_PASSE,
        "confirmation_mot_de_passe": MOT_DE_PASSE,
    }
    return donnees | overrides


def _creer_proprietaire_existant(email):
    compte = get_user_model().objects.create_user(
        email,
        MOT_DE_PASSE,
        email_verifie_le=timezone.now(),
    )
    tenant = Tenant.objects.create(
        nom="Premier établissement",
        statut=StatutTenant.ACTIF,
        cle_idempotence=uuid.uuid4(),
        cree_par=compte,
    )
    Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom=tenant.nom,
        type_educatif="ecole_classique",
        cree_par=compte,
    )
    AdhesionTenant.objects.create(
        tenant=tenant,
        utilisateur=compte,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=compte,
    )
    return compte, tenant


@override_settings(MAILERS=MAILERS_LOCAL, EDUFLOW_BASE_URL="http://testserver")
def test_public_homepage_lists_only_active_plans_and_real_rights():
    acteur = _creer_utilisateur()
    actif = _creer_plan(acteur, prix_mensuel=Decimal("2500.00"))
    inactif = _creer_plan(acteur, code="archive", nom="Forfait Archivé", actif=False)

    response = Client().get(reverse("parcours_tenant:accueil"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Créer mon établissement" in content
    assert "Forfait Essentiel" in content
    assert "250 apprenants" in content
    assert "HTG</strong> / mois" in content
    assert "HTG / an" in content
    assert "Non inclus" in content
    assert "archive" not in content
    assert actif.nom in content
    assert inactif.nom not in content
    assert "12 mensualités, sans remise." in content


@override_settings(MAILERS=MAILERS_LOCAL, EDUFLOW_BASE_URL="http://testserver")
def test_public_signup_verifies_email_waits_for_operator_and_activates_only_after_payment():
    operateur = _creer_utilisateur()
    plan = _creer_plan(operateur)
    client = Client()

    accueil = client.get("/")
    page_inscription = client.get(reverse("parcours_tenant:inscription"))
    reponse = client.post(
        reverse("parcours_tenant:inscription"),
        _donnees_inscription(plan),
    )

    assert accueil.status_code == 200
    assert page_inscription.status_code == 200
    assert page_inscription["Referrer-Policy"] == "same-origin"
    assert "/static/js/password-toggle.js" in page_inscription.content.decode()
    assert "/static/css/password-toggle.css" in page_inscription.content.decode()
    assert plan.nom in page_inscription.content.decode()
    assert reverse("connexion") in page_inscription.content.decode()
    assert "Se connecter" in page_inscription.content.decode()
    assert reponse.status_code == 200
    assert "Vérifiez votre boîte e-mail" in reponse.content.decode()
    assert len(mail.outbox) == 1

    demande = DemandeInscriptionTenant.objects.get()
    compte = demande.compte
    tenant = demande.tenant
    assert compte.email == "direction@instituthorizon.ht"
    assert compte.is_active is False
    assert compte.email_verifie_le is None
    assert tenant.statut == StatutTenant.DEMANDE
    assert not AdhesionTenant.objects.filter(tenant=tenant).exists()
    assert not Institution.objects.filter(tenant=tenant).exists()
    assert demande.statut == StatutDemandeInscription.EMAIL_A_VERIFIER
    assert "aucun paiement n’est initié" in mail.outbox[0].body

    url = re.search(r"http://testserver\S+", mail.outbox[0].body).group()
    chemin = urlparse(url).path
    jeton = chemin.rstrip("/").split("/")[-1]
    assert demande.empreinte_jeton != jeton
    page_verification = client.get(chemin)
    assert page_verification.status_code == 200
    assert page_verification["Referrer-Policy"] == "same-origin"
    assert "Confirmez votre adresse" in page_verification.content.decode()
    demande.refresh_from_db()
    compte.refresh_from_db()
    assert demande.statut == StatutDemandeInscription.EMAIL_A_VERIFIER
    assert compte.email_verifie_le is None

    csrf_client = Client(enforce_csrf_checks=True)
    page_verification_csrf = csrf_client.get(chemin)
    assert page_verification_csrf.status_code == 200
    csrf_token = csrf_client.cookies["csrftoken"].value
    origine_nulle = csrf_client.post(
        chemin,
        HTTP_X_CSRFTOKEN=csrf_token,
        HTTP_ORIGIN="null",
    )
    assert origine_nulle.status_code == 403

    verification = csrf_client.post(
        chemin,
        HTTP_X_CSRFTOKEN=csrf_token,
        HTTP_ORIGIN="http://testserver",
    )

    demande.refresh_from_db()
    compte.refresh_from_db()
    assert verification.status_code == 200
    assert "en cours d’examen" in verification.content.decode()
    assert demande.statut == StatutDemandeInscription.EN_ATTENTE
    assert compte.email_verifie_le is not None
    assert compte.is_active is False
    assert tenant.statut == StatutTenant.DEMANDE
    assert not AdhesionTenant.objects.filter(tenant=tenant).exists()

    confirmation_rejouee = client.get(chemin)
    assert confirmation_rejouee.status_code == 200
    assert "Adresse déjà confirmée" in confirmation_rejouee.content.decode()
    assert DemandeInscriptionTenant.objects.count() == 1
    assert (
        EvenementAudit.objects.filter(
            tenant=tenant,
            action="tenant.inscription_email_verifie",
        ).count()
        == 1
    )

    approuvee = traiter_demande_inscription_tenant(
        demande.pk,
        acteur=operateur,
        approuver=True,
    )
    compte.refresh_from_db()
    tenant.refresh_from_db()
    assert approuvee.statut == StatutDemandeInscription.VALIDEE
    assert compte.is_active is True
    assert tenant.statut == StatutTenant.PROVISIONNEMENT
    assert Institution.objects.get(tenant=tenant).type_educatif == "ecole_professionnelle"
    assert AdhesionTenant.objects.get(tenant=tenant, utilisateur=compte).role == "proprietaire"
    assert not tenant.abonnements_saas.exists()

    client.force_login(compte)
    dashboard = client.get(reverse("tableau_de_bord:accueil"))
    assert dashboard.status_code == 200
    assert "est en préparation" in dashboard.content.decode()
    assert plan.nom in dashboard.content.decode()

    maintenant = timezone.now()
    abonnement = creer_abonnement(
        tenant=tenant,
        plan=plan,
        commence_le=maintenant - timedelta(minutes=1),
        termine_le=maintenant + timedelta(days=30),
        acteur=operateur,
        cle_idempotence=uuid.uuid4(),
    )
    paiement = enregistrer_paiement(
        abonnement=abonnement,
        montant=Decimal("100.00"),
        devise="HTG",
        reference="DEMO-PAIEMENT-TEST",
        acteur=operateur,
        cle_idempotence=uuid.uuid4(),
    )
    decider_evenement_paiement(paiement.pk, acteur=operateur, confirmer=True)
    tenant.refresh_from_db()

    assert tenant.statut == StatutTenant.ACTIF
    assert client.get(reverse("tableau_de_bord:accueil")).status_code == 200


@override_settings(MAILERS=MAILERS_LOCAL, EDUFLOW_BASE_URL="http://testserver")
def test_free_plan_automatically_activates_tenant_for_seven_days_after_email_verification():
    operateur = _creer_utilisateur()
    plan = _creer_plan(
        operateur,
        code="gratuit",
        nom="Plan Gratuit",
    )
    client = Client(enforce_csrf_checks=True)
    page_inscription = client.get(reverse("parcours_tenant:inscription"))
    csrf_token = client.cookies["csrftoken"].value
    inscription = client.post(
        reverse("parcours_tenant:inscription"),
        _donnees_inscription(plan),
        HTTP_X_CSRFTOKEN=csrf_token,
        HTTP_ORIGIN="http://testserver",
    )
    demande = DemandeInscriptionTenant.objects.get()
    url = re.search(r"http://testserver\S+", mail.outbox[0].body).group()
    chemin = urlparse(url).path
    page_verification = client.get(chemin)
    csrf_token = client.cookies["csrftoken"].value
    verification = client.post(
        chemin,
        HTTP_X_CSRFTOKEN=csrf_token,
        HTTP_ORIGIN="http://testserver",
    )

    demande.refresh_from_db()
    demande.compte.refresh_from_db()
    demande.tenant.refresh_from_db()
    abonnement = abonnement_actif_pour_tenant(demande.tenant)

    assert inscription.status_code == 200
    assert page_inscription.status_code == 200
    assert page_verification.status_code == 200
    assert verification.status_code == 200
    assert "Votre établissement est prêt" in verification.content.decode()
    assert demande.statut == StatutDemandeInscription.VALIDEE
    assert demande.traitee_par is None
    assert demande.compte.is_active is True
    assert demande.compte.email_verifie_le is not None
    assert demande.tenant.statut == StatutTenant.ACTIF
    assert AdhesionTenant.objects.filter(
        tenant=demande.tenant,
        utilisateur=demande.compte,
        role="proprietaire",
    ).exists()
    assert abonnement is not None
    assert abonnement.plan == plan
    assert abonnement.termine_le - abonnement.commence_le == timedelta(days=7)
    assert not abonnement.evenements_paiement.exists()
    assert client.login(
        username=demande.compte.email,
        password=MOT_DE_PASSE,
    )
    dashboard = client.get(reverse("tableau_de_bord:accueil"))
    assert dashboard.status_code == 200
    assert "est en préparation" not in dashboard.content.decode()
    assert EvenementAudit.objects.filter(
        tenant=demande.tenant,
        action="abonnement.gratuit_active",
    ).exists()


def test_logged_in_owner_creates_free_tenant_without_reentering_account_details():
    operateur = _creer_utilisateur()
    plan = _creer_plan(operateur, code="gratuit", nom="Plan Gratuit")
    proprietaire, _ = _creer_proprietaire_existant("existing-owner@example.org")
    client = Client()
    client.force_login(proprietaire)
    nombre_comptes = get_user_model().objects.count()
    url = reverse("parcours_tenant:inscription")

    formulaire = client.get(url)
    contenu = formulaire.content.decode()
    response = client.post(
        url,
        {
            "nom_etablissement": "Mon deuxième établissement",
            "type_educatif": "ecole_classique",
            "pays": "ht",
            "telephone": "+509 3700 0000",
            "effectif_apprenants": "125",
            "plan": str(plan.pk),
        },
    )

    demande = DemandeInscriptionTenant.objects.get(
        tenant__nom="Mon deuxième établissement",
    )
    assert formulaire.status_code == 200
    assert 'name="email"' not in contenu
    assert 'name="prenom_responsable"' not in contenu
    assert 'name="mot_de_passe"' not in contenu
    assert "sidebar-tenant" in contenu
    assert f'href="{reverse("parcours_tenant:mes-etablissements")}"' in contenu
    assert f'href="{reverse("parcours_tenant:inscription")}"' in contenu
    assert response.status_code == 200
    assert "Votre établissement est prêt" in response.content.decode()
    assert demande.compte == proprietaire
    assert demande.statut == StatutDemandeInscription.VALIDEE
    assert demande.tenant.statut == StatutTenant.ACTIF
    assert AdhesionTenant.objects.filter(
        tenant=demande.tenant,
        utilisateur=proprietaire,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
    ).exists()
    assert get_user_model().objects.count() == nombre_comptes
    assert client.session["eduflow_tenant_actif"] == str(demande.tenant_id)


def test_logged_in_owner_paid_tenant_request_reuses_account_and_waits_for_operator():
    operateur = _creer_utilisateur()
    plan = _creer_plan(
        operateur,
        code="etablissement-plus",
        prix_mensuel=Decimal("2500.00"),
    )
    proprietaire, _ = _creer_proprietaire_existant("paid-owner@example.org")
    client = Client()
    client.force_login(proprietaire)
    reponse = client.post(
        reverse("parcours_tenant:inscription"),
        {
            "nom_etablissement": "Établissement payant",
            "type_educatif": "ecole_classique",
            "pays": "HT",
            "telephone": "+509 3700 0000",
            "effectif_apprenants": "400",
            "plan": str(plan.pk),
        },
    )

    demande = DemandeInscriptionTenant.objects.get(
        tenant__nom="Établissement payant",
    )
    assert reponse.status_code == 200
    assert "en cours d’examen" in reponse.content.decode()
    assert demande.compte == proprietaire
    assert demande.statut == StatutDemandeInscription.EN_ATTENTE
    assert demande.tenant.statut == StatutTenant.DEMANDE
    assert not AdhesionTenant.objects.filter(tenant=demande.tenant).exists()
    assert not mail.outbox


def test_non_owner_cannot_open_authenticated_tenant_creation():
    utilisateur = get_user_model().objects.create_user(
        "non-owner@example.org",
        MOT_DE_PASSE,
        email_verifie_le=timezone.now(),
    )
    client = Client()
    client.force_login(utilisateur)

    response = client.get(reverse("parcours_tenant:inscription"))

    assert response.status_code == 403


@override_settings(MAILERS=MAILERS_LOCAL, EDUFLOW_BASE_URL="http://testserver")
def test_public_signup_requires_csrf_and_rolls_back_if_email_cannot_be_sent(monkeypatch):
    from applications.organisations import views

    operateur = _creer_utilisateur()
    plan = _creer_plan(operateur)
    client = Client(enforce_csrf_checks=True)
    form = client.get(reverse("parcours_tenant:inscription"))
    csrf = client.cookies["csrftoken"].value

    sans_csrf = client.post(
        reverse("parcours_tenant:inscription"),
        _donnees_inscription(plan),
    )
    assert sans_csrf.status_code == 403

    origine_opaque = client.post(
        reverse("parcours_tenant:inscription"),
        _donnees_inscription(plan),
        HTTP_X_CSRFTOKEN=csrf,
        HTTP_ORIGIN="null",
    )
    assert origine_opaque.status_code == 403

    monkeypatch.setattr(views, "send_mail", lambda **kwargs: 0)
    echec = client.post(
        reverse("parcours_tenant:inscription"),
        _donnees_inscription(plan),
        HTTP_X_CSRFTOKEN=csrf,
    )

    assert form.status_code == 200
    assert echec.status_code == 503
    assert get_user_model().objects.filter(email="direction@instituthorizon.ht").count() == 0
    assert Tenant.objects.filter(nom="Institut Horizon").count() == 0
    assert DemandeInscriptionTenant.objects.count() == 0


@override_settings(MAILERS=MAILERS_LOCAL, EDUFLOW_BASE_URL="http://testserver")
def test_expired_verification_link_and_rejection_require_explicit_decision_reason():
    operateur = _creer_utilisateur()
    plan = _creer_plan(operateur)
    demande, jeton = creer_demande_inscription_tenant(
        email="responsable@example.org",
        mot_de_passe=MOT_DE_PASSE,
        prenom="Alice",
        nom="Proprietaire",
        nom_tenant="École Exemple",
        type_educatif="ecole_classique",
        pays="HT",
        telephone="+509 3700 0001",
        effectif_apprenants=100,
        plan_id=plan.pk,
    )
    demande.jeton_expire_le = timezone.now() - timedelta(seconds=1)
    demande.save(update_fields=("jeton_expire_le",))

    with pytest.raises(ValidationError, match="a expiré"):
        verifier_email_demande_inscription(jeton)
    assert demande.compte.email_verifie_le is None

    demande.jeton_expire_le = timezone.now() + timedelta(hours=1)
    demande.save(update_fields=("jeton_expire_le",))
    verifier_email_demande_inscription(jeton)
    demande.refresh_from_db()
    with pytest.raises(ValidationError, match="motif est obligatoire"):
        traiter_demande_inscription_tenant(
            demande.pk,
            acteur=operateur,
            approuver=False,
        )
    assert demande.statut == StatutDemandeInscription.EN_ATTENTE

    refusee = traiter_demande_inscription_tenant(
        demande.pk,
        acteur=operateur,
        approuver=False,
        motif="Les renseignements fournis doivent être complétés.",
    )
    assert refusee.statut == StatutDemandeInscription.REFUSEE
    assert refusee.compte.is_active is False
    assert refusee.tenant.statut == StatutTenant.DEMANDE
    assert refusee.traitee_par == operateur
    assert EvenementAudit.objects.filter(
        tenant=demande.tenant,
        action="tenant.inscription_refusee",
        motif="Les renseignements fournis doivent être complétés.",
    ).exists()


@override_settings(MAILERS=MAILERS_LOCAL, EDUFLOW_BASE_URL="http://testserver")
def test_only_saas_operator_can_review_and_approve_a_verified_request():
    proprietaire_plan = _creer_utilisateur()
    plan = _creer_plan(proprietaire_plan)
    demande, jeton = creer_demande_inscription_tenant(
        email="direction-operator@example.org",
        mot_de_passe=MOT_DE_PASSE,
        prenom="Alice",
        nom="Responsable",
        nom_tenant="Établissement Opérateur",
        type_educatif="universite",
        pays="HT",
        telephone="+509 3700 0002",
        effectif_apprenants=500,
        plan_id=plan.pk,
    )
    verifier_email_demande_inscription(jeton)

    sans_permission = get_user_model().objects.create_user(
        "staff-without-saas-permission@example.org",
        MOT_DE_PASSE,
        is_staff=True,
        email_verifie_le=timezone.now(),
    )
    operateur = get_user_model().objects.create_user(
        "saas-reviewer@example.org",
        MOT_DE_PASSE,
        is_staff=True,
        email_verifie_le=timezone.now(),
    )
    permission = Permission.objects.get(
        codename="gerer_abonnements_saas",
        content_type__app_label="abonnements",
    )
    operateur.user_permissions.add(permission)

    url = reverse("admin:organisations_demandeinscriptiontenant_changelist")
    client = Client()
    client.force_login(sans_permission)
    interdit = client.get(url)
    assert interdit.status_code == 403

    client.force_login(operateur)
    liste = client.get(url)
    assert liste.status_code == 200
    validee = client.post(
        url,
        {
            "action": "valider_demandes",
            "_selected_action": [str(demande.pk)],
            "index": "0",
        },
    )

    demande.refresh_from_db()
    demande.tenant.refresh_from_db()
    assert validee.status_code == 302
    assert demande.statut == StatutDemandeInscription.VALIDEE
    assert demande.tenant.statut == StatutTenant.PROVISIONNEMENT
    assert not demande.tenant.abonnements_saas.exists()
    assert len(mail.outbox) == 1


def test_approval_recovers_a_verified_request_already_in_provisioning():
    operateur = _creer_utilisateur()
    plan = _creer_plan(operateur, prix_mensuel=Decimal("100"))
    demande, jeton = creer_demande_inscription_tenant(
        email="provisioning-recovery@example.org",
        mot_de_passe=MOT_DE_PASSE,
        prenom="Alice",
        nom="Responsable",
        nom_tenant="Établissement à reprendre",
        type_educatif="universite",
        pays="HT",
        telephone="+509 3700 0003",
        effectif_apprenants=500,
        plan_id=plan.pk,
    )
    verifier_email_demande_inscription(jeton)
    transitionner_tenant(
        demande.tenant_id,
        StatutTenant.PROVISIONNEMENT,
        acteur=operateur,
        motif="Préparation déjà commencée.",
    )
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=demande.tenant,
        nom=demande.tenant.nom,
        type_educatif=demande.type_educatif,
        pays=demande.pays,
        cree_par=demande.compte,
    )
    adhesion = AdhesionTenant.objects.create(
        tenant=demande.tenant,
        utilisateur=demande.compte,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=demande.compte,
    )

    validee = traiter_demande_inscription_tenant(
        demande.pk,
        acteur=operateur,
        approuver=True,
    )
    demande.compte.refresh_from_db()
    demande.tenant.refresh_from_db()

    assert validee.statut == StatutDemandeInscription.VALIDEE
    assert demande.tenant.statut == StatutTenant.PROVISIONNEMENT
    assert demande.compte.is_active
    assert Institution.objects.get(tenant=demande.tenant) == institution
    assert AdhesionTenant.objects.get(tenant=demande.tenant) == adhesion
    assert not demande.tenant.abonnements_saas.exists()


def test_approval_recovers_a_verified_request_with_an_already_active_tenant():
    operateur = _creer_utilisateur()
    plan = _creer_plan(operateur, prix_mensuel=Decimal("100"))
    demande, jeton = creer_demande_inscription_tenant(
        email="active-tenant-recovery@example.org",
        mot_de_passe=MOT_DE_PASSE,
        prenom="Alice",
        nom="Responsable",
        nom_tenant="Établissement actif à reprendre",
        type_educatif="universite",
        pays="HT",
        telephone="+509 3700 0004",
        effectif_apprenants=500,
        plan_id=plan.pk,
    )
    verifier_email_demande_inscription(jeton)
    Tenant.objects.filter(pk=demande.tenant_id).update(statut=StatutTenant.ACTIF)

    validee = traiter_demande_inscription_tenant(
        demande.pk,
        acteur=operateur,
        approuver=True,
    )
    demande.tenant.refresh_from_db()

    assert validee.statut == StatutDemandeInscription.VALIDEE
    assert demande.tenant.statut == StatutTenant.ACTIF
    assert Institution.objects.filter(tenant=demande.tenant).exists()
    assert AdhesionTenant.objects.filter(
        tenant=demande.tenant,
        utilisateur=demande.compte,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
    ).exists()
    assert not demande.tenant.abonnements_saas.exists()
