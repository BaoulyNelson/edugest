"""Tests adversariaux de provisioning, contexte et accès entre tenants."""

import uuid

import pytest
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.organisations.models import (
    AdhesionTenant,
    EvenementAudit,
    RoleAdhesion,
    StatutAdhesion,
    StatutTenant,
    Tenant,
)
from applications.organisations.services import (
    provisionner_tenant,
    transitionner_tenant,
)

pytestmark = pytest.mark.django_db


def _creer_utilisateur(email: str):
    from django.contrib.auth import get_user_model

    return get_user_model().objects.create_user(
        email,
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )


def _creer_tenant(proprietaire, nom: str):
    return provisionner_tenant(
        createur=proprietaire,
        nom=nom,
        cle_idempotence=uuid.uuid4(),
    )


def test_tenant_status_is_read_only_in_admin():
    assert "statut" in admin.site._registry[Tenant].get_readonly_fields(None)


def test_provisioning_is_idempotent_and_creates_one_active_owner():
    proprietaire = _creer_utilisateur("proprietaire@example.org")
    cle = uuid.uuid4()

    premier_tenant, premiere_adhesion, cree = provisionner_tenant(
        createur=proprietaire,
        nom=" École Alpha ",
        cle_idempotence=cle,
    )
    second_tenant, seconde_adhesion, second_cree = provisionner_tenant(
        createur=proprietaire,
        nom="École Alpha",
        cle_idempotence=cle,
    )

    assert cree is True
    assert second_cree is False
    assert second_tenant.pk == premier_tenant.pk
    assert seconde_adhesion.pk == premiere_adhesion.pk
    assert premier_tenant.statut == StatutTenant.ACTIF
    assert premiere_adhesion.role == RoleAdhesion.PROPRIETAIRE
    assert EvenementAudit.objects.filter(
        tenant=premier_tenant,
        action="tenant.statut_modifie",
    ).count() == 2


def test_idempotency_key_cannot_be_reused_for_another_owner_or_name():
    from applications.organisations.services import ConflitIdempotence

    proprietaire = _creer_utilisateur("premier@example.org")
    autre = _creer_utilisateur("autre@example.org")
    cle = uuid.uuid4()
    provisionner_tenant(createur=proprietaire, nom="Alpha", cle_idempotence=cle)

    with pytest.raises(ConflitIdempotence):
        provisionner_tenant(createur=autre, nom="Alpha", cle_idempotence=cle)
    with pytest.raises(ConflitIdempotence):
        provisionner_tenant(createur=proprietaire, nom="Beta", cle_idempotence=cle)


def test_rest_routes_are_unavailable():
    client = Client()

    anciennes_routes = (
        "/api/v1/tenants/",
        "/api/v1/tenants/current/",
        "/api/v1/education/campuses/",
        "/api/v1/education/candidatures/",
        "/api/v1/education/affectations/",
        "/api/v1/education/baremes-frais/",
        "/api/v1/education/rapports/effectifs/",
        "/api/v1/platform/plans/",
    )
    assert all(client.get(url).status_code == 404 for url in anciennes_routes)
    assert client.post("/api/v1/tenants/", {"nom": "École Alpha"}).status_code == 404


def test_tenant_transitions_require_valid_state_and_reason():
    proprietaire = _creer_utilisateur("owner@example.org")
    tenant, _, _ = _creer_tenant(proprietaire, "École Alpha")

    with pytest.raises(ValidationError, match="motif est obligatoire"):
        transitionner_tenant(
            tenant.pk,
            StatutTenant.SUSPENDU,
            acteur=proprietaire,
        )
    tenant = transitionner_tenant(
        tenant.pk,
        StatutTenant.RESTREINT,
        acteur=proprietaire,
        motif="Incident à examiner.",
    )
    assert tenant.statut == StatutTenant.RESTREINT
    assert EvenementAudit.objects.filter(
        tenant=tenant,
        action="tenant.statut_modifie",
        details__nouveau_statut=StatutTenant.RESTREINT,
    ).exists()


def test_owner_can_manage_members_only_inside_selected_tenant():
    proprietaire = _creer_utilisateur("owner-a@example.org")
    membre = _creer_utilisateur("member-a@example.org")
    autre_proprietaire = _creer_utilisateur("owner-b@example.org")
    tenant_a, adhesion_proprietaire, _ = _creer_tenant(proprietaire, "École Alpha")
    tenant_b, _, _ = _creer_tenant(autre_proprietaire, "École Beta")
    rendre_tenant_abonne(tenant_a, proprietaire)
    adhesion_membre = AdhesionTenant.objects.create(
        tenant=tenant_a,
        utilisateur=membre,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=proprietaire,
    )
    adhesion_autre_tenant = AdhesionTenant.objects.create(
        tenant=tenant_b,
        utilisateur=membre,
        role=RoleAdhesion.MEMBRE,
        statut=StatutAdhesion.ACTIVE,
        cree_par=autre_proprietaire,
    )
    client = Client()
    client.force_login(proprietaire)
    session = client.session
    session["eduflow_tenant_actif"] = str(tenant_a.pk)
    session.save()

    liste = client.get(reverse("parcours_tenant:equipe"))
    modification = client.post(
        reverse("parcours_tenant:equipe"),
        {
            "action": "modifier",
            "adhesion_id": adhesion_membre.pk,
            f"adhesion-{adhesion_membre.pk}-role": RoleAdhesion.ENSEIGNANT,
            f"adhesion-{adhesion_membre.pk}-statut": StatutAdhesion.SUSPENDUE,
        },
    )
    autre_tenant = client.post(
        reverse("parcours_tenant:equipe"),
        {
            "action": "modifier",
            "adhesion_id": adhesion_autre_tenant.pk,
            f"adhesion-{adhesion_autre_tenant.pk}-role": RoleAdhesion.MEMBRE,
            f"adhesion-{adhesion_autre_tenant.pk}-statut": StatutAdhesion.REVOQUEE,
        },
    )
    proprietaire_protege = client.post(
        reverse("parcours_tenant:equipe"),
        {
            "action": "modifier",
            "adhesion_id": adhesion_proprietaire.pk,
            f"adhesion-{adhesion_proprietaire.pk}-role": RoleAdhesion.PROPRIETAIRE,
            f"adhesion-{adhesion_proprietaire.pk}-statut": StatutAdhesion.REVOQUEE,
        },
    )

    assert liste.status_code == 200
    assert b"member-a@example.org" in liste.content
    assert b"owner-b@example.org" not in liste.content
    assert modification.status_code == 302
    assert autre_tenant.status_code == 404
    assert proprietaire_protege.status_code == 302
    adhesion_membre.refresh_from_db()
    assert adhesion_membre.role == RoleAdhesion.ENSEIGNANT
    assert adhesion_membre.statut == StatutAdhesion.SUSPENDUE
    adhesion_autre_tenant.refresh_from_db()
    assert adhesion_autre_tenant.statut == StatutAdhesion.ACTIVE
    adhesion_proprietaire.refresh_from_db()
    assert adhesion_proprietaire.statut == StatutAdhesion.ACTIVE
