"""Configuration des organisations et de leur isolation."""

from django.apps import AppConfig


class OrganisationsConfig(AppConfig):
    """Application des tenants, memberships et invitations."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.organisations"
    label = "organisations"
    verbose_name = "Organisations"
