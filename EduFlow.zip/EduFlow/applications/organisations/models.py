"""Modèles de tenants, memberships, invitations et journal d’audit."""

import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q


class StatutTenant(models.TextChoices):
    DEMANDE = "demande", "Demande"
    PROVISIONNEMENT = "provisionnement", "Provisionnement"
    ACTIF = "actif", "Actif"
    RESTREINT = "restreint", "Restreint"
    SUSPENDU = "suspendu", "Suspendu"
    SORTIE = "sortie", "Offboarding"
    ARCHIVE = "archive", "Archivé"


class StatutDemandeInscription(models.TextChoices):
    EMAIL_A_VERIFIER = "email_a_verifier", "Adresse e-mail à vérifier"
    EN_ATTENTE = "en_attente", "En attente de validation"
    VALIDEE = "validee", "Validée"
    REFUSEE = "refusee", "Refusée"


class RoleAdhesion(models.TextChoices):
    PROPRIETAIRE = "proprietaire", "Propriétaire"
    ADMINISTRATEUR = "administrateur", "Administrateur"
    GESTIONNAIRE = "gestionnaire", "Gestionnaire"
    ENSEIGNANT = "enseignant", "Enseignant"
    MEMBRE = "membre", "Membre"


class StatutAdhesion(models.TextChoices):
    ACTIVE = "active", "Active"
    SUSPENDUE = "suspendue", "Suspendue"
    REVOQUEE = "revoquee", "Révoquée"


class StatutInvitation(models.TextChoices):
    EN_ATTENTE = "en_attente", "En attente"
    ACCEPTEE = "acceptee", "Acceptée"
    REVOQUEE = "revoquee", "Révoquée"
    EXPIREE = "expiree", "Expirée"


class Tenant(models.Model):
    """Organisation cliente, frontière de propriété des données éducatives."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    nom = models.CharField(max_length=200)
    statut = models.CharField(
        max_length=20,
        choices=StatutTenant.choices,
        default=StatutTenant.DEMANDE,
    )
    cle_idempotence = models.UUIDField(unique=True, editable=False)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="tenants_crees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("nom", "id")
        verbose_name = "tenant"
        verbose_name_plural = "tenants"
        constraints = [
            models.CheckConstraint(
                condition=Q(statut__in=StatutTenant.values),
                name="tenant_statut_valide",
            ),
        ]

    def __str__(self) -> str:
        return self.nom


class DemandeInscriptionTenant(models.Model):
    """Demande publique d’ouverture d’un tenant, séparée du compte responsable."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.OneToOneField(
        Tenant,
        on_delete=models.PROTECT,
        related_name="demande_inscription",
    )
    compte = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="demandes_inscription_tenant",
    )
    plan = models.ForeignKey(
        "abonnements.PlanSaaS",
        on_delete=models.PROTECT,
        related_name="demandes_inscription_tenant",
    )
    type_educatif = models.SlugField(max_length=40)
    pays = models.CharField(max_length=2, default="HT")
    telephone = models.CharField(max_length=30)
    effectif_apprenants = models.PositiveIntegerField()
    statut = models.CharField(
        max_length=24,
        choices=StatutDemandeInscription.choices,
        default=StatutDemandeInscription.EMAIL_A_VERIFIER,
    )
    empreinte_jeton = models.CharField(max_length=64, unique=True)
    jeton_expire_le = models.DateTimeField()
    email_verifie_le = models.DateTimeField(null=True, blank=True)
    traitee_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="demandes_inscription_tenant_traitees",
    )
    traitee_le = models.DateTimeField(null=True, blank=True)
    motif_decision = models.CharField(max_length=500, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("cree_le",)
        constraints = [
            models.CheckConstraint(
                condition=models.Q(statut__in=StatutDemandeInscription.values),
                name="demande_inscription_statut_valide",
            ),
        ]
        permissions = [
            (
                "traiter_demande_inscription_tenant",
                "Peut traiter les demandes publiques de tenant",
            ),
        ]
        verbose_name = "demande d’inscription de tenant"
        verbose_name_plural = "demandes d’inscription de tenant"

    def __str__(self):
        return f"{self.tenant.nom} — {self.get_statut_display()}"


class AdhesionTenant(models.Model):
    """Rôle et état d’un compte dans un tenant donné."""

    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE, related_name="adhesions")
    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="adhesions_tenant",
    )
    role = models.CharField(max_length=20, choices=RoleAdhesion.choices)
    statut = models.CharField(
        max_length=12,
        choices=StatutAdhesion.choices,
        default=StatutAdhesion.ACTIVE,
    )
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adhesions_creees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    modifie_le = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=Q(role__in=RoleAdhesion.values),
                name="adhesion_role_valide",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutAdhesion.values),
                name="adhesion_statut_valide",
            ),
            models.UniqueConstraint(
                fields=("tenant", "utilisateur"),
                name="adhesion_tenant_utilisateur_unique",
            ),
            models.UniqueConstraint(
                fields=("tenant",),
                condition=Q(role=RoleAdhesion.PROPRIETAIRE, statut=StatutAdhesion.ACTIVE),
                name="tenant_un_proprietaire_actif",
            ),
        ]
        indexes = [
            models.Index(fields=("utilisateur", "statut"), name="adhesion_user_status_idx"),
        ]
        verbose_name = "adhésion à un tenant"
        verbose_name_plural = "adhésions aux tenants"

    def __str__(self) -> str:
        return f"{self.utilisateur_id} — {self.tenant_id} ({self.role})"


class InvitationTenant(models.Model):
    """Invitation à usage unique ; seul le condensat du jeton est conservé."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE, related_name="invitations")
    email = models.EmailField()
    role = models.CharField(max_length=20, choices=RoleAdhesion.choices)
    statut = models.CharField(
        max_length=12,
        choices=StatutInvitation.choices,
        default=StatutInvitation.EN_ATTENTE,
    )
    empreinte_jeton = models.CharField(max_length=64, unique=True)
    expire_le = models.DateTimeField()
    invite_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="invitations_tenant_creees",
    )
    acceptee_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="invitations_tenant_acceptees",
    )
    cree_le = models.DateTimeField(auto_now_add=True)
    acceptee_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=Q(role__in=RoleAdhesion.values),
                name="invitation_role_valide",
            ),
            models.CheckConstraint(
                condition=Q(statut__in=StatutInvitation.values),
                name="invitation_statut_valide",
            ),
            models.UniqueConstraint(
                fields=("tenant", "email"),
                condition=Q(statut=StatutInvitation.EN_ATTENTE),
                name="invitation_tenant_email_en_attente_unique",
            ),
        ]
        indexes = [
            models.Index(fields=("tenant", "statut"), name="invitation_tenant_status_idx"),
        ]
        verbose_name = "invitation de tenant"
        verbose_name_plural = "invitations de tenant"

    def __str__(self) -> str:
        return f"{self.email} — {self.tenant_id} ({self.statut})"


class EvenementAudit(models.Model):
    """Événement d’audit sans contenu éducatif sensible ni jeton d’accès."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="evenements_audit",
    )
    acteur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="evenements_audit",
    )
    action = models.CharField(max_length=100)
    type_objet = models.CharField(max_length=100)
    id_objet = models.CharField(max_length=100)
    motif = models.CharField(max_length=500, blank=True)
    details = models.JSONField(default=dict, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-cree_le",)
        indexes = [
            models.Index(fields=("tenant", "cree_le"), name="audit_tenant_created_idx"),
        ]
        verbose_name = "événement d’audit"
        verbose_name_plural = "événements d’audit"

    def __str__(self) -> str:
        return f"{self.action} — {self.type_objet}:{self.id_objet}"
