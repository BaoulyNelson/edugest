"""Formulaires publics de demande d’inscription d’un établissement."""

import re

from django import forms
from django.contrib.auth import get_user_model, password_validation
from django.core.exceptions import ValidationError as DjangoValidationError
from django.core.validators import RegexValidator

from applications.abonnements.models import PlanSaaS
from applications.organisations.models import (
    RoleAdhesion,
    StatutAdhesion,
)

TYPES_ETABLISSEMENT = (
    ("ecole_classique", "École classique"),
    ("universite", "Université"),
    ("ecole_professionnelle", "École professionnelle"),
    ("centre_formation", "Centre de formation"),
    ("etablissement_technique", "Établissement technique"),
    ("autre", "Autre établissement éducatif"),
)


class DemandeInscriptionForm(forms.Form):
    nom_etablissement = forms.CharField(max_length=200, label="Nom de l’établissement")
    type_educatif = forms.ChoiceField(
        choices=TYPES_ETABLISSEMENT,
        label="Type d’établissement",
    )
    pays = forms.CharField(
        max_length=2,
        min_length=2,
        initial="HT",
        label="Pays",
        help_text="Code pays ISO à deux lettres, par exemple HT.",
    )
    email = forms.EmailField(label="E-mail professionnel")
    prenom_responsable = forms.CharField(max_length=150, label="Prénom du responsable")
    nom_responsable = forms.CharField(max_length=150, label="Nom du responsable")
    telephone = forms.CharField(
        max_length=30,
        label="Téléphone professionnel",
        widget=forms.TextInput(attrs={"placeholder": "+509 0000 0000"}),
        validators=[
            RegexValidator(
                re.compile(r"^\+?[0-9 .()\-]{6,30}$"),
                "Saisissez un numéro de téléphone valide.",
            )
        ],
    )
    effectif_apprenants = forms.IntegerField(
        min_value=1,
        label="Nombre approximatif d’apprenants",
    )
    plan = forms.ModelChoiceField(
        queryset=PlanSaaS.objects.none(),
        label="Forfait souhaité",
    )
    mot_de_passe = forms.CharField(
        strip=False,
        widget=forms.PasswordInput,
        label="Créer un mot de passe",
    )
    confirmation_mot_de_passe = forms.CharField(
        strip=False,
        widget=forms.PasswordInput,
        label="Confirmer le mot de passe",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["plan"].queryset = PlanSaaS.objects.filter(actif=True).order_by("code")

    def clean_pays(self):
        pays = self.cleaned_data["pays"].strip().upper()
        if not re.fullmatch(r"[A-Z]{2}", pays, flags=re.ASCII):
            raise forms.ValidationError("Utilisez un code pays ISO à deux lettres.")
        return pays

    def clean_email(self):
        email = get_user_model().objects.normalize_email(
            self.cleaned_data["email"].strip()
        ).casefold()
        if get_user_model().objects.filter(email=email).exists():
            raise forms.ValidationError(
                "Cette adresse est déjà associée à un compte. Connectez-vous ou contactez "
                "EduFlow si vous n’y avez pas accès."
            )
        return email

    def clean(self):
        cleaned_data = super().clean()
        mot_de_passe = cleaned_data.get("mot_de_passe")
        confirmation = cleaned_data.get("confirmation_mot_de_passe")
        if mot_de_passe and confirmation and mot_de_passe != confirmation:
            self.add_error(
                "confirmation_mot_de_passe",
                "Les mots de passe ne correspondent pas.",
            )
        if mot_de_passe:
            compte = get_user_model()(
                email=cleaned_data.get("email", ""),
                first_name=cleaned_data.get("prenom_responsable", ""),
                last_name=cleaned_data.get("nom_responsable", ""),
            )
            try:
                password_validation.validate_password(mot_de_passe, compte)
            except DjangoValidationError as erreur:
                self.add_error("mot_de_passe", erreur)
        return cleaned_data


class DemandeNouveauTenantForm(forms.Form):
    """Informations du nouvel établissement sans recréer le compte responsable."""

    nom_etablissement = forms.CharField(max_length=200, label="Nom de l’établissement")
    type_educatif = forms.ChoiceField(
        choices=TYPES_ETABLISSEMENT,
        label="Type d’établissement",
    )
    pays = forms.CharField(
        max_length=2,
        min_length=2,
        initial="HT",
        label="Pays",
        help_text="Code pays ISO à deux lettres, par exemple HT.",
    )
    telephone = forms.CharField(
        max_length=30,
        label="Téléphone professionnel",
        widget=forms.TextInput(attrs={"placeholder": "+509 0000 0000"}),
        validators=[
            RegexValidator(
                re.compile(r"^\+?[0-9 .()\-]{6,30}$"),
                "Saisissez un numéro de téléphone valide.",
            )
        ],
    )
    effectif_apprenants = forms.IntegerField(
        min_value=1,
        label="Nombre approximatif d’apprenants",
    )
    plan = forms.ModelChoiceField(
        queryset=PlanSaaS.objects.none(),
        label="Forfait souhaité",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["plan"].queryset = PlanSaaS.objects.filter(actif=True).order_by("code")

    def clean_pays(self):
        pays = self.cleaned_data["pays"].strip().upper()
        if not re.fullmatch(r"[A-Z]{2}", pays, flags=re.ASCII):
            raise forms.ValidationError("Utilisez un code pays ISO à deux lettres.")
        return pays


class InvitationEquipeForm(forms.Form):
    email = forms.EmailField(label="Adresse e-mail")
    role = forms.ChoiceField(
        choices=tuple(
            (role, label)
            for role, label in RoleAdhesion.choices
            if role != RoleAdhesion.PROPRIETAIRE
        ),
        label="Rôle",
    )

    def clean_email(self):
        return get_user_model().objects.normalize_email(
            self.cleaned_data["email"].strip()
        ).casefold()


class ModificationAdhesionForm(forms.Form):
    role = forms.ChoiceField(
        choices=tuple(
            (role, label)
            for role, label in RoleAdhesion.choices
            if role != RoleAdhesion.PROPRIETAIRE
        ),
        label="Rôle",
    )
    statut = forms.ChoiceField(
        choices=StatutAdhesion.choices,
        label="Accès",
    )


class AcceptationInvitationForm(forms.Form):
    jeton = forms.CharField(max_length=128, widget=forms.HiddenInput)
    mot_de_passe = forms.CharField(
        required=False,
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
        label="Mot de passe (requis pour un nouveau compte)",
    )
    confirmation_mot_de_passe = forms.CharField(
        required=False,
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
        label="Confirmer le mot de passe",
    )

    def clean(self):
        cleaned_data = super().clean()
        mot_de_passe = cleaned_data.get("mot_de_passe", "")
        confirmation = cleaned_data.get("confirmation_mot_de_passe", "")
        if mot_de_passe != confirmation:
            self.add_error(
                "confirmation_mot_de_passe",
                "Les mots de passe ne correspondent pas.",
            )
        return cleaned_data
