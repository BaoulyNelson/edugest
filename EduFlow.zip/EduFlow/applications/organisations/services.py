"""Opérations métier transactionnelles pour le cycle de vie des tenants."""

import hashlib
import secrets
import uuid
from datetime import timedelta

from django.contrib.auth import get_user_model, password_validation
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError, models, transaction
from django.utils import timezone

from applications.organisations.models import (
    AdhesionTenant,
    DemandeInscriptionTenant,
    EvenementAudit,
    InvitationTenant,
    RoleAdhesion,
    StatutAdhesion,
    StatutDemandeInscription,
    StatutInvitation,
    StatutTenant,
    Tenant,
)
from applications.referentiels.models import Institution

CompteUtilisateur = get_user_model()

TRANSITIONS_TENANT_AUTORISEES = {
    StatutTenant.DEMANDE: {StatutTenant.PROVISIONNEMENT},
    StatutTenant.PROVISIONNEMENT: {StatutTenant.ACTIF, StatutTenant.SUSPENDU},
    StatutTenant.ACTIF: {StatutTenant.RESTREINT, StatutTenant.SUSPENDU, StatutTenant.SORTIE},
    StatutTenant.RESTREINT: {StatutTenant.ACTIF, StatutTenant.SUSPENDU, StatutTenant.SORTIE},
    StatutTenant.SUSPENDU: {StatutTenant.ACTIF, StatutTenant.SORTIE},
    StatutTenant.SORTIE: {StatutTenant.ARCHIVE},
    StatutTenant.ARCHIVE: set(),
}
STATUTS_EXIGEANT_UN_MOTIF = {
    StatutTenant.RESTREINT,
    StatutTenant.SUSPENDU,
    StatutTenant.SORTIE,
    StatutTenant.ARCHIVE,
}
DUREE_INVITATION = timedelta(days=7)
DUREE_VERIFICATION_INSCRIPTION = timedelta(hours=24)


class ConflitIdempotence(Exception):
    """Une clé d’idempotence déjà utilisée accompagne des données différentes."""


def _journaliser(
    *,
    action: str,
    objet: models.Model,
    acteur,
    tenant: Tenant | None,
    motif: str = "",
    details: dict | None = None,
) -> EvenementAudit:
    return EvenementAudit.objects.create(
        tenant=tenant,
        acteur=acteur,
        action=action,
        type_objet=objet._meta.label_lower,
        id_objet=str(objet.pk),
        motif=motif,
        details=details or {},
    )


def transitionner_tenant(
    tenant_id: uuid.UUID,
    nouveau_statut: str,
    *,
    acteur,
    motif: str = "",
) -> Tenant:
    """Valide et journalise une transition de cycle de vie."""
    with transaction.atomic():
        tenant = Tenant.objects.select_for_update().get(pk=tenant_id)
        if nouveau_statut == tenant.statut:
            return tenant
        if nouveau_statut not in TRANSITIONS_TENANT_AUTORISEES.get(tenant.statut, set()):
            raise DjangoValidationError(
                f"Transition interdite : {tenant.statut} vers {nouveau_statut}."
            )
        if nouveau_statut in STATUTS_EXIGEANT_UN_MOTIF and not motif.strip():
            raise DjangoValidationError("Un motif est obligatoire pour cette transition.")

        ancien_statut = tenant.statut
        tenant.statut = nouveau_statut
        tenant.save(update_fields=("statut", "modifie_le"))
        _journaliser(
            action="tenant.statut_modifie",
            objet=tenant,
            acteur=acteur,
            tenant=tenant,
            motif=motif,
            details={"ancien_statut": ancien_statut, "nouveau_statut": nouveau_statut},
        )
        return tenant


def provisionner_tenant(
    *,
    createur,
    nom: str,
    cle_idempotence: uuid.UUID,
) -> tuple[Tenant, AdhesionTenant, bool]:
    """Crée atomiquement le tenant et son propriétaire ; les reprises sont idempotentes."""
    nom_normalise = nom.strip()
    if not nom_normalise:
        raise DjangoValidationError("Le nom du tenant est obligatoire.")

    with transaction.atomic():
        try:
            tenant, cree = Tenant.objects.get_or_create(
                cle_idempotence=cle_idempotence,
                defaults={
                    "nom": nom_normalise,
                    "cree_par": createur,
                    "statut": StatutTenant.DEMANDE,
                },
            )
        except IntegrityError:
            tenant = Tenant.objects.select_for_update().get(cle_idempotence=cle_idempotence)
            cree = False

        tenant = Tenant.objects.select_for_update().get(pk=tenant.pk)
        if not cree:
            if tenant.nom != nom_normalise or tenant.cree_par_id != createur.pk:
                raise ConflitIdempotence
            adhesion = AdhesionTenant.objects.get(
                tenant=tenant,
                utilisateur=createur,
                role=RoleAdhesion.PROPRIETAIRE,
            )
            return tenant, adhesion, False

        transitionner_tenant(
            tenant.pk,
            StatutTenant.PROVISIONNEMENT,
            acteur=createur,
            motif="Provisionnement initial.",
        )
        adhesion = AdhesionTenant.objects.create(
            tenant=tenant,
            utilisateur=createur,
            role=RoleAdhesion.PROPRIETAIRE,
            statut=StatutAdhesion.ACTIVE,
            cree_par=createur,
        )
        _journaliser(
            action="adhesion.creee",
            objet=adhesion,
            acteur=createur,
            tenant=tenant,
            details={"role": adhesion.role},
        )
        tenant = transitionner_tenant(
            tenant.pk,
            StatutTenant.ACTIF,
            acteur=createur,
            motif="Provisionnement initial terminé.",
        )
        return tenant, adhesion, True


def creer_invitation(
    *,
    tenant: Tenant,
    invite_par,
    email: str,
    role: str,
) -> tuple[InvitationTenant, str]:
    """Crée une invitation à durée limitée et ne retourne le jeton brut qu’une fois."""
    if role not in RoleAdhesion.values or role == RoleAdhesion.PROPRIETAIRE:
        raise DjangoValidationError("Le rôle demandé ne peut pas être attribué par invitation.")
    if tenant.statut != StatutTenant.ACTIF:
        raise DjangoValidationError("Seul un tenant actif peut inviter des membres.")

    adresse = CompteUtilisateur.objects.normalize_email(email.strip()).casefold()
    if not adresse:
        raise DjangoValidationError("Une adresse e-mail est obligatoire.")
    with transaction.atomic():
        compte_existant = CompteUtilisateur.objects.filter(email=adresse).first()
        if compte_existant and not compte_existant.is_active:
            raise DjangoValidationError("Ce compte est désactivé.")
        if (
            compte_existant
            and AdhesionTenant.objects.filter(
                tenant=tenant,
                utilisateur=compte_existant,
            ).exists()
        ):
            raise DjangoValidationError(
                "Ce compte possède déjà une adhésion ; un administrateur doit la réactiver."
            )
        invitations_existantes = InvitationTenant.objects.select_for_update().filter(
            tenant=tenant,
            email=adresse,
            statut=StatutInvitation.EN_ATTENTE,
        )
        for existante in invitations_existantes:
            if existante.expire_le > timezone.now():
                raise DjangoValidationError("Une invitation active existe déjà pour cette adresse.")
            existante.statut = StatutInvitation.EXPIREE
            existante.save(update_fields=("statut",))
            _journaliser(
                action="invitation.expiree",
                objet=existante,
                acteur=invite_par,
                tenant=tenant,
            )

        jeton = secrets.token_urlsafe(32)
        try:
            with transaction.atomic():
                invitation = InvitationTenant.objects.create(
                    tenant=tenant,
                    email=adresse,
                    role=role,
                    empreinte_jeton=hashlib.sha256(jeton.encode("utf-8")).hexdigest(),
                    expire_le=timezone.now() + DUREE_INVITATION,
                    invite_par=invite_par,
                )
        except IntegrityError as error:
            raise DjangoValidationError(
                "Une invitation active existe déjà pour cette adresse."
            ) from error
        _journaliser(
            action="invitation.creee",
            objet=invitation,
            acteur=invite_par,
            tenant=tenant,
            details={"role": role},
        )
        return invitation, jeton


def modifier_adhesion(
    *,
    tenant: Tenant,
    adhesion_id: uuid.UUID,
    acteur,
    role: str | None = None,
    statut: str | None = None,
) -> AdhesionTenant:
    """Modifie une adhésion du tenant sans permettre la révocation de son propriétaire."""
    with transaction.atomic():
        adhesion = (
            AdhesionTenant.objects.select_for_update().filter(tenant=tenant, pk=adhesion_id).first()
        )
        if adhesion is None:
            raise AdhesionTenant.DoesNotExist
        if adhesion.role == RoleAdhesion.PROPRIETAIRE:
            raise DjangoValidationError(
                "Le propriétaire doit être transféré par un workflow dédié."
            )
        if role is not None:
            if role not in RoleAdhesion.values or role == RoleAdhesion.PROPRIETAIRE:
                raise DjangoValidationError("Le rôle demandé ne peut pas être attribué.")
            adhesion.role = role
        if statut is not None:
            if statut not in StatutAdhesion.values:
                raise DjangoValidationError("Le statut d’adhésion est invalide.")
            adhesion.statut = statut
        adhesion.save(update_fields=("role", "statut", "modifie_le"))
        _journaliser(
            action="adhesion.modifiee",
            objet=adhesion,
            acteur=acteur,
            tenant=tenant,
            details={"role": adhesion.role, "statut": adhesion.statut},
        )
        return adhesion


def verifier_invitation(jeton: str) -> InvitationTenant:
    """Vérifie un jeton sans le modifier et ne révèle aucune adresse e-mail."""
    empreinte = hashlib.sha256(jeton.encode("utf-8")).hexdigest()
    invitation = (
        InvitationTenant.objects.select_related("tenant")
        .filter(
            empreinte_jeton=empreinte,
            statut=StatutInvitation.EN_ATTENTE,
        )
        .first()
    )
    if invitation is None or invitation.expire_le <= timezone.now():
        raise DjangoValidationError("Cette invitation est invalide ou expirée.")
    return invitation


def accepter_invitation(*, jeton: str, mot_de_passe: str = "") -> tuple[CompteUtilisateur, bool]:
    """Vérifie l’adresse par le jeton, crée le compte si nécessaire et active l’adhésion."""
    empreinte = hashlib.sha256(jeton.encode("utf-8")).hexdigest()
    invitation_expiree = False

    with transaction.atomic():
        invitation = (
            InvitationTenant.objects.select_for_update()
            .select_related("tenant")
            .filter(empreinte_jeton=empreinte)
            .first()
        )
        if invitation is None:
            raise DjangoValidationError("Cette invitation est invalide.")
        if invitation.statut == StatutInvitation.ACCEPTEE:
            compte = CompteUtilisateur.objects.get(pk=invitation.acceptee_par_id)
            return compte, False
        if invitation.statut != StatutInvitation.EN_ATTENTE:
            raise DjangoValidationError("Cette invitation n’est plus disponible.")
        if invitation.expire_le <= timezone.now():
            invitation.statut = StatutInvitation.EXPIREE
            invitation.save(update_fields=("statut",))
            _journaliser(
                action="invitation.expiree",
                objet=invitation,
                acteur=None,
                tenant=invitation.tenant,
            )
            invitation_expiree = True
        elif invitation.tenant.statut != StatutTenant.ACTIF:
            raise DjangoValidationError("Ce tenant n’accepte plus d’invitations.")
        else:
            compte = CompteUtilisateur.objects.filter(email=invitation.email).first()
            nouveau_compte = compte is None
            if nouveau_compte:
                if not mot_de_passe:
                    raise DjangoValidationError(
                        {"mot_de_passe": "Un mot de passe est requis pour créer le compte."}
                    )
                compte = CompteUtilisateur(email=invitation.email)
                try:
                    password_validation.validate_password(mot_de_passe, compte)
                except DjangoValidationError as erreur:
                    raise DjangoValidationError({"mot_de_passe": erreur.messages}) from erreur
                compte = CompteUtilisateur.objects.create_user(
                    invitation.email,
                    mot_de_passe,
                    email_verifie_le=timezone.now(),
                )
            else:
                if not compte.is_active:
                    raise DjangoValidationError("Ce compte est désactivé.")
                if compte.email_verifie_le is None:
                    compte.email_verifie_le = timezone.now()
                    compte.save(update_fields=("email_verifie_le",))

            adhesion, adhesion_creee = AdhesionTenant.objects.get_or_create(
                tenant=invitation.tenant,
                utilisateur=compte,
                defaults={
                    "role": invitation.role,
                    "statut": StatutAdhesion.ACTIVE,
                    "cree_par": invitation.invite_par,
                },
            )
            if not adhesion_creee and adhesion.statut != StatutAdhesion.ACTIVE:
                raise DjangoValidationError("Une adhésion non active existe déjà.")

            invitation.statut = StatutInvitation.ACCEPTEE
            invitation.acceptee_par = compte
            invitation.acceptee_le = timezone.now()
            invitation.save(update_fields=("statut", "acceptee_par", "acceptee_le"))
            _journaliser(
                action="invitation.acceptee",
                objet=invitation,
                acteur=compte,
                tenant=invitation.tenant,
                details={"role": invitation.role},
            )
            if adhesion_creee:
                _journaliser(
                    action="adhesion.creee",
                    objet=adhesion,
                    acteur=compte,
                    tenant=invitation.tenant,
                    details={"role": adhesion.role},
                )

    if invitation_expiree:
        raise DjangoValidationError("Cette invitation est invalide ou expirée.")
    return compte, nouveau_compte


def revoquer_invitation(invitation_id: uuid.UUID, *, motif: str) -> None:
    """Révoque une invitation dont l’e-mail n’a pas pu être distribué."""
    with transaction.atomic():
        invitation = InvitationTenant.objects.select_for_update().get(pk=invitation_id)
        if invitation.statut != StatutInvitation.EN_ATTENTE:
            return
        invitation.statut = StatutInvitation.REVOQUEE
        invitation.save(update_fields=("statut",))
        _journaliser(
            action="invitation.revoquee",
            objet=invitation,
            acteur=None,
            tenant=invitation.tenant,
            motif=motif,
        )


def creer_demande_inscription_tenant(
    *,
    email: str,
    mot_de_passe: str,
    prenom: str,
    nom: str,
    nom_tenant: str,
    type_educatif: str,
    pays: str,
    telephone: str,
    effectif_apprenants: int,
    plan_id: uuid.UUID,
) -> tuple[DemandeInscriptionTenant, str]:
    """Crée le compte et le tenant en demande, sans adhésion ni accès prématuré."""
    from applications.abonnements.models import PlanSaaS

    adresse = CompteUtilisateur.objects.normalize_email(email.strip()).casefold()
    nom_normalise = nom_tenant.strip()
    if not adresse or not nom_normalise:
        raise DjangoValidationError("L’adresse e-mail et le nom de l’établissement sont requis.")
    if effectif_apprenants < 0:
        raise DjangoValidationError("L’effectif ne peut pas être négatif.")

    compte = CompteUtilisateur(email=adresse, first_name=prenom.strip(), last_name=nom.strip())
    try:
        password_validation.validate_password(mot_de_passe, compte)
    except DjangoValidationError as erreur:
        raise DjangoValidationError({"mot_de_passe": erreur.messages}) from erreur

    with transaction.atomic():
        try:
            plan = PlanSaaS.objects.select_for_update().get(pk=plan_id, actif=True)
        except PlanSaaS.DoesNotExist as erreur:
            raise DjangoValidationError("Le forfait sélectionné n’est plus disponible.") from erreur
        compte = CompteUtilisateur.objects.create_user(
            adresse,
            mot_de_passe,
            first_name=prenom.strip(),
            last_name=nom.strip(),
            is_active=False,
        )
        tenant = Tenant.objects.create(
            nom=nom_normalise,
            statut=StatutTenant.DEMANDE,
            cle_idempotence=uuid.uuid4(),
            cree_par=compte,
        )
        jeton = secrets.token_urlsafe(32)
        demande = DemandeInscriptionTenant.objects.create(
            tenant=tenant,
            compte=compte,
            plan=plan,
            type_educatif=type_educatif,
            pays=pays,
            telephone=telephone.strip(),
            effectif_apprenants=effectif_apprenants,
            statut=StatutDemandeInscription.EMAIL_A_VERIFIER,
            empreinte_jeton=hashlib.sha256(jeton.encode("utf-8")).hexdigest(),
            jeton_expire_le=timezone.now() + DUREE_VERIFICATION_INSCRIPTION,
        )
        _journaliser(
            action="tenant.inscription_demandee",
            objet=demande,
            acteur=compte,
            tenant=tenant,
            details={"plan": plan.code},
        )
        return demande, jeton


def creer_demande_nouveau_tenant(
    *,
    compte,
    nom_tenant: str,
    type_educatif: str,
    pays: str,
    telephone: str,
    effectif_apprenants: int,
    plan_id: uuid.UUID,
) -> DemandeInscriptionTenant:
    """Ouvre un tenant lié au compte vérifié d’un propriétaire existant."""
    if compte.email_verifie_le is None:
        raise DjangoValidationError("L’adresse e-mail du propriétaire doit être vérifiée.")
    if effectif_apprenants < 1:
        raise DjangoValidationError("L’effectif doit être supérieur à zéro.")
    if not AdhesionTenant.objects.filter(
        utilisateur=compte,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
        tenant__statut__in=(StatutTenant.ACTIF, StatutTenant.RESTREINT),
        tenant__institution__isnull=False,
    ).exists():
        raise DjangoValidationError(
            "Seul le propriétaire d’un établissement actif peut en créer un autre."
        )

    from applications.abonnements.models import PlanSaaS

    with transaction.atomic():
        plan = (
            PlanSaaS.objects.select_for_update()
            .filter(pk=plan_id, actif=True)
            .first()
        )
        if plan is None:
            raise DjangoValidationError("Le forfait sélectionné n’est plus disponible.")

        maintenant = timezone.now()
        jeton = secrets.token_urlsafe(32)
        tenant = Tenant.objects.create(
            nom=nom_tenant.strip(),
            statut=StatutTenant.DEMANDE,
            cle_idempotence=uuid.uuid4(),
            cree_par=compte,
        )
        demande = DemandeInscriptionTenant.objects.create(
            tenant=tenant,
            compte=compte,
            plan=plan,
            type_educatif=type_educatif,
            pays=pays,
            telephone=telephone.strip(),
            effectif_apprenants=effectif_apprenants,
            statut=StatutDemandeInscription.EN_ATTENTE,
            empreinte_jeton=hashlib.sha256(jeton.encode("utf-8")).hexdigest(),
            jeton_expire_le=maintenant + DUREE_VERIFICATION_INSCRIPTION,
            email_verifie_le=compte.email_verifie_le,
        )
        _journaliser(
            action="tenant.inscription_demandee",
            objet=demande,
            acteur=compte,
            tenant=tenant,
            details={"plan": plan.code, "compte_existant": True},
        )
        if plan.est_gratuit:
            traiter_demande_inscription_tenant(
                demande.pk,
                acteur=compte,
                approuver=True,
                motif="Création par un propriétaire déjà vérifié avec le forfait gratuit.",
            )
            demande.refresh_from_db()
        return demande


def verifier_email_demande_inscription(jeton: str) -> DemandeInscriptionTenant:
    """Vérifie l’adresse e-mail associée à un jeton de demande non expiré."""
    empreinte = hashlib.sha256(jeton.encode("utf-8")).hexdigest()
    with transaction.atomic():
        demande = (
            DemandeInscriptionTenant.objects.select_for_update()
            .select_related("compte", "tenant", "plan")
            .filter(empreinte_jeton=empreinte)
            .first()
        )
        if demande is None:
            raise DjangoValidationError("Ce lien de vérification est invalide.")
        if demande.statut == StatutDemandeInscription.EMAIL_A_VERIFIER:
            if demande.jeton_expire_le <= timezone.now():
                raise DjangoValidationError("Ce lien de vérification a expiré.")

            maintenant = timezone.now()
            compte = CompteUtilisateur.objects.select_for_update().get(pk=demande.compte_id)
            compte.email_verifie_le = maintenant
            compte.save(update_fields=("email_verifie_le",))
            demande.statut = StatutDemandeInscription.EN_ATTENTE
            demande.email_verifie_le = maintenant
            demande.save(update_fields=("statut", "email_verifie_le"))
            _journaliser(
                action="tenant.inscription_email_verifie",
                objet=demande,
                acteur=compte,
                tenant=demande.tenant,
            )
        elif not (
            demande.statut == StatutDemandeInscription.EN_ATTENTE and demande.plan.est_gratuit
        ):
            return demande
    if demande.statut == StatutDemandeInscription.EN_ATTENTE and demande.plan.est_gratuit:
        return traiter_demande_inscription_tenant(
            demande.pk,
            acteur=None,
            approuver=True,
            motif="Activation automatique du plan gratuit après vérification de l’adresse.",
        )
    return demande


def obtenir_demande_verification_email(jeton: str) -> DemandeInscriptionTenant:
    """Charge une demande associée au lien sans confirmer l’adresse par un simple GET."""
    empreinte = hashlib.sha256(jeton.encode("utf-8")).hexdigest()
    demande = (
        DemandeInscriptionTenant.objects.select_related("compte", "tenant", "plan")
        .filter(empreinte_jeton=empreinte)
        .first()
    )
    if demande is None:
        raise DjangoValidationError("Ce lien de vérification est invalide.")
    if (
        demande.statut == StatutDemandeInscription.EMAIL_A_VERIFIER
        and demande.jeton_expire_le <= timezone.now()
    ):
        raise DjangoValidationError("Ce lien de vérification a expiré.")
    return demande


def traiter_demande_inscription_tenant(
    demande_id: uuid.UUID,
    *,
    acteur,
    approuver: bool,
    motif: str = "",
) -> DemandeInscriptionTenant:
    """Valide ou refuse une demande, avec provisioning audité à l’approbation."""
    with transaction.atomic():
        demande = (
            DemandeInscriptionTenant.objects.select_for_update()
            .select_related("compte", "tenant", "plan")
            .get(pk=demande_id)
        )
        if demande.statut != StatutDemandeInscription.EN_ATTENTE:
            raise DjangoValidationError("Seule une demande vérifiée en attente peut être traitée.")

        if approuver:
            if not demande.plan.actif:
                raise DjangoValidationError(
                    "Le forfait choisi n’est plus actif; la demande ne peut pas être validée."
                )
            if demande.compte.email_verifie_le is None:
                raise DjangoValidationError("L’adresse e-mail du responsable n’est pas vérifiée.")
            if demande.tenant.statut not in (
                StatutTenant.DEMANDE,
                StatutTenant.PROVISIONNEMENT,
                StatutTenant.ACTIF,
            ):
                raise DjangoValidationError("Le tenant n’est plus dans l’état de demande.")

            tenant = demande.tenant
            if tenant.statut == StatutTenant.DEMANDE:
                tenant = transitionner_tenant(
                    demande.tenant_id,
                    StatutTenant.PROVISIONNEMENT,
                    acteur=acteur,
                    motif="Demande d’inscription validée.",
                )

            Institution.objects.get_or_create(
                tenant=tenant,
                defaults={
                    "cle_idempotence": uuid.uuid4(),
                    "nom": tenant.nom,
                    "type_educatif": demande.type_educatif,
                    "pays": demande.pays,
                    "cree_par": demande.compte,
                },
            )
            adhesion = AdhesionTenant.objects.filter(
                tenant=tenant,
                utilisateur=demande.compte,
            ).first()
            if adhesion is None:
                AdhesionTenant.objects.create(
                    tenant=tenant,
                    utilisateur=demande.compte,
                    role=RoleAdhesion.PROPRIETAIRE,
                    statut=StatutAdhesion.ACTIVE,
                    cree_par=demande.compte,
                )
            elif (
                adhesion.role != RoleAdhesion.PROPRIETAIRE
                or adhesion.statut != StatutAdhesion.ACTIVE
            ):
                raise DjangoValidationError(
                    "L’adhésion existante du responsable doit être vérifiée avant validation."
                )
            demande.compte.is_active = True
            demande.compte.save(update_fields=("is_active",))
            demande.statut = StatutDemandeInscription.VALIDEE
            if demande.plan.est_gratuit:
                from applications.abonnements.services import creer_abonnement_gratuit

                creer_abonnement_gratuit(
                    tenant=tenant,
                    plan=demande.plan,
                    cree_par=demande.compte,
                )
                tenant = transitionner_tenant(
                    tenant.pk,
                    StatutTenant.ACTIF,
                    acteur=None,
                    motif="Activation automatique du plan gratuit.",
                )
            action = "tenant.inscription_validee"
        else:
            if not motif.strip():
                raise DjangoValidationError("Un motif est obligatoire pour refuser une demande.")
            demande.statut = StatutDemandeInscription.REFUSEE
            action = "tenant.inscription_refusee"

        demande.traitee_par = acteur
        demande.traitee_le = timezone.now()
        demande.motif_decision = motif.strip()
        demande.save(update_fields=("statut", "traitee_par", "traitee_le", "motif_decision"))
        _journaliser(
            action=action,
            objet=demande,
            acteur=acteur,
            tenant=demande.tenant,
            motif=motif,
            details={"plan": demande.plan.code},
        )
        return demande
