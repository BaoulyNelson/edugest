import logging
from smtplib import SMTPException

from django.conf import settings
from django.contrib import admin, messages
from django.core.exceptions import ValidationError as DjangoValidationError
from django.core.mail import send_mail
from django.urls import reverse

from applications.organisations.models import (
    AdhesionTenant,
    DemandeInscriptionTenant,
    EvenementAudit,
    InvitationTenant,
    Tenant,
)
from applications.organisations.services import traiter_demande_inscription_tenant

logger = logging.getLogger(__name__)

admin.site.register((AdhesionTenant, InvitationTenant, EvenementAudit))


@admin.register(Tenant)
class TenantAdmin(admin.ModelAdmin):
    readonly_fields = ("statut",)


@admin.register(DemandeInscriptionTenant)
class DemandeInscriptionTenantAdmin(admin.ModelAdmin):
    list_display = (
        "tenant",
        "email_responsable",
        "plan",
        "statut",
        "cree_le",
    )
    list_filter = ("statut", "type_educatif", "pays")
    search_fields = ("tenant__nom", "compte__email", "plan__nom")
    list_select_related = ("tenant", "compte", "plan", "traitee_par")
    readonly_fields = (
        "id",
        "tenant",
        "compte",
        "plan",
        "type_educatif",
        "pays",
        "telephone",
        "effectif_apprenants",
        "statut",
        "empreinte_jeton",
        "jeton_expire_le",
        "email_verifie_le",
        "traitee_par",
        "traitee_le",
        "cree_le",
    )
    fields = readonly_fields + ("motif_decision",)
    actions = ("valider_demandes", "refuser_demandes")

    @admin.display(description="E-mail du responsable", ordering="compte__email")
    def email_responsable(self, obj):
        return obj.compte.email

    @staticmethod
    def _operateur(request):
        return request.user.is_superuser or request.user.has_perm(
            "abonnements.gerer_abonnements_saas"
        )

    def has_module_permission(self, request):
        return self._operateur(request)

    def has_view_permission(self, request, obj=None):
        return self._operateur(request)

    def has_change_permission(self, request, obj=None):
        return self._operateur(request)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def get_queryset(self, request):
        return super().get_queryset(request).select_related(
            "tenant",
            "compte",
            "plan",
            "traitee_par",
        )

    def _notifier(self, request, demande, *, approuvee):
        if approuvee:
            subject = "Votre demande EduFlow a été validée"
            message = (
                f"Bonjour {demande.compte.get_full_name()},\n\n"
                f"Votre demande pour {demande.tenant.nom} a été validée. "
                "L’espace est en préparation. L’accès aux fonctionnalités sera ouvert "
                "après la mise en place et la confirmation de l’abonnement.\n\n"
                f"Connexion : {settings.EDUFLOW_BASE_URL}{reverse('connexion')}\n"
            )
        else:
            subject = "Mise à jour de votre demande EduFlow"
            message = (
                f"Bonjour {demande.compte.get_full_name()},\n\n"
                f"Votre demande pour {demande.tenant.nom} n’a pas été retenue.\n"
                f"Motif : {demande.motif_decision}\n"
            )
        try:
            nombre_envoye = send_mail(
                subject=subject,
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[demande.compte.email],
                fail_silently=False,
            )
        except (OSError, SMTPException):
            logger.exception(
                "Échec de notification pour la demande tenant %s.",
                demande.pk,
            )
            self.message_user(
                request,
                f"La demande {demande.tenant.nom} a été traitée, mais l’e-mail n’a pas pu "
                "être distribué.",
                level=messages.ERROR,
            )
            return
        if nombre_envoye != 1:
            logger.error("Aucun e-mail distribué pour la demande tenant %s.", demande.pk)
            self.message_user(
                request,
                f"La demande {demande.tenant.nom} a été traitée, mais l’e-mail n’a pas pu "
                "être distribué.",
                level=messages.ERROR,
            )

    @admin.action(description="Valider les demandes vérifiées et préparer leur espace")
    def valider_demandes(self, request, queryset):
        for demande in queryset:
            try:
                demande = traiter_demande_inscription_tenant(
                    demande.pk,
                    acteur=request.user,
                    approuver=True,
                )
            except DjangoValidationError as erreur:
                self.message_user(
                    request,
                    f"{demande.tenant.nom} : {' '.join(erreur.messages)}",
                    level=messages.ERROR,
                )
                continue
            self._notifier(request, demande, approuvee=True)
            self.message_user(request, f"Demande validée : {demande.tenant.nom}.")

    @admin.action(
        description=(
            "Refuser les demandes sélectionnées "
            "(saisir et enregistrer le motif dans chaque dossier avant cette action)"
        )
    )
    def refuser_demandes(self, request, queryset):
        for demande in queryset:
            try:
                demande = traiter_demande_inscription_tenant(
                    demande.pk,
                    acteur=request.user,
                    approuver=False,
                    motif=demande.motif_decision,
                )
            except DjangoValidationError as erreur:
                self.message_user(
                    request,
                    f"{demande.tenant.nom} : {' '.join(erreur.messages)}",
                    level=messages.ERROR,
                )
                continue
            self._notifier(request, demande, approuvee=False)
            self.message_user(request, f"Demande refusée : {demande.tenant.nom}.")
