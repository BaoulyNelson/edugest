"""Routes Django classiques du parcours d’inscription tenant."""

from django.urls import path

from applications.organisations import views

app_name = "parcours_tenant"

urlpatterns = [
    path("", views.accueil_public, name="accueil"),
    path("creer-etablissement/", views.demande_inscription, name="inscription"),
    path(
        "espace/mes-etablissements/",
        views.mes_etablissements,
        name="mes-etablissements",
    ),
    path(
        "espace/mes-etablissements/<uuid:tenant_id>/",
        views.profil_etablissement,
        name="profil-etablissement",
    ),
    path("verifier-inscription/<str:jeton>/", views.verifier_email, name="verifier-email"),
    path("invitation/accepter/", views.accepter_invitation_web, name="accepter-invitation"),
    path("espace/equipe/", views.equipe_tenant, name="equipe"),
]
