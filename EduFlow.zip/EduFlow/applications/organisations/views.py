"""Vues Django classiques des pages publiques et du parcours d’inscription."""

import logging
from smtplib import SMTPException
from urllib.parse import urlencode

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.exceptions import ValidationError as DjangoValidationError
from django.core.mail import send_mail
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Count, Q, Sum
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.http import require_GET, require_http_methods

from applications.abonnements.models import (
    Abonnement,
    EnregistrementUsage,
    PlanSaaS,
    StatutAbonnement,
)
from applications.comptes.limites import (
    NOMBRE_MAX_TENTATIVES_IP,
    empreinte_requete,
    enregistrer_tentative,
    est_bloquee,
)
from applications.organisations.access import resoudre_adhesion_active
from applications.organisations.forms import (
    AcceptationInvitationForm,
    DemandeInscriptionForm,
    DemandeNouveauTenantForm,
    InvitationEquipeForm,
    ModificationAdhesionForm,
)
from applications.organisations.models import (
    AdhesionTenant,
    DemandeInscriptionTenant,
    EvenementAudit,
    InvitationTenant,
    RoleAdhesion,
    StatutAdhesion,
    StatutDemandeInscription,
    StatutInvitation,
    StatutTenant,
    Tenant,
)
from applications.organisations.services import (
    accepter_invitation,
    creer_demande_inscription_tenant,
    creer_demande_nouveau_tenant,
    creer_invitation,
    modifier_adhesion,
    obtenir_demande_verification_email,
    revoquer_invitation,
    verifier_email_demande_inscription,
    verifier_invitation,
)
from applications.personnes.models import ProfilApprenant, ProfilEnseignant
from applications.referentiels.models import (
    AnneeAcademique,
    Groupe,
    PeriodeAcademique,
    StatutAnneeAcademique,
)
from applications.referentiels.services import modifier_referentiel
from applications.tableau_de_bord.forms import FormulaireParametresEtablissement
from applications.tableau_de_bord.views import _contexte_espace

logger = logging.getLogger(__name__)
SESSION_TENANT_KEY = "eduflow_tenant_actif"


class DistributionEmailImpossible(Exception):
    """Le serveur de messagerie n’a accepté aucun destinataire."""


def _plans_publics():
    return PlanSaaS.objects.filter(actif=True).prefetch_related("droits").order_by("code")


def _sans_cache(
    response: HttpResponse,
    *,
    referrer_policy: str = "no-referrer",
) -> HttpResponse:
    response["Cache-Control"] = "no-store"
    response["Referrer-Policy"] = referrer_policy
    return response


@require_GET
def accueil_public(request):
    if request.user.is_authenticated:
        return redirect("tableau_de_bord:accueil")
    return render(request, "organisations/accueil_public.html", {"plans": _plans_publics()})


def _tenants_du_proprietaire(utilisateur):
    return Tenant.objects.filter(
        Q(
            adhesions__utilisateur=utilisateur,
            adhesions__role=RoleAdhesion.PROPRIETAIRE,
            adhesions__statut__in=(StatutAdhesion.ACTIVE, StatutAdhesion.SUSPENDUE),
        )
        | Q(demande_inscription__compte=utilisateur)
    ).distinct()


def _compteurs_etablissements(tenant_ids):
    apprenants = {
        item["tenant_id"]: item["nombre"]
        for item in ProfilApprenant.objects.filter(tenant_id__in=tenant_ids)
        .values("tenant_id")
        .annotate(nombre=Count("pk"))
    }
    enseignants = {
        item["tenant_id"]: item["nombre"]
        for item in ProfilEnseignant.objects.filter(
            tenant_id__in=tenant_ids,
            actif=True,
        )
        .values("tenant_id")
        .annotate(nombre=Count("pk"))
    }
    groupes = {
        item["tenant_id"]: item["nombre"]
        for item in Groupe.objects.filter(tenant_id__in=tenant_ids, actif=True)
        .values("tenant_id")
        .annotate(nombre=Count("pk"))
    }
    return {
        tenant_id: {
            "apprenants": apprenants.get(tenant_id, 0),
            "enseignants": enseignants.get(tenant_id, 0),
            "groupes": groupes.get(tenant_id, 0),
        }
        for tenant_id in tenant_ids
    }


def _contrats_etablissements(tenant_ids):
    contrats = (
        Abonnement.objects.filter(
            tenant_id__in=tenant_ids,
            statut__in=(StatutAbonnement.EN_ATTENTE, StatutAbonnement.ACTIF),
        )
        .select_related("plan")
        .order_by("tenant_id", "-cree_le")
    )
    contrats_par_tenant = {}
    for contrat in contrats:
        contrats_par_tenant.setdefault(contrat.tenant_id, contrat)
    return contrats_par_tenant


def _enrichir_etablissements(etablissements, tenant_ids):
    compteurs = _compteurs_etablissements(tenant_ids)
    contrats = _contrats_etablissements(tenant_ids)
    for etablissement in etablissements:
        etablissement.compteurs = compteurs.get(etablissement.pk, {})
        etablissement.contrat = contrats.get(etablissement.pk)
        demande = getattr(etablissement, "demande_inscription", None)
        etablissement.demande = demande
        etablissement.forfait_incoherent = bool(
            demande and etablissement.contrat and demande.plan_id != etablissement.contrat.plan_id
        )
    return etablissements


def _contexte_profil_etablissement(tenant):
    institution = getattr(tenant, "institution", None)
    if institution is None:
        return {
            "profil_completude": 0,
            "champs_profil": [],
            "droits_abonnement": [],
            "activite_recente": [],
            "annee_active": None,
            "periodes_actives": [],
        }

    champs_a_completer = (
        ("Nom court", institution.nom_court),
        ("Code officiel", institution.code_officiel),
        ("Directeur ou responsable", institution.responsable),
        ("Adresse", institution.adresse),
        ("Téléphone officiel", institution.telephone),
        ("E-mail officiel", institution.email_officiel),
        ("Logo", institution.logo),
        ("Signature ou cachet", institution.signature),
    )
    champs_profil = [{"nom": nom, "complete": bool(valeur)} for nom, valeur in champs_a_completer]
    profil_completude = round(
        100 * sum(champ["complete"] for champ in champs_profil) / len(champs_profil)
    )

    contrat = getattr(tenant, "contrat", None)
    droits_abonnement = []
    if contrat:
        usages = dict(
            EnregistrementUsage.objects.filter(abonnement=contrat)
            .values("droit_id")
            .annotate(total=Sum("quantite"))
            .values_list("droit_id", "total")
        )
        for droit in contrat.plan.droits.order_by("code"):
            droits_abonnement.append(
                {
                    "droit": droit,
                    "usage": usages.get(droit.pk, 0),
                    "pourcentage": (
                        min(100, round(100 * usages.get(droit.pk, 0) / droit.limite))
                        if droit.limite
                        else None
                    ),
                }
            )

    annee_active = AnneeAcademique.objects.filter(
        tenant=tenant,
        institution=institution,
        statut=StatutAnneeAcademique.ACTIVE,
    ).first()
    periodes_actives = (
        PeriodeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
            annee_academique=annee_active,
        )
        if annee_active
        else PeriodeAcademique.objects.none()
    )
    return {
        "profil_completude": profil_completude,
        "champs_profil": champs_profil,
        "droits_abonnement": droits_abonnement,
        "activite_recente": EvenementAudit.objects.filter(tenant=tenant)
        .select_related("acteur")
        .order_by("-cree_le")[:5],
        "annee_active": annee_active,
        "periodes_actives": periodes_actives,
    }


@login_required
@never_cache
@require_GET
def mes_etablissements(request):
    """Liste uniquement les tenants appartenant au propriétaire connecté."""
    tous_les_tenants = (
        _tenants_du_proprietaire(request.user)
        .select_related(
            "institution",
            "demande_inscription__plan",
        )
        .order_by("nom", "id")
    )
    tenant_ids_tous = list(tous_les_tenants.values_list("pk", flat=True))
    requetes = DemandeInscriptionTenant.objects.filter(
        tenant_id__in=tenant_ids_tous,
        statut__in=(StatutDemandeInscription.EMAIL_A_VERIFIER, StatutDemandeInscription.EN_ATTENTE),
    )
    terme = request.GET.get("q", "").strip()[:100]
    statut = request.GET.get("statut", "").strip()
    etablissements = tous_les_tenants
    if terme:
        etablissements = etablissements.filter(
            Q(nom__icontains=terme) | Q(institution__nom__icontains=terme)
        )
    if statut == "actif":
        etablissements = etablissements.filter(statut=StatutTenant.ACTIF)
    elif statut == "en_preparation":
        etablissements = etablissements.filter(
            Q(statut__in=(StatutTenant.DEMANDE, StatutTenant.PROVISIONNEMENT))
            | Q(
                demande_inscription__statut__in=(
                    StatutDemandeInscription.EMAIL_A_VERIFIER,
                    StatutDemandeInscription.EN_ATTENTE,
                ),
            )
        )
    page = Paginator(etablissements, 12).get_page(request.GET.get("page"))
    tenant_ids_page = [tenant.pk for tenant in page.object_list]
    page.object_list = _enrichir_etablissements(page.object_list, tenant_ids_page)

    totaux = _compteurs_etablissements(tenant_ids_tous)
    return _sans_cache(
        render(
            request,
            "organisations/mes_etablissements.html",
            {
                **_contexte_espace(request),
                "page": page,
                "terme": terme,
                "statut_selectionne": statut,
                "nombre_etablissements": len(tenant_ids_tous),
                "nombre_actifs": tous_les_tenants.filter(statut=StatutTenant.ACTIF).count(),
                "nombre_en_preparation": requetes.count(),
                "total_apprenants": sum(item["apprenants"] for item in totaux.values()),
                "total_enseignants": sum(item["enseignants"] for item in totaux.values()),
                "total_groupes": sum(item["groupes"] for item in totaux.values()),
                "tenant_actif_id": request.session.get(SESSION_TENANT_KEY),
                "adhesions_gerables": {
                    str(tenant_id)
                    for tenant_id in AdhesionTenant.objects.filter(
                        utilisateur=request.user,
                        role=RoleAdhesion.PROPRIETAIRE,
                        statut=StatutAdhesion.ACTIVE,
                        tenant__institution__isnull=False,
                    ).values_list("tenant_id", flat=True)
                },
            },
        ),
        referrer_policy="same-origin",
    )


@login_required
@never_cache
@require_http_methods(["GET", "POST"])
def profil_etablissement(request, tenant_id):
    """Affiche ou modifie les informations d’un établissement du propriétaire."""
    tenant = get_object_or_404(
        _tenants_du_proprietaire(request.user).select_related(
            "institution", "demande_inscription__plan"
        ),
        pk=tenant_id,
    )
    institution = getattr(tenant, "institution", None)
    proprietaire_actif = AdhesionTenant.objects.filter(
        tenant=tenant,
        utilisateur=request.user,
        role=RoleAdhesion.PROPRIETAIRE,
        statut=StatutAdhesion.ACTIVE,
    ).exists()
    if request.method == "POST" and (not proprietaire_actif or institution is None):
        raise PermissionDenied(
            "Seul le propriétaire actif peut modifier les informations de l’établissement."
        )

    _enrichir_etablissements([tenant], [tenant.pk])
    formulaire = None
    if institution:
        formulaire = FormulaireParametresEtablissement(
            request.POST if request.method == "POST" else None,
            request.FILES if request.method == "POST" else None,
            instance=institution,
        )
        if request.method == "POST" and formulaire.is_valid():
            try:
                modifier_referentiel(
                    objet=formulaire.instance,
                    acteur=request.user,
                    valeurs=formulaire.cleaned_data,
                )
            except DjangoValidationError as erreur:
                if hasattr(erreur, "message_dict"):
                    for champ, erreurs in erreur.message_dict.items():
                        formulaire.add_error(
                            champ if champ in formulaire.fields else None,
                            erreurs,
                        )
                else:
                    formulaire.add_error(None, erreur.messages)
            else:
                messages.success(
                    request,
                    "Les informations de l’établissement ont été mises à jour.",
                )
                return redirect(
                    "parcours_tenant:profil-etablissement",
                    tenant_id=tenant.pk,
                )

    return _sans_cache(
        render(
            request,
            "organisations/profil_etablissement.html",
            {
                **_contexte_espace(request),
                "etablissement": tenant,
                "tenant_actif_id": request.session.get(SESSION_TENANT_KEY),
                "formulaire": formulaire,
                "institution": institution,
                "proprietaire_actif": proprietaire_actif,
                **_contexte_profil_etablissement(tenant),
            },
        ),
        referrer_policy="same-origin",
    )


@never_cache
@sensitive_post_parameters("mot_de_passe", "confirmation_mot_de_passe")
@require_http_methods(["GET", "POST"])
def demande_inscription(request):
    if request.user.is_authenticated:
        if not AdhesionTenant.objects.filter(
            utilisateur=request.user,
            role=RoleAdhesion.PROPRIETAIRE,
            statut=StatutAdhesion.ACTIVE,
            tenant__statut__in=(StatutTenant.ACTIF, StatutTenant.RESTREINT),
            tenant__institution__isnull=False,
        ).exists():
            raise PermissionDenied(
                "Seul le propriétaire d’un établissement actif peut en créer un autre."
            )
        if request.user.email_verifie_le is None:
            raise PermissionDenied("Vérifiez votre adresse e-mail avant de créer un établissement.")

        contexte_navigation = _contexte_espace(request)
        plans = _plans_publics()
        form = DemandeNouveauTenantForm(request.POST or None)
        if request.method == "POST":
            empreinte_ip = empreinte_requete(
                action="nouveau-tenant-proprietaire",
                identifiant=request.user.email,
                adresse_ip=request.META.get("REMOTE_ADDR", ""),
            )
            if est_bloquee(empreinte_ip):
                return _sans_cache(
                    render(
                        request,
                        "organisations/demande_inscription_limitee.html",
                        contexte_navigation,
                        status=429,
                    ),
                    referrer_policy="same-origin",
                )
            enregistrer_tentative(
                empreinte_ip,
                nombre_max=NOMBRE_MAX_TENTATIVES_IP,
            )
            if plans and form.is_valid():
                try:
                    demande = creer_demande_nouveau_tenant(
                        compte=request.user,
                        nom_tenant=form.cleaned_data["nom_etablissement"],
                        type_educatif=form.cleaned_data["type_educatif"],
                        pays=form.cleaned_data["pays"],
                        telephone=form.cleaned_data["telephone"],
                        effectif_apprenants=form.cleaned_data["effectif_apprenants"],
                        plan_id=form.cleaned_data["plan"].pk,
                    )
                except DjangoValidationError as erreur:
                    if hasattr(erreur, "message_dict"):
                        for champ, erreurs in erreur.message_dict.items():
                            form.add_error(champ if champ in form.fields else None, erreurs)
                    else:
                        form.add_error(None, erreur.messages)
                except IntegrityError:
                    logger.exception("Conflit lors de la création d’un tenant par un propriétaire.")
                    form.add_error(
                        None,
                        "La demande n’a pas pu être créée. Réessayez ou contactez EduFlow.",
                    )
                else:
                    acces_ouvert = demande.statut == StatutDemandeInscription.VALIDEE
                    if acces_ouvert:
                        request.session[SESSION_TENANT_KEY] = str(demande.tenant_id)
                    return _sans_cache(
                        render(
                            request,
                            "organisations/demande_tenant_confirmee.html",
                            {
                                **contexte_navigation,
                                "demande": demande,
                                "acces_ouvert": acces_ouvert,
                            },
                        ),
                        referrer_policy="same-origin",
                    )

        return _sans_cache(
            render(
                request,
                "organisations/demande_tenant_connectee.html",
                {
                    **contexte_navigation,
                    "form": form,
                    "plans_disponibles": plans.exists(),
                },
            ),
            referrer_policy="same-origin",
        )

    plans = _plans_publics()
    initial = {}
    if request.method == "GET" and request.GET.get("plan"):
        plan = plans.filter(pk=request.GET["plan"]).first()
        if plan is not None:
            initial["plan"] = plan
    form = DemandeInscriptionForm(request.POST or None, initial=initial)
    if request.method == "POST":
        empreinte_ip = empreinte_requete(
            action="inscription-tenant",
            identifiant="",
            adresse_ip=request.META.get("REMOTE_ADDR", ""),
        )
        if est_bloquee(empreinte_ip):
            response = render(
                request,
                "organisations/demande_inscription_limitee.html",
                status=429,
            )
            return _sans_cache(response, referrer_policy="same-origin")
        enregistrer_tentative(
            empreinte_ip,
            nombre_max=NOMBRE_MAX_TENTATIVES_IP,
        )
    if request.method == "POST" and plans:
        if form.is_valid():
            try:
                with transaction.atomic():
                    demande, jeton = creer_demande_inscription_tenant(
                        email=form.cleaned_data["email"],
                        mot_de_passe=form.cleaned_data["mot_de_passe"],
                        prenom=form.cleaned_data["prenom_responsable"],
                        nom=form.cleaned_data["nom_responsable"],
                        nom_tenant=form.cleaned_data["nom_etablissement"],
                        type_educatif=form.cleaned_data["type_educatif"],
                        pays=form.cleaned_data["pays"],
                        telephone=form.cleaned_data["telephone"],
                        effectif_apprenants=form.cleaned_data["effectif_apprenants"],
                        plan_id=form.cleaned_data["plan"].pk,
                    )
                    url_verification = (
                        f"{settings.EDUFLOW_BASE_URL}"
                        f"{reverse('parcours_tenant:verifier-email', args=(jeton,))}"
                    )
                    nombre_envoye = send_mail(
                        subject="Confirmez votre adresse e-mail — EduFlow",
                        message=(
                            "Bonjour,\n\n"
                            "Pour confirmer l’adresse e-mail du responsable de "
                            f"{demande.tenant.nom}, ouvrez ce lien dans les 24 heures :\n"
                            f"{url_verification}\n\n"
                            + (
                                "Après confirmation, le plan gratuit sera activé "
                                "automatiquement pour sept jours et vous pourrez vous "
                                "connecter. Aucun paiement n’est initié.\n"
                                if demande.plan.est_gratuit
                                else "Après confirmation, votre demande sera examinée par "
                                "EduFlow. La création de la demande n’active ni "
                                "l’établissement ni un abonnement et aucun paiement n’est "
                                "initié.\n"
                            )
                        ),
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        recipient_list=[demande.compte.email],
                        fail_silently=False,
                    )
                    if nombre_envoye != 1:
                        raise DistributionEmailImpossible
            except DjangoValidationError as erreur:
                if hasattr(erreur, "message_dict"):
                    for champ, erreurs in erreur.message_dict.items():
                        form.add_error(champ if champ in form.fields else None, erreurs)
                else:
                    form.add_error(None, erreur.messages)
            except IntegrityError:
                logger.exception("Conflit lors de la création d’une demande d’inscription.")
                form.add_error(
                    "email",
                    "Cette demande n’a pas pu être créée. Vérifiez l’adresse saisie ou "
                    "contactez EduFlow.",
                )
            except (OSError, SMTPException, DistributionEmailImpossible):
                logger.exception("Échec d’envoi de l’e-mail de vérification EduFlow.")
                response = render(
                    request,
                    "organisations/inscription_email_erreur.html",
                    status=503,
                )
                return _sans_cache(response, referrer_policy="same-origin")
            else:
                response = render(
                    request,
                    "organisations/inscription_email_envoye.html",
                    {"email": demande.compte.email},
                )
                return _sans_cache(response, referrer_policy="same-origin")

    response = render(
        request,
        "organisations/demande_inscription.html",
        {"form": form, "plans_disponibles": plans.exists()},
    )
    return _sans_cache(response, referrer_policy="same-origin")


@never_cache
@require_http_methods(["GET", "POST"])
def verifier_email(request, jeton):
    if request.method == "GET":
        try:
            demande = obtenir_demande_verification_email(jeton)
        except DjangoValidationError as erreur:
            response = render(
                request,
                "organisations/inscription_verification.html",
                {"erreur": " ".join(erreur.messages)},
                status=400,
            )
            return _sans_cache(response, referrer_policy="same-origin")
        response = render(
            request,
            "organisations/inscription_verification.html",
            {
                "demande": demande,
                "confirmation_requise": demande.statut == "email_a_verifier",
            },
        )
        return _sans_cache(response, referrer_policy="same-origin")

    try:
        demande = verifier_email_demande_inscription(jeton)
    except DjangoValidationError as erreur:
        response = render(
            request,
            "organisations/inscription_verification.html",
            {"erreur": " ".join(erreur.messages)},
            status=400,
        )
        return _sans_cache(response, referrer_policy="same-origin")

    response = render(
        request,
        "organisations/inscription_verification.html",
        {
            "demande": demande,
            "confirmation_terminee": True,
            "acces_ouvert": demande.statut == StatutDemandeInscription.VALIDEE,
        },
    )
    return _sans_cache(response, referrer_policy="same-origin")


def _adhesion_equipe(request):
    tenant_id = request.session.get(SESSION_TENANT_KEY)
    if not tenant_id:
        tenant_ids = list(
            AdhesionTenant.objects.filter(
                utilisateur=request.user,
                statut=StatutAdhesion.ACTIVE,
                tenant__statut=StatutTenant.ACTIF,
            ).values_list("tenant_id", flat=True)[:2]
        )
        if len(tenant_ids) == 1:
            tenant_id = str(tenant_ids[0])
            request.session[SESSION_TENANT_KEY] = tenant_id
        else:
            messages.info(request, "Choisissez un établissement pour gérer son équipe.")
            raise Http404

    adhesion = resoudre_adhesion_active(request.user, str(tenant_id))
    if adhesion.role not in (
        RoleAdhesion.PROPRIETAIRE,
        RoleAdhesion.ADMINISTRATEUR,
    ):
        raise PermissionDenied
    return adhesion


def _rendre_equipe(request, adhesion, *, invitation_form=None, adhesion_form=None):
    membres = (
        AdhesionTenant.objects.filter(tenant=adhesion.tenant)
        .select_related("utilisateur")
        .order_by("utilisateur__email", "pk")
    )
    invitations = InvitationTenant.objects.filter(
        tenant=adhesion.tenant,
        statut=StatutInvitation.EN_ATTENTE,
        expire_le__gt=timezone.now(),
    ).order_by("-cree_le")
    page_membres = Paginator(membres, 25).get_page(request.GET.get("page"))
    return render(
        request,
        "organisations/equipe.html",
        {
            "workspace": adhesion,
            "workspace_accessible": True,
            "role_gestion": True,
            "role_enseignant": False,
            "membres": [
                {
                    "adhesion": membre,
                    "form": (
                        adhesion_form
                        if adhesion_form is not None
                        and adhesion_form.prefix == f"adhesion-{membre.pk}"
                        else ModificationAdhesionForm(
                            prefix=f"adhesion-{membre.pk}",
                            initial={"role": membre.role, "statut": membre.statut},
                        )
                    ),
                }
                for membre in page_membres
            ],
            "page": page_membres,
            "invitations": invitations,
            "invitation_form": invitation_form or InvitationEquipeForm(),
            "adhesion_form": adhesion_form,
        },
    )


@login_required
@never_cache
@require_http_methods(["GET", "POST"])
def equipe_tenant(request):
    adhesion_courante = _adhesion_equipe(request)
    if request.method == "GET":
        return _rendre_equipe(request, adhesion_courante)

    if request.POST.get("action") == "inviter":
        form = InvitationEquipeForm(request.POST)
        if form.is_valid():
            try:
                invitation, jeton = creer_invitation(
                    tenant=adhesion_courante.tenant,
                    invite_par=request.user,
                    email=form.cleaned_data["email"],
                    role=form.cleaned_data["role"],
                )
            except DjangoValidationError as erreur:
                form.add_error(None, erreur.messages)
            else:
                url_acceptation = (
                    f"{settings.EDUFLOW_BASE_URL}"
                    f"{reverse('parcours_tenant:accepter-invitation')}"
                    f"?{urlencode({'jeton': jeton})}"
                )
                try:
                    nombre_envoye = send_mail(
                        subject=f"Invitation EduFlow — {adhesion_courante.tenant.nom}",
                        message=(
                            f"Vous êtes invité à rejoindre {adhesion_courante.tenant.nom} "
                            "dans EduFlow.\n\n"
                            f"Acceptez l’invitation avant le "
                            f"{invitation.expire_le:%Y-%m-%d %H:%M UTC} :\n"
                            f"{url_acceptation}\n\n"
                            "Ce lien est personnel et ne peut être utilisé qu’une seule fois."
                        ),
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        recipient_list=[invitation.email],
                        fail_silently=False,
                    )
                except (OSError, SMTPException):
                    revoquer_invitation(
                        invitation.pk,
                        motif="Échec de distribution de l’e-mail.",
                    )
                    logger.exception(
                        "Échec de distribution de l’invitation %s.",
                        invitation.pk,
                    )
                    form.add_error(
                        None,
                        "L’e-mail d’invitation n’a pas pu être distribué. Réessayez.",
                    )
                else:
                    if nombre_envoye != 1:
                        revoquer_invitation(
                            invitation.pk,
                            motif="Aucun destinataire n’a accepté l’e-mail.",
                        )
                        logger.error(
                            "Aucun e-mail distribué pour l’invitation %s.",
                            invitation.pk,
                        )
                        form.add_error(
                            None,
                            "L’e-mail d’invitation n’a pas pu être distribué. Réessayez.",
                        )
                    else:
                        messages.success(
                            request,
                            f"Invitation envoyée à {invitation.email}.",
                        )
                        return redirect("parcours_tenant:equipe")
        return _rendre_equipe(
            request,
            adhesion_courante,
            invitation_form=form,
        )

    if request.POST.get("action") == "modifier":
        membre = get_object_or_404(
            AdhesionTenant,
            tenant=adhesion_courante.tenant,
            pk=request.POST.get("adhesion_id"),
        )
        if membre.role == RoleAdhesion.PROPRIETAIRE:
            messages.error(
                request,
                "Le propriétaire ne peut pas être modifié depuis cette page.",
            )
            return redirect("parcours_tenant:equipe")

        form = ModificationAdhesionForm(
            request.POST,
            prefix=f"adhesion-{membre.pk}",
        )
        if form.is_valid():
            try:
                modifier_adhesion(
                    tenant=adhesion_courante.tenant,
                    adhesion_id=membre.pk,
                    acteur=request.user,
                    role=form.cleaned_data["role"],
                    statut=form.cleaned_data["statut"],
                )
            except DjangoValidationError as erreur:
                form.add_error(None, erreur.messages)
            else:
                messages.success(request, "Les accès du membre ont été mis à jour.")
                return redirect("parcours_tenant:equipe")
        return _rendre_equipe(
            request,
            adhesion_courante,
            adhesion_form=form,
        )

    raise Http404


@never_cache
@sensitive_post_parameters("mot_de_passe", "confirmation_mot_de_passe")
@require_http_methods(["GET", "POST"])
def accepter_invitation_web(request):
    jeton = request.GET.get("jeton", "") if request.method == "GET" else ""
    form = AcceptationInvitationForm(initial={"jeton": jeton})
    if request.method == "POST":
        empreinte = empreinte_requete(
            action="acceptation-invitation",
            identifiant="",
            adresse_ip=request.META.get("REMOTE_ADDR", ""),
        )
        if est_bloquee(empreinte):
            return _sans_cache(
                render(
                    request,
                    "organisations/accepter_invitation.html",
                    {
                        "erreur": "Trop de tentatives. Réessayez dans quelques minutes.",
                        "form": form,
                    },
                    status=429,
                ),
                referrer_policy="same-origin",
            )
        enregistrer_tentative(empreinte, nombre_max=NOMBRE_MAX_TENTATIVES_IP)
        form = AcceptationInvitationForm(request.POST)
        if not form.is_valid():
            invitation = None
            try:
                invitation = verifier_invitation(form.cleaned_data.get("jeton", ""))
            except DjangoValidationError:
                pass
            return _sans_cache(
                render(
                    request,
                    "organisations/accepter_invitation.html",
                    {
                        "erreur": "Vérifiez les informations saisies.",
                        "erreurs": form.errors,
                        "jeton": form.cleaned_data.get("jeton", ""),
                        "form": form,
                        "invitation": invitation,
                    },
                    status=400,
                ),
                referrer_policy="same-origin",
            )
        jeton = form.cleaned_data["jeton"]

    try:
        invitation = verifier_invitation(jeton)
    except DjangoValidationError as erreur:
        return _sans_cache(
            render(
                request,
                "organisations/accepter_invitation.html",
                {"erreur": " ".join(erreur.messages), "form": form},
                status=400,
            ),
            referrer_policy="same-origin",
        )

    if request.method == "POST":
        try:
            accepter_invitation(
                jeton=jeton,
                mot_de_passe=form.cleaned_data["mot_de_passe"],
            )
        except DjangoValidationError as erreur:
            erreurs = getattr(erreur, "message_dict", None) or {"invitation": erreur.messages}
            return _sans_cache(
                render(
                    request,
                    "organisations/accepter_invitation.html",
                    {
                        "erreur": "L’invitation n’a pas pu être acceptée.",
                        "erreurs": erreurs,
                        "jeton": jeton,
                        "invitation": invitation,
                        "form": form,
                    },
                    status=400,
                ),
                referrer_policy="same-origin",
            )
        logger.info("Invitation acceptée pour le compte %s.", invitation.email)
        return _sans_cache(
            render(
                request,
                "organisations/accepter_invitation.html",
                {"acceptee": True},
            ),
            referrer_policy="same-origin",
        )

    return _sans_cache(
        render(
            request,
            "organisations/accepter_invitation.html",
            {
                "invitation": invitation,
                "jeton": jeton,
                "form": AcceptationInvitationForm(initial={"jeton": jeton}),
            },
        ),
        referrer_policy="same-origin",
    )
