"""Résolution métier du tenant à partir d’une adhésion active."""

import uuid

from django.core.exceptions import PermissionDenied, ValidationError
from django.http import Http404

from applications.abonnements.services import abonnement_actif_pour_tenant
from applications.organisations.models import (
    AdhesionTenant,
    StatutAdhesion,
    StatutTenant,
)


def resoudre_adhesion_active(utilisateur, tenant_id: str | None) -> AdhesionTenant:
    """Résout le tenant sélectionné uniquement via une adhésion active du compte."""
    if not tenant_id:
        raise ValidationError({"X-Tenant-ID": "Sélectionnez un tenant autorisé."})
    try:
        identifiant = uuid.UUID(tenant_id)
    except (AttributeError, TypeError, ValueError) as error:
        raise ValidationError(
            {"X-Tenant-ID": "L’identifiant du tenant doit être un UUID."}
        ) from error

    adhesion = (
        AdhesionTenant.objects.select_related("tenant")
        .filter(
            tenant_id=identifiant,
            utilisateur=utilisateur,
            statut=StatutAdhesion.ACTIVE,
            tenant__statut__in=(StatutTenant.ACTIF, StatutTenant.RESTREINT),
        )
        .first()
    )
    if adhesion is None:
        raise Http404
    if abonnement_actif_pour_tenant(adhesion.tenant) is None:
        raise PermissionDenied("Aucun abonnement actif n’autorise l’accès à ce tenant.")
    return adhesion


def adhesion_active_de_session(request) -> AdhesionTenant | None:
    """Renvoie l’adhésion active du tenant choisi dans la session, si elle existe."""
    if not request.user.is_authenticated:
        return None
    tenant_id = request.session.get("eduflow_tenant_actif")
    if not tenant_id:
        return None
    try:
        return resoudre_adhesion_active(request.user, str(tenant_id))
    except (Http404, PermissionDenied, ValidationError):
        return None
