"""Services atomiques des inscriptions, transferts et statuts datés."""

import uuid

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from applications.admissions.models import Candidature, StatutCandidature
from applications.inscriptions.models import (
    HistoriqueInscription,
    Inscription,
    StatutInscription,
    TypeHistoriqueInscription,
)
from applications.organisations.models import EvenementAudit, Tenant
from applications.personnes.models import ProfilApprenant
from applications.referentiels.models import AnneeAcademique, Groupe, Institution, Programme


class ConflitIdempotenceInscription(Exception):
    """Une clé ou une candidature d’inscription a déjà produit une autre opération."""


TRANSITIONS_INSCRIPTION = {
    StatutInscription.ACTIVE: {
        StatutInscription.INTERROMPUE,
        StatutInscription.RETIREE,
        StatutInscription.TERMINEE,
    },
    StatutInscription.INTERROMPUE: {
        StatutInscription.ACTIVE,
        StatutInscription.RETIREE,
        StatutInscription.TERMINEE,
    },
    StatutInscription.RETIREE: set(),
    StatutInscription.TERMINEE: set(),
}


def _enregistrer_historique(
    *,
    inscription: Inscription,
    acteur,
    type_operation: str,
    date_effet,
    avant: dict,
    apres: dict,
) -> HistoriqueInscription:
    return HistoriqueInscription.objects.create(
        tenant=inscription.tenant,
        institution=inscription.institution,
        inscription=inscription,
        acteur=acteur,
        type_operation=type_operation,
        date_effet=date_effet,
        avant=avant,
        apres=apres,
    )


def _journaliser(*, inscription: Inscription, acteur, action: str, champs: list[str]):
    return EvenementAudit.objects.create(
        tenant=inscription.tenant,
        acteur=acteur,
        action=f"inscription.{action}",
        type_objet="inscriptions.inscription",
        id_objet=str(inscription.pk),
        details={"champs": sorted(champs)},
    )


def creer_inscription(
    *,
    tenant: Tenant,
    institution: Institution,
    acteur,
    candidature_id,
    groupe: Groupe | None,
    date_debut,
    cle_idempotence: uuid.UUID,
) -> tuple[Inscription, bool]:
    with transaction.atomic():
        existante = Inscription.objects.filter(cle_idempotence=cle_idempotence).first()
        if existante is not None:
            if (
                existante.tenant_id != tenant.pk
                or existante.candidature_id != candidature_id
                or existante.groupe_id != getattr(groupe, "pk", None)
                or existante.date_debut != date_debut
            ):
                raise ConflitIdempotenceInscription
            return existante, False

        candidature = (
            Candidature.objects.select_for_update()
            .select_related("personne", "institution", "annee_academique", "programme")
            .get(
                pk=candidature_id,
                tenant=tenant,
                institution=institution,
                statut=StatutCandidature.ADMISE,
            )
        )
        try:
            apprenant = ProfilApprenant.objects.get(
                tenant=tenant,
                institution=institution,
                personne=candidature.personne,
            )
        except ProfilApprenant.DoesNotExist as error:
            raise ValidationError(
                "La candidature admise ne possède pas encore de profil apprenant."
            ) from error

        inscription = Inscription(
            tenant=tenant,
            institution=institution,
            cree_par=acteur,
            cle_idempotence=cle_idempotence,
            candidature=candidature,
            apprenant=apprenant,
            annee_academique=candidature.annee_academique,
            programme=candidature.programme,
            groupe=groupe,
            statut=StatutInscription.ACTIVE,
            date_debut=date_debut,
        )
        inscription.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        try:
            with transaction.atomic():
                inscription.save(force_insert=True)
        except IntegrityError as error:
            existante = (
                Inscription.objects.filter(candidature_id=candidature_id)
                .first()
            )
            if existante is not None:
                if (
                    existante.groupe_id == getattr(groupe, "pk", None)
                    and existante.date_debut == date_debut
                ):
                    return existante, False
                raise ConflitIdempotenceInscription from error
            raise

        _enregistrer_historique(
            inscription=inscription,
            acteur=acteur,
            type_operation=TypeHistoriqueInscription.CREATION,
            date_effet=date_debut,
            avant={},
            apres={
                "statut": inscription.statut,
                "annee_academique": str(inscription.annee_academique_id),
                "programme": str(inscription.programme_id),
                "groupe": str(inscription.groupe_id) if inscription.groupe_id else None,
            },
        )
        _journaliser(
            inscription=inscription,
            acteur=acteur,
            action="creee",
            champs=["candidature", "annee_academique", "programme", "groupe", "date_debut"],
        )
        return inscription, True


def transitionner_inscription(
    *,
    inscription_id,
    tenant: Tenant,
    acteur,
    nouveau_statut: str,
    date_effet,
) -> Inscription:
    with transaction.atomic():
        inscription = Inscription.objects.select_for_update().get(
            pk=inscription_id,
            tenant=tenant,
        )
        if nouveau_statut == inscription.statut:
            return inscription
        if nouveau_statut not in TRANSITIONS_INSCRIPTION[inscription.statut]:
            raise ValidationError("Cette transition d’inscription n’est pas autorisée.")
        _valider_date_effet(inscription, date_effet)

        avant = {"statut": inscription.statut, "date_fin": _date(inscription.date_fin)}
        inscription.statut = nouveau_statut
        if nouveau_statut in (StatutInscription.RETIREE, StatutInscription.TERMINEE):
            inscription.date_fin = date_effet
        elif nouveau_statut == StatutInscription.ACTIVE:
            inscription.date_fin = None
        inscription.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        inscription.save(update_fields=("statut", "date_fin", "modifie_le"))
        apres = {"statut": inscription.statut, "date_fin": _date(inscription.date_fin)}
        _enregistrer_historique(
            inscription=inscription,
            acteur=acteur,
            type_operation=TypeHistoriqueInscription.STATUT,
            date_effet=date_effet,
            avant=avant,
            apres=apres,
        )
        _journaliser(
            inscription=inscription,
            acteur=acteur,
            action="statut_modifie",
            champs=["statut", "date_fin"],
        )
        return inscription


def transferer_inscription(
    *,
    inscription_id,
    tenant: Tenant,
    acteur,
    annee_academique: AnneeAcademique,
    programme: Programme,
    groupe: Groupe | None,
    date_effet,
) -> Inscription:
    with transaction.atomic():
        inscription = (
            Inscription.objects.select_for_update(of=("self",))
            .select_related("annee_academique", "programme", "groupe")
            .get(pk=inscription_id, tenant=tenant)
        )
        if inscription.statut not in (
            StatutInscription.ACTIVE,
            StatutInscription.INTERROMPUE,
        ):
            raise ValidationError(
                "Seule une inscription active ou interrompue peut être transférée."
            )
        _valider_date_effet(inscription, date_effet)

        avant = {
            "annee_academique": str(inscription.annee_academique_id),
            "programme": str(inscription.programme_id),
            "groupe": str(inscription.groupe_id) if inscription.groupe_id else None,
        }
        inscription.annee_academique = annee_academique
        inscription.programme = programme
        inscription.groupe = groupe
        inscription.full_clean(
            exclude=("cle_idempotence",),
            validate_unique=False,
            validate_constraints=False,
        )
        inscription.save(
            update_fields=("annee_academique", "programme", "groupe", "modifie_le")
        )
        apres = {
            "annee_academique": str(inscription.annee_academique_id),
            "programme": str(inscription.programme_id),
            "groupe": str(inscription.groupe_id) if inscription.groupe_id else None,
        }
        _enregistrer_historique(
            inscription=inscription,
            acteur=acteur,
            type_operation=TypeHistoriqueInscription.TRANSFERT,
            date_effet=date_effet,
            avant=avant,
            apres=apres,
        )
        _journaliser(
            inscription=inscription,
            acteur=acteur,
            action="transferee",
            champs=["annee_academique", "programme", "groupe"],
        )
        return inscription


def _valider_date_effet(inscription: Inscription, date_effet) -> None:
    if date_effet < inscription.date_debut:
        raise ValidationError("La date d’effet ne peut précéder le début de l’inscription.")
    derniere = inscription.historique.order_by("-date_effet", "-cree_le").first()
    if derniere is not None and date_effet < derniere.date_effet:
        raise ValidationError("La date d’effet ne peut précéder un événement déjà historisé.")


def _date(valeur):
    return valeur.isoformat() if valeur is not None else None
