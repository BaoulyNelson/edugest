"""Formulaires HTML classiques pour inscrire les candidats admis."""

import uuid

from django import forms
from django.utils import timezone

from applications.admissions.models import Candidature, StatutCandidature
from applications.inscriptions.models import Inscription, StatutInscription
from applications.referentiels.models import AnneeAcademique, Groupe, Programme


class InscriptionCreationForm(forms.Form):
    cle_idempotence = forms.UUIDField(widget=forms.HiddenInput)
    candidature = forms.ModelChoiceField(
        queryset=Candidature.objects.none(),
        label="Candidature admise",
    )
    groupe = forms.ModelChoiceField(
        queryset=Groupe.objects.none(),
        label="Groupe",
        required=False,
        empty_label="Affecter un groupe plus tard",
    )
    date_debut = forms.DateField(
        label="Date de début",
        widget=forms.DateInput(attrs={"type": "date"}),
    )

    def __init__(self, *args, tenant, institution, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("cle_idempotence", uuid.uuid4())
        self.fields["candidature"].queryset = (
            Candidature.objects.filter(
                tenant=tenant,
                institution=institution,
                statut=StatutCandidature.ADMISE,
                inscription__isnull=True,
            )
            .select_related("personne", "annee_academique", "programme")
            .order_by("personne__nom", "personne__prenom")
        )
        self.fields["candidature"].label_from_instance = lambda item: (
            f"{item.personne} — {item.programme.nom} · {item.annee_academique.nom}"
        )
        self.fields["groupe"].queryset = Groupe.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")

    def clean_candidature(self):
        candidature = self.cleaned_data["candidature"]
        if Inscription.objects.filter(candidature=candidature).exists():
            raise forms.ValidationError("Cette candidature possède déjà une inscription.")
        return candidature


class TransitionInscriptionForm(forms.Form):
    statut = forms.ChoiceField(label="Nouveau statut", choices=StatutInscription.choices)
    date_effet = forms.DateField(
        label="Date d’effet",
        widget=forms.DateInput(attrs={"type": "date"}),
        initial=timezone.localdate,
    )

    def __init__(self, *args, inscription, **kwargs):
        super().__init__(*args, **kwargs)
        transitions = {
            StatutInscription.ACTIVE: (
                StatutInscription.INTERROMPUE,
                StatutInscription.RETIREE,
                StatutInscription.TERMINEE,
            ),
            StatutInscription.INTERROMPUE: (
                StatutInscription.ACTIVE,
                StatutInscription.RETIREE,
                StatutInscription.TERMINEE,
            ),
            StatutInscription.RETIREE: (),
            StatutInscription.TERMINEE: (),
        }
        self.fields["statut"].choices = [
            (value, label)
            for value, label in StatutInscription.choices
            if value in transitions[inscription.statut]
        ]
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")


class TransfertInscriptionForm(forms.Form):
    annee_academique = forms.ModelChoiceField(
        queryset=AnneeAcademique.objects.none(),
        label="Année académique",
    )
    programme = forms.ModelChoiceField(
        queryset=Programme.objects.none(),
        label="Programme",
    )
    groupe = forms.ModelChoiceField(
        queryset=Groupe.objects.none(),
        label="Groupe",
        required=False,
        empty_label="Affecter un groupe plus tard",
    )
    date_effet = forms.DateField(
        label="Date d’effet",
        widget=forms.DateInput(attrs={"type": "date"}),
        initial=timezone.localdate,
    )

    def __init__(self, *args, tenant, institution, inscription, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["annee_academique"].queryset = AnneeAcademique.objects.filter(
            tenant=tenant,
            institution=institution,
        ).order_by("-debut")
        self.fields["programme"].queryset = Programme.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        ).order_by("nom")
        self.fields["groupe"].queryset = Groupe.objects.filter(
            tenant=tenant,
            institution=institution,
            actif=True,
        ).order_by("nom")
        if not self.is_bound:
            self.initial.update(
                annee_academique=inscription.annee_academique_id,
                programme=inscription.programme_id,
                groupe=inscription.groupe_id,
            )
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "saas-input")
