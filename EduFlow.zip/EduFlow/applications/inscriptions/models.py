"""Inscriptions datées et historique immuable des changements."""

import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from applications.admissions.models import Candidature
from applications.organisations.models import Tenant
from applications.personnes.models import ObjetEducatifTenant, ProfilApprenant
from applications.referentiels.models import (
    AnneeAcademique,
    Groupe,
    Institution,
    Programme,
)


class StatutInscription(models.TextChoices):
    ACTIVE = "active", "Active"
    INTERROMPUE = "interrompue", "Interrompue"
    RETIREE = "retiree", "Retirée"
    TERMINEE = "terminee", "Terminée"


class TypeHistoriqueInscription(models.TextChoices):
    CREATION = "creation", "Création"
    STATUT = "statut", "Changement de statut"
    TRANSFERT = "transfert", "Transfert pédagogique"


class Inscription(ObjetEducatifTenant):
    """Rattachement d’un apprenant admis à une année et un programme."""

    cle_idempotence = models.UUIDField(unique=True, editable=False)
    candidature = models.OneToOneField(
        Candidature,
        on_delete=models.PROTECT,
        related_name="inscription",
    )
    apprenant = models.ForeignKey(
        ProfilApprenant,
        on_delete=models.PROTECT,
        related_name="inscriptions",
    )
    annee_academique = models.ForeignKey(
        AnneeAcademique,
        on_delete=models.PROTECT,
        related_name="inscriptions",
    )
    programme = models.ForeignKey(
        Programme,
        on_delete=models.PROTECT,
        related_name="inscriptions",
    )
    groupe = models.ForeignKey(
        Groupe,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="inscriptions",
    )
    statut = models.CharField(
        max_length=12,
        choices=StatutInscription.choices,
        default=StatutInscription.ACTIVE,
    )
    date_debut = models.DateField()
    date_fin = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ("-date_debut", "id")
        constraints = [
            models.CheckConstraint(
                condition=Q(statut__in=StatutInscription.values),
                name="inscription_statut_valide",
            ),
            models.CheckConstraint(
                condition=Q(date_fin__isnull=True) | Q(date_fin__gte=models.F("date_debut")),
                name="inscription_dates_valides",
            ),
        ]
        indexes = [
            models.Index(
                fields=("tenant", "annee_academique", "statut"),
                name="inscription_tenant_annee_idx",
            ),
            models.Index(
                fields=("tenant", "apprenant"),
                name="ins_tenant_apprenant_idx",
            ),
        ]
        verbose_name = "inscription"
        verbose_name_plural = "inscriptions"

    def __str__(self) -> str:
        return f"{self.apprenant} — {self.annee_academique}"

    def clean(self):
        super().clean()
        erreurs = {}
        references = (
            ("candidature", self.candidature if self.candidature_id else None),
            ("apprenant", self.apprenant if self.apprenant_id else None),
            ("annee_academique", self.annee_academique if self.annee_academique_id else None),
            ("programme", self.programme if self.programme_id else None),
            ("groupe", self.groupe if self.groupe_id else None),
        )
        for champ, objet in references:
            if objet is not None and (
                objet.tenant_id != self.tenant_id
                or objet.institution_id != self.institution_id
            ):
                erreurs[champ] = (
                    "La référence doit appartenir au même tenant et à la même institution."
                )
        if self.candidature_id and self.apprenant_id:
            if self.candidature.personne_id != self.apprenant.personne_id:
                erreurs["apprenant"] = "L’apprenant doit correspondre à la candidature admise."
        if self.groupe_id and self.annee_academique_id:
            if self.groupe.annee_academique_id != self.annee_academique_id:
                erreurs["groupe"] = "Le groupe doit appartenir à l’année sélectionnée."
        if self.groupe_id and self.programme_id and self.groupe.programme_id:
            if self.groupe.programme_id != self.programme_id:
                erreurs["groupe"] = "Le groupe doit appartenir au programme sélectionné."
        if erreurs:
            raise ValidationError(erreurs)


class HistoriqueInscription(models.Model):
    """Événement daté sans copie des données personnelles de l’apprenant."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.PROTECT,
        related_name="historiques_inscription",
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.PROTECT,
        related_name="historiques_inscription",
    )
    inscription = models.ForeignKey(
        Inscription,
        on_delete=models.PROTECT,
        related_name="historique",
    )
    acteur = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="historiques_inscription_crees",
    )
    type_operation = models.CharField(
        max_length=12,
        choices=TypeHistoriqueInscription.choices,
    )
    date_effet = models.DateField()
    avant = models.JSONField(default=dict, blank=True)
    apres = models.JSONField(default=dict, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("date_effet", "cree_le")
        indexes = [
            models.Index(
                fields=("tenant", "inscription", "date_effet"),
                name="hist_ins_tenant_date_idx",
            ),
        ]
        verbose_name = "historique d’inscription"
        verbose_name_plural = "historiques d’inscription"

    def __str__(self) -> str:
        return f"{self.type_operation} — {self.inscription_id} ({self.date_effet})"

    def clean(self):
        super().clean()
        if (
            self.inscription_id
            and (
                self.inscription.tenant_id != self.tenant_id
                or self.inscription.institution_id != self.institution_id
            )
        ):
            raise ValidationError(
                {
                    "inscription": (
                        "L’inscription doit appartenir au même tenant et à la même institution."
                    )
                }
            )
