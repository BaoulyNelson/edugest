from django.contrib import admin

from applications.inscriptions.models import HistoriqueInscription, Inscription

admin.site.register((Inscription, HistoriqueInscription))
