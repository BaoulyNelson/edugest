"""Routes HTML du module des inscriptions."""

from django.urls import path

from applications.inscriptions.views import detail_inscription, gestion_inscriptions

app_name = "inscriptions_web"

urlpatterns = [
    path("", gestion_inscriptions, name="gestion"),
    path("<uuid:inscription_id>/", detail_inscription, name="detail"),
]
