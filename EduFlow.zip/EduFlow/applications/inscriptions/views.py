"""Vues HTML de création et de consultation des inscriptions."""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import models
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods

from applications.inscriptions.forms import (
    InscriptionCreationForm,
    TransfertInscriptionForm,
    TransitionInscriptionForm,
)
from applications.inscriptions.models import (
    HistoriqueInscription,
    Inscription,
    StatutInscription,
)
from applications.inscriptions.services import (
    ConflitIdempotenceInscription,
    creer_inscription,
    transferer_inscription,
    transitionner_inscription,
)
from applications.referentiels.models import AnneeAcademique
from applications.referentiels.views import _exiger_gestion
from applications.tableau_de_bord.views import _page_privee


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def gestion_inscriptions(request):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    institution = workspace.tenant.institution
    formulaire = InscriptionCreationForm(
        request.POST or None,
        tenant=workspace.tenant,
        institution=institution,
    )
    if request.method == "POST" and formulaire.is_valid():
        try:
            inscription, cree = creer_inscription(
                tenant=workspace.tenant,
                institution=institution,
                acteur=request.user,
                candidature_id=formulaire.cleaned_data["candidature"].pk,
                groupe=formulaire.cleaned_data["groupe"],
                date_debut=formulaire.cleaned_data["date_debut"],
                cle_idempotence=formulaire.cleaned_data["cle_idempotence"],
            )
        except ConflitIdempotenceInscription:
            formulaire.add_error(
                None,
                _("Cette opération entre en conflit avec une inscription existante."),
            )
        except ValidationError as error:
            _ajouter_erreur(formulaire, error)
        else:
            if cree:
                messages.success(
                    request,
                    _("L’inscription de %(apprenant)s a été créée.") % {
                        "apprenant": inscription.apprenant,
                    },
                )
            return redirect("inscriptions_web:gestion")

    inscriptions = (
        Inscription.objects.filter(
            tenant=workspace.tenant,
            institution=institution,
        )
        .select_related(
            "apprenant__personne",
            "annee_academique",
            "programme",
            "groupe",
        )
        .order_by("-date_debut", "apprenant__personne__nom")
    )
    terme = request.GET.get("q", "").strip()
    if terme:
        inscriptions = inscriptions.filter(
            models.Q(apprenant__personne__nom__icontains=terme)
            | models.Q(apprenant__personne__prenom__icontains=terme)
        )
    annee = request.GET.get("annee_academique", "").strip()
    if annee:
        inscriptions = inscriptions.filter(annee_academique_id=annee)
    statut = request.GET.get("statut", "").strip()
    if statut in StatutInscription.values:
        inscriptions = inscriptions.filter(statut=statut)
    annees = AnneeAcademique.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    ).order_by("-debut")

    return render(
        request,
        "inscriptions/gestion.html",
        {
            **contexte,
            "formulaire": formulaire,
            "candidatures_a_inscrire": formulaire.fields["candidature"].queryset.exists(),
            "inscriptions": inscriptions[:100],
            "terme": terme,
            "annees": annees,
            "annee_selectionnee": annee,
            "statuts": StatutInscription.choices,
            "statut_selectionne": statut,
        },
    )


@login_required
@_page_privee
@require_http_methods(["GET", "POST"])
def detail_inscription(request, inscription_id):
    workspace, contexte = _exiger_gestion(request)
    if workspace is None:
        return redirect("tableau_de_bord:accueil")
    inscription = get_object_or_404(
        Inscription.objects.select_related(
            "apprenant__personne",
            "annee_academique",
            "programme",
            "groupe",
            "candidature",
        ),
        pk=inscription_id,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
    )
    transition_form = TransitionInscriptionForm(
        request.POST if request.POST.get("action") == "statut" else None,
        inscription=inscription,
    )
    transfert_form = TransfertInscriptionForm(
        request.POST if request.POST.get("action") == "transfert" else None,
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        inscription=inscription,
    )

    if request.method == "POST":
        if request.POST.get("action") == "statut" and transition_form.is_valid():
            try:
                transitionner_inscription(
                    inscription_id=inscription.pk,
                    tenant=workspace.tenant,
                    acteur=request.user,
                    nouveau_statut=transition_form.cleaned_data["statut"],
                    date_effet=transition_form.cleaned_data["date_effet"],
                )
            except ValidationError as error:
                _ajouter_erreur(transition_form, error)
            else:
                messages.success(request, _("Le statut de l’inscription a été mis à jour."))
                return redirect("inscriptions_web:detail", inscription_id=inscription.pk)
        elif request.POST.get("action") == "transfert" and transfert_form.is_valid():
            try:
                transferer_inscription(
                    inscription_id=inscription.pk,
                    tenant=workspace.tenant,
                    acteur=request.user,
                    annee_academique=transfert_form.cleaned_data["annee_academique"],
                    programme=transfert_form.cleaned_data["programme"],
                    groupe=transfert_form.cleaned_data["groupe"],
                    date_effet=transfert_form.cleaned_data["date_effet"],
                )
            except ValidationError as error:
                _ajouter_erreur(transfert_form, error)
            else:
                messages.success(request, _("Le transfert pédagogique a été enregistré."))
                return redirect("inscriptions_web:detail", inscription_id=inscription.pk)
        elif request.POST.get("action") not in {"statut", "transfert"}:
            transition_form.add_error(None, _("Cette opération n’est pas reconnue."))

    historique = HistoriqueInscription.objects.filter(
        tenant=workspace.tenant,
        institution=workspace.tenant.institution,
        inscription=inscription,
    ).select_related("acteur")
    return render(
        request,
        "inscriptions/detail.html",
        {
            **contexte,
            "inscription": inscription,
            "transition_form": transition_form,
            "transfert_form": transfert_form,
            "historique": historique[:100],
            "peut_transferer": inscription.statut
            in (StatutInscription.ACTIVE, StatutInscription.INTERROMPUE),
        },
    )


def _ajouter_erreur(formulaire, error):
    erreurs = getattr(error, "message_dict", None)
    if erreurs:
        for champ, messages_erreur in erreurs.items():
            formulaire.add_error(
                champ if champ in formulaire.fields else None,
                messages_erreur,
            )
    else:
        formulaire.add_error(None, error.messages)
