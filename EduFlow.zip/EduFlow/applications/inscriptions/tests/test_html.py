import uuid
from datetime import date

import pytest
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from applications.abonnements.tests.factories import rendre_tenant_abonne
from applications.admissions.models import Candidature, StatutCandidature
from applications.admissions.services import transitionner_candidature
from applications.inscriptions.models import HistoriqueInscription, StatutInscription
from applications.inscriptions.services import creer_inscription
from applications.organisations.services import provisionner_tenant
from applications.personnes.models import Personne
from applications.referentiels.models import AnneeAcademique, Groupe, Institution, Programme

pytestmark = pytest.mark.django_db


def _preparer_inscription():
    utilisateur = get_user_model().objects.create_user(
        f"inscription-html-{uuid.uuid4().hex}@example.org",
        "mot-de-passe-solide",
        email_verifie_le=timezone.now(),
    )
    tenant, _, _ = provisionner_tenant(
        createur=utilisateur,
        nom="École HTML",
        cle_idempotence=uuid.uuid4(),
    )
    rendre_tenant_abonne(tenant, utilisateur)
    institution = Institution.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        nom="École HTML",
        type_educatif="ecole",
        cree_par=utilisateur,
    )
    annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        nom="2026-2027",
        debut=date(2026, 9, 1),
        fin=date(2027, 6, 30),
    )
    programme = Programme.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        code="secondaire",
        nom="Secondaire",
    )
    groupe = Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        annee_academique=annee,
        programme=programme,
        code="s1",
        nom="Secondaire 1",
    )
    personne = Personne.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        prenom="Alex",
        nom="Élève",
    )
    candidature = Candidature.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        reference="CAND-HTML",
        personne=personne,
        annee_academique=annee,
        programme=programme,
    )
    transitionner_candidature(
        candidature_id=candidature.pk,
        tenant=tenant,
        acteur=utilisateur,
        nouveau_statut=StatutCandidature.SOUMISE,
    )
    transitionner_candidature(
        candidature_id=candidature.pk,
        tenant=tenant,
        acteur=utilisateur,
        nouveau_statut=StatutCandidature.EN_EXAMEN,
    )
    transitionner_candidature(
        candidature_id=candidature.pk,
        tenant=tenant,
        acteur=utilisateur,
        nouveau_statut=StatutCandidature.ADMISE,
    )
    inscription, _ = creer_inscription(
        tenant=tenant,
        institution=institution,
        acteur=utilisateur,
        candidature_id=candidature.pk,
        groupe=groupe,
        date_debut=date(2026, 9, 1),
        cle_idempotence=uuid.uuid4(),
    )
    client = Client()
    client.force_login(utilisateur)
    return {
        "client": client,
        "inscription": inscription,
        "institution": institution,
        "tenant": tenant,
        "utilisateur": utilisateur,
    }


def test_html_inscription_status_transfer_and_history():
    contexte = _preparer_inscription()
    client = contexte["client"]
    inscription = contexte["inscription"]
    url = reverse("inscriptions_web:detail", args=(inscription.pk,))

    detail = client.get(url)
    assert detail.status_code == 200
    assert "Historique du parcours" in detail.content.decode()

    transition = client.post(
        url,
        {
            "action": "statut",
            "statut": StatutInscription.INTERROMPUE,
            "date_effet": "2026-10-01",
        },
    )
    assert transition.status_code == 302
    inscription.refresh_from_db()
    assert inscription.statut == StatutInscription.INTERROMPUE

    tenant = contexte["tenant"]
    institution = contexte["institution"]
    utilisateur = contexte["utilisateur"]
    nouvelle_annee = AnneeAcademique.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        nom="2027-2028",
        debut=date(2027, 9, 1),
        fin=date(2028, 6, 30),
    )
    nouveau_programme = Programme.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        code="primaire",
        nom="Primaire",
    )
    nouveau_groupe = Groupe.objects.create(
        cle_idempotence=uuid.uuid4(),
        tenant=tenant,
        institution=institution,
        cree_par=utilisateur,
        annee_academique=nouvelle_annee,
        programme=nouveau_programme,
        code="p1",
        nom="Primaire 1",
    )
    transfert = client.post(
        url,
        {
            "action": "transfert",
            "annee_academique": str(nouvelle_annee.pk),
            "programme": str(nouveau_programme.pk),
            "groupe": str(nouveau_groupe.pk),
            "date_effet": "2026-10-15",
        },
    )
    assert transfert.status_code == 302
    inscription.refresh_from_db()
    assert inscription.annee_academique == nouvelle_annee
    assert inscription.programme == nouveau_programme
    assert inscription.groupe == nouveau_groupe
    assert HistoriqueInscription.objects.filter(inscription=inscription).count() == 3


def test_html_inscription_detail_is_tenant_scoped():
    contexte = _preparer_inscription()
    autre_contexte = _preparer_inscription()

    response = autre_contexte["client"].get(
        reverse("inscriptions_web:detail", args=(contexte["inscription"].pk,))
    )

    assert response.status_code == 404
